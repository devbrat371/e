/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.digital.testauto.scripts.movemoney;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.hsbc.digital.testauto.library.BrowserLib;
import com.hsbc.digital.testauto.library.FileUtil;
import com.hsbc.digital.testauto.library.ReflectionUtil;
import com.hsbc.digital.testauto.library.XMLUtil;
import com.hsbc.digital.testauto.models.Transaction;
import com.hsbc.digital.testauto.models.TransactionFlow;
import com.hsbc.digital.testauto.pageobject.AddBeneficiaryModel;
import com.hsbc.digital.testauto.pageobject.FlyerMenuNavigationModel;
import com.hsbc.digital.testauto.pageobject.LandingPageModel;
import com.hsbc.digital.testauto.pageobject.LoginModel;
import com.hsbc.digital.testauto.pageobject.MoveMoneyCapturePageModel;
import com.hsbc.digital.testauto.pageobject.MoveMoneyConfirmPageModel;
import com.hsbc.digital.testauto.pageobject.MoveMoneyVerifyPageModel;

/**
 * <p>
 * <b> Class is used to define all the scenario for Story 312 - M2Company </b>
 * 
 * @version 1.0.0
 * @author Shweta Jain
 * 
 *         </p>
 */

public class M2Company {

    WebDriver driver;
    BrowserLib browserLib;
    Map<String, String> envProperties;
    LoginModel loginModel;
    FlyerMenuNavigationModel navigate;
    AddBeneficiaryModel addBeneModel;
    LandingPageModel landingPageModel;
    MoveMoneyCapturePageModel mmCapturePageModel;
    MoveMoneyVerifyPageModel mmVerifyPageModel;
    MoveMoneyConfirmPageModel mmConfirmPageModel;

    private static final String CURRENCY_CODE = "currencyCode";
    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(M2Company.class);

    @Parameters({"browser", "entity"})
    @BeforeMethod(alwaysRun = true)
    public void beforeMethod(final String browser, final String entity, Method testMethod) {
        try {
            this.browserLib = new BrowserLib(browser);
            this.driver = this.browserLib.getDriver();
            this.envProperties = FileUtil.getConfigProperties(entity);
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            loginModel = (LoginModel) ReflectionUtil.getEntityPOM(entity, "LoginPage", driver);
            navigate = (FlyerMenuNavigationModel) ReflectionUtil.getEntityPOM(entity, "FlyerMenuNavigation", driver);
            addBeneModel = (AddBeneficiaryModel) ReflectionUtil.getEntityPOM(entity, "AddBeneficiary", driver);
            mmCapturePageModel = (MoveMoneyCapturePageModel) ReflectionUtil.getEntityPOM(entity, "MoveMoneyCapturePage", driver);
            mmVerifyPageModel = (MoveMoneyVerifyPageModel) ReflectionUtil.getEntityPOM(entity, "MoveMoneyVerifyPage", driver);
            mmConfirmPageModel = (MoveMoneyConfirmPageModel) ReflectionUtil.getEntityPOM(entity, "MoveMoneyConfirmPage", driver);
            landingPageModel = (LandingPageModel) ReflectionUtil.getEntityPOM(entity, "LandingPage", driver);
            String profile = XMLUtil.getProfileName(testMethod, entity);
            loginModel.login(profile, this.envProperties);
            loginModel.switchLanguage("English");
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException e) {
            M2Company.logger.error("Exception thrown at Login:login():", e);
        } catch (Exception e) {
            M2Company.logger.error("Exception thrown at Login:login():", e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "cancelM2CompanyNowTransactionCapturePage")
    public void cancelM2CompanyNowTransactionCapturePage() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2COMPANY_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addBeneModel.domesticCompanyPayees());
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get(CURRENCY_CODE)));
            mmCapturePageModel.processIsValidAccInFromDropDown(transaction.getToAccount(), envProperties.get(CURRENCY_CODE));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickCancelButton();
            mmCapturePageModel.clickCancelPopUpCancelButton();
            landingPageModel.isLeftHandMenuForAccountsOnDashboardDisplayed();
            Reporter.log("cancelM2CompanyNowTransactionCapturePage test passed.");
        } catch (Exception e) {
            M2Company.logger.error(e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "negateCancelM2CompanyNowTransactionCapturePage")
    public void negateCancelM2CompanyNowTransactionCapturePage() throws InterruptedException {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2COMPANY_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addBeneModel.domesticCompanyPayees());
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get(CURRENCY_CODE)));
            mmCapturePageModel.processIsValidAccInFromDropDown(transaction.getToAccount(), envProperties.get(CURRENCY_CODE));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickCancelButton();
            mmCapturePageModel.clickContinuePopupContinueButton();
            mmCapturePageModel.verifyDetailsAfterNegatingCancelOnCapturePage(transaction);
            Reporter.log("negateCancelM2CompanyNowTransactionCapturePage test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error(e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "cancelM2CompanyNowTransactionReviewPage")
    public void cancelM2CompanyNowTransactionReviewPage() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2COMPANY_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addBeneModel.domesticCompanyPayees());
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get(CURRENCY_CODE)));
            mmCapturePageModel.processIsValidAccInFromDropDown(transaction.getToAccount(), envProperties.get(CURRENCY_CODE));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyLCY2LCYNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickCancelButton();
            mmVerifyPageModel.clickCancelPopUpCancelButton();
            mmCapturePageModel.verifyPageTitle();
            Reporter.log("cancelM2CompanyNowTransactionReviewPage test passed");
        } catch (Exception e) {
            M2Company.logger.error(e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "editM2CompanyNowTransaction")
    public void editM2CompanyNowTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2COMPANY_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addBeneModel.domesticCompanyPayees());
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get(CURRENCY_CODE)));
            mmCapturePageModel.processIsValidAccInFromDropDown(transaction.getToAccount(), envProperties.get(CURRENCY_CODE));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyLCY2LCYNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickEditDetailsButton();
            mmCapturePageModel.selectFromAccountByAccountDetail(transaction.getFromAccount());
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyLCY2LCYNowTransactionDetailsOnVerifyPage(transaction);
            // negate cancel flow on verify Page
            mmVerifyPageModel.clickCancelButton();
            mmVerifyPageModel.clickContinuePopupContinueButton();
            mmVerifyPageModel.verifyPageTitle();
            Reporter.log("editM2CompanyNowTransaction test passed");
        } catch (Exception e) {
            M2Company.logger.error(e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2CompanyNowTransaction")
    public void m2CompanyNowTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2COMPANY_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addBeneModel.domesticCompanyPayees());
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get(CURRENCY_CODE)));
            mmCapturePageModel.processIsValidAccInFromDropDown(transaction.getToAccount(), envProperties.get(CURRENCY_CODE));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            mmCapturePageModel.enterTransferAmount(transaction);
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyLCY2LCYNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyLCY2LCYNowTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.referenceNumber(transaction);
            mmConfirmPageModel.clickBacktoMyAccountsButton();
            landingPageModel.selectAccountOnDashboardByNameAndNumber(transaction.getFromAccount());
            landingPageModel.isImmediateTransactionPosted(transaction);
            Reporter.log("m2CompanyNowTransaction test passed");

        } catch (Exception e) {
            M2Company.logger.error(e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2CompanyLaterTransaction")
    public void m2CompanyLaterTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2COMPANY_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addBeneModel.domesticCompanyPayees());
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get(CURRENCY_CODE)));
            mmCapturePageModel.processIsValidAccInFromDropDown(transaction.getToAccount(), envProperties.get(CURRENCY_CODE));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickLaterTab();
            transaction.setLaterDate(mmCapturePageModel.enterLaterDate(envProperties));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyLCY2LCYLaterTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyLCY2LCYLaterTransactionDetailsOnConfirmPage(transaction);
            Reporter.log("m2CompanyLaterTransaction test passed");
        } catch (Exception e) {
            M2Company.logger.error(e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2CompanyRecurringTransaction")
    public void m2CompanyRecurringTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2COMPANY_TRANSFER);
            navigate.navigateToMypayeesPage();
            transaction.setToAccount(addBeneModel.domesticCompanyPayees());
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get(CURRENCY_CODE)));
            mmCapturePageModel.processIsValidAccInFromDropDown(transaction.getToAccount(), envProperties.get(CURRENCY_CODE));
            mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickRecurringTab();
            transaction.setFirstDateOfTransaction(mmCapturePageModel.enterDateOfFirstTransfer(envProperties));
            transaction.setFrequencyValue(mmCapturePageModel.selectFrequency());
            transaction.setNumberOfPayment(mmCapturePageModel.enterNumberOfPayment(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyLCY2LCYRecurringTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyLCY2LCYRecurringTransactionDetailsOnConfirmPage(transaction);
            Reporter.log("m2CompanyRecurringTransaction test passed");
        } catch (Exception e) {
            M2Company.logger.error(e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2CompanyNowInlineTransaction")
    public void m2CompanyNowInlineTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2COMPANY_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get(CURRENCY_CODE)));
            transaction.setToAccount(mmCapturePageModel.enterNewCompanyPayeeDetails());
            mmCapturePageModel.enterTransferAmount(transaction);
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyLCY2LCYNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyLCY2LCYNowTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.referenceNumber(transaction);
            mmConfirmPageModel.clickBacktoMyAccountsButton();
            landingPageModel.selectAccountOnDashboardByNameAndNumber(transaction.getFromAccount());
            landingPageModel.isImmediateTransactionPosted(transaction);
            Reporter.log("m2CompanyNowInlineTransaction test passed");

        } catch (Exception e) {
            M2Company.logger.error(e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2CompanyLaterInlineTransaction")
    public void m2CompanyLaterInlineTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2COMPANY_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get(CURRENCY_CODE)));
            transaction.setToAccount(mmCapturePageModel.enterNewCompanyPayeeDetails());
            mmCapturePageModel.enterTransferAmount(transaction);
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickLaterTab();
            transaction.setLaterDate(mmCapturePageModel.enterLaterDate(envProperties));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyLCY2LCYLaterTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyLCY2LCYLaterTransactionDetailsOnConfirmPage(transaction);
            Reporter.log("m2CompanyLaterInlineTransaction test passed");
        } catch (Exception e) {
            M2Company.logger.error(e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2CompanyRecurringInlineTransaction")
    public void m2CompanyRecurringInlineTransaction() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2COMPANY_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get(CURRENCY_CODE)));
            transaction.setToAccount(mmCapturePageModel.enterNewCompanyPayeeDetails());
            mmCapturePageModel.enterTransferAmount(transaction);
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickRecurringTab();
            transaction.setFirstDateOfTransaction(mmCapturePageModel.enterDateOfFirstTransfer(envProperties));
            transaction.setFrequencyValue(mmCapturePageModel.selectFrequency());
            transaction.setNumberOfPayment(mmCapturePageModel.enterNumberOfPayment(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyLCY2LCYRecurringTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyLCY2LCYRecurringTransactionDetailsOnConfirmPage(transaction);
            Reporter.log("m2CompanyRecurringInlineTransaction test passed");
        } catch (Exception e) {
            M2Company.logger.error(e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "m2CompanyTransactionNotAllowedFromFCYAccount")
    public void m2CompanyTransactionNotAllowedFromFCYAccount() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2COMPANY_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get(CURRENCY_CODE)));
            mmCapturePageModel.verifyCompanyPayeeList();
            Reporter.log("m2CompanyTransactionNotAllowedFromFCYAccount test passed");
        } catch (Exception e) {
            M2Company.logger.error(e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @AfterMethod(alwaysRun = true)
    public void afterTest() {
        this.browserLib.closeAllBrowsers();
    }

    /**
     * 
     * <p>
     * <b> This method is used to take screen shot so every test script should
     * have it as it is used by Framework internally. </b>
     * </p>
     * 
     * @return driver
     */
    public WebDriver getDriver() {
        return this.driver;
    }
}
