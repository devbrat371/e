/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.scripts.communication;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.hsbc.digital.testauto.library.BrowserLib;
import com.hsbc.digital.testauto.library.FileUtil;
import com.hsbc.digital.testauto.library.ReflectionUtil;
import com.hsbc.digital.testauto.library.XMLUtil;
import com.hsbc.digital.testauto.pageobject.FlyerMenuNavigationModel;
import com.hsbc.digital.testauto.pageobject.LoginModel;
import com.hsbc.digital.testauto.pageobject.SecureMessageModel;
import com.hsbc.digital.testauto.pageobject.us.SecureMessagePage;

/**
 * <p>
 * <b> This Test Script has scripts for Story 15 Secure Messaging where user
 * will send/Receive/Read messages for communication with Bank. </b>
 * 
 * @author Shrikant Joshi
 * @version 1.0.0
 *          </p>
 */
public class SecureMessaging extends SecureMessagePage {

    WebDriver driver;
    BrowserLib browserLib;
    Map<String, String> envProperties;
    LoginModel loginModel;
    SecureMessageModel secureMessageModel;
    FlyerMenuNavigationModel navigationMenu;

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(SecureMessaging.class);

    public SecureMessaging(WebDriver driver) {
        super(driver);
        // TODO Auto-generated constructor stub
    }

    @Parameters({"browser", "entity"})
    @BeforeMethod(alwaysRun = true)
    public void beforeMethod(final String browser, final String entity, final Method testMethod) {
        try {
            this.browserLib = new BrowserLib(browser);
            this.driver = this.browserLib.getDriver();
            this.envProperties = FileUtil.getConfigProperties(entity);
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            String profile = XMLUtil.getProfileName(testMethod, entity);
            loginModel = (LoginModel) ReflectionUtil.getEntityPOM(entity, "LoginPage", driver);
            secureMessageModel = (SecureMessageModel) ReflectionUtil.getEntityPOM(entity, "SecureMessagePage", driver);
            navigationMenu = (FlyerMenuNavigationModel) ReflectionUtil.getEntityPOM(entity, "FlyerMenuNavigation", driver);
            loginModel.login(profile, this.envProperties);
            loginModel.switchLanguage("English");
        } catch (Exception e) {
            SecureMessaging.logger.error("Exception thrown:", e);
        }
    }

    @Test(testName = "Send Secure Message End to End", groups = {"functionaltest"})
    public void doMessaging() {
        try {
            secureMessageModel.navigateToMessageCenter();
            String messageTitle = secureMessageModel.readMessage();
            secureMessageModel.replyToMessage(messageTitle);
            secureMessageModel.backToMessages();
            secureMessageModel.printMessage();
            secureMessageModel.deleteCurrentMessage(false);
            secureMessageModel.deleteCurrentMessage(true);
            secureMessageModel.isMessageExist(messageTitle);
            secureMessageModel.sendMessage();
            secureMessageModel.backToMessages();
        } catch (Exception e) {
            SecureMessaging.logger.error("Exception at SecureMessaging Script:doMessaging()", e);
            Assert.fail("Exception at doMessaging:", e);
        }
    }

    @Test(groups = {"functionaltest"})
    public void cancelReplyMessage() {
        try {
            secureMessageModel.navigateToMessageCenter();
            String messageTitle = secureMessageModel.readMessage();
            secureMessageModel.typeReplyMessage();
            secureMessageModel.cancelReplyMessage(false);
            secureMessageModel.verifyMessage(messageTitle, false);
            secureMessageModel.cancelReplyMessage(true);
            secureMessageModel.verifyMessage(messageTitle, true);
        } catch (Exception e) {
            SecureMessaging.logger.error("Exception at SecureMessaging Script:cancelReplyMessage()", e);
            Assert.fail("Exception at cancelReplyMessage:", e);
        }
    }


    @Test(groups = {"functionaltest"}, enabled = false)
    public void cancelSendMessage() {
        try {
            secureMessageModel.navigateToMessageCenter();
            secureMessageModel.typeNewMessage();
            secureMessageModel.cancelSendMessage(false);
            secureMessageModel.checkSendMessageCancel(false);
            secureMessageModel.cancelSendMessage(true);
            secureMessageModel.checkSendMessageCancel(true);
        } catch (Exception e) {
            SecureMessaging.logger.error("Exception at SecureMessaging Script:cancelSendMessage()", e);
            Assert.fail("Exception at cancelSendMessage:", e);
        }
    }

    @Override
    @Test(testName = "Send Secure Message via header link End to End", groups = {"functionaltest"})
    public void sendMessageFromLink() {
        try {
            secureMessageModel.checkMessageNotification();
            secureMessageModel.navigateToMessageCenterSendMessage();
            secureMessageModel.sendMessageFromLink();
        } catch (Exception e) {
            SecureMessaging.logger.error("Exception at SecureMessaging Script :sendMessageFromLink()", e);
            Assert.fail("Exception at doMessaging:", e);
        }
    }

    @Test(groups = {"functionaltest"})
    public void cancelSubmitBillingDispute() {
        try {
            secureMessageModel.navigateToReportProblem(secureMessageModel.billPayProblemButton);
            secureMessageModel.enterBillingDisputeDetailsTxnSummary(SecureMessageModel.problemReasonArray[0],
                "cancelSubmitBillingDispute", null);
            secureMessageModel.cancelProblem(false);
            secureMessageModel.verifyProblem(secureMessageModel.submitBillingDisputeTitle, false);
            secureMessageModel.cancelProblem(true);
            secureMessageModel.verifyProblem(secureMessageModel.submitBillingDisputeTitle, true);
        } catch (Exception e) {
            SecureMessaging.logger.error("Exception at SecureMessaging cancelSubmitBillingDispute()", e);
            Assert.fail("Exception at cancelSubmitBillingDispute:", e);
        }
    }

    @AfterMethod(alwaysRun = true)
    public void afterMethod() {
        this.browserLib.closeAllBrowsers();
    }

    /**
     * 
     * <p>
     * <b> This method is used to take screen shot so every test script should
     * have it as it is used by Framework internally. </b>
     * </p>
     * 
     * @return driver
     */
    public WebDriver getDriver() {
        return this.driver;
    }

}
