/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.scripts.landingpage;

import java.lang.reflect.Method;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.hsbc.digital.testauto.library.BrowserLib;
import com.hsbc.digital.testauto.library.FileUtil;
import com.hsbc.digital.testauto.library.ReflectionUtil;
import com.hsbc.digital.testauto.library.XMLUtil;
import com.hsbc.digital.testauto.pageobject.FlyerMenuNavigationModel;
import com.hsbc.digital.testauto.pageobject.LoginModel;
import com.hsbc.digital.testauto.pageobject.UserInterfaceRequirementDashboardModel;


/**
 * <p>
 * <b> This Test script class has scripts for Story 38 - Dashboard � User
 * Interface Requirement, it is for Verifying the all the links in the Header,
 * Footer and all the widgets present on the dashboard page. </b>
 * </p>
 */
public class UserInterfaceRequirementDashboard {

    WebDriver driver;
    BrowserLib browserLib;
    Map<String, String> envProperties;
    LoginModel loginModel;
    UserInterfaceRequirementDashboardModel dashboardModel;
    FlyerMenuNavigationModel navigationModel;

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(UserInterfaceRequirementDashboard.class);

    @Parameters({"browser", "entity"})
    @BeforeMethod(alwaysRun = true)
    public void beforeMethod(final String browser, final String entity, final Method method) {
        try {
            this.browserLib = new BrowserLib(browser);
            this.driver = this.browserLib.getDriver();
            this.envProperties = FileUtil.getConfigProperties(entity);
            loginModel = (LoginModel) ReflectionUtil.getEntityPOM(entity, "LoginPage", driver);
            dashboardModel = (UserInterfaceRequirementDashboardModel) ReflectionUtil.getEntityPOM(entity,
                "UserInterfaceRequirementDashboard", driver);
            navigationModel = (FlyerMenuNavigationModel) ReflectionUtil.getEntityPOM(entity, "FlyerMenuNavigation", driver);
            String profile = XMLUtil.getProfileName(method, entity);
            loginModel.login(profile, this.envProperties);
            loginModel.switchLanguage("English");
        } catch (Exception e) {
            UserInterfaceRequirementDashboard.logger.error("Exception thrown at Login Contructor:", e);
        }
    }

    /**
     * Test Case is for verifying all the components displayed on the dashboard
     * page, i.e. Masthead, Welcome Message, Account Summary Widget, Account
     * Overview Widget and its buttons, Quick transfer Widget, Exchange Rate
     * Widget
     */
    @Test(groups = {"functionaltest"})
    public void verifyAllComponents() {
        try {
            dashboardModel.verifyMastHead();
            dashboardModel.verifyWelcomeMessage();
            dashboardModel.verifyAccountSummaryWidget();
            dashboardModel.verifyAccountOverviewWidget();
            dashboardModel.verifyQuickTransferWidget();
            dashboardModel.verifyExchangeRateCalculatorWidget();
        } catch (Exception e) {
            UserInterfaceRequirementDashboard.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * Test Case is for verifying all the components Footer Links on the
     * Dashboard Page
     */
    @Test(groups = {"functionaltest"})
    public void verifyAllFooterLinksOnDashboard() {
        try {
            dashboardModel.aboveFooterLink();
            dashboardModel.footerLink();
            dashboardModel.belowFooterLink();
        } catch (Exception e) {
            UserInterfaceRequirementDashboard.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * Test Case is for verifying all the components Header Links on the
     * Dashboard Page for Mass Customer
     */
    @Test(groups = {"functionaltest"})
    public void verifyAllHeaderLinksOnDashboardForMass() {
        try {
            dashboardModel.verifyHSBCLogoForMass();
            dashboardModel.verifyAllHeaderLinksForMass(navigationModel);
        } catch (Exception e) {
            UserInterfaceRequirementDashboard.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * Test Case is for verifying all the components Header Links on the
     * Dashboard Page for Advance Customer
     */
    @Test(groups = {"functionaltest"})
    public void verifyAllHeaderLinksOnDashboardForAdvance() {
        try {
            dashboardModel.verifyHSBCLogoForAdvance();
            dashboardModel.verifyAllHeaderLinksForAdvance(navigationModel);
        } catch (Exception e) {
            UserInterfaceRequirementDashboard.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * Test Case is for verifying all the components Header Links on the
     * Dashboard Page for Premium Customer
     */
    @Test(groups = {"functionaltest"})
    public void verifyAllHeaderLinksOnDashboardForPremier() {
        try {
            dashboardModel.verifyHSBCLogoForPremier();
            dashboardModel.verifyAllHeaderLinksForPremier(navigationModel);
        } catch (Exception e) {
            UserInterfaceRequirementDashboard.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    @AfterMethod(alwaysRun = true)
    public void afterMethod() {
        this.browserLib.closeAllBrowsers();
    }

    /**
     * 
     * <p>
     * <b> This method is used to take screen shot so every test script should
     * have it as it is used by Framework internally. </b>
     * </p>
     * 
     * @return driver
     */
    public WebDriver getDriver() {
        return this.driver;
    }


}
