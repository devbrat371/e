/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.scripts.communication;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.hsbc.digital.testauto.library.BrowserLib;
import com.hsbc.digital.testauto.library.FileUtil;
import com.hsbc.digital.testauto.library.ReflectionUtil;
import com.hsbc.digital.testauto.library.XMLUtil;
import com.hsbc.digital.testauto.pageobject.AccountDetails;
import com.hsbc.digital.testauto.pageobject.FlyerMenuNavigationModel;
import com.hsbc.digital.testauto.pageobject.LoginModel;
import com.hsbc.digital.testauto.pageobject.UpdatePersonelInformationModel;

/**
 * <p>
 * <b> This class will hold testing scripts for story 13&14 Update Contact
 * Details </b>
 * </p>
 * 
 * @version 1.0.0
 * @author Midde Rajesh Kumar
 * 
 */

public class UpdatePersonelInformation {
	WebDriver driver;
	BrowserLib browserLib;
	Map<String, String> envProperties;
	LoginModel loginModel;
	UpdatePersonelInformationModel updatePersonelInformationModel;
	FlyerMenuNavigationModel flyerMenuNavigation;
	Map<String, String> profileProperties;
	public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger
			.getLogger(UpdatePersonelInformation.class);

	@Parameters({ "browser", "entity" })
	@BeforeMethod(alwaysRun = true)
	public void beforeMethod(final String browser, final String entity,
			final Method method) {
		try {
			browserLib = new BrowserLib(browser);
			driver = browserLib.getDriver();
			envProperties = FileUtil.getConfigProperties(entity);
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			loginModel = (LoginModel) ReflectionUtil.getEntityPOM(entity,
					"LoginPage", driver);
			updatePersonelInformationModel = (UpdatePersonelInformationModel) ReflectionUtil
					.getEntityPOM(entity, "UpdatePersonelInformation", driver);
			flyerMenuNavigation = (FlyerMenuNavigationModel) ReflectionUtil
					.getEntityPOM(entity, "FlyerMenuNavigation", driver);
			String profile = XMLUtil.getProfileName(method, entity);
			profileProperties = FileUtil.getTestDataProperties(
					envProperties.get("countryCode"), profile);
			loginModel.login(profile, envProperties);
			loginModel.switchLanguage("English");
		} catch (Exception e) {
			UpdatePersonelInformation.logger.error(
					"Exception thrown at Login Contructor:", e);
		}
	}

	/**
	 * 
	 * This method is to Update the Contact Details
	 * 
	 */
	@Test(groups = { "functionaltest" })
	public void updatePersonelDetails() {
		try {

			flyerMenuNavigation.navigateToUpdateContactDetails();
			AccountDetails objAccountDetails = updatePersonelInformationModel
					.inputContactDetails();
			updatePersonelInformationModel.clickOnUpdateDetails();
			updatePersonelInformationModel.verifyReviewPage(profileProperties,
					objAccountDetails);
			updatePersonelInformationModel.clickOnConfirm();
			updatePersonelInformationModel.clickOnBackToMyAccounts();
			updatePersonelInformationModel.verifyDashBoardPageIsDisplayed();
			flyerMenuNavigation.navigateToUpdateContactDetails();
			updatePersonelInformationModel
					.verifyUpdatedDetailsOnCapturePage(objAccountDetails);
		} catch (Exception e) {
			UpdatePersonelInformation.logger.error("Exception:", e);
			Assert.fail("Exception thrown Test case failed :" + e.getMessage(),
					e);
		}
	}

	/**
	 * 
	 * This method is to verify the error message for with out entering the
	 * county details. NA for CBH
	 * 
	 */
	@Test(groups = { "functionaltest" })
	public void verifyWithoutCountryDetails() {
		try {
			flyerMenuNavigation.navigateToUpdateContactDetails();
			updatePersonelInformationModel
					.inputContactDetailsWithCountryInput();
			updatePersonelInformationModel.clickOnUpdateDetails();
			updatePersonelInformationModel.verificaitonForWithoutCountryInput();
		} catch (Exception e) {
			UpdatePersonelInformation.logger.error("Exception:", e);
			Assert.fail("Exception thrown Test case failed :" + e.getMessage(),
					e);
		}
	}

	/**
	 * 
	 * This method is to check the Cancel flow on UpdateContactDetails Page
	 * 
	 */
	@Test(groups = { "functionaltest" })
	public void verifyCancelFlowFromCapture() {
		try {
			flyerMenuNavigation.navigateToUpdateContactDetails();
			updatePersonelInformationModel.inputContactDetails();
			updatePersonelInformationModel.CancelFlowFromCapturePage();
			updatePersonelInformationModel.verifyDashBoardPageIsDisplayed();
		} catch (Exception e) {
			UpdatePersonelInformation.logger.error("Exception:", e);
			Assert.fail("Exception thrown Test case failed :" + e.getMessage(),
					e);
		}
	}

	/**
	 * 
	 * This method is to Check Edit functionality
	 * 
	 */
	@Test(groups = { "functionaltest" })
	public void verifyEditDetailsFlow() {
		try {
			flyerMenuNavigation.navigateToUpdateContactDetails();
			updatePersonelInformationModel.inputContactDetails();
			updatePersonelInformationModel.clickOnUpdateDetails();
			updatePersonelInformationModel.clickOnEditDetailsButton();
			updatePersonelInformationModel.verifyEditDetailsFunctionality();
		} catch (Exception e) {
			UpdatePersonelInformation.logger.error("Exception:", e);
			Assert.fail("Exception thrown Test case failed :" + e.getMessage(),
					e);
		}
	}

	/**
	 * 
	 * This method is to check the cancel flow on EditDetails Page
	 * 
	 */
	@Test(groups = { "functionaltest" })
	public void cancelFlowFromVerifyPage() {
		try {
			flyerMenuNavigation.navigateToUpdateContactDetails();
			updatePersonelInformationModel.inputContactDetails();
			updatePersonelInformationModel.clickOnUpdateDetails();
			updatePersonelInformationModel.CancelFlowFromReviewPage();
			updatePersonelInformationModel.verifyDashBoardPageIsDisplayed();
		} catch (Exception e) {
			UpdatePersonelInformation.logger.error("Exception:", e);
			Assert.fail("Exception thrown Test case failed :" + e.getMessage(),
					e);
		}
	}

	/**
	 * 
	 * This method is to check the cancel flow on Popup Page NA for CBH
	 */
	@Test(groups = { "functionaltest" })
	public void popUpCancelFlow() {
		try {
			flyerMenuNavigation.navigateToUpdateContactDetails();
			updatePersonelInformationModel.inputContactDetails();
			updatePersonelInformationModel.clickOnUpdateDetails();
			updatePersonelInformationModel.clickOnCancel();
			updatePersonelInformationModel.verifyPopUpPage();
			updatePersonelInformationModel.clickOnCancel();
			updatePersonelInformationModel.verifyDashBoardPageIsDisplayed();
		} catch (Exception e) {
			UpdatePersonelInformation.logger.error("Exception:", e);
			Assert.fail("Exception thrown Test case failed :" + e.getMessage(),
					e);
		}
	}

	/**
	 * 
	 * This method is to check the cancel flow on Popup Page
	 * 
	 */
	@Test(groups = { "functionaltest" })
	public void popUpDontCancelFlow() {
		try {
			flyerMenuNavigation.navigateToUpdateContactDetails();
			updatePersonelInformationModel.inputContactDetails();
			updatePersonelInformationModel.clickOnUpdateDetails();
			updatePersonelInformationModel.clickOnCancel();
			updatePersonelInformationModel.clickAndVerifyPopUpDontCancel();
		} catch (Exception e) {
			UpdatePersonelInformation.logger.error("Exception:", e);
			Assert.fail("Exception thrown Test case failed :" + e.getMessage(),
					e);
		}
	}

	@AfterMethod(alwaysRun = true)
	public void afterMethod() {
		browserLib.closeAllBrowsers();
	}

	/**
	 * 
	 * <p>
	 * <b> This method is used to take screen shot so every test script should
	 * have it as it is used by Framework internally. </b>
	 * </p>
	 * 
	 * @return driver
	 */
	public WebDriver getDriver() {
		return driver;
	}
}
