/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.scripts.landingpage;

import java.lang.reflect.Method;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.hsbc.digital.testauto.library.BrowserLib;
import com.hsbc.digital.testauto.library.FileUtil;
import com.hsbc.digital.testauto.library.ReflectionUtil;
import com.hsbc.digital.testauto.library.XMLUtil;
import com.hsbc.digital.testauto.models.Transaction;
import com.hsbc.digital.testauto.pageobject.LandingPageModel;
import com.hsbc.digital.testauto.pageobject.LoginModel;
import com.hsbc.digital.testauto.pageobject.MoveMoneyCapturePageModel;

/**
 * <p>
 * <b> This class will hold testing scripts for story 2&4
 * TransactionHistoryAndSmartSearch </b>
 * </p>
 * 
 * @version 1.0.0
 * @author Vaibhav Sharma
 * 
 */
public class TransactionHistoryAndSmartSearch {

    WebDriver driver;
    BrowserLib browserLib;
    Map<String, String> envProperties;
    LoginModel loginModel;
    LandingPageModel landingPageModel;
    MoveMoneyCapturePageModel moveMoneyCapturePageModel;

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(TransactionHistoryAndSmartSearch.class);

    @Parameters({"browser", "entity"})
    @BeforeMethod(alwaysRun = true)
    public void beforeMethod(final String browser, final String entity, final Method method) {
        try {
            browserLib = new BrowserLib(browser);
            driver = browserLib.getDriver();
            envProperties = FileUtil.getConfigProperties(entity);
            String profile = XMLUtil.getProfileName(method, entity);
            loginModel = (LoginModel) ReflectionUtil.getEntityPOM(entity, "LoginPage", driver);
            landingPageModel = (LandingPageModel) ReflectionUtil.getEntityPOM(entity, "LandingPage", driver);
            moveMoneyCapturePageModel = (MoveMoneyCapturePageModel) ReflectionUtil.getEntityPOM(entity, "MoveMoneyCapturePage",
                driver);
            loginModel.login(profile, envProperties);
            loginModel.switchLanguage("English");
        } catch (Exception e) {
            TransactionHistoryAndSmartSearch.logger.error("Exception thrown at Login Contructor:", e);
        }
    }

    @Test(testName = "Verify default order of transactions functionality", groups = {"functionaltest"})
    public void validateTransactionsDefaultOrder() {
        try {
            landingPageModel.verifyTransactionHistorySection(LandingPageModel.VIEW_TRANSACTION_TEXT);
            landingPageModel.defaultOrderCheck();
        } catch (Exception e) {
            BillPaymentHistory.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(testName = "View historic transaction by date filter", groups = {"functionaltest"})
    public void viewTransactionHistoryWithDateRange() {
        try {
            landingPageModel.verifyTransactionHistorySection(LandingPageModel.VIEW_TRANSACTION_TEXT);
            String fromDate = landingPageModel.getFromDate();
            String toDate = landingPageModel.getToDate();
            landingPageModel.clickSearchButton();
            landingPageModel.enterFromDate(fromDate);
            landingPageModel.enterToDate(toDate);
            landingPageModel.clickViewResultButton();
            landingPageModel.verifyTransactionHistoryInDateRage(fromDate, toDate);
        } catch (Exception e) {
            TransactionHistoryAndSmartSearch.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage());
        }
    }

    @Test(testName = "Sort the transaction by date", groups = {"functionaltest"})
    public void verifySortingByDate() {
        try {
            landingPageModel.verifyTransactionHistorySection(LandingPageModel.VIEW_TRANSACTION_TEXT);
            landingPageModel.verifyDateSorting();
        } catch (Exception e) {
            TransactionHistoryAndSmartSearch.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(testName = "View historic transaction by account Name", groups = {"functionaltest"})
    public void viewTransactionHistoryByAccountName() {
        try {
            landingPageModel.verifyTransactionHistorySection(LandingPageModel.VIEW_TRANSACTION_TEXT);
            landingPageModel.clickSearchButton();
            String descriptionName = landingPageModel.getDescriptionName();
            landingPageModel.enterSearchName(descriptionName);
            landingPageModel.clickViewResultButton();
            landingPageModel.compareResultByName(descriptionName);
        } catch (Exception e) {
            TransactionHistoryAndSmartSearch.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage());
        }
    }

    @Test(testName = "View historic transaction by amount", groups = {"functionaltest"})
    public void viewTransactionHistoryByAmount() {
        try {
            landingPageModel.verifyTransactionHistorySection(LandingPageModel.VIEW_TRANSACTION_TEXT);
            landingPageModel.clickSearchButton();
            int fromAmount = landingPageModel.enterFromAmount();
            int toAmount = landingPageModel.enterToAmount();
            landingPageModel.clickViewResultButton();
            landingPageModel.compareResultAmount(fromAmount, toAmount);
        } catch (Exception e) {
            TransactionHistoryAndSmartSearch.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(testName = "View more button functionality", groups = {"functionaltest"})
    public void verifyViewMoreButtonFuntionality() {
        try {
            landingPageModel.verifyTransactionHistorySection(LandingPageModel.VIEW_MORE_BUTTON_TEXT);
            landingPageModel.verifyViewMoreButtonFunctionality();
        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
            TransactionHistoryAndSmartSearch.logger.error("Exception:", e);
        }
    }

    @Test(testName = "Verify functionality of Print button ", groups = {"functionaltest"})
    public void verifyPrintButtonFunctionality() {
        try {
            landingPageModel.verifyTransactionHistorySection(LandingPageModel.VIEW_TRANSACTION_TEXT);
            landingPageModel.clickPrintButton();
            landingPageModel.verifyPrintButtonOnPopup();
        } catch (Exception e) {
            TransactionHistoryAndSmartSearch.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(testName = "Sort the transaction by amount", groups = {"functionaltest"})
    public void verifySortingByAmount() {
        try {
            landingPageModel.verifyTransactionHistorySection(LandingPageModel.VIEW_TRANSACTION_TEXT);
            landingPageModel.verifyAmountSorting();
        } catch (Exception e) {
            TransactionHistoryAndSmartSearch.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage());
        }
    }

    @Test(testName = "Sort the transaction by description", groups = {"functionaltest"})
    public void verifySortingByDescription() {
        try {
            landingPageModel.verifyTransactionHistorySection(LandingPageModel.VIEW_TRANSACTION_TEXT);
            landingPageModel.verifyDescriptionSorting();
        } catch (Exception e) {
            TransactionHistoryAndSmartSearch.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    @Test(testName = "Verify Error When no transaction are displayed", groups = {"functionaltest"})
    public void verifyErrorForNoTransaction() {
        try {
            landingPageModel.verifyTransactionHistorySection(LandingPageModel.ERROR_MESSAGE);
            landingPageModel.verifyErrorMessageForInvalidDetails();
            landingPageModel.verifyHelpIconLink();
        } catch (Exception e) {
            TransactionHistoryAndSmartSearch.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(testName = "Verify the error message for Invalid Date", groups = {"functionaltest"})
    public void verifyErrorMessageForInvalidDate() {
        try {
            landingPageModel.verifyTransactionHistorySection(LandingPageModel.VIEW_TRANSACTION_TEXT);
            landingPageModel.clickSearchButton();
            landingPageModel.enterInvalidFromDate();
            landingPageModel.enterInvalidToDate();
            landingPageModel.clickViewResultButton();
            landingPageModel.verifyErrorMessageForInvalidDate();
        } catch (Exception e) {
            TransactionHistoryAndSmartSearch.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(testName = "Verify error for invalid description name", groups = {"functionaltest"})
    public void verifyErrorInvalidAccName() {
        try {
            landingPageModel.verifyTransactionHistorySection(LandingPageModel.VIEW_TRANSACTION_TEXT);
            landingPageModel.clickSearchButton();
            landingPageModel.enterInvalidSearchName();
            landingPageModel.clickViewResultButton();
            landingPageModel.verifyErrorForInvalidAccountName();
        } catch (Exception e) {
            TransactionHistoryAndSmartSearch.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(testName = "Verify functionality of Clear Results button", groups = {"functionaltest"})
    public void verifyClearResultsButtonFunctionality() {
        try {
            landingPageModel.verifyTransactionHistorySection(LandingPageModel.VIEW_TRANSACTION_TEXT);
            landingPageModel.clickSearchButton();
            landingPageModel.enterInvalidSearchName();
            landingPageModel.verifyClearResultsButton();
        } catch (Exception e) {
            TransactionHistoryAndSmartSearch.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(testName = "Verify functionality of 'Search Again' button", groups = {"functionaltest"})
    public void verifySearchAgainButtonFunctionality() {
        try {
            landingPageModel.verifyTransactionHistorySection(LandingPageModel.VIEW_TRANSACTION_TEXT);
            String fromDate = landingPageModel.getFromDate();
            String toDate = landingPageModel.getToDate();
            landingPageModel.clickSearchButton();
            landingPageModel.enterFromDate(fromDate);
            landingPageModel.enterToDate(toDate);
            String descriptionName = landingPageModel.getDescriptionName();
            landingPageModel.enterSearchName(descriptionName);
            landingPageModel.clickViewResultButton();
            landingPageModel.validateDisclaimerText();
            landingPageModel.verifySearchAgainButton(descriptionName);
        } catch (Exception e) {
            TransactionHistoryAndSmartSearch.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(testName = "Verify functionality of Clear Search button with desclaimer", groups = {"functionaltest"})
    public void verifyClearSearchButtonFunctionality() {
        try {
            Transaction transaction = new Transaction();
            landingPageModel.verifyTransactionHistorySection(LandingPageModel.VIEW_TRANSACTION_TEXT);
            landingPageModel.verifyHelpIconLink();
            landingPageModel.clickSearchButton();
            transaction.setTransactionsList(landingPageModel.transactionsList());
            String descriptionName = landingPageModel.getDescriptionName();
            landingPageModel.enterSearchName(descriptionName);
            landingPageModel.clickViewResultButton();
            landingPageModel.verifyClearSearchButton(transaction.getTransactionsList());
        } catch (Exception e) {
            TransactionHistoryAndSmartSearch.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(testName = "Verify functionality of 'Transaction not listed' button", groups = {"functionaltest"})
    public void verifyTransactionNotListedButtonFunctionality() {
        try {
            landingPageModel.verifyTransactionHistorySection(LandingPageModel.VIEW_TRANSACTION_TEXT);
            landingPageModel.clickSearchButton();
            String descriptionName = landingPageModel.getDescriptionName();
            landingPageModel.enterSearchName(descriptionName);
            landingPageModel.clickViewResultButton();
            landingPageModel.verifyTransactionNotListedButton();
        } catch (Exception e) {
            TransactionHistoryAndSmartSearch.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(testName = "Navigate to Move Money page", groups = {"functionaltest"})
    public void navigateMoveMoneyPage() {
        try {
            landingPageModel.verifyTransactionHistorySection(LandingPageModel.VIEW_TRANSACTION_TEXT);
            landingPageModel.clickMoveMoneyButton();
            moveMoneyCapturePageModel.verifyPageTitle();
        } catch (Exception e) {
            TransactionHistoryAndSmartSearch.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(testName = "verify visibility of ViewMore button", groups = {"functionaltest"})
    public void verifyVisibilityOfViewMore() {
        try {
            landingPageModel.verifyTransactionHistorySection(LandingPageModel.VIEW_TRANSACTION_TEXT);
            landingPageModel.verifyVisibilityOfViewMoreButton();
        } catch (Exception e) {
            TransactionHistoryAndSmartSearch.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage());
        }
    }

    @AfterMethod(alwaysRun = true)
    public void afterMethod() {
        this.browserLib.closeAllBrowsers();
    }

    /**
     * 
     * <p>
     * <b> This method is used to take screen shot so every test script should
     * have it as it is used by Framework internally. </b>
     * </p>
     * 
     * @return driver
     */
    public WebDriver getDriver() {
        return this.driver;
    }
}
