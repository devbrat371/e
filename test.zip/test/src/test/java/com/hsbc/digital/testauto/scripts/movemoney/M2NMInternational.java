/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.scripts.movemoney;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.hsbc.digital.testauto.library.BrowserLib;
import com.hsbc.digital.testauto.library.FileUtil;
import com.hsbc.digital.testauto.library.ReflectionUtil;
import com.hsbc.digital.testauto.library.XMLUtil;
import com.hsbc.digital.testauto.models.Transaction;
import com.hsbc.digital.testauto.models.TransactionFlow;
import com.hsbc.digital.testauto.pageobject.AddBeneficiaryModel;
import com.hsbc.digital.testauto.pageobject.FlyerMenuNavigationModel;
import com.hsbc.digital.testauto.pageobject.LandingPageModel;
import com.hsbc.digital.testauto.pageobject.LoginModel;
import com.hsbc.digital.testauto.pageobject.MoveMoneyCapturePageModel;
import com.hsbc.digital.testauto.pageobject.MoveMoneyConfirmPageModel;
import com.hsbc.digital.testauto.pageobject.MoveMoneyVerifyPageModel;

/**
 * <p>
 * <b> Class is used to define all the scenario for Story 39 - M2NM Domestic
 * </b>
 * 
 * @version 1.0.0
 * @author Umaji Chavan and Ajay Jaiswal
 * 
 *         </p>
 */

public class M2NMInternational {

    WebDriver driver;
    BrowserLib browserLib;
    Map<String, String> envProperties;
    Map<String, String> profileProperties;
    String profile;
    LoginModel loginModel;
    FlyerMenuNavigationModel navigate;
    AddBeneficiaryModel addPayeeModel;
    LandingPageModel landingPageModel;


    MoveMoneyCapturePageModel mmCapturePageModel;
    MoveMoneyVerifyPageModel mmVerifyPageModel;
    MoveMoneyConfirmPageModel mmConfirmPageModel;

    MoveMoneyCapturePageModel mmCapturePage;
    MoveMoneyVerifyPageModel mmVerifyPage;
    MoveMoneyConfirmPageModel mmConfirmPage;

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(M2NMInternational.class);

    @Parameters({"browser", "entity"})
    @BeforeMethod(alwaysRun = true)
    public void beforeMethod(final String browser, final String entity, final Method testMethod) throws Exception {
        try {
            this.browserLib = new BrowserLib(browser);
            this.driver = this.browserLib.getDriver();
            this.envProperties = FileUtil.getConfigProperties(entity);
            this.profile = XMLUtil.getProfileName(testMethod, entity);
            this.profileProperties = FileUtil.getTestDataProperties(this.envProperties.get("countryCode"), this.profile);
            this.driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            this.loginModel = (LoginModel) ReflectionUtil.getEntityPOM(entity, "LoginPage", this.driver);
            this.navigate = (FlyerMenuNavigationModel) ReflectionUtil.getEntityPOM(entity, "FlyerMenuNavigation", this.driver);
            //  this.addPayeeModel = (AddBeneficiaryModel) ReflectionUtil.getEntityPOM(entity, "AddBeneficiary", this.driver);
            this.mmCapturePageModel = (MoveMoneyCapturePageModel) ReflectionUtil.getEntityPOM(entity, "MoveMoneyCapturePage",
                this.driver);
            this.mmCapturePage = (MoveMoneyCapturePageModel) ReflectionUtil.getEntityPOM(entity, "MoveMoneyCapturePage",
                this.driver);

            this.mmVerifyPageModel = (MoveMoneyVerifyPageModel) ReflectionUtil.getEntityPOM(entity, "MoveMoneyVerifyPage",
                this.driver);
            this.mmConfirmPageModel = (MoveMoneyConfirmPageModel) ReflectionUtil.getEntityPOM(entity, "MoveMoneyConfirmPage",
                this.driver);

            this.mmVerifyPage = (MoveMoneyVerifyPageModel) ReflectionUtil.getEntityPOM(entity, "MoveMoneyVerifyPage", this.driver);
            this.mmConfirmPage = (MoveMoneyConfirmPageModel) ReflectionUtil.getEntityPOM(entity, "MoveMoneyConfirmPage",
                this.driver);
            /*          this.mmCapturePage = (MoveMoneyCapturePageModel) ReflectionUtil.getEntityPOM(entity, "MoveMoneyCapturePage",
                          this.driver);*/

            this.landingPageModel = (LandingPageModel) ReflectionUtil.getEntityPOM(entity, "LandingPage", this.driver);
            this.profile = XMLUtil.getProfileName(testMethod, entity);
            this.loginModel.login(this.profile, this.envProperties);
            this.loginModel.switchLanguage("English");
        } catch (Exception e) {
            M2NMInternational.logger.error("Exception thrown at Login Contructor:", e);
        }
    }

    @Test(groups = {"functionaltest", "regressiontest", "smoketest"}, enabled = true, testName = "negateCancelLCY2LCYNowInlineTransactionCapturePage")
    public void m2nmLCY2LCYNowTransactionPrint() {
        try {

            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            this.navigate.navigateToNewTransactionPage();

            transaction.setFromAccount(this.mmCapturePage.selectDomesticFromLCYAccount(this.envProperties.get("currencyCode")));
            this.mmCapturePage.inlinedatafilling();
            transaction.setToAccount(this.mmCapturePage.enterMyPayeeDetails(this.profile, this.envProperties));
            this.mmCapturePage.enterTransferAmount();

            this.mmCapturePageModel.clickContinueButton();


            this.mmVerifyPage.ContinueWithTDS(this.profile, this.profileProperties, 5);
            this.mmVerifyPageModel.clickConfirmButton();

            this.mmConfirmPage.clickConfirmButton();

            this.mmConfirmPageModel.verifyFCY2FCYNowTransactionDetailsOnConfirmPage(transaction);
            Reporter.log("negateCancelLCY2LCYNowInlineTransactionCapturePage test passed");
        } catch (Exception e) {
            M2NMDomestic.logger.error(e);
            e.printStackTrace();
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /*
        @Test(groups = {"functionaltest"}, testName = "cancelLCY2LCYNowTransactionCapturePage")
        public void cancelLCY2LCYNowTransactionCapturePage() {
            try {
                Transaction transaction = new Transaction();
                transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
                this.navigate.navigateToMypayeesPage();
                transaction.setToAccount(this.addPayeeModel.domesticHSBCPersonLCYPayees(this.envProperties.get("currencyCode")));
                this.navigate.navigateToNewTransactionPage();
                transaction
                    .setFromAccount(this.mmCapturePageModel.selectDomesticFromLCYAccount(this.envProperties.get("currencyCode")));
                this.mmCapturePageModel.processPayeeSelection(transaction.getToAccount());
                // TODO : Need to uncomment for entity where its working properly.
                // mmCapturePageModel.isPaymentLimitLinkDisplayed();
                this.mmCapturePageModel.enterTransferAmount(transaction);
                this.mmCapturePageModel.enterYourReferenceText(transaction);
                this.mmCapturePageModel.clickCancelButton();
                this.mmCapturePageModel.clickCancelPopUpCancelButton();
                this.landingPageModel.isLeftHandMenuForAccountsOnDashboardDisplayed();
                Reporter.log("cancelLCY2LCYNowTransactionCapturePage test passed.");
            } catch (Exception e) {
                M2NMInternational.logger.error("Exception:", e);
                Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
            }
        }
    */
    /**
     * 
     * <p>
     * <b> This method is used to take screen shot so every test script should
     * have it as it is used by Framework internally. </b>
     * </p>
     * 
     * @return driver
     */
    public WebDriver getDriver() {
        return this.driver;
    }
}
