/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.scripts.movemoney;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.hsbc.digital.testauto.library.BrowserLib;
import com.hsbc.digital.testauto.library.FileUtil;
import com.hsbc.digital.testauto.library.ReflectionUtil;
import com.hsbc.digital.testauto.library.XMLUtil;
import com.hsbc.digital.testauto.models.Transaction;
import com.hsbc.digital.testauto.models.TransactionFlow;
import com.hsbc.digital.testauto.pageobject.AddBeneficiaryModel;
import com.hsbc.digital.testauto.pageobject.FlyerMenuNavigationModel;
import com.hsbc.digital.testauto.pageobject.LandingPageModel;
import com.hsbc.digital.testauto.pageobject.LoginModel;
import com.hsbc.digital.testauto.pageobject.MoveMoneyCapturePageModel;
import com.hsbc.digital.testauto.pageobject.MoveMoneyConfirmPageModel;
import com.hsbc.digital.testauto.pageobject.MoveMoneyVerifyPageModel;

/**
 * <p>
 * <b> TODO : Insert description of the class's responsibility/role. </b>
 * </p>
 */
public class IETransfer {
    WebDriver driver;
    BrowserLib browserLib;
    Map<String, String> envProperties;
    String profile;
    LoginModel loginModel;
    FlyerMenuNavigationModel navigate;
    AddBeneficiaryModel addPayeeModel;
    LandingPageModel landingPageModel;
    MoveMoneyCapturePageModel mmCapturePageModel;
    MoveMoneyVerifyPageModel mmVerifyPageModel;
    MoveMoneyConfirmPageModel mmConfirmPageModel;

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(IETransfer.class);

    @Parameters({"browser", "entity"})
    @BeforeMethod(alwaysRun = true)
    public void beforeMethod(final String browser, final String entity, final Method testMethod) throws Exception {
        try {
            this.browserLib = new BrowserLib(browser);
            this.driver = this.browserLib.getDriver();
            this.envProperties = FileUtil.getConfigProperties(entity);
            this.driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            this.loginModel = (LoginModel) ReflectionUtil.getEntityPOM(entity, "LoginPage", this.driver);
            this.navigate = (FlyerMenuNavigationModel) ReflectionUtil.getEntityPOM(entity, "FlyerMenuNavigation", this.driver);
            this.addPayeeModel = (AddBeneficiaryModel) ReflectionUtil.getEntityPOM(entity, "AddBeneficiary", this.driver);
            this.mmCapturePageModel = (MoveMoneyCapturePageModel) ReflectionUtil.getEntityPOM(entity, "MoveMoneyCapturePage",
                this.driver);
            this.mmVerifyPageModel = (MoveMoneyVerifyPageModel) ReflectionUtil.getEntityPOM(entity, "MoveMoneyVerifyPage",
                this.driver);
            this.mmConfirmPageModel = (MoveMoneyConfirmPageModel) ReflectionUtil.getEntityPOM(entity, "MoveMoneyConfirmPage",
                this.driver);
            this.landingPageModel = (LandingPageModel) ReflectionUtil.getEntityPOM(entity, "LandingPage", this.driver);
            this.profile = XMLUtil.getProfileName(testMethod, entity);
            this.loginModel.login(this.profile, this.envProperties);
            this.loginModel.switchLanguage("English");
        } catch (Exception e) {
            M2NMDomestic.logger.error("Exception thrown at Login Contructor:", e);
        }
    }


    @Test(groups = {"functionaltest"}, testName = "m2mFCYToFCYNow")
    public void m2mFCYToFCYNow() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2NMHSBC_TRANSFER);
            this.navigate.navigateToMypayeesPage();
            transaction.setToAccount(this.addPayeeModel.domesticHSBCPersonLCYPayees(this.envProperties.get("currencyCode")));
            this.navigate.navigateToNewTransactionPage();
            transaction
                .setFromAccount(this.mmCapturePageModel.selectDomesticFromLCYAccount(this.envProperties.get("currencyCode")));
            IETransfer.logger.info(transaction.getToAccount());
            this.mmCapturePageModel.processIsValidAccInFromDropDown(transaction.getToAccount(),
                this.envProperties.get("currencyCode"));
            transaction.setAmount(this.mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setPayeeReference(this.mmCapturePageModel.enterPayeeMassageText());
            this.mmCapturePageModel.clickContinueButton();


            Reporter.log("m2mFCYToFCYNow test passed.");
        } catch (Exception e) {
            IETransfer.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }
}
