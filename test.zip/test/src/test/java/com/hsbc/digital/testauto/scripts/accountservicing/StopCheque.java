/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.scripts.accountservicing;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.hsbc.digital.testauto.library.BrowserLib;
import com.hsbc.digital.testauto.library.FileUtil;
import com.hsbc.digital.testauto.library.ReflectionUtil;
import com.hsbc.digital.testauto.library.XMLUtil;
import com.hsbc.digital.testauto.models.StopChequeDetails;
import com.hsbc.digital.testauto.pageobject.FlyerMenuNavigationModel;
import com.hsbc.digital.testauto.pageobject.LandingPageModel;
import com.hsbc.digital.testauto.pageobject.LoginModel;
import com.hsbc.digital.testauto.pageobject.StopChequeCapturePageModel;
import com.hsbc.digital.testauto.pageobject.StopChequeConfirmPageModel;
import com.hsbc.digital.testauto.pageobject.StopChequeVerifyPageModel;

/**
 * <p>
 * <b> Script which will be used to test Story 26 Stop cheque. </b>
 * </p>
 */
public class StopCheque {

    WebDriver driver;
    BrowserLib browserLib;
    Map<String, String> envProperties;
    LoginModel loginModel;
    FlyerMenuNavigationModel navigate;
    StopChequeCapturePageModel stopChequeCaptureModel;
    StopChequeVerifyPageModel stopChequeVerifyModel;
    StopChequeConfirmPageModel stopChequeConfirmModel;
    LandingPageModel landingPageModel;
    Map<String, String> profileProperties;

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(StopChequeCapturePageModel.class);

    @Parameters({"browser", "entity"})
    @BeforeMethod(alwaysRun = true)
    public void beforeMethod(final String browser, final String entity, final Method method) {
        try {
            browserLib = new BrowserLib(browser);
            driver = browserLib.getDriver();
            envProperties = FileUtil.getConfigProperties(entity);
            String profile = XMLUtil.getProfileName(method, entity);
            profileProperties = FileUtil.getTestDataProperties(entity, profile);
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            loginModel = (LoginModel) ReflectionUtil.getEntityPOM(entity, "LoginPage", driver);
            navigate = (FlyerMenuNavigationModel) ReflectionUtil.getEntityPOM(entity, "FlyerMenuNavigation", driver);
            stopChequeCaptureModel = (StopChequeCapturePageModel) ReflectionUtil.getEntityPOM(entity, "StopChequeCapturePage",
                driver);
            stopChequeVerifyModel = (StopChequeVerifyPageModel) ReflectionUtil.getEntityPOM(entity, "StopChequeVerifyPage", driver);
            stopChequeConfirmModel = (StopChequeConfirmPageModel) ReflectionUtil.getEntityPOM(entity, "StopChequeConfirmPage",
                driver);
            landingPageModel = (LandingPageModel) ReflectionUtil.getEntityPOM(entity, "LandingPage", driver);
            loginModel.login(profile, this.envProperties);
        } catch (Exception e) {
            StopCheque.logger.error("Exception thrown at Login Contructor:", e);
        }
    }


    // Verify cancel button functionality on Capture page
    @Test(testName = "stopChequeCancelCapturePage", groups = {"functionaltest"})
    public void stopChequeCancelCapturePage() {
        try {
            StopChequeDetails stopCheque = new StopChequeDetails();
            stopCheque.setIssueChequeAccount(stopChequeCaptureModel.populateAccountDetails(profileProperties));
            navigate.navigateToStopAChequePage();
            stopCheque.setIssueChequeAccount(stopChequeCaptureModel.selectAccountOnStopACheckPage(stopCheque
                .getIssueChequeAccount()));
            stopCheque.setStopChequeDetails(stopChequeCaptureModel.enterStopChequeDetails(stopCheque));
            stopCheque.setReasonToStopCheque(stopChequeCaptureModel.selectReasonToStopCheque());
            stopChequeCaptureModel.verifyHelpIcon();
            stopChequeCaptureModel.clickCancelButton();
            stopChequeCaptureModel.clickCancelPopUpCancelButton();
            landingPageModel.isLeftHandMenuForAccountsOnDashboardDisplayed();
            Reporter.log("stopChequeCancelCapturePage test passed.");
        } catch (Exception e) {
            StopCheque.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    // Verify negate cancel functionality on Capture page
    @Test(testName = "stopChequeNegateCancelCapturePage", groups = {"functionaltest"})
    public void stopChequeNegateCancelCapturePage() {
        try {
            StopChequeDetails stopCheque = new StopChequeDetails();
            stopCheque.setIssueChequeAccount(stopChequeCaptureModel.populateAccountDetails(profileProperties));
            navigate.navigateToStopAChequePage();
            stopCheque.setIssueChequeAccount(stopChequeCaptureModel.selectAccountOnStopACheckPage(stopCheque
                .getIssueChequeAccount()));
            stopCheque.setStopChequeDetails(stopChequeCaptureModel.enterStopChequeDetails(stopCheque));
            stopCheque.setReasonToStopCheque(stopChequeCaptureModel.selectReasonToStopCheque());
            stopChequeCaptureModel.verifyHelpIcon();
            stopChequeCaptureModel.clickCancelButton();
            stopChequeCaptureModel.clickContinuePopUpCancelButton();
            stopChequeCaptureModel.verifyDetailsAfterNegatingCancelOnCapturePage(stopCheque);
            Reporter.log("stopChequeNegateCancelCapturePage test passed.");
        } catch (Exception e) {
            StopCheque.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    // Verify cancel button functionality on Verify page
    @Test(testName = "stopChequeCancelVerifyPage", groups = {"functionaltest"})
    public void stopChequeCancelVerifyPage() {
        try {
            StopChequeDetails stopCheque = new StopChequeDetails();
            stopCheque.setIssueChequeAccount(stopChequeCaptureModel.populateAccountDetails(profileProperties));
            navigate.navigateToStopAChequePage();
            stopCheque.setIssueChequeAccount(stopChequeCaptureModel.selectAccountOnStopACheckPage(stopCheque
                .getIssueChequeAccount()));
            stopCheque.setStopChequeDetails(stopChequeCaptureModel.enterStopChequeDetails(stopCheque));
            stopCheque.setReasonToStopCheque(stopChequeCaptureModel.selectReasonToStopCheque());
            stopChequeCaptureModel.clickContinueButton();
            stopChequeVerifyModel.validateReviewPageWithChequeNumber(stopCheque);
            stopChequeVerifyModel.clickCancelButton();
            stopChequeVerifyModel.clickCancelPopUpCancelButton();
            stopChequeCaptureModel.verifyPageTitle();
            Reporter.log("stopChequeCancelVerifyPage test passed.");
        } catch (Exception e) {
            StopCheque.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    // Verify cancel button functionality on Verify page
    @Test(testName = "stopChequeNegateCancelVerifyPage", groups = {"functionaltest"})
    public void stopChequeNegateCancelVerifyPage() {
        try {
            StopChequeDetails stopCheque = new StopChequeDetails();
            stopCheque.setIssueChequeAccount(stopChequeCaptureModel.populateAccountDetails(profileProperties));
            navigate.navigateToStopAChequePage();
            stopCheque.setIssueChequeAccount(stopChequeCaptureModel.selectAccountOnStopACheckPage(stopCheque
                .getIssueChequeAccount()));
            stopCheque.setStopChequeDetails(stopChequeCaptureModel.enterStopChequeDetails(stopCheque));
            stopCheque.setReasonToStopCheque(stopChequeCaptureModel.selectReasonToStopCheque());
            stopChequeCaptureModel.clickContinueButton();
            stopChequeVerifyModel.validateReviewPageWithChequeNumber(stopCheque);
            stopChequeVerifyModel.clickCancelButton();
            stopChequeVerifyModel.clickContinuePopUpCancelButton();
            stopChequeCaptureModel.verifyPageTitle();
            Reporter.log("stopChequeNegateCancelVerifyPage test passed.");
        } catch (Exception e) {
            StopCheque.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    // Verify Edit Details button functionality on Verify page
    @Test(testName = "editStopACheque", groups = {"functionaltest"})
    public void editStopACheque() {
        try {
            StopChequeDetails stopCheque = new StopChequeDetails();
            stopCheque.setIssueChequeAccount(stopChequeCaptureModel.populateAccountDetails(profileProperties));
            navigate.navigateToStopAChequePage();
            stopCheque.setIssueChequeAccount(stopChequeCaptureModel.selectAccountOnStopACheckPage(stopCheque
                .getIssueChequeAccount()));
            stopCheque.setStopChequeDetails(stopChequeCaptureModel.enterStopChequeDetails(stopCheque));
            stopCheque.setReasonToStopCheque(stopChequeCaptureModel.selectReasonToStopCheque());
            stopChequeCaptureModel.clickContinueButton();
            stopChequeVerifyModel.validateReviewPageWithChequeNumber(stopCheque);
            stopChequeVerifyModel.clickEditDetailsButton();
            stopCheque = new StopChequeDetails();
            stopCheque.setIssueChequeAccount(stopChequeCaptureModel.populateAccountDetails(profileProperties));
            stopCheque.setIssueChequeAccount(stopChequeCaptureModel.selectAccountOnStopACheckPage(stopCheque
                .getIssueChequeAccount()));
            stopCheque.setStopChequeDetails(stopChequeCaptureModel.enterStopChequeDetails(stopCheque));
            stopCheque.setReasonToStopCheque(stopChequeCaptureModel.selectReasonToStopCheque());
            stopChequeCaptureModel.clickContinueButton();
            stopChequeVerifyModel.verifyPageTitle();
            stopChequeVerifyModel.validateReviewPageWithChequeNumber(stopCheque);
            Reporter.log("editStopACheque test passed.");
        } catch (Exception e) {
            StopCheque.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    // This will complete the flow of Stop cheque along with verification of
    // Disclaimer/Call Support message anf check the functionality of Stop
    // another cheque button
    @Test(testName = "stopACheque", groups = {"functionaltest"})
    public void stopACheque() {
        try {
            StopChequeDetails stopCheque = new StopChequeDetails();
            stopCheque.setIssueChequeAccount(stopChequeCaptureModel.populateAccountDetails(profileProperties));
            navigate.navigateToStopAChequePage();
            stopCheque.setIssueChequeAccount(stopChequeCaptureModel.selectAccountOnStopACheckPage(stopCheque
                .getIssueChequeAccount()));
            stopCheque.setStopChequeDetails(stopChequeCaptureModel.enterStopChequeDetails(stopCheque));
            stopCheque.setReasonToStopCheque(stopChequeCaptureModel.selectReasonToStopCheque());
            stopChequeCaptureModel.verifyHelpIcon();
            stopChequeCaptureModel.clickContinueButton();
            stopChequeVerifyModel.validateReviewPageWithChequeNumber(stopCheque);
            stopChequeVerifyModel.clickConfirmButton();
            stopChequeConfirmModel.validateConfirmPageWithChequeNumber(stopCheque);
            Reporter.log("stopACheque test passed.");
        } catch (Exception e) {
            StopCheque.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    // verify functionality of Print button
    @Test(testName = "stopChequePrintCapability", groups = {"functionaltest"})
    public void stopChequePrintCapability() {
        try {
            StopChequeDetails stopCheque = new StopChequeDetails();
            stopCheque.setIssueChequeAccount(stopChequeCaptureModel.populateAccountDetails(profileProperties));
            navigate.navigateToStopAChequePage();
            stopCheque.setIssueChequeAccount(stopChequeCaptureModel.selectAccountOnStopACheckPage(stopCheque
                .getIssueChequeAccount()));
            stopCheque.setStopChequeDetails(stopChequeCaptureModel.enterStopChequeDetails(stopCheque));
            stopCheque.setReasonToStopCheque(stopChequeCaptureModel.selectReasonToStopCheque());
            stopChequeCaptureModel.clickContinueButton();
            stopChequeVerifyModel.validateReviewPageWithChequeNumber(stopCheque);
            stopChequeVerifyModel.clickConfirmButton();
            stopChequeConfirmModel.validateConfirmPageWithChequeNumber(stopCheque);
            stopChequeConfirmModel.clickPrintButton();
            stopChequeConfirmModel.verifyPrintPageTitle();
            stopChequeConfirmModel.clickCancelOnPrintDialog();
            Reporter.log("stopChequePrintCapability test passed.");
        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
            StopCheque.logger.error("Exception:", e);
        }
    }

    // Verify error message for mandatory fields on Stop Cheque capture page
    @Test(testName = "stopChequeErrorOnBlankMandatoryFields", groups = {"functionaltest"})
    public void stopChequeErrorOnBlankMandatoryFields() {
        try {
            StopChequeDetails stopCheque = new StopChequeDetails();
            stopCheque.setIssueChequeAccount(stopChequeCaptureModel.populateAccountDetails(profileProperties));
            navigate.navigateToStopAChequePage();
            stopCheque.setIssueChequeAccount(stopChequeCaptureModel.selectAccountOnStopACheckPage(stopCheque
                .getIssueChequeAccount()));
            stopChequeCaptureModel.clickContinueButton();
            stopChequeCaptureModel.validateFieldErrorsCapturePage();
            Reporter.log("stopChequeErrorOnBlankMandatoryFields test passed.");
        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
            StopCheque.logger.error("Exception:", e);
        }
    }


    // Verify error message for mandatory fields on Stop Cheque capture page
    @Test(testName = "stopChequeErrorOnBlankOtherReasonField", groups = {"functionaltest"})
    public void stopChequeErrorOnBlankOtherReasonField() {
        try {
            StopChequeDetails stopCheque = new StopChequeDetails();
            stopCheque.setIssueChequeAccount(stopChequeCaptureModel.populateAccountDetails(profileProperties));
            navigate.navigateToStopAChequePage();
            stopCheque.setIssueChequeAccount(stopChequeCaptureModel.selectAccountOnStopACheckPage(stopCheque
                .getIssueChequeAccount()));
            stopChequeCaptureModel.selectOtherReasonToStopCheque();
            stopChequeCaptureModel.clickContinueButton();
            stopChequeCaptureModel.otherReasonFieldErrorMessage();
            Reporter.log("stopChequeErrorOnBlankOtherReasonField test passed.");
        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
            StopCheque.logger.error("Exception:", e);
        }
    }


    // Verify error for duplicate cheque
    @Test(testName = "duplicateStopCheque", groups = {"functionaltest"})
    public void duplicateStopCheque() {
        try {
            StopChequeDetails stopCheque = new StopChequeDetails();
            stopCheque.setIssueChequeAccount(stopChequeCaptureModel.populateAccountDetails(profileProperties));
            navigate.navigateToStopAChequePage();
            stopCheque.setIssueChequeAccount(stopChequeCaptureModel.selectAccountOnStopACheckPage(stopCheque
                .getIssueChequeAccount()));
            stopCheque.setStopChequeDetails(stopChequeCaptureModel.enterStopChequeDetails(stopCheque));
            stopCheque.setReasonToStopCheque(stopChequeCaptureModel.selectReasonToStopCheque());
            stopChequeCaptureModel.clickContinueButton();
            stopChequeVerifyModel.validateReviewPageWithChequeNumber(stopCheque);
            stopChequeVerifyModel.clickConfirmButton();
            stopChequeConfirmModel.validateConfirmPageWithChequeNumber(stopCheque);
            stopChequeConfirmModel.clickStopAnotherChequeButton();
            stopChequeCaptureModel.selectAccountByDetails(stopCheque.getIssueChequeAccount());
            stopChequeCaptureModel.enterStopChequeDetails(stopCheque);
            stopChequeCaptureModel.selectReasontoStopChequeForDuplicateFlow(stopCheque);
            stopChequeCaptureModel.clickContinueButton();
            stopChequeVerifyModel.validateReviewPageWithChequeNumber(stopCheque);
            stopChequeVerifyModel.clickConfirmButton();
            stopChequeVerifyModel.verifyDuplicateChequeError();
            Reporter.log("duplicateStopCheque test passed.");
        } catch (Exception e) {
            StopCheque.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(testName = "stopChequeRange", groups = {"functionaltest"})
    public void stopChequeRange() {
        try {
            StopChequeDetails stopCheque = new StopChequeDetails();
            stopCheque.setIssueChequeAccount(stopChequeCaptureModel.populateAccountDetails(profileProperties));
            navigate.navigateToStopAChequePage();
            stopCheque.setIssueChequeAccount(stopChequeCaptureModel.selectAccountOnStopACheckPage(stopCheque
                .getIssueChequeAccount()));
            stopCheque.setStopChequeRange(stopChequeCaptureModel.enterStopChequeRange(stopCheque));
            stopCheque.setReasonToStopCheque(stopChequeCaptureModel.selectReasonToStopCheque());
            stopChequeCaptureModel.verifyHelpIcon();
            stopChequeCaptureModel.clickContinueButton();
            stopChequeVerifyModel.validateReviewPageWithChequeRange(stopCheque);
            stopChequeVerifyModel.clickConfirmButton();
            stopChequeConfirmModel.validateConfirmPageWithChequeRange(stopCheque);
            Reporter.log("stopChequeRange test passed.");
        } catch (Exception e) {
            StopCheque.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(testName = "stopChequefromManage", groups = {"functionaltest"})
    public void stopChequefromManage() {
        try {
            StopChequeDetails stopCheque = new StopChequeDetails();
            stopCheque.setIssueChequeAccount(stopChequeCaptureModel.populateAccountDetails(profileProperties));
            stopCheque.setIssueChequeAccount(landingPageModel.selectAccountForStopchequeFromManage(stopCheque));
            stopChequeCaptureModel.verifyPageTitle();
            stopChequeCaptureModel.checkAccountAndDisclaimer(stopCheque);
            Reporter.log("stopChequefromManage test passed.");
        } catch (Exception e) {
            StopCheque.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @AfterMethod(alwaysRun = true)
    public void afterTest() {
        this.browserLib.closeAllBrowsers();
    }

    /**
     * @return the driver
     */
    public WebDriver getDriver() {
        return this.driver;
    }


}
