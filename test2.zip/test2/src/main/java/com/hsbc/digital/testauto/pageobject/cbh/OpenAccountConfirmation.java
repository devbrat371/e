/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.cbh;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.models.OpenAccountDetails;
import com.hsbc.digital.testauto.pageobject.OpenAccountConfirmationModel;

/**
 * <p>
 * <b> This class will hold locators and specific implementation for Canada
 * entity. </b>
 * </p>
 */
public class OpenAccountConfirmation extends OpenAccountConfirmationModel {

    @FindBy(xpath = "//div[contains(@class,'confirmation')]//p")
    private WebElement confirmationMessage;

    @FindBy(xpath = "//dt[text()='Application Reference']/following-sibling::dd[1]")
    private WebElement applicationRefrenceConfirm;

    @FindBy(xpath = "//dt[text()='Product Name']/following-sibling::dd[1]")
    private WebElement productNAmeConfirm;

    @FindBy(xpath = "//dt[text()='New Account Number']/following-sibling::dd[1]")
    private WebElement newAccountNumberConfirm;

    @FindBy(xpath = "//dt[contains(text(),'Interest Rate')]/following-sibling::dd[1]//span[1]")
    private WebElement intrestRateConfirm;

    @FindBy(xpath = "//dt[text()='Reason for opening account']/following-sibling::dd[1]")
    private WebElement reasonConfirm;

    @FindBy(xpath = "//button[contains(@data-dojo-attach-point,'printSuccess') and contains(text(),'Print application')]")
    private WebElement printButtonConfirm;

    @FindBy(xpath = "//button[contains(@data-dojo-attach-point,'printButton') and contains(text(),'Print')]")
    private WebElement printButtonpOpUp;

    @FindBy(xpath = "//button[contains(@data-dojo-attach-point,'closeButton') and contains(text(),'Cancel')]")
    private WebElement printCancelButtonpOpUp;

    @FindBy(xpath = "//input[contains(@value,'Back')]")
    private WebElement backToMyAccountButton;


    private static final String MESSAGE_SUCCESS = "Application approved";

    public OpenAccountConfirmation(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    @Override
    public OpenAccountDetails verifyConfirmationPage() {
        Assert.assertTrue(confirmationMessage.getText().contains(OpenAccountConfirmation.MESSAGE_SUCCESS),
            "Confirmation message is not displayed");

        Assert.assertTrue(applicationRefrenceConfirm.isDisplayed(), "Application refrence is not displayed on confirmation page.");
        Assert.assertTrue(productNAmeConfirm.isDisplayed(), "Product Name is not displayed on confirmation page.");
        Assert.assertTrue(newAccountNumberConfirm.isDisplayed(), "New Account number is not displayed on confirmation page.");
        OpenAccountDetails objOpenAccountDetails = new OpenAccountDetails();
        objOpenAccountDetails.setCreatedAccount(newAccountNumberConfirm.getText());
        Assert.assertTrue(intrestRateConfirm.isDisplayed(), "Intrest Rate is not displayed on confirmation page.");
        Assert.assertTrue(reasonConfirm.isDisplayed(), "Reason is not displayed on confirmation page.");
        Assert.assertTrue(backToMyAccountButton.isDisplayed(), "Back to my Account button is not displayed");
        backToMyAccountButton.click();
        Reporter.log("Back to my account button clicked");

        return objOpenAccountDetails;

    }

    @Override
    public OpenAccountDetails verifyConfirmationPageForTermDeposit() {
        Assert.assertTrue(confirmationMessage.getText().contains(OpenAccountConfirmation.MESSAGE_SUCCESS),
            "Confirmation message is not displayed");

        Assert.assertTrue(applicationRefrenceConfirm.isDisplayed(), "Application refrence is not displayed on confirmation page.");
        Assert.assertTrue(productNAmeConfirm.isDisplayed(), "Product Name is not displayed on confirmation page.");
        Assert.assertTrue(newAccountNumberConfirm.isDisplayed(), "New Account number is not displayed on confirmation page.");
        OpenAccountDetails objOpenAccountDetails = new OpenAccountDetails();
        objOpenAccountDetails.setCreatedAccount(newAccountNumberConfirm.getText());
        Assert.assertTrue(intrestRateConfirm.isDisplayed(), "Intrest Rate is not displayed on confirmation page.");
        Assert.assertTrue(backToMyAccountButton.isDisplayed(), "Back to my Account button is not displayed");
        backToMyAccountButton.click();
        Reporter.log("Back to my account button clicked");

        return objOpenAccountDetails;

    }

    @Override
    public void verifyPrintButtonFunctionality() {
        Assert.assertTrue(printButtonConfirm.isDisplayed(), "Print button is not displayed");
        printButtonConfirm.click();
        Reporter.log("Click on Print button");

        Assert.assertTrue(printButtonpOpUp.isDisplayed(), "Print pop up is not displayed");
        Assert.assertTrue(printCancelButtonpOpUp.isDisplayed(), "Cancel button on print pop up is not displayed");
        Reporter.log("Print pop up is displayed");


    }
}
