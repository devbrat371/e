/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject;

import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.DateUtil;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.models.Transaction;
import com.hsbc.digital.testauto.models.TransactionFrequency;
import com.hsbc.digital.testauto.ui.library.UICommonUtil;

/**
 * <p>
 * <b> Abstract Class is used to define all the common function required for
 * Confirm page of Move Money stories With Primary story being Story 39 </b>
 * 
 * @version 1.0.0
 * @author Neeraj Kumar & Pramesh
 * 
 *         </p>
 */
public abstract class MoveMoneyConfirmPageModel {

    protected final WebDriverWait wait;
    protected final UICommonUtil uiCommonUtil;
    /**
     * Field Label on Verify page
     */
    protected static final String SCROLL_TO_VIEW = "arguments[0].scrollIntoView(true);";
    protected static final String LABEL_FROM = "From";
    protected static final String LABEL_TO = "To";
    protected static final String LABEL_AMOUNT = "Amount";
    protected final String LABEL_DEBIT_AMOUNT = "Debit amount";
    protected static final String LABEL_PAYMENT_DATE = "Payment date";
    protected static final String LABEL_YOUR_REFERENCE = "Your reference";
    protected static final String LABEL_PAYEE_REFERENCE = "Payee's reference";
    protected static final String LABEL_START_DATE = "Start date";
    protected static final String LABEL_TRANSACTION_END_DATE = "Transaction end date";
    protected static final String LABEL_FREQUENCY = "Frequency";
    protected static final String LABEL_NUMBER_OF_PAYMENT = "Number of payments";
    protected static final String DEFAULT_PAYMENT_DATE_VALUE = "Now";
    protected static final String LABEL_PAYEE_ADDRESS = "Payee address";
    protected static final String LABEL_REASON_FOR_TRANSACTION = "Reason for transaction";
    protected static final String DATE_FORMAT = "dd MMM yyyy";
    private static final String LABEL_REFERENCE_NUMBER = "Reference number";
    protected static final String PAYMENT_RECURRING_VALUE = "Recurring ";
    protected static final Map<String, String> labels = new HashMap<>();

    @FindBy(xpath = "//div[contains(@id, 'Confirm')]")
    protected WebElement confirmPage;

    @FindBy(xpath = "//div[contains(@id, 'Confirm')]//div[contains(@class, 'steptracker-heading')]")
    protected WebElement confirmPageTitle;

    @FindBy(xpath = "//div[contains(@id, 'ConfirmOtrHSBCPymt')]//input[@value='New transfer']")
    protected WebElement newTransactionButton;

    @FindBy(xpath = "//*[@value='My accounts' or (contains(text(),'My accounts') and @data-dojo-attach-point='_accntSummaryNavigation')]")
    protected WebElement backtoMyAccountsButton;

    @FindBy(xpath = "//div[contains(@class, 'submitButtonsPanel')]//*[contains(@class, 'printIcon') or contains(@class, 'PrintIcon')]")
    private WebElement printButton;

    @FindBy(xpath = "//div[contains(@id, 'PrintFriendlyFormatDialog') and contains(@aria-labelledby, 'title')]")
    private WebElement printPage;

    @FindBy(xpath = "//div[contains(@id, 'PrintFriendlyFormatDialog')]//*[contains(@class, 'printFriendlyHeading')]")
    private WebElement printPageTitle;

    @FindBy(xpath = "//div[contains(@id, 'PrintFriendlyFormatDialog') and contains(@aria-labelledby, 'title')]//button[@data-dojo-attach-point= 'closeButton']")
    private WebElement cancelOnPrintDialogButton;

    @FindBy(xpath = "//div[contains(@id, 'PrintFriendlyFormatDialog') and contains(@aria-labelledby, 'title')]//button[@data-dojo-attach-point= 'printButton']")
    private WebElement printOnPrintDialogButton;

    private final By locatorReferenceNumber = By.xpath("//div[contains(@class, 'itemLabel') and contains(text(), '"
        + LABEL_REFERENCE_NUMBER + "')]//following-sibling::div[contains(@class, 'itemValue')]");

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(MoveMoneyConfirmPageModel.class);


    /**
     * // This initElements method will create all WebElements
     * 
     * @param driver
     */
    public MoveMoneyConfirmPageModel(final WebDriver driver) {
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, 30000);
        uiCommonUtil = new UICommonUtil(driver);
    }


    protected void setAllLabel(Transaction transaction) {
        System.out.println(transaction.getTransactionFlow().toString());
        switch (transaction.getTransactionFlow().toString()) {
        case "M2NMHSBCTransfer":
            labels.put(LABEL_FROM, "Account");
            labels.put(LABEL_TO, "To");
            labels.put(LABEL_AMOUNT, "Amount");
            labels.put(LABEL_DEBIT_AMOUNT, "Debit amount");
            labels.put(LABEL_PAYMENT_DATE, "Payment date");
            labels.put(LABEL_YOUR_REFERENCE, "Your reference");
            labels.put(LABEL_START_DATE, "Start date");
            labels.put(LABEL_TRANSACTION_END_DATE, "Transaction end date");
            labels.put(LABEL_FREQUENCY, "Frequency");
            labels.put(LABEL_NUMBER_OF_PAYMENT, "Number of payments");
            labels.put(LABEL_REASON_FOR_TRANSACTION, "Reason for transaction");
            labels.put(PAYMENT_RECURRING_VALUE, "Recurring ");
            labels.put(LABEL_PAYEE_ADDRESS, "Payee address");
            break;
        default:
            break;
        }

    }

    protected String getLabel(String labelName) {
        return labels.get(labelName);
    }

    /**
     * Method to return transaction reference number from Confirm page
     */
    public Transaction referenceNumber(Transaction transactionDetail) {
        WebElement referenceNumberValue = confirmPage.findElement(locatorReferenceNumber);
        transactionDetail.setReferenceNumber(referenceNumberValue.getText());
        return transactionDetail;
    }

    protected void isFromAccountNameDisplayed(AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_FROM, accountDetail.getAccountName(), UICommonUtil.confirmPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given From Account Name not found.");
        Reporter.log("From Account Name displayed is :" + accountDetail.getAccountName());
    }

    protected void isFromAccountNumberDisplayed(AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_FROM, accountDetail.getAccountNumber(),
            UICommonUtil.confirmPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
            "Given From Account Number not found.");
        Reporter.log("From Account Number displayed is :" + accountDetail.getAccountNumber());
    }

    protected void isToAccountNameDisplayed(AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_TO, accountDetail.getAccountName(), UICommonUtil.confirmPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given To Account Name not found.");
        Reporter.log("To Account Name displayed is :" + accountDetail.getAccountName());
    }

    protected void isToAccountNumberDisplayed(AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_TO, accountDetail.getAccountNumber(), UICommonUtil.confirmPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given To Account Number not found.");
        Reporter.log("To Account Number displayed is :" + accountDetail.getAccountNumber());
    }

    protected void isAmountDisplayed(String amount) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_AMOUNT, amount, UICommonUtil.confirmPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Transfer Amount not found.");
        Reporter.log("Amount displayed is :" + amount);
    }

    protected void isDebitAmountDisplayed(String amount) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_DEBIT_AMOUNT, amount, UICommonUtil.confirmPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Transfer Amount not found.");
        Reporter.log("Amount displayed is :" + amount);
    }

    protected void isPaymentDateDisplayed(String paymentDate) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_PAYMENT_DATE, "Now", UICommonUtil.confirmPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Payment Date not found.");
        Reporter.log("Payment Date displayed is :" + paymentDate);
    }

    protected void isPaymentDateAsLaterDateDisplayed(Transaction transaction) {
        String paymentDate;
        try {
            paymentDate = DateUtil.getDateToString(DATE_FORMAT, transaction.getLaterDate());
            Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_PAYMENT_DATE, paymentDate, UICommonUtil.confirmPage,
                UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Payment Date not found.");
            Reporter.log("Payment Date displayed is :" + paymentDate);
        } catch (ParseException e) {
            MoveMoneyConfirmPageModel.logger.error(e);
            Assert.fail("Parsing to Payment Date Fail " + e.getMessage(), e);
        }
    }

    protected void isYourReferenceTextDisplayed(String yourReference) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_YOUR_REFERENCE, yourReference, UICommonUtil.confirmPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Your Reference Text not found.");
        Reporter.log("Your Reference Text displayed is :" + yourReference);
    }

    protected void isPayeeReferenceTextDisplayed(String payeeReference) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_YOUR_REFERENCE, payeeReference, UICommonUtil.verifyPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Your Reference Text not found.");
        Reporter.log("Your Reference Text displayed is :" + payeeReference);
    }

    protected void isStartDateDisplayed(Transaction transaction) {
        try {
            String startDate = DateUtil.getDateToString(DATE_FORMAT, transaction.getFirstDateOfTransaction());
            Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_START_DATE, startDate, UICommonUtil.confirmPage,
                UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Start Date not found.");
            Reporter.log("Start Date displayed is :" + startDate);
        } catch (ParseException e) {
            MoveMoneyCapturePageModel.logger.error(e);
            Assert.fail("Parsing to Payment Date Fail " + e.getMessage(), e);
        }

    }


    private void isPayeeAdressDisplayed(String address) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_PAYEE_ADDRESS, address, UICommonUtil.verifyPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Number Of Payment not found.");
        Reporter.log("Number Of Payment displayed is :" + address);
    }

    protected void isTransactionEndDateDisplayed(TransactionFrequency transactionFrequency) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_TRANSACTION_END_DATE, transactionFrequency.getValue(),
            UICommonUtil.confirmPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
            "Given Transaction End Date dropdown value not found.");
        Reporter.log("Transaction End Date dropdown value displayed is :" + transactionFrequency.getValue());
    }

    protected void isFrequencyDisplayed(String frequencyValue) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_FREQUENCY, frequencyValue, UICommonUtil.confirmPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Frequency Value not found.");
        Reporter.log("Frequency Value displayed is :" + frequencyValue);
    }

    protected void isRecurringFrequencyDisplayed(String frequencyValue) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_FREQUENCY, PAYMENT_RECURRING_VALUE + frequencyValue,
            UICommonUtil.verifyPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Frequency Value not found.");
        Reporter.log("Frequency Value displayed is :" + frequencyValue);
    }

    protected void isNumberOfPaymentDisplayed(String valueNOP) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_NUMBER_OF_PAYMENT, valueNOP, UICommonUtil.confirmPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Number Of Payment not found.");
        Reporter.log("Number Of Payment displayed is :" + valueNOP);
    }

    protected void isReasonForTransaction(String reasonForTransaction) {
        Assert.assertTrue(!uiCommonUtil.textByParentAndSibling(LABEL_REASON_FOR_TRANSACTION, reasonForTransaction,
            UICommonUtil.confirmPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
            "Given Reason For Transaction not found.");
        Reporter.log("Reason For Transaction Field is Not Applicable");
    }

    public void verifyConfirmPageTitle() {
        wait.until(ExpectedConditions.visibilityOf(confirmPageTitle));
        Assert.assertTrue(confirmPageTitle.isDisplayed(), "Confirm Page is not displayed.");
        Reporter.log("Confirm Page is displayed.");
    }

    public void verifyPrintPageTitle() {
        wait.until(ExpectedConditions.visibilityOf(printPageTitle));
        Assert.assertTrue(printPageTitle.isDisplayed(), "Print Page is not displayed.");
        Reporter.log("Print Page is displayed.");
    }

    public void clickNewTransactionButton() {
        wait.until(ExpectedConditions.elementToBeClickable(newTransactionButton));
        newTransactionButton.click();
        Reporter.log("Confirm button is clicked.");
    }

    public void clickBacktoMyAccountsButton() {
        wait.until(ExpectedConditions.elementToBeClickable(backtoMyAccountsButton));
        backtoMyAccountsButton.click();
        Reporter.log("Cancel button is clicked.");
    }

    public void clickPrintButton() {
        wait.until(ExpectedConditions.elementToBeClickable(printButton));
        printButton.click();
        Reporter.log("Edit Details button is clicked.");
    }

    public void clickCancelOnPrintDialog() {
        wait.until(ExpectedConditions.elementToBeClickable(cancelOnPrintDialogButton));
        cancelOnPrintDialogButton.click();
        wait.until(ExpectedConditions.not(ExpectedConditions.visibilityOf(printPage)));
        Reporter.log("Print page is closed.");
    }

    /**************** Now Flow Verification *************/
    /**
     * Method to verify Transaction details on confirm page for Now flow
     */
    protected void validateNowFlow(Transaction transaction) {
        wait.until(ExpectedConditions.visibilityOf(confirmPageTitle));
        isFromAccountNameDisplayed(transaction.getFromAccount());
        isFromAccountNumberDisplayed(transaction.getFromAccount());
        if (StringUtils.isNotEmpty(transaction.getToAccount().getAccountName())) {
            isToAccountNameDisplayed(transaction.getToAccount());
        }
        isToAccountNumberDisplayed(transaction.getToAccount());
        isPaymentDateDisplayed(DEFAULT_PAYMENT_DATE_VALUE);
        isYourReferenceTextDisplayed(transaction.getYourReference());
    }

    public void verifyLCY2LCYNowTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYNow Transaction Details verified on Confirm Page.");
    }

    public void verifyM2CLCY2LCYNowTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        this.verifyLCY2LCYNowTransactionDetailsOnConfirmPage(transactionDetail);

    }

    public void verifyNonHSBCLCY2LCYNowTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isAmountDisplayed(transactionDetail.getAmount());
        isPayeeReferenceTextDisplayed(transactionDetail.getPayeeReference());
        Reporter.log("LCY2LCYNowNonHSBC Transaction Details verified on Verify Page.");
    }

    public void verifyInlineNonHSBCLCY2LCYNowTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        verifyNonHSBCLCY2LCYNowTransactionDetailsOnConfirmPage(transactionDetail);
        if (!transactionDetail.getAddress1().trim().isEmpty()) {
            isPayeeAdressDisplayed(transactionDetail.getAddress1());
        }
        Reporter.log("InlineLCY2LCYNowNonHSBC Transaction Details verified on Verify Page.");
    }

    /**
     * Method to verify Transaction details on confirm page for Now flow
     */
    public void verifyLCY2FCYNowTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2FCYNow Transaction Details verified on Confirm Page.");
    }

    /**
     * Method to verify FCY to FCY Transaction details on confirm page for Now
     * flow
     */
    public void verifyFCY2FCYNowTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("FCY2FCYNow Transaction Details verified on Confirm Page.");
    }

    /**
     * Method to verify FCY to LCY Transaction details on confirm page for Now
     * flow
     */
    public void verifyFCY2LCYNowTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isReasonForTransaction(transactionDetail.getReasonForTransaction());
        Reporter.log("FCY2LCYNow Transaction Details verified on Confirm Page.");
    }

    public void verifyNonHSBCFCY2LCYNowTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isAmountDisplayed(transactionDetail.getAmount());
        isPayeeReferenceTextDisplayed(transactionDetail.getPayeeReference());
        Reporter.log("NonHSBCFCY2LCYNow Transaction Details verified on Confirm Page.");
    }

    public void verifyInlineNonHSBCFCY2LCYNowTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        verifyNonHSBCFCY2LCYNowTransactionDetailsOnConfirmPage(transactionDetail);
        if (!transactionDetail.getAddress1().trim().isEmpty()) {
            isPayeeAdressDisplayed(transactionDetail.getAddress1());
        }
        Reporter.log("InlineNonHSBCFCY2LCYNow Transaction Details verified on Confirm Page.");
    }

    /**************** Later Flow Verification ****************/
    /**
     * Method to verify LCY to LCY Transaction details on confirm page for
     * Later flow
     */
    protected void validateLaterFlow(Transaction transaction) {
        wait.until(ExpectedConditions.visibilityOf(confirmPageTitle));
        isFromAccountNameDisplayed(transaction.getFromAccount());
        isFromAccountNumberDisplayed(transaction.getFromAccount());
        if (StringUtils.isNotEmpty(transaction.getToAccount().getAccountName())) {
            isToAccountNameDisplayed(transaction.getToAccount());
        }
        isToAccountNumberDisplayed(transaction.getToAccount());
        isPaymentDateAsLaterDateDisplayed(transaction);
        isYourReferenceTextDisplayed(transaction.getYourReference());
    }

    public void verifyLCY2LCYLaterTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateLaterFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYLater Transaction Details verified on Confirm Page.");
    }

    public void verifyM2CLCY2LCYLaterTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        this.verifyLCY2LCYLaterTransactionDetailsOnConfirmPage(transactionDetail);
    }

    public void verifyM2CFCY2LCYLaterTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        this.verifyLCY2LCYLaterTransactionDetailsOnConfirmPage(transactionDetail);
    }

    public void verifyNonHSBCLCY2LCYLaterTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateLaterFlow(transactionDetail);
        isAmountDisplayed(transactionDetail.getAmount());
        isPayeeReferenceTextDisplayed(transactionDetail.getPayeeReference());
        Reporter.log("LCY2LCYLaterNonHSBC Transaction Details verified on Confirm Page.");
    }

    public void verifyInlineNonHSBCLCY2LCYLaterTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        verifyNonHSBCLCY2LCYLaterTransactionDetailsOnConfirmPage(transactionDetail);
        if (!transactionDetail.getAddress1().trim().isEmpty()) {
            isPayeeAdressDisplayed(transactionDetail.getAddress1());
        }
        Reporter.log("LCY2LCYLaterNonHSBC Transaction Details verified on Verify Page.");
    }

    /**************** Later Flow Verification ****************/
    /**
     * Method to verify LCY to FCY Transaction details on confirm page for
     * Later flow
     */
    public void verifyLCY2FCYLaterTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateLaterFlow(transactionDetail);
        isAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2FCYLater Transaction Details verified on Confirm Page.");
    }

    public void verifyFCY2LCYLaterTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateLaterFlow(transactionDetail);
        isAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("FCY2LCYLater Transaction Details verified on Confirm Page.");
    }

    public void verifyNonHSBCFCY2LCYLaterTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        verifyFCY2LCYLaterTransactionDetailsOnConfirmPage(transactionDetail);
        isPayeeReferenceTextDisplayed(transactionDetail.getPayeeReference());
        Reporter.log("NonHSBCFCY2LCYLater Transaction Details verified on Confirm Page.");
    }

    public void verifyInlineNonHSBCFCY2LCYLaterTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        verifyNonHSBCFCY2LCYLaterTransactionDetailsOnConfirmPage(transactionDetail);
        if (!transactionDetail.getAddress1().trim().isEmpty()) {
            isPayeeAdressDisplayed(transactionDetail.getAddress1());
        }
        Reporter.log("InlineNonHSBCFCY2LCYLater Transaction Details verified on Confirm Page.");
    }

    public void verifyFCY2FCYLaterTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateLaterFlow(transactionDetail);
        isAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("FCY2FCYLater Transaction Details verified on Confirm Page.");
    }

    /**
     * Method to verify Transaction details on confirm page for Recurring flow
     */
    protected void validateRecurringFlow(Transaction transaction) {
        wait.until(ExpectedConditions.visibilityOf(confirmPageTitle));
        isFromAccountNameDisplayed(transaction.getFromAccount());
        isFromAccountNumberDisplayed(transaction.getFromAccount());
        if (StringUtils.isNotEmpty(transaction.getToAccount().getAccountName())) {
            isToAccountNameDisplayed(transaction.getToAccount());
        }

        isToAccountNumberDisplayed(transaction.getToAccount());
        isYourReferenceTextDisplayed(transaction.getYourReference());
        isStartDateDisplayed(transaction);
    }

    public void verifyLCY2LCYRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("LCY2LCYRecurring Transaction Details verified on Confirm Page.");
    }

    public void verifyNonHSBCLCY2LCYRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        if (StringUtils.isNotEmpty(transactionDetail.getAddress1())) {
            isPayeeAdressDisplayed(transactionDetail.getAddress1());
        }
        Reporter.log("LCY2LCYRecurringNonHSBC Transaction Details verified on Confirm Page.");
    }

    public void verifyInlineNonHSBCLCY2LCYRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        verifyNonHSBCLCY2LCYRecurringTransactionDetailsOnConfirmPage(transactionDetail);
        isPayeeAdressDisplayed(transactionDetail.getAddress1());
        Reporter.log("InlineLCY2LCYRecurringNonHSBC Transaction Details verified on Confirm Page.");
    }

    public void verifyM2MLCY2LCYRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isRecurringFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isAmountDisplayed(transactionDetail.getAmount());
        isTransactionEndDateDisplayed(transactionDetail.getTransactionFrequency());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("LCY2LCYRecurring Transaction Details verified on Confirm Page.");
    }


    /**
     * Method to verify LCY2FCYRecurring Transaction details on confirm page
     * for Recurring flow
     */
    public void verifyLCY2FCYRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("LCY2FCYRecurring Transaction Details Verified on Confirm Page");
    }

    public void verifyM2MLCY2FCYRecurringTransactionDetailsOnConfirmPage(final Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isRecurringFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isAmountDisplayed(transactionDetail.getAmount());
        isTransactionEndDateDisplayed(transactionDetail.getTransactionFrequency());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("LCY2FCYRecurring Transaction Details Verified on Confirm Page");
    }

    /**
     * Method to verify FCY2LCYRecurring Transaction details on confirm page
     * for Recurring flow
     */
    public void verifyFCY2LCYRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("FCY2LCYRecurring Transaction Details Verified on Confirm Page");
    }

    public void verifyNonHSBCFCY2LCYRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        verifyFCY2LCYRecurringTransactionDetailsOnConfirmPage(transactionDetail);
        isPayeeReferenceTextDisplayed(transactionDetail.getPayeeReference());
        Reporter.log("NonHSBCFCY2LCYRecurring Transaction Details Verified on Confirm Page");
    }

    public void verifyInlineNonHSBCFCY2LCYRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        verifyNonHSBCFCY2LCYRecurringTransactionDetailsOnConfirmPage(transactionDetail);
        if (!transactionDetail.getAddress1().trim().isEmpty()) {
            isPayeeAdressDisplayed(transactionDetail.getAddress1());
        }
        Reporter.log("InlineNonHSBCFCY2LCYRecurring Transaction Details Verified on Confirm Page");
    }

    public void verifyM2MFCY2LCYRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isRecurringFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isAmountDisplayed(transactionDetail.getAmount());
        isTransactionEndDateDisplayed(transactionDetail.getTransactionFrequency());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("FCY2LCYRecurring Transaction Details Verified on Confirm Page");
    }

    /**
     * Method to verify FCY2FCYRecurring Transaction details on confirm page
     * for Recurring flow
     */
    public void verifyFCY2FCYRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("FCY2LFYRecurring Transaction Details Verified on Confirm Page");
    }

    public void verifyM2MFCY2FCYRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isRecurringFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isAmountDisplayed(transactionDetail.getAmount());
        isTransactionEndDateDisplayed(transactionDetail.getTransactionFrequency());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("FCY2LFYRecurring Transaction Details Verified on Confirm Page");
    }

}
