/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject;

import java.text.ParseException;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.models.Transaction;

/**
 * <p>
 * <b> This class is parent pom and will contains functions and locators for
 * Contact me & RM story. </b>
 * </p>
 */
public abstract class ContactMeAndContactRMModel {

    private final WebDriverWait wait;
    private final WebDriver driver;


    @FindBy(xpath = "  //span[@class='title']")
    private WebElement dashboardtitle;

    @FindBy(xpath = "//div[@id='masthead-navigation-sections']//span[text()='Contact HSBC']")
    private WebElement contactHSBCFlyerMenu;

    @FindBy(xpath = "//a[text()='Contact and support']")
    private WebElement contacAndSupportLink;

    @FindBy(xpath = "//a[text()='Have a specialist contact me']")
    private WebElement specialistContactMeLink;

    @FindBy(xpath = "//h2[@class='contactMeTitle']")
    private WebElement contactMeHeading;

    @FindBy(xpath = "//input[contains(@id,'arrowid') and contains(@id,'contactSubject')]")
    private WebElement enquiryAboutArrow;

    @FindBy(xpath = "//input[contains(@id,'arrowid') and contains(@id,'contactMethod')]")
    private WebElement contactArrow;

    @FindBy(xpath = "//div[contains(@id,'contactSubject')]//table//tr")
    private List<WebElement> enquiryAboutList;

    @FindBy(xpath = "//div[contains(@id,'contactType')]//table//tr")
    private List<WebElement> contactYouList;

    @FindBy(xpath = "//table[contains(@id,'contactSubject')]//span[contains(@class,'ValidationTextBoxLabel')]")
    private List<WebElement> enquiryAboutTextBox;

    @FindBy(xpath = "//table[contains(@id,'contactMethod')]//span[contains(@class,'ValidationTextBoxLabel')]")
    private List<WebElement> contactYouTextBox;

    @FindBy(xpath = "//textarea[contains(@id,'contactMessage')]")
    private WebElement messageAreaText;

    @FindBy(xpath = "//button[@type='submit' and text()='Submit']")
    private WebElement submitButton;

    @FindBy(xpath = "//button[@type='button' and @data-dojo-attach-point='cancelBtnNode']")
    private WebElement cancelButton;

    @FindBy(xpath = "//div[contains(@data-dojo-attach-point,'dapEmail') and contains(@class,'email')]")
    private WebElement emailText;

    // Review page locators

    @FindBy(xpath = "//h2[@class='contactMeTitle']]")
    private WebElement headingReviewPage;

    @FindBy(xpath = "//span[contains(@id,'Button')]//span[@class='icon']")
    private WebElement editDetailsButton;

    @FindBy(xpath = "//div[@class='submitButtonsPanel']//button[@type='submit' and text()='Confirm']")
    private WebElement confirmButton;

    @FindBy(xpath = "//button[@data-dojo-attach-point='cancelNode']")
    private WebElement cancelButtonReview;

    @FindBy(xpath = "//div[contains(@class,'cancelPanel') and not(contains(@style,'display: none'))]//button[text()='Cancel']")
    private WebElement cancelButtonCancelPopUp;

    @FindBy(xpath = "//div[contains(@class,'cancelPanel') and not(contains(@style,'display: none'))]//button[contains(text(),'Do')]")
    private WebElement dontCancelButtonCancelPopUp;

    @FindBy(xpath = " //dt[@class='row' and text()='Subject']//following-sibling::dd[1]")
    private WebElement subjectReview;

    @FindBy(xpath = " //dt[@class='row' and text()='Subject']//following-sibling::dd[2]")
    private WebElement eMailReview;

    @FindBy(xpath = " //dt[@class='row' and text()='Subject']//following-sibling::dd[6]")
    private WebElement messageReview;

    // Locators on confirmation
    @FindBy(xpath = "//div[contains(@class,'confirmation')]//span[text()='Success']")
    public List<WebElement> confirmationMessage;

    @FindBy(xpath = "//div[@class='submitButtonsPanel']//a[contains(text(),'account')]")
    private WebElement backToMyAccountButton;


    // links present of Capture page
    @FindBy(xpath = "//a[text()='Accounts and services']")
    private WebElement accountAndSevicesLink;

    @FindBy(xpath = "//a[text()='HSBC MasterCard']")
    private WebElement masterCardLink;

    @FindBy(xpath = "//a[text()='Ways to Bank']")
    private WebElement waysToBankLink;

    @FindBy(xpath = "//a[text()='Book an appointment']")
    private WebElement bookAnAppointmentLink;

    @FindBy(xpath = "//a[text()='Make a complaint']")
    private WebElement makeCoplaintLink;

    @FindBy(xpath = "//a[text()='Branch Locator']")
    private WebElement branchLocatorLink;

    @FindBy(xpath = "//a[text()='Mortgage Rates']")
    private WebElement mortgageRatesLink;

    @FindBy(xpath = "//a[text()='Contact us']")
    private WebElement contactUs;

    // locators for Contact US

    @FindBy(xpath = "//input[contains(@id,'arrowid')]")
    private WebElement enquiryAboutArrowContactUs;

    @FindBy(xpath = "//div[@id='contactType_menu']//table//tr")
    public List<WebElement> enquiryAboutArrowContactUsTable;

    @FindBy(xpath = "//div//h3[text()='Contact numbers']")
    private WebElement contactNumberHeading;

    // Links on Contact US


    @FindBy(xpath = "  //h2[text()='Contact us']")
    private WebElement contactUSHeading;

    @FindBy(xpath = "//div[@class='contactMeCol']//a[@title='Request']")
    private WebElement requestcallBackLink;

    @FindBy(xpath = "//div[@class='contactMeCol']//a[@title='Send']")
    private WebElement sendUsMessageLink;

    @FindBy(xpath = "//a[text()='Find a Branch and ATM']")
    private WebElement branchATMLink;

    @FindBy(xpath = "//a[text()='Ways to Bank']")
    private WebElement waysToBankLinks;

    @FindBy(xpath = "//a[text()='Resolving your complaints']")
    private WebElement resolvingComplaintsLink;

    @FindBy(xpath = "//a[text()='HSBC MasterCard']")
    private WebElement masterCardLinks;

    @FindBy(xpath = "//a[text()='HSBC on Social Media']")
    private WebElement socialMediaLink;

    @FindBy(xpath = "//a[text()='HSBC Capital']")
    private WebElement capitalHSBCLink;

    @FindBy(xpath = "//a[text()='HSBC InvestDirect']")
    private WebElement investDirectLink;

    @FindBy(xpath = "//a[text()='HSBC Safeguard']")
    private WebElement safeguardHSBCLInk;


    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(ContactMeAndContactRMModel.class);

    public ContactMeAndContactRMModel(final WebDriver driver) {
        PageFactory.initElements(driver, this);
        this.driver = driver;
        wait = new WebDriverWait(driver, 30000);
    }


    public void mouseOverOnContactUs() {
        Actions action = new Actions(driver);
        action.moveToElement(contactHSBCFlyerMenu).build().perform();
        Reporter.log("Mouseover to the Contact HSBC flyer menu");
        wait.until(ExpectedConditions.visibilityOf(contacAndSupportLink));
    }


    public void navigateContactRMPage() {
        specialistContactMeLink.click();
        Reporter.log("Contact Me Link clicked");
        Assert.assertTrue(contactMeHeading.isDisplayed(), "Contact me page is not displayed");
        Reporter.log("Contact me page is displayed");
    }


    public Transaction captureContactRMDetails() {
        Transaction transaction = new Transaction();
        transaction.setgetEnquiryAbout(selectEnquiry());
        transaction.setContactYou(selectContactYou());
        transaction.setMessage(enterMessage());
        return transaction;
    }


    public String selectEnquiry() {
        String enquiryAbout = StringUtils.EMPTY;
        enquiryAboutArrow.click();
        Reporter.log("Enquiry about list clicked");
        int randomIndex = RandomUtil.generateIntNumber(2, enquiryAboutList.size());
        Assert.assertTrue(!enquiryAboutList.isEmpty(), "Option to enquiry about are present");
        for (int i = 0; i < enquiryAboutList.size(); i++) {
            WebElement enquiryList = enquiryAboutList.get(i);
            if (i == randomIndex) {
                enquiryList.click();
                // ?? need to clear below
                enquiryAbout = enquiryAboutTextBox.get(0).getText();
                break;
            }
        }
        return enquiryAbout;

    }

    public String selectContactYou() {
        contactArrow.click();
        String contactYou = StringUtils.EMPTY;
        Reporter.log("Contact you list clicked");
        int randomIndex = RandomUtil.generateIntNumber(1, contactYouList.size());
        Assert.assertTrue(!contactYouList.isEmpty(), "Option to enquiry about are present");

        for (int i = 0; i < contactYouList.size(); i++) {
            WebElement contactYouRow = contactYouList.get(i);

            if (i == randomIndex) {
                contactYouRow.click();
                // ?? need to clear below
                contactYou = contactYouTextBox.get(0).getText();
                break;
            }
        }
        return contactYou;

    }

    public String enterMessage() {
        String contactMessage = RandomUtil.generateAlphabatic(10);
        messageAreaText.click();
        messageAreaText.sendKeys(contactMessage);
        Reporter.log("Message is entered as :" + contactMessage);
        return contactMessage;

    }

    public void verifyeMail() {
        Assert.assertTrue(emailText.isDisplayed(), "email is not populated");
        Reporter.log("eMail is populated as " + emailText.getText());
    }

    public void clickSubmitButton() {
        submitButton.click();
        Reporter.log("Submit button clicked");
    }


    public void validateReviewPage(final Transaction transaction) throws ParseException {
        Assert.assertTrue(subjectReview.getText().contains(transaction.getEnquiryAbout()), "enquiry about did not match");
        Assert.assertTrue(messageReview.getText().contains(transaction.getMessage()), "Message did not match");
        Assert.assertTrue(eMailReview.getText().contains(transaction.getContactYou()), "eMail did not match");

    }

    public void verifyEditDetailsFunctionality() {
        editDetailsButton.click();
        Assert.assertTrue(messageAreaText.isDisplayed(), "Not able to Edit details after clicking on Edit Details button");
        Reporter.log("User is able to navigate to Capture page after clicking on Edit Details button");
    }

    public void verifyCancelButtonFunctinalityReview() {
        cancelButtonReview.click();
        Reporter.log("Cancel button click on Review page");
        cancelButtonCancelPopUp.click();
        Reporter.log("Cancel button clicked from popup");
        Assert.assertTrue(contactMeHeading.isDisplayed(),
            "Not navigated to capture page after cancelling the eprocess from review page");
        Reporter.log("Navigated to capture page after cancelling th eprocess from review page");

    }

    public void verifyCancelButtonFunctinalityCapture() {
        cancelButton.click();
        Reporter.log("Cancel button click on Capture page");
        cancelButtonCancelPopUp.click();
        Reporter.log("Cancel button clicked from popup");
        Assert.assertTrue(dashboardtitle.isDisplayed(),
            "Not navigated to capture page after cancelling th eprocess from capyure page");
        Reporter.log("Navigated to capture page after cancelling th eprocess from capture page");

    }

    public void clickConfirmButton() {
        confirmButton.click();
        Reporter.log("Confirm button clicked on Review page");

    }

    public void verifyConfirmationMessage() {
        Assert.assertTrue(!confirmationMessage.isEmpty(), "Confirmation message is not displayed");
        Reporter.log("Confirmation message is displayed as " + confirmationMessage.get(0).getText());
    }

    public void verifyBackToMyAccountFunctionality() {
        backToMyAccountButton.click();
        Reporter.log("Click on Back To My Account button on confirmation page");
        Assert.assertTrue(dashboardtitle.isDisplayed(), "Not navigated to capture page after clickin on Back to My Account button");
        Reporter.log("Navigated to Dahboard page after clicking on  Back to My Account button");

    }

    // Functions for Contact US

    public void selectEnquiryAboutContactUs() {
        enquiryAboutArrowContactUs.click();
        Reporter.log("Contact us enquiry about list clicked");
        // ?? need to check blow code
        int randomIndex = RandomUtil.generateIntNumber(2, contactYouList.size());
        Assert.assertTrue(!enquiryAboutArrowContactUsTable.isEmpty(), "Option to enquiry about are present on Contact Us page");
        for (int i = 0; i < enquiryAboutArrowContactUsTable.size(); i++) {
            WebElement enquiryItem = enquiryAboutArrowContactUsTable.get(i);
            if (i == randomIndex) {
                enquiryItem.click();
                break;
            }
        }
    }

    public void navigateContactUSPage() {
        contacAndSupportLink.click();
        Reporter.log("Contact And Support Link Link clicked");
        Assert.assertTrue(contactUSHeading.isDisplayed(), "Contact Us page is not displayed");
        Reporter.log("Contact Us page is displayed");

    }

    public void verifyRequestCallBackLinkFunctionality() {
        requestcallBackLink.click();
        Reporter.log("Request Call Back link clicked");
        // ?? is it pop up or new page
        Assert.assertTrue(contactMeHeading.isDisplayed(), "Not navigated to Contact Me page via Request call back link");
        Reporter.log("Navigated to Contact Me page via Request call back link");

    }

    public void verifyLinksOnContactUsPage() {
        Assert.assertTrue(sendUsMessageLink.isDisplayed(), "Send us message link not displayed");
        Assert.assertTrue(branchATMLink.isDisplayed(), "Branch ATM link not displayed");
        Assert.assertTrue(waysToBankLinks.isDisplayed(), "Ways to Bank link is not displayed");
        Assert.assertTrue(resolvingComplaintsLink.isDisplayed(), "resolving complaints link is not displayed");
        Assert.assertTrue(masterCardLinks.isDisplayed(), "Master Card link is not displayed");
        Assert.assertTrue(socialMediaLink.isDisplayed(), "Social Media link is not displayed");
        Assert.assertTrue(capitalHSBCLink.isDisplayed(), "Capital HSBC Link is not displayed");
        Assert.assertTrue(investDirectLink.isDisplayed(), "invest Direct link is not displayed");
        Assert.assertTrue(safeguardHSBCLInk.isDisplayed(), "Safe guard hsbc link is not displayed");
        Reporter.log("All links on contact us page verified.");
    }


}
