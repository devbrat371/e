/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.hsbc.digital.testauto.library.FileUtil;
import com.hsbc.digital.testauto.library.TokenGenerator;


// import com.gsp.scripts.Login;

/**
 * <p>
 * <b> Abstract class to hold Generic functionality of Page as well declaration
 * for all specific functions for each entity.<br>
 * Need to verify for new entity before adding new function. </b>
 * 
 * @version 1.0.0
 * @author Shrikant Joshi
 *         </p>
 */
public abstract class LoginModel {

    /** Driver for locators and functionality will be passed from Children. */
    protected final WebDriver driver;
    protected WebDriverWait wait;
    protected TokenGenerator tokenGenerator;
    private static final String ACC_LVL_CAM30 = "CAM30";
    private static final String ACC_LVL_CAM40 = "CAM40";


    @FindBy(xpath = "//*[@id='innerPage']/div/form/div[2]/div[1]/div/div/div/span/input")
    private WebElement activateNowButton;

    @FindBy(xpath = "//*[@id='innerPage']/div/form/div[2]/div[2]/div/div/a/input[2]")
    private WebElement activateLaterButton;

    @FindBy(xpath = "//input[@id='Username1' or @id='username'] ")
    private WebElement userName;

    @FindBy(css = "input.submit_input")
    private WebElement continueButton;

    @FindBy(xpath = "//a[contains(@href,'CAM10TO30')]")
    private WebElement withoutSecure;

    @FindBy(xpath = ".//*[@id='innerPage']//following-sibling::li[contains(@class,'first')]")
    private WebElement withSecure;

    @FindBy(xpath = "//*[@id='memorableAnswer']")
    private WebElement memorableAnswer;

    @FindBy(xpath = "//*[@id='password']")
    private WebElement password;

    @FindBy(xpath = "//*[@id='secureCode']")
    private WebElement secureKey;

    @FindBy(id = "idv_OtpCredential")
    private WebElement otpCode;

    @FindBy(css = "input.submit_input")
    private WebElement submitButton;

    @FindBy(xpath = "//*[@id='languageDefault']")
    private WebElement defaultLanguage;

    @FindBy(xpath = "//*[@id='mastheadLanguageDropDownButton_group_gpib_cmn_bijit_LanguageToggle_0']/span[3]")
    private WebElement languageDrowdownIcon;

    @FindBy(xpath = "//*[@id='dijit_MenuItem_0_text']/a")
    private WebElement selectLanguage;

    @FindBy(xpath = "//*[@id='hdx_dijits_Dialog_0']/div[2]/div")
    private WebElement confirmDialogBox;

    @FindBy(xpath = "//*[@id='hdx_dijits_Dialog_0']/div[2]/div/div[2]/div[2]/button/span[1]")
    private WebElement confirmDialogYesButton;

    @FindBy(css = "li#dijit__WidgetBase_0.navigation-item>a.navigation-link")
    protected WebElement myBankingMenu;

    @FindBy(xpath = "//*[contains(@name,'pass') and @type='password']")
    private List<WebElement> passwordFields;

    private final By popUpWindow = By.xpath("//*[contains(@class, 'lightboxInner')]");
    private final By popUpOverLay = By.cssSelector("div.overlay");
    private final By locatorPassword = By.xpath("//*[@id='password']");
    private final By locatorPasswordBox = By.xpath("//div[contains(@class, 'logonBox')]//div[contains(@id, 'viewNo')]");

    private static final String ACTIVATION_PAGE_TITLE = "Security Device Activation: Security Device, Notification | HSBC";


    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(LoginModel.class);

    /**
     * Constructor to instantiate locators with driver.Will be invoked from
     * Children only.
     * 
     * @param driver
     */
    public LoginModel(final WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        this.wait = new WebDriverWait(driver, 30000);
        this.tokenGenerator = new TokenGenerator();
    }


    public void setUserName(final String strUserId) {
        this.userName.clear();
        this.userName.sendKeys(strUserId);
    }


    public void clickContinue() {
        this.continueButton.click();
    }

    public void loginToUserNamePage(final String strUserName, final String password) {
        setUserName(strUserName);
        clickContinue();
    }


    public void setMemorableAnswer(final String strMemans) {
        this.memorableAnswer.clear();
        this.memorableAnswer.sendKeys(strMemans);
    }

    public void setOtp(final String strOtp) {
        this.otpCode.clear();
        this.otpCode.sendKeys(strOtp);
    }


    public void waitAndClickSubmit() {
        wait.until(ExpectedConditions.elementToBeClickable(this.submitButton));
        submitButton.click();

    }

    public void clickWithoutSecure() {
        this.withoutSecure.click();

    }

    public void clickWithSecure() {
        this.withSecure.click();

    }

    public void setPassword(final String memorableAnswer) {
        wait.until(ExpectedConditions.elementToBeClickable(password));
        password.click();
        password.clear();
        password.sendKeys(memorableAnswer);
    }

    public void setSecureKey(final String otp) {
        wait.until(ExpectedConditions.elementToBeClickable(secureKey));
        secureKey.click();
        secureKey.clear();
        secureKey.sendKeys(otp);
    }

    public boolean isPasswordDisplayed() {
        boolean flag = false;
        if (!driver.findElements(locatorPassword).isEmpty() && driver.findElement(locatorPassword).isDisplayed()) {
            flag = true;
        }
        return flag;
    }

    protected void waitAndCloseLoginPopUp() {
        wait.until(ExpectedConditions.visibilityOf(driver.findElement(popUpWindow)));
        if (driver.findElements(popUpWindow).size() > 0 && driver.findElement(popUpWindow).isDisplayed()) {
            driver.findElement(popUpOverLay).click();
        }
    }

    public void login(final String profile, final Map<String, String> envProperties) throws IOException {
        try {

            Map<String, String> profileProperties = FileUtil.getTestDataProperties(envProperties.get("countryCode"), profile);
            String camLevel = profileProperties.get("camLevel");
            String userName = profileProperties.get("userName");
            String serialNumber = profileProperties.get("serialNumber");
            String otpkey = profileProperties.get("otpKey");
            String memorableAnswer = profileProperties.get("memorableAnswer");
            String password = profileProperties.get("password");
            String guid = profileProperties.get("guid");
            String url = envProperties.get("url");
            String saasUrl = envProperties.get("saasUrl");
            if (StringUtils.isNotEmpty(saasUrl)) {
                driver.get(saasUrl);
            }
            this.driver.get(url);
            if (LoginModel.ACC_LVL_CAM30.equalsIgnoreCase(camLevel)) {
                loginWithoutOtp(userName, memorableAnswer, password);
                waitAndClickSubmit();
            } else if (LoginModel.ACC_LVL_CAM40.equalsIgnoreCase(camLevel)) {
                loginWithOtp(userName, memorableAnswer, otpkey, serialNumber, password);
                waitAndClickSubmit();
            } else if (camLevel.equalsIgnoreCase("")) {
                loginToUserNamePage(guid, password);
            }
            waitForDashboardPage();
        } catch (Exception e) {
            LoginModel.logger.error("Excption thrown at LoginModel:login() :", e);
        }
    }

    public void loginWithOtp(final String userName, final String memorableAnswer, final String otpKey, final String serialNumber,
        final String password) {
        String otp = StringUtils.EMPTY;

        try {
            loginToUserNamePage(userName, password);
            if (!driver.findElements(locatorPasswordBox).isEmpty()) {
                if (isPasswordDisplayed()) {
                    setPassword(password);
                } else {
                    otp = this.tokenGenerator.generateOTP(userName, serialNumber, otpKey);
                    setSecureKey(otp);
                }
            } else {
                otp = this.tokenGenerator.generateOTP(userName, serialNumber, otpKey);
                clickWithSecure();

                wait.until(ExpectedConditions.visibilityOf(this.memorableAnswer));
                setMemorableAnswer(memorableAnswer);
                this.wait.until(ExpectedConditions.visibilityOf(this.otpCode));
                setOtp(otp);
            }
        } catch (IOException e) {
            LoginModel.logger.error("Exception thrown LoginModel:loginWithOtp :", e);
        }
    }

    public void loginWithoutOtp(final String userName, final String memorableAnswer, final String password) {
        loginToUserNamePage(userName, password);
        if (this.driver.getTitle().contains(LoginModel.ACTIVATION_PAGE_TITLE)) {
            clickActivateSecureDeviceLater();
        }
        try {
            clickWithoutSecure();
        } catch (NoSuchElementException e) {
            LoginModel.logger.error("Exception: ", e);
        }
        this.wait.until(ExpectedConditions.visibilityOf(this.memorableAnswer));
        setMemorableAnswer(memorableAnswer);
        typePassword(password);
    }

    protected void typePassword(final String password) {
        for (int index = 0; index < this.passwordFields.size(); index++) {
            if (this.passwordFields.get(index).isEnabled()) {
                this.passwordFields.get(index).sendKeys(String.valueOf(password.charAt(index)));
            }
        }
    }

    public void clickActivateSecureDeviceNow() {
        this.activateNowButton.click();
    }

    public void clickActivateSecureDeviceLater() {
        activateLaterButton.click();
    }

    public void switchLanguage(final String language) {
        String defaultlanguage = defaultLanguage.getText();
        if (!language.equalsIgnoreCase(defaultlanguage)) {
            languageDrowdownIcon.click();
            try {
                Thread.sleep(8000);
            } catch (InterruptedException exception) {
                LoginModel.logger.error("Exception:", exception);
            }
            selectLanguage.click();
            confirmDialogBox.isDisplayed();
            confirmDialogYesButton.click();
            waitForDashboardPage();
        }
    }

    public void waitForDashboardPage() {
        this.wait.until(ExpectedConditions.elementToBeClickable(myBankingMenu));
    }
}
