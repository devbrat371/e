package com.hsbc.digital.testauto.pageobject.mx;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.hsbc.digital.testauto.pageobject.MoveMoneyCapturePageModel;

public class MoveMoneyCapturePage extends MoveMoneyCapturePageModel {

    public MoveMoneyCapturePage(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

}
