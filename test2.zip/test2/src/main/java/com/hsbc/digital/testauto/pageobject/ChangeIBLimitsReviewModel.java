/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

/**
 * <p>
 * <b> This model class will hold locators and functionality for Change
 * Internet Banking Limits Review page. </b>
 * </p>
 * 
 * @version 1.0.0
 * @author SatyaPrakash S Vyas
 */
public abstract class ChangeIBLimitsReviewModel {

    protected final WebDriverWait wait;

    @FindBy(xpath = "//div[contains(@id,'ChangeLimits')]/div[1]/h2")
    private WebElement reviewPageTitle;

    @FindBy(xpath = "//div[@class='itemsATM totalATMListWrapperNew']")
    private List<WebElement> updatedDailyLimits;

    @FindBy(xpath = "//div[@class='itemsATM totalATMListWrapperNew']/span[@class='currencyType']")
    private List<WebElement> updatedDailyLimitsCurrency;

    @FindBy(xpath = "//button[@class='iconButton editIcon']")
    private WebElement editButton;

    @FindBy(xpath = "//button[contains(@class,'btnPrimary confirmBtn')]")
    private WebElement confirmButton;

    @FindBy(xpath = "//button[@data-dojo-attach-point='cancelVerifyBtn']")
    private WebElement cancelButton;

    @FindBy(xpath = "//div[contains(@id,'hdx_dijits_Dialog_') and not (contains(@style,'display: none'))]//button[@title='Cancel']")
    protected WebElement cancelDialogYes;

    @FindBy(xpath = "//div[contains(@id,'hdx_dijits_Dialog_') and not (contains(@style,'display: none'))]//button[@class='btnTertiary']")
    protected WebElement cancelDialogNo;

    @FindBy(xpath = "//*[@id='_dashboardHeading']/h1/span[text()='My accounts']")
    private WebElement dashboardPage;

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(ChangeIBLimitsReviewModel.class);

    public ChangeIBLimitsReviewModel(final WebDriver driver) {
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, 30000);
    }

    public void validateAndConfirm(final List<Double> newDailyLimits) {
        List<Double> updatedLimits = new ArrayList<>();
        for (int i = 0; i < updatedDailyLimits.size(); i++) {
            String currency = updatedDailyLimitsCurrency.get(i).getText();
            String updatedLimitValue = updatedDailyLimits.get(i).getText().replace(currency, "").replace(",", "");
            updatedLimits.add(Double.parseDouble(updatedLimitValue));
        }
        Assert.assertTrue(updatedLimits.containsAll(newDailyLimits), "Values are not equal");
        Reporter.log("Daily limits are updated correctly.");
        wait.until(ExpectedConditions.elementToBeClickable(confirmButton));
        confirmButton.click();
        Reporter.log("Values verified and Confirm button clicked on verify page.");
    }

    public void clickEditButton() {
        wait.until(ExpectedConditions.elementToBeClickable(editButton));
        editButton.click();
        Reporter.log("Edit button clicked.");
    }

    public void clickCancelButton(final boolean value) {
        wait.until(ExpectedConditions.elementToBeClickable(cancelButton));
        cancelButton.click();
        if (value) {
            cancelDialogYes.click();
            wait.until(ExpectedConditions.visibilityOf(dashboardPage));
            Reporter.log("Cancel with Yes button clicked and Dashboard page shown.");
        } else {
            cancelDialogNo.click();
            reviewPageTitle.isDisplayed();
            Reporter.log("Cancel with No button clicked and review page shown.");
        }
    }

    public void enterReauthCode(final Map<String, String> profileProperties) throws IOException {
        Reporter.log("Not applicable here");
    }

}
