package com.hsbc.digital.testauto.library;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * <p>
 * <b> Class is used to Format Date to Required Date Format, Add Days to Date,
 * Get Next Date and Valid Later or Recurring Date. </b>
 * 
 * @version 1.0.0
 * @author Neeraj Kumar
 * 
 *         </p>
 */

public class DateUtil {

    public static final String TWO_DECIMAL_PLACE_FORMATTER = "#.00";
    public static final String DATE_FORMAT_MMDDYYYY = "MM/dd/yyyy";
    public static final String DATE_FORMAT_DDMMMYYYY = "dd MMM yyyy";
    public static final String DATE_FORMAT_MMMDDYYYY = "MMM dd, yyyy";
    public static final String DATE_FORMAT_MMMDDYYYY_SPACE = "MMM dd yyyy";
    public static final String DATE_FORMAT_DDMMYYYY = "dd/MM/yyyy";


    private DateUtil() {

    }

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(DateUtil.class);


    /**
     * 
     * This Method is used to parse input date in Date format
     * 
     * @param inputDateFormat
     * @param inputDate
     * @return Parsed date in Date format
     * @throws ParseException
     */
    public static Date getStringToDate(final String inputDateFormat, final String inputDate) throws ParseException {
        Date parsedDate = null;
        SimpleDateFormat format = new SimpleDateFormat(inputDateFormat);
        parsedDate = format.parse(inputDate);
        return parsedDate;
    }

    /**
     * Return Date String from Date
     */


    /**
     * This method is used to parse input date in String format
     * 
     * @param targetDateFormat
     * @param inputDate
     * @return Parsed date in String Format
     * @throws ParseException
     */
    public static String getDateToString(final String targetDateFormat, final Date inputDate) throws ParseException {
        String parsedDate = null;
        SimpleDateFormat format = new SimpleDateFormat(targetDateFormat);
        parsedDate = format.format(inputDate);
        return parsedDate;
    }


    /**
     * 
     * This Method is used to add days to the selected date
     * 
     * @param inputDate
     * @param daysToAdd
     * @return Processed date in Date format
     */
    public static Date addDays(final Date inputDate, final int daysToAdd) {
        Date userDate;
        Calendar cal = Calendar.getInstance();
        cal.setTime(inputDate);
        cal.add(Calendar.DAY_OF_YEAR, daysToAdd);
        userDate = cal.getTime();
        return userDate;
    }

    /**
     * 
     * This Method is used to add years to the selected date
     * 
     * @param inputDate
     * @param yearsToAdd
     * @return Processed date in Date format
     */
    public static Date addYears(final Date inputDate, final int yearsToAdd) {
        Date userDate;
        Calendar cal = Calendar.getInstance();
        cal.setTime(inputDate);
        cal.add(Calendar.YEAR, yearsToAdd);
        userDate = cal.getTime();
        return userDate;
    }

    /**
     * 
     * This Method is used to return current system date
     * 
     * @return Current System Date in Date format
     * @throws ParseException
     */
    public static Date getSystemDate() throws ParseException {
        Date date = new Date();
        return date;
    }
}