/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.DateUtil;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.models.OpenAccountDetails;
import com.hsbc.digital.testauto.pageobject.ca.OpenAccountVerify;

/***
 * <p>
 * <b> This model class will hold locators and functionality for Open Account
 * Verify page. </b>
 * </p>
 * 
 * @author SatyaPrakash S Vyas
 * @version 1.0.0
 */
public abstract class OpenAccountVerifyModel {

    private final WebDriverWait wait;
    protected final JavascriptExecutor jsx;


    @FindBy(xpath = "//div[@id='stackContainer']//h2[text()='Verify']")
    private WebElement headingVerifyPage;
    /**
     * Error Message List
     */
    @FindBy(xpath = "//div[@class='alertPanel error']")
    private List<WebElement> widgetErrors;

    @FindBy(xpath = "//*[contains(@data-dojo-attach-point,'ProductName')]")
    private WebElement appliedProductName;

    /**
     * Debit Account Name
     */
    @FindBy(xpath = "//*[@data-dojo-attach-point='_accountSelectedAtt']")
    private WebElement debitAccountName;

    /**
     * Debit Account Number
     */
    @FindBy(xpath = "//*[@data-dojo-attach-point='_accountSelectedAccNumberAtt']")
    protected WebElement debitAccountNumber;

    @FindBy(xpath = "//*[@data-dojo-attach-point='_accountTermSel']")
    private WebElement accountTerm;

    @FindBy(xpath = "//*[@data-dojo-attach-point='_currLozenge']/following-sibling::strong")
    private WebElement accountCurrencyLabel;

    @FindBy(xpath = "//*[@data-dojo-attach-point='_amountEnteredAtt']")
    private WebElement amountToDeposit;

    @FindBy(xpath = "//*[@data-dojo-attach-point='_effectiveDate']")
    private WebElement effectiveDateLabel;

    @FindBy(xpath = "//*[contains(@data-dojo-attach-point,'nterestRate')]")
    protected WebElement interestRateLabel;

    @FindBy(xpath = "//*[@data-dojo-attach-point='_interestAmount']")
    protected WebElement interestAmountField;

    @FindBy(xpath = "//*[@data-dojo-attach-point='_interestPaid']")
    private WebElement interestPaidLabel;

    /**
     * Credit Account Details
     */
    @FindBy(xpath = "//*[@data-dojo-attach-point='_interestCreditedTo']")
    private WebElement creditAccountName;

    @FindBy(xpath = "//*[@data-dojo-attach-point='_interestCreditedAccNum']")
    private WebElement creditAccountNumber;

    @FindBy(xpath = "//*[@data-dojo-attach-point='_maturityDate']")
    private WebElement maturityDateLabel;

    @FindBy(xpath = "//*[contains(@class,'btnPrimary')]//span[text()='Confirm']")
    private WebElement confirmButton;

    @FindBy(xpath = "//*[contains(@class,'btnTertiary') and @data-dojo-attach-point='cancelBtnNode']")
    private WebElement cancelButton;

    @FindBy(xpath = "//*[@data-dojo-attach-point='editBtnNode']")
    private WebElement editTheseDetailsButton;

    @FindBy(xpath = "//div[contains(@id,'hdx_dijits_Dialog_') and not (contains(@style,'display: none'))]//button[(@data-dojo-attach-point='_captureCancelYes')]")
    private WebElement cancelDialogYes;

    @FindBy(xpath = "//div[contains(@id,'hdx_dijits_Dialog_') and not (contains(@style,'display: none'))]//button[(@data-dojo-attach-point='_captureCancelNo')]")
    private WebElement cancelDialogNo;

    /**
     * Print button section
     */
    @FindBy(xpath = "//*[contains(@class,'btnTertiary') and contains(@data-dojo-attach-point,'_print')]")
    private WebElement printButton;

    @FindBy(xpath = "//div[contains(@id,'hdx_dijits_PrintFriendlyFormatDialog_') and not (contains(@style,'display: none'))]")
    private WebElement printDialog;

    @FindBy(xpath = "//div[contains(@id,'hdx_dijits_PrintFriendlyFormatDialog_') and not (contains(@style,'display: none'))]//button[@data-dojo-attach-point='closeButton']")
    private WebElement printDialogCancelButton;

    @FindBy(xpath = "//form[@name='_openTermAcctForm']")
    private WebElement openTDOptionsForm;

    @FindBy(xpath = "//*[@id='productsContainer']/div/div[1]/h2")
    private WebElement opennewTDTitleHeading;

    private static final String DATE_FORMAT_DDMMMYYYY = "dd MMM yyyy";
    private static final String SCROLL_TO_VIEW = "arguments[0].scrollIntoView(true);";

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(OpenAccountVerifyModel.class);

    public OpenAccountVerifyModel(final WebDriver driver) {
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, 10);
        jsx = (JavascriptExecutor) driver;
    }

    /**
     * Verifying title heading of the page
     */
    public void verifyTitle() {
        wait.until(ExpectedConditions.visibilityOf(headingVerifyPage));
    }

    /**
     * This is Generic Method to Verify Details on page
     * 
     * @param openAccount
     *            : OpenAccountDetails
     * @param envProperties
     *            : Map<String, String>
     * @param isTermInMonths
     *            : true/false
     */
    public void verifyDetails(final OpenAccountDetails openAccount, final Map<String, String> envProperties) {
        verifyTitle();
        if (!widgetErrors.isEmpty() && widgetErrors.get(0).isDisplayed()) {
            Assert.fail("Error message shown is: " + widgetErrors.get(0).getText());
        } else {
            String productName = openAccount.getProductName();
            AccountDetails debitAccount = openAccount.getDebitAccount();
            String selectedInvestmentAccount = openAccount.getInvestmentAccount();
            String selectedTerm = openAccount.getTermDuration();
            String currency = openAccount.getCurrency();
            Double selectedAmount = openAccount.getAmount();
            String maturityInstruction = openAccount.getMaturityInstruction();
            String maturityDate = openAccount.getMaturityDate();
            String interestRate = openAccount.getInterestRate();
            String additionalOnlineRate = openAccount.getAdditionalOnlineRate();
            String interestPaidInterval = openAccount.getInterestPaidInterval();
            AccountDetails creditAccount = openAccount.getCreditAccount();
            String totalRate = openAccount.getTotalRate();
            Boolean isTermInMonths = openAccount.getIsTermInMonths();

            validateProductName(productName);
            validateDebitAccount(debitAccount);
            validateInvestmentAccount(selectedInvestmentAccount);
            validateAccountCurrency(currency);
            // TODO : validateSelectedTerm(selectedTerm, isTermInMonths);
            validateSelectedAmount(selectedAmount);
            validateMaturityInstruction(maturityInstruction);
            // TODO :validateMaturityDate(maturityDate);
            validateEffectiveDate(envProperties);
            validateInterestRate(interestRate);
            validateInterestPaid(interestPaidInterval);
            validateCreditAccount(creditAccount);
            validateAdditionalOnlineRate(additionalOnlineRate);
            validateTotalRate(totalRate);
        }
    }

    public void validateProductName(final String productName) {
        Assert.assertTrue(isValueCorrect(productName, getProductNameElement(), false), "Product Name is not correct, Expected:- "
            + productName + " & Actual is:- " + getProductNameElement().getText());
        Reporter.log("Product Name matched.");
    }

    public void validateDebitAccount(final AccountDetails debitAccount) {
        Assert.assertTrue(
            isAccountVerified(debitAccount, debitAccountName, debitAccountNumber),
            "Debit Account Details are Not Same ,Expected: " + debitAccount.getAccountName() + ","
                + debitAccount.getAccountNumber() + " & Actual is :-" + debitAccountName.getText() + ","
                + debitAccountNumber.getText());
        Reporter.log("Debit Account Details matched.");
    }

    protected void validateInvestmentAccount(final String selectedInvestmentAccount) {
        // Do nothing. Handled in entity POM
    }

    public void validateAccountCurrency(final String currency) {
        if (currency != null) {
            Assert.assertTrue(isValueCorrect(currency, getAccountCurrencyElement(), false),
                "Account currency is not correct, Expected:- " + currency + " & Actual is:- "
                    + getAccountCurrencyElement().getText());
            Reporter.log("Currency matched.");
        }
    }

    public void validateSelectedTerm(final String selectedTerm, final Boolean isTermInMonths) {
        if (selectedTerm != null) {
            String term = selectedTerm;
            if (isTermInMonths && StringUtils.containsIgnoreCase(selectedTerm, "year")) {
                int noOfYears = Integer.parseInt(selectedTerm.split(" ")[0]);
                term = noOfYears * 12 + " Months";
            }
            Assert.assertTrue(isValueCorrect(term, accountTerm, false), "Account Term is not correct, Expected:- " + term
                + " & Actual is:- " + accountTerm.getText());
            Reporter.log("Term duration matched.");
        }
    }

    public void validateSelectedAmount(final Double selectedAmount) {
        if (selectedAmount != null) {
            Assert.assertTrue(isValueCorrect(selectedAmount, amountToDeposit), "Amount is not same, Expected:- " + selectedAmount
                + " & Actual is:- " + amountToDeposit.getText());
            Reporter.log("Amount matched.");
        }
    }

    protected void validateMaturityInstruction(final String maturityInstruction) {
        // Do nothing. Handled in entity POM
    }

    protected void validateMaturityDate(final String maturityDate) {
        // Do nothing. Handled in entity POM
    }

    public void validateEffectiveDate(final Map<String, String> envProperties) {
        if (envProperties != null) {
            String effectiveDate = StringUtils.EMPTY;
            String hubDate = envProperties.get("hubDate");
            String hubFormat = envProperties.get("hubFormat");
            try {
                effectiveDate = DateUtil.getDateToString(OpenAccountVerifyModel.DATE_FORMAT_DDMMMYYYY,
                    DateUtil.getStringToDate(hubFormat, hubDate));
            } catch (ParseException e) {
                OpenAccountVerify.logger.error("Error in Hub date.", e);
            }
            Assert.assertTrue(isValueCorrect(effectiveDate, effectiveDateLabel, false),
                "Effective Date does not match, Expected:- " + effectiveDate + " & Actual is:- " + effectiveDateLabel.getText());
            Reporter.log("Effective Date  matched.");
        }
    }

    public void validateInterestRate(final String interestRate) {
        if (interestRate != null) {
            Assert.assertTrue(isValueCorrect(interestRate, getInterestRateElement(), false),
                "Interest Rate is not same, Expected:- " + interestRate + " & Actual is:- " + getInterestRateElement().getText());
            Reporter.log("Interest Rate matched.");
        }
    }

    protected void validateInterestPaid(final String interestPaidInterval) {
        if (interestPaidInterval != null) {
            Assert.assertTrue(
                isValueCorrect(interestPaidInterval, interestPaidLabel, true),
                "Interest Paid interval is not same, Expected:- " + interestPaidInterval + " & Actual is:- "
                    + interestPaidLabel.getText());
            Reporter.log("Interest Paid interval matched.");
        }
    }

    protected void validateCreditAccount(final AccountDetails creditAccount) {
        if (creditAccount != null) {
            Assert.assertTrue(
                isAccountVerified(creditAccount, creditAccountName, creditAccountNumber),
                "Debit Account Details are Not Same ,Expected: " + creditAccount.getAccountName() + ","
                    + creditAccount.getAccountNumber() + " & Actual is :-" + creditAccountName.getText() + ","
                    + creditAccountNumber.getText());
            Reporter.log("Credit Account details matched.");
        }
    }

    protected void validateAdditionalOnlineRate(final String additionalOnlineRate) {
        // Do nothing. Handled in entity POM
    }

    protected void validateTotalRate(final String totalRate) {
        // Do nothing. Handled in entity POM
    }

    protected WebElement getProductNameElement() {
        return appliedProductName;
    }

    protected WebElement getAccountCurrencyElement() {
        return accountCurrencyLabel;
    }

    protected WebElement getInterestRateElement() {
        return interestRateLabel;
    }

    public String getMaturityDate() {
        jsx.executeScript(OpenAccountVerifyModel.SCROLL_TO_VIEW, maturityDateLabel);
        Reporter.log("Maturity date is: " + maturityDateLabel.getText());
        return maturityDateLabel.getText();
    }

    /**
     * This is Generic Method to Verify Account Details
     * 
     * @param accountDetails
     *            : Account Details
     * @param accountName
     *            : Confirmation Account Name
     * @param accountNumber
     *            : Confirmation Account Number
     * @return <b> true/false <b>
     */
    private boolean isAccountVerified(final AccountDetails accountDetails, final WebElement accountName,
        final WebElement accountNumber) {
        jsx.executeScript(OpenAccountVerifyModel.SCROLL_TO_VIEW, accountName);
        return accountDetails.getAccountName().equalsIgnoreCase(accountName.getText())
            && accountDetails.getAccountNumber().equalsIgnoreCase(accountNumber.getText());
    }

    /**
     * This is Generic Method to Verify String values
     * 
     * @param savedValue
     *            : Saved value in String
     * @param presentValue
     *            : Value present on page
     * @param checkByContains
     *            : true/false
     * @return <b> true/false <b>
     */
    protected boolean isValueCorrect(final String savedValue, final WebElement presentValue, final boolean checkByContains) {
        boolean flag;
        jsx.executeScript(OpenAccountVerifyModel.SCROLL_TO_VIEW, presentValue);
        if (checkByContains) {
            flag = StringUtils.contains(presentValue.getText(), savedValue);
        } else {
            flag = savedValue.equalsIgnoreCase(presentValue.getText());
        }
        return flag;
    }

    /**
     * This is Generic Method to Verify Double values
     * 
     * @param savedValue
     *            : Saved value in Double
     * @param presentValue
     *            :Value present on page as WebElement
     * @return <b> true/false <b>
     */
    protected boolean isValueCorrect(final Double savedValue, final WebElement presentValue) {
        jsx.executeScript(OpenAccountVerifyModel.SCROLL_TO_VIEW, presentValue);
        return savedValue == Double.parseDouble(presentValue.getText());
    }

    /**
     * This method clicks T&C checkbox for accepting terms and conditions on
     * verify page.
     */

    public void clickTnCCheckbox() {}

    /**
     * This method checks Print functionality on verify page.
     */
    private void clickPrintButton() {
        printButton.click();
        printDialog.isDisplayed();
        printDialogCancelButton.click();
        Reporter.log("Print button is clicked on verify Page.");
    }

    /**
     * This method clicks Confirm button on verify page.
     */
    public void clickConfirmButton() {
        confirmButton.click();
        Reporter.log("Confirm button clicked. | ");
    }

    /**
     * This method clicks Edit these details button on verify page.
     */
    public void clickEditDetailsButton() {
        wait.until(ExpectedConditions.elementToBeClickable(editTheseDetailsButton));
        editTheseDetailsButton.click();
        Assert.assertTrue(openTDOptionsForm.isDisplayed(), "Options page not shown for Open TD.");
        Reporter.log("Edit These Details button on verify page clicked and Options page shown.");
    }

    public void clickCancelButton(final boolean isCancel) {
        cancelButton.click();
        if (isCancel) {
            cancelDialogYes.click();
            wait.until(ExpectedConditions.visibilityOf(opennewTDTitleHeading));
            jsx.executeScript(OpenAccountVerifyModel.SCROLL_TO_VIEW, opennewTDTitleHeading);
            Reporter.log("Cancel button - Continue clicked and Product details page shown.");
        } else {
            cancelDialogNo.click();
            wait.until(ExpectedConditions.visibilityOf(headingVerifyPage));
            Reporter.log("Verify Page shown after clicking Cancel button - Cancel clicked.");
        }
    }

    /**
     * @return interestRate
     */
    public String getInterestRate() {
        Reporter.log("Interest rate is: " + interestRateLabel.getText());
        return interestRateLabel.getText();
    }

    /**
     * Print interest rate
     * 
     * @return interestAmount : String
     */
    public String getInterestAmount() {
        Reporter.log("Interest amount is: " + interestAmountField.getText());
        return interestAmountField.getText();
    }

    /**
     * Contains verify page methods for TD products
     * 
     * @param openAccount
     * @param envProperties
     */
    public void openTDProductVerifyPage(final OpenAccountDetails openAccount, final Map<String, String> envProperties) {
        verifyDetails(openAccount, envProperties);
        openAccount.setInterestAmount(getInterestAmount());
        openAccount.setMaturityDate(getMaturityDate());
        clickTnCCheckbox();
        clickPrintButton();
        clickConfirmButton();
    }

    /**
     * Contains verify page methods for US TD product
     * 
     * @param openAccount
     * @param envProperties
     */
    public void openUSTermDepositVerifyPage(final OpenAccountDetails openAccount, final Map<String, String> envProperties) {
        verifyDetails(openAccount, envProperties);
        openAccount.setMaturityDate(getMaturityDate());
        clickPrintButton();
        clickConfirmButton();
    }

    /**
     * Contains verify page methods for products
     * 
     * @param openAccount
     * @param envProperties
     */
    public void openAccountVerifyPage(final OpenAccountDetails openAccount, final Map<String, String> envProperties) {
        verifyDetails(openAccount, envProperties);
        openAccount.setInterestAmount(getInterestAmount());
        clickPrintButton();
        clickConfirmButton();
    }

    /**
     * <p>
     * <b> TODO : Insert description of the method's responsibility/role. </b>
     * </p>
     * 
     * @param objOpenAccountDetails
     */
    public void verifyReviewPageForSaving(final OpenAccountDetails objOpenAccountDetails) {
        // TODO Auto-generated method stub

    }

    /**
     * <p>
     * <b> TODO : Insert description of the method's responsibility/role. </b>
     * </p>
     * 
     * @param objOpenAccountDetails
     */
    public void verifyReviewPageForTermDeposit(final OpenAccountDetails objOpenAccountDetails) {
        // TODO Auto-generated method stub

    }

    /**
     * <p>
     * <b> TODO : Insert description of the method's responsibility/role. </b>
     * </p>
     * 
     */
    public void cancelFlowFromVerify() {
        // TODO Auto-generated method stub

    }

    /**
     * <p>
     * <b> TODO : Insert description of the method's responsibility/role. </b>
     * </p>
     * 
     */
    public void clicksConfirmButton() {
        // TODO Auto-generated method stub

    }

    public void selectTermAndConditionVerifyPage() {}
}
