package com.hsbc.digital.testauto.pageobject;

/*
 * This is POJO class for Story15-SecureMessaging Author- Aniket Chinake
 */
public class SecureMessage {
    private String accountNumber;
    private String accountName;
    private String problemReason;
    private String paymentAmount;
    private String payeeName;
    private String additionalComments;
    private String typeOfTransaction;
    private String problemWithTransaction;
    private String apprPostingDate;
    private String paymentFrequency;

    public void setAccountNumber(final String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountName(final String accountName) {
        this.accountName = accountName;
    }

    public String getAccountName() {
        return this.accountName;
    }

    public void setProblemReason(final String problemReason) {
        this.problemReason = problemReason;
    }

    public String getProblemReason() {
        return this.problemReason;
    }

    public void setPaymentAmount(final String paymentAmount) {
        this.paymentAmount = paymentAmount;
    }

    public String getPaymentAmount() {
        return this.paymentAmount;
    }

    public void setPayeeName(final String payeeName) {
        this.payeeName = payeeName;
    }

    public String getPayeeName() {
        return this.payeeName;
    }

    public void setAdditionalComments(final String additionalComments) {
        this.additionalComments = additionalComments;
    }

    public String getAdditionalComments() {
        return this.additionalComments;
    }

    public void setTypeOfTxn(final String typeOfTransaction) {
        this.typeOfTransaction = typeOfTransaction;
    }

    public String getTypeOfTxn() {
        return typeOfTransaction;
    }

    public void setProblemWithTxn(final String problemWithTransaction) {
        this.problemWithTransaction = problemWithTransaction;
    }

    public String getProblemWithTxn() {
        return problemWithTransaction;
    }

    public void setApprPostingDate(final String apprPostingDate) {
        this.apprPostingDate = apprPostingDate;
    }

    public String getApprPostingDate() {
        return apprPostingDate;
    }

    public void setPaymentFreq(final String paymentFrequency) {
        this.paymentFrequency = paymentFrequency;
    }

    public String getPaymentFreq() {
        return paymentFrequency;
    }

}
