/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject;

import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

/**
 * <p>
 * <b> This Model class will hold locators and functionality related methods
 * for Story Report Lost Or Stolen Card that can be used around all entities
 * </b>
 * </p>
 * 
 * @version 1.0.0
 * @author Deepti Patil
 * 
 */
public abstract class ReportLostOrStolenCardModel {

    private final WebDriver driver;

    // Locator for list of Accounts in Account Summary Section
    @FindBy(xpath = "//div[contains(@id,'TitlePane')]/span[@isgspentity='yes']")
    private List<WebElement> accountsLists;

    // Locator for report Lost Stolen Card Link on manage tab
    @FindBy(xpath = "//div[contains(@class,'manage')]//a[contains(text(),'lost or stolen card')]")
    private List<WebElement> reportLostStolenCardLink;

    // Locator for card Services Title on manage tab
    @FindBy(xpath = "//strong[contains(text(),'Card services')]")
    private WebElement cardServicesTitle;

    // Locator for close button on report Lost Or Stolen Card Dialog box
    @FindBy(xpath = "//div[contains(@id,'Dialog') and not(contains(@style,'display: none'))]//input[@value='Close']")
    private WebElement closeButton;

    // Locator for Manage button on overview section
    @FindBy(xpath = "//button[contains(@class,'manage') and @aria-hidden='false']")
    private List<WebElement> manageButtonList;

    // Locator for dashboard page
    @FindBy(xpath = "//*[@id='_dashboardHeading']/h1/span")
    private WebElement dashboardPage;

    // Locator for report Lost Or Stolen Card Title on dialog box
    @FindBy(xpath = "//div[contains(@id,'Dialog') and not(contains(@style,'display: none'))]//div[contains(@class,'lostStolenCard')]//h2")
    private WebElement reportLostOrStolenCardTitle;

    // Locator for report Lost Or Stolen disclaimer
    @FindBy(xpath = "//div[contains(@id,'Dialog') and not(contains(@style,'display: none'))]//p[contains(@class,'Disclaimer')]")
    private WebElement disclaimer;

    // Locator for report Lost Or Stolen Contact numbers
    @FindBy(xpath = "//div[contains(@id,'Dialog') and not(contains(@style,'display: none'))]//ul")
    private WebElement contactDetails;

    public ReportLostOrStolenCardModel(final WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    /**
     * Method to verify report Lost Card Footer Menu Flow.
     * 
     */
    public void reportLostCardFooterMenuFlow() {}

    /**
     * Method to verify report Lost Card Manage Flow.
     * 
     */
    public void reportLostCardManageFlow() {
        selectingAccount();
        clickReportLostOrStolenCardLink();
        isReportLostOrStolenCardDialogDisplayed();
        clickCloseButton();
    }

    /**
     * Method to click on close button on report Lost Card dialog box.
     * 
     */
    public void clickCloseButton() {
        scrollToWebElement(closeButton);
        closeButton.click();
        Reporter.log("Clicked on Close button. ");
    }

    /**
     * Method to scroll.
     * 
     * @param webElement
     */
    public void scrollToWebElement(final WebElement element) {
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
    }

    /**
     * Method to select account on dashboard page.
     * 
     */
    public void selectingAccount() {
        for (WebElement account : accountsLists) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", account);
            account.click();
            Reporter.log("Account Selected is: " + account.getText());
            if (getManageButtonList().isEmpty()) {
                Reporter.log("Manage button not displayed for selected account. Please select another account. ");
            } else {
                clickManageButton();
                if (isReportLostOrStolenCardLinkDisplayed()) {
                    break;
                }
            }
        }
    }

    public List<WebElement> getManageButtonList() {
        return manageButtonList;
    }

    /**
     * Method to click on manage button on overview section.
     * 
     */
    public void clickManageButton() {
        Reporter.log("Clicking manage button");
        if (dashboardPage.isDisplayed()) {
            getManageButtonList().get(0).click();
            Reporter.log("Manage button clicked.");
        } else {
            Assert.fail("Manage button is not getting displayed");
        }
    }

    /**
     * Method to check if Report Lost Or Stolen Card Link is Displayed on
     * manage section.
     * 
     */
    public boolean isReportLostOrStolenCardLinkDisplayed() {
        Assert.assertTrue(!reportLostStolenCardLink.isEmpty(), "Report Lost Or Stolen Card Link not displayed. ");
        Reporter.log("Report Lost Or Stolen Card link is displayed. ");
        return true;
    }

    /**
     * Method to click on Report Lost Or Stolen Card Link on manage section
     * 
     */
    public void clickReportLostOrStolenCardLink() {
        if (cardServicesTitle.isDisplayed()) {
            reportLostStolenCardLink.get(0).click();
            Reporter.log("Report lost Or stolen card link clicked. ");
        } else {
            Reporter.log("Link not found. ");
        }
    }

    /**
     * Method to check if Report Lost Or Stolen Card Dialog box is Displayed.
     * 
     */
    public void isReportLostOrStolenCardDialogDisplayed() {
        Assert.assertTrue(reportLostOrStolenCardTitle.isDisplayed(), "Report Lost Or Stolen Card Dialog not displayed. ");
        Reporter.log("Report Lost Or Stolen Card Dialog is displayed. ");
    }

    /**
     * Method to check if Disclaimer message is Displayed.
     * 
     */
    public void isDisclaimerDisplayed() {
        Assert.assertTrue(disclaimer.isDisplayed(), "Disclaimer message not displayed. ");
        Reporter.log("Disclaimer message is displayed. ");
    }

    /**
     * Method to check if Contact details is Displayed.
     * 
     */
    public void isContactDetailsDisplayed() {
        Assert.assertTrue(contactDetails.isDisplayed(), "Contact details not displayed. ");
        Reporter.log("Contact details is displayed. ");
    }
}
