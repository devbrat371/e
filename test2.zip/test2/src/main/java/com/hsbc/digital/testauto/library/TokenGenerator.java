/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.library;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

import org.apache.commons.lang3.StringUtils;

/**
 * 
 * <p>
 * <b> This class will provide Secure token for user authentication and
 * transaction signing tokens for DP270. </b>
 * </p>
 * 
 * @author Shrikant Joshi
 * @version 1.0.0
 */
public class TokenGenerator {

    private static final String DP_CLOUD_URL = "http://cn000glt0075.cn.hsbc/publicapi/token";
    private static final String PARAM_USER_NAME = "username";
    private static final String PARAM_TYPE = "type";
    private static final String PARAM_KEY = "key";
    private static final String PARAM_ACCOUNT = "account";
    private static final String PARAM_MIN = "min";
    private static final int OTP_TYPE = 1;
    private static final int OTP_TYPE_REAUTH = 2;
    private static final int ACCOUNT_TDS_TYPE = 3;
    private static final String PARAM_SEPERATOR = "&";
    private static final String VALUE_SEPERATOR = "=";

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(TokenGenerator.class);


    /**
     * 
     * <p>
     * <b> Method to get Token while login into the application. </b>
     * </p>
     * 
     * @param userName
     *            - Profile of user
     * @param serialno
     *            - Profile serial number
     * @param otpkey
     *            - Access key
     * @return Secure Token
     * @throws IOException
     */
    public String generateOTP(final String userName, final String serialno, final String otpkey) throws IOException {
        String otp = StringUtils.EMPTY;
        try {
            otp = getOTP(userName, otpkey);
        } catch (NumberFormatException e) {
            TokenGenerator.logger.error("Exception thrown:", e);
            otp = getOTP(userName + "_" + serialno, otpkey);
        } catch (Exception e) {
            TokenGenerator.logger.error("Exception thrown:", e);
        }
        return otp;
    }

    public String getOTP(final String userName, final String otpkey) throws IOException {
        String otp;
        do {
            otp = processRequest(buildTokenURL(userName, otpkey, null));
        } while (!(otp.length() == 6));
        return otp;
    }

    /**
     * 
     * <p>
     * <b> Returns Transaction signin code for user transactions based on given
     * account number with last 8 digits. </b>
     * </p>
     * 
     * @param userName
     *            - Profile name
     * @param otpkey
     *            - Access key
     * @param refAccountNumber
     * @return Transaction signin token
     * @throws IOException
     */
    public String getTransactionTDS(final String userName, final String otpkey, final String refAccountNumber) throws IOException {
        String otp;
        do {
            otp = processRequest(buildTokenURL(userName, otpkey, refAccountNumber));
        } while (!(otp.length() == 6));
        return otp;
    }

    /**
     * 
     * <p>
     * <b> Method to send URL request and get the response. this method is used
     * for internal purpose only. </b>
     * </p>
     * 
     * @param url
     *            - URL to invoke
     * @return Token received from Cloud
     * @throws IOException
     */
    private String processRequest(final String url) throws IOException {
        URL dpcloud = new URL(url);
        TokenGenerator.logger.info("req URL:" + url);
        URLConnection yc = dpcloud.openConnection();
        yc.setConnectTimeout(50000);
        BufferedReader in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
        String inputLine = in.readLine();
        int token = Integer.parseInt(inputLine.replaceAll("[\\D]", ""));
        in.close();
        return String.valueOf(token);
    }

    private String buildTokenURL(final String userName, final String otpKey, final String refAccountNumber) {
        String tokenString = PARAM_TYPE
            + VALUE_SEPERATOR
            + (refAccountNumber == null ? +OTP_TYPE : ACCOUNT_TDS_TYPE + PARAM_SEPERATOR + PARAM_ACCOUNT + VALUE_SEPERATOR
                + refAccountNumber);
        return new StringBuilder().append(DP_CLOUD_URL).append("?").append(PARAM_USER_NAME).append(VALUE_SEPERATOR)
            .append(userName).append(PARAM_SEPERATOR).append(PARAM_KEY).append(VALUE_SEPERATOR).append(otpKey)
            .append(PARAM_SEPERATOR).append(tokenString).append(PARAM_SEPERATOR).append(PARAM_MIN).append(VALUE_SEPERATOR)
            .append("Y").toString();
    }

    /**
     * 
     * <p>
     * <b> Method to get Reauth Code </b>
     * </p>
     * 
     * @param userName
     *            - Profile of user
     * @param serialno
     *            - Profile serial number
     * @param otpkey
     *            - Access key
     * @return Secure Token
     * @throws IOException
     */
    public String generateReauthCode(final String userName, final String serialno, final String otpkey) throws IOException {
        String otp = StringUtils.EMPTY;
        try {
            otp = getReauthCode(userName, otpkey);
        } catch (NumberFormatException e) {
            TokenGenerator.logger.error("Exception thrown:", e);
            otp = getReauthCode(userName + "_" + serialno, otpkey);
        } catch (Exception e) {
            TokenGenerator.logger.error("Exception thrown:", e);
        }
        return otp;

    }

    public String getReauthCode(final String userName, final String otpkey) throws IOException {
        String otp;
        do {
            otp = processRequest(buildURLForReauthCode(userName, otpkey));
        } while (!(otp.length() == 6));
        return otp;
    }

    private String buildURLForReauthCode(final String userName, final String otpKey) {
        String tokenString = PARAM_TYPE + VALUE_SEPERATOR + (OTP_TYPE_REAUTH + PARAM_SEPERATOR);
        return new StringBuilder().append(DP_CLOUD_URL).append("?").append(PARAM_USER_NAME).append(VALUE_SEPERATOR)
            .append(userName).append(PARAM_SEPERATOR).append(tokenString).append(PARAM_KEY).append(VALUE_SEPERATOR).append(otpKey)
            .append(PARAM_SEPERATOR).append(PARAM_MIN).append(VALUE_SEPERATOR).append("Y").toString();
    }
}
