package com.hsbc.digital.testauto.pageobject.prd;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.hsbc.digital.testauto.pageobject.DownloadStatementHistoryModel;

/**
 * <p>
 * <b> This class will hold locators and specific implementation for Download
 * Statement History for PRD entity. </b>
 * </p>
 */
public class DownloadStatementHistory extends DownloadStatementHistoryModel {

    public DownloadStatementHistory(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }
}
