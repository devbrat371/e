package com.hsbc.digital.testauto.pageobject.us;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.pageobject.AddBeneficiaryModel;

public class AddBeneficiary extends com.hsbc.digital.testauto.pageobject.AddBeneficiaryModel {
    protected final WebDriverWait wait;
    private final JavascriptExecutor jsx;

    private static final String ENTITY_BANK_COUNTRY = "US";

    private final By locatorCompanyPayeeName = By
        .xpath("//div[starts-with(@id,'gridx_Grid_')]//td[contains(@class,'payeeName')]/span[2]");


    public AddBeneficiary(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, 30000);
        jsx = (JavascriptExecutor) driver;
    }


    /**
     * method starts from here @author Md Tanbir Hossain
     */
    @Override
    protected List<AccountDetails> validCompanyPayeeDetails() {
        List<AccountDetails> storeAccountValue = new ArrayList<>();
        storeAccountValue.clear();
        List<WebElement> payeeList = driver.findElements(locatorAllPayeesRow);
        if (!payeeList.isEmpty()) {
            for (WebElement payee : payeeList) {
                jsx.executeScript(AddBeneficiaryModel.SCROLL_TO_VIEW, payee);
                if (payee.findElement(locatorPayeeType).getAttribute("alt").equalsIgnoreCase(AddBeneficiaryModel.COMPANY_PAYEE)) {
                    String companyPayeeName = payee.findElement(this.locatorCompanyPayeeName).getText();
                    String companyPayeeNumber = payee.findElement(
                        By.xpath("//div[starts-with(@id,'gridx_Grid_')]//td[contains(@class,'payeeName')]/span[text()='"
                            + companyPayeeName + "']/parent::*//span[1]")).getText();
                    AccountDetails accountInformations = new AccountDetails();
                    accountInformations.setAccountName(companyPayeeName);
                    accountInformations.setAccountNumber(companyPayeeNumber);
                    storeAccountValue.add(accountInformations);
                }
            }
        }
        return storeAccountValue;
    }

    @Override
    protected String getEntityBankCountry() {
        return ENTITY_BANK_COUNTRY;
    }
}
