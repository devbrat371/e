/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.DateUtil;
import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.models.AccountDetails;


/***
 * <p>
 * <b> This model class will hold locators and functionality for Download
 * Statement History page. </b>
 * </p>
 * 
 * @author Midde Rajesh Kumar
 * @version 1.0.0
 */

public abstract class DownloadStatementHistoryModel {

    protected final WebDriver driver;
    WebDriverWait wait;

    /* ********** This section is for statement and advice section  ***********  */

    @FindBy(xpath = "//table[@id='group_gpib_newstmt_bijit_StatementDownload_0_Account']/tbody/tr/td[2]")
    private WebElement accountDropDownIcon;

    @FindBy(xpath = "//div[contains(@class,'dijitSelectMenu')]")
    private WebElement accountDropDownItems;

    @FindBy(xpath = "//div[contains(@id,'StatementDownload')]/following::tr[starts-with(@id,'dijit_MenuItem_')]")
    protected List<WebElement> tempDropdownList;

    @FindBy(xpath = "//table[@id='selectByDate']/tbody/tr/td[2]")
    private WebElement dateDropDownIcon;

    @FindBy(xpath = "//div[contains(@class,'dijit dijitReset dijitInline dijitLeft dijitDownArrowButton dijitSelectMenu dijitSelect dijitValidationTextBox')]")
    private WebElement dateDropDownItems;

    @FindBy(xpath = "//div[contains(@dijitpopupparent,'selectByDate')]/div/div/div[contains(@id,'selectByDate_')]/table/tbody/tr")
    List<WebElement> dateDropdownList;

    @FindBy(xpath = "//*[contains(@class,'iconButton viewDownload')]")
    private WebElement downloadButton;

    @FindBy(xpath = "//div[contains(@data-dojo-attach-point,'statementDownloadList')]/span")
    private WebElement downloadStatementList;

    /* This section is for The result data */

    @FindBy(xpath = "//div[contains(@data-dojo-attach-point,'statementDownloadList')]/div[contains(@id,'StatementDownloadItem_')]")
    protected List<WebElement> resultedList;
    // Not able to capture element due to unavailability of test data
    @FindBy(xpath = "")
    private WebElement noTransactionHistoryMessage;

    protected String selectedYear;
    public static final String EXPECTEDERRORMESSAGE = "No Transaction History";


    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(DownloadStatementHistoryModel.class);


    public DownloadStatementHistoryModel(final WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    /**
     * 
     * This method is for selection the Account from the drop down list
     * 
     */
    public void selectAccountFromDropDownList() {
        selectFromDropDown(accountDropDownIcon, tempDropdownList);
    }

    public void selectFromDropDown(final WebElement dropDownIconElement, final List<WebElement> tempDropdownList) {
        dropDownIconElement.click();
        int listCount = tempDropdownList.size();
        int selectedElementNumber = RandomUtil.generateIntNumber(1, listCount);
        for (int count = 1; count < listCount; count++) {
            WebElement tempAccDropDown = tempDropdownList.get(count);
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", tempAccDropDown);
            if (count == selectedElementNumber) {
                Reporter.log("Dropdown Selected:" + tempAccDropDown.getText());
                tempAccDropDown.click();
                break;
            }

        }
    }

    public AccountDetails selectYearFromDropdown() {
        AccountDetails accountDetails = new AccountDetails();
        selectedYear = selectYearFromDropDownList(dateDropdownList);
        accountDetails.setSelectedYear(selectedYear);
        Reporter.log("Year: " + selectedYear + " selected from Search By Date List");
        return accountDetails;
    }

    /**
     * 
     * This method is for selection the year from the drop down list
     * 
     */
    public String selectYearFromDropDownList(final List<WebElement> dateList) {
        dateDropDownIcon.click();
        String selectedDate = StringUtils.EMPTY;
        int datelistCount = dateList.size();
        int selectedElementNumber = RandomUtil.generateIntNumber(0, datelistCount);
        for (int count = 0; count < datelistCount; count++) {
            WebElement tempAccDropDown = dateList.get(count);
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", tempAccDropDown);
            if (count == selectedElementNumber) {
                selectedDate = tempAccDropDown.getText();
                Reporter.log("Dropdown Selected:" + selectedDate);
                tempAccDropDown.click();
                break;
            }
        }
        return selectedDate;
    }

    /**
     * 
     * This method is to verify the download button functionality
     * 
     * @throws InterruptedException
     * 
     */
    public void clickAndVerifyDownloadTransaction() throws InterruptedException {
        int currentWindowCount = driver.getWindowHandles().size();
        downloadButton.click();
        int newWindowCount = driver.getWindowHandles().size();
        Assert.assertTrue(newWindowCount > currentWindowCount, "DownLoad Page Opened");
    }

    /**
     * 
     * This method is for verifying if no history statements are avialable
     * 
     */
    public void verifyNoTransactionHistoryMessage() {
        Assert.assertTrue(noTransactionHistoryMessage.isDisplayed(), "There are no Transactions avilable");
        Reporter.log("No Statement Transaction History Message displayed");
    }

    /**
     * 
     * This method is to select notification channel preference
     * 
     */

    public void notificationChannelPreference() {
        Reporter.log("Please call the notification prference methods here");
    }

    /**
     * 
     * This method is to notify the user by sms
     * 
     */
    public void userIsNotifiedBySms() {
        Reporter.log("Please check Your Cell for Confirmation");
    }

    /**
     * 
     * This method is to notify the user by email
     * 
     */
    public void userIsNotifiedByEmail() {
        Reporter.log("Please check Your Mail for Confirmation");
    }

    /**
     * This functionality is not yet implemented
     * 
     * 
     */
    public void selectFutrueDateToTerminateAlerts() {

    }

    /**
     * This functionality is to print the List of dates
     * 
     * 
     */

    public void verifyDateDropDownList() {
        dateDropDownIcon.click();
        List<WebElement> datesDropdownList = dateDropdownList;
        for (WebElement elem : datesDropdownList) {
            Reporter.log("Date DropDown Options: " + elem.getText());
        }
    }

    /**
     * This is to get the input format for the respective entity
     * 
     * @return
     */
    public String getOutputFormat() {
        return DateUtil.DATE_FORMAT_DDMMMYYYY;
    }

    /**
     * 
     * This method is for verifying the order of displayed transaction history
     * 
     */
    public void verifyOrderofDisplay() {
        String firstDateDisplayes = StringUtils.EMPTY;
        String nextDateDisplayes = StringUtils.EMPTY;
        Date firstDate = null;
        Date nextDate = null;
        if (selectedYear.contains(firstDateDisplayes)) {
            for (int i = 0; i < resultedList.size() - 1; i++) {
                firstDateDisplayes = resultedList.get(i).findElement(By.tagName("span")).getText();
                nextDateDisplayes = resultedList.get(i + 1).findElement(By.tagName("span")).getText();
                try {
                    firstDate = DateUtil.getStringToDate(getOutputFormat(), firstDateDisplayes);
                    nextDate = DateUtil.getStringToDate(getOutputFormat(), nextDateDisplayes);
                } catch (ParseException e) {
                    DownloadStatementHistoryModel.logger.error("Date Format Conversion Error", e);
                }
                if (firstDate.after(nextDate) || firstDate.equals(nextDate)) {
                    Reporter.log("Statement History Displayed in correct Order");
                } else {
                    Reporter.log("Statement History Displayed is not in correct Order");
                }
            }
        } else if (("Latest").equalsIgnoreCase(selectedYear)) {
            {
                for (int i = 0; i < resultedList.size() - 1; i++) {
                    firstDateDisplayes = resultedList.get(i).findElement(By.tagName("span")).getText();
                    nextDateDisplayes = resultedList.get(i + 1).findElement(By.tagName("span")).getText();
                    try {
                        firstDate = DateUtil.getStringToDate(getOutputFormat(), firstDateDisplayes);
                        nextDate = DateUtil.getStringToDate(getOutputFormat(), nextDateDisplayes);
                    } catch (ParseException e) {
                        DownloadStatementHistoryModel.logger.error("Date Format Conversion Error", e);
                    }
                    if (firstDate.after(nextDate)) {
                        Reporter.log("Statement History Displayed in correct Order");
                    } else {
                        Reporter.log("Statement History Displayed is not in correct Order");
                    }
                }
            }
        }
    }
}
