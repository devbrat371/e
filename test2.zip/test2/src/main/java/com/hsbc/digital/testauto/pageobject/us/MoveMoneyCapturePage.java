package com.hsbc.digital.testauto.pageobject.us;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.FileUtil;
import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.models.Transaction;
import com.hsbc.digital.testauto.pageobject.MoveMoneyCapturePageModel;

public class MoveMoneyCapturePage extends MoveMoneyCapturePageModel {

    protected static final String ENTITY_BANK_COUNTRY = "United states of america";
    private static final String SCROLL_TO_VIEW = "arguments[0].scrollIntoView(true);";
    private static final String COUNTRY_US = "United states";
    protected static final String VALIDEMAILADDRESS = "tESTUSER@ABC.COM";
    protected static final String UNTILFURTHERNOTICE = "Until further notice";
    private final JavascriptExecutor jsx;
    private static final String COMPANY_PAYEE_DETAIL_ENTITY = "us";

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(MoveMoneyCapturePage.class);


    // *************************** Transaction end date dropdown
    // .//div[text()='Transaction end
    // date']//following-sibling::div[contains(@class,'dijit dijitReset
    // dijitInline dijitLeft dijitDownArrowButton')]
    @FindBy(xpath = ".//*[text()='Transaction end date']//following-sibling::div[contains(@class,'dijitSelectMenu selectDropDown')]/table//td[2]/input")
    private WebElement transactionEndDate;

    // ************************ Payee Search Options Fill up
    // ********************
    @FindBy(xpath = "//div[@class='alertPanel info']/p")
    private WebElement addNewPayeeDisclaimer;
    @FindBy(xpath = "//input[starts-with(@id,'companyName')]")
    private WebElement companyNameTxt;
    @FindBy(xpath = ".//input[starts-with(@id,'zipCodeLabel')]")
    private WebElement companyZipTxt;
    @FindBy(xpath = ".//input[starts-with(@id,'actNumLabel')]")
    private WebElement accountNumberTxt;
    @FindBy(xpath = ".//input[starts-with(@id,'confirmActNumLabel')]")
    private WebElement confirmAccountNumberTxt;
    @FindBy(xpath = "//button[@value='Search Payee' and @class='btnSecondary']")
    private WebElement searchPayeeBtn;
    @FindBy(xpath = "//button[@data-dojo-attach-point='_searchPayee']")
    private WebElement searchCompanyPayeeBtn;

    // **************************** Add Payee Options Pop UP
    // ************************
    @FindBy(xpath = "//div[@class='searchDialog']/h1")
    private WebElement searchPayeePopUpTxt;
    @FindBy(xpath = "//div[contains(@class,'gridxRow')]")
    private List<WebElement> searchedPayeeList;
    @FindBy(xpath = ".//button[contains(@class,'addPayee')]")
    private List<WebElement> addPayeeBtn;
    @FindBy(xpath = ".//button[@data-dojo-attach-point='_addPayeeManual']")
    private WebElement addPayeeManuallyBtn;

    // ***************************** After Selecting Existing Searched Payee
    // ****************************
    @FindBy(xpath = "//td[@class='gridxCell']/div/label")
    private List<WebElement> payeeNameLabel;
    @FindBy(xpath = "//span[@data-dojo-attach-point='_BillPayeeNameValue']")
    private WebElement payeeNameValue;
    @FindBy(xpath = "//div[@class='addressSeperator']")
    private WebElement payeeAdressValue;
    @FindBy(xpath = ".//input[contains(@id,'_teleNo')]")
    private WebElement payeeTelephoneNumberTxt;

    // ****************************** After Selecting Manually Add Payee
    // ************************
    @FindBy(xpath = "//input[contains(@id,'payeeNameLabel')]")
    private WebElement addManualPayeeName;
    @FindBy(xpath = ".//input[contains(@id,'addressLabel')]")
    private WebElement addPayeeFirstAddress;
    @FindBy(xpath = ".//input[contains(@id,'addressLabel1')]")
    private WebElement addPayeeSecondAddress;
    @FindBy(xpath = ".//input[contains(@id,'cityLabel')]")
    private WebElement addManuallyPayeeCity;
    @FindBy(xpath = "//div[contains(@class,'stateField')]//td[contains(@class,'dijitArrowButton')]")
    private WebElement payeeStateDropDownArrow;
    @FindBy(xpath = "//div[contains(@id,'Select_')]//tr")
    private List<WebElement> payeeStateList;
    @FindBy(xpath = ".//input[contains(@id,'_zipCodeLabel')]")
    private WebElement addManuallyPayeeZip;
    @FindBy(xpath = ".//input[contains(@id,'_BillPayeeAccountNum')]")
    private WebElement toPayeeAccountNumber;
    @FindBy(xpath = ".//input[contains(@id,'confirmBillPayeeAccountNum')]")
    private WebElement confirmPayeeAccountNumber;
    @FindBy(xpath = ".//input[contains(@id,'telephoneLabel')]")
    private WebElement addManuallyPayeeTelephone;

    @FindBy(xpath = "//div[@data-dojo-attach-point='_purposeOfTransactionAttr']//input[contains(@class,'dijitArrowButtonInner')]")
    private WebElement reasonForTransactionIcon;

    public MoveMoneyCapturePage(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
        jsx = (JavascriptExecutor) driver;
    }

    /**
     * method to check if the acc is valid for US entity
     * 
     * @author Md Tanbir Hossain
     */
    @Override
    protected boolean isValidAccount(final boolean domesticAccount, final String entity, final String accountlocation) {

        return (domesticAccount && accountlocation.equalsIgnoreCase(MoveMoneyCapturePage.COUNTRY_US))

        || (!domesticAccount && !accountlocation.equalsIgnoreCase(entity));
    }

    @Override
    protected void selectPayee(final WebElement myPayeeDropIcon, final WebElement payeeList, final String accName,
        final String accNumber) {
        myPayeeDropIcon.click();
        wait.until(ExpectedConditions.visibilityOf(payeeList));
        List<WebElement> payeesRows = payeeList.findElements(menuPopup);
        for (WebElement payee : payeesRows) {
            jsx.executeScript(MoveMoneyCapturePage.SCROLL_TO_VIEW, payee);
            if (payee.getText().contains(accName)) {
                WebElement payeeAccountNumber = driver.findElements(locatorPayeeAccountNumber).isEmpty() ? driver
                    .findElement(locatorSelectedPayeeAccountNumber) : driver.findElement(locatorPayeeAccountNumber);

                if (payeeAccountNumber.getText().replaceAll(" ", "").equals(accNumber)) {
                    payee.click();
                    uiCommonUtil.activeElement(amountLabel).click();
                    break;
                }
            }
        }
    }

    /**
     * @author Md Tanbir Hossain method to check if the selected acc is correct
     * 
     */
    @Override
    protected void isValidAccInFromDropDown(final WebElement myPayeeDropIcon, final WebElement payeeList, final String accName,
        final String accNumber, final String currencyCode) {
        boolean flag = false;
        int i = 1;
        myPayeeDropIcon.click();
        do {
            wait.until(ExpectedConditions.visibilityOf(payeeList));
            List<WebElement> payeesRows = payeeList.findElements(menuPopup);
            for (WebElement payee : payeesRows) {
                jsx.executeScript(MoveMoneyCapturePage.SCROLL_TO_VIEW, payee);
                if (payee.getText().contains(accName)) {
                    comparePayeeNameAndNo(accName, accNumber);
                    payee.click();
                    uiCommonUtil.activeElement(amountLabel).click();
                    flag = true;
                    break;
                }
            }
            if (!flag) {
                selectDomesticFromLCYAccount(currencyCode);
                myPayeeDropIcon.click();
            } else {
                i = 5;
            }
            i++;
        } while (i <= 5 && !flag);
    }

    protected void comparePayeeNameAndNo(final String accName, final String accNumber) {

        List<WebElement> payeeAccountNumbers = driver.findElements(By.xpath("//div[contains(@id, 'myPayee')]//span[text()='"
            + accName + "']/following-sibling::*//span[@class='accountDetails']"));
        for (WebElement accountNumber : payeeAccountNumbers) {
            if (accountNumber.getText().replaceAll(" ", "").equals(accNumber)) {
                MoveMoneyCapturePage.logger.info("payee located");
            }
        }
    }

    /**
     * @author Md Tanbir Hossain adding try catch block to handle the absence
     *         of reference text field
     * 
     */
    @Override
    public String enterYourReferenceText(final Transaction transactionDetail) {
        String yourReference = RandomUtil.generateAlphaNumericText(MoveMoneyCapturePageModel.DEFAULT_REFERENCE_TEXT_LENGTH);
        List<WebElement> countYourReference = driver.findElements(MoveMoneyCapturePageModel.yourReferenceElements
            .get(transactionDetail.getTransactionFlow()));
        if (!countYourReference.isEmpty()) {
            WebElement fieldYourReference = driver.findElement(MoveMoneyCapturePageModel.yourReferenceElements
                .get(transactionDetail.getTransactionFlow()));
            if (fieldYourReference.isDisplayed()) {
                fieldYourReference.click();
                fieldYourReference.clear();
                fieldYourReference.sendKeys(yourReference);
                fieldYourReference.sendKeys(Keys.RETURN);
                Reporter.log("Your Reference entered is :" + yourReference);
            } else {
                Reporter.log("Your Reference field is not displayed");
            }
        }
        return yourReference;
    }


    /**
     * @author Ranadeep Banik Overriding the method of adding new payee It is
     *         changed according to the US requirements
     */
    @Override
    public AccountDetails enterNewCompanyPayeeDetails() {
        Map<String, String> properties = FileUtil.getConfigProperties(COMPANY_PAYEE_DETAIL_ENTITY);
        AccountDetails accountDetails = new AccountDetails();
        super.clickTabsToOpenNewCompanyPayeeDetails();
        String companyAccountNumber = RandomUtil.generateIntNumber(MoveMoneyCapturePageModel.DEFAULT_ACCOUNT_NUMBER_LENGTH);
        String companyName = properties.get("CompanyName");
        String zipCode = properties.get("ZipCode");
        enterCompanyName(companyName);
        enterCompanyAddressZip(zipCode);
        enterCompanyAccountNumber(companyAccountNumber);
        accountDetails.setAccountNumber(companyAccountNumber);
        clickSearchPayeeTab();
        wait.until(ExpectedConditions.visibilityOf(searchPayeePopUpTxt));
        return selectAddPayeeProcess(MoveMoneyCapturePageModel.DEFAULT_LIST_STARTING_INDEX, COMPANY_PAYEE_DETAIL_ENTITY,
            searchedPayeeList, addPayeeBtn, accountDetails, payeeStateDropDownArrow, payeeStateList);
    }

    /**
     * @author Ranadeep Banik Method Added for Adding new Payee Manually
     *         According to US Requirements
     */
    private AccountDetails addManualPayee(final String entity, final WebElement dropDownicon, final List<WebElement> dropDownItems,
        final AccountDetails accountDetails) {
        Map<String, String> properties = FileUtil.getConfigProperties(entity);
        String payeeName = RandomUtil.generateAlphaNumericText(RandomUtil.generateIntNumber(3, 10));
        String payeeAdd1 = properties.get("PayeeAdd1");
        String payeeAdd2 = properties.get("PayeeAdd2");
        String payeeCity = properties.get("PayeeCity");
        String payeeState = properties.get("PayeeState");
        String payeeZipCode = properties.get("PayeeZip");
        String telephone = properties.get("Telephone");
        clickAddPayeeManuallyButton();
        addPayeeName(payeeName);
        accountDetails.setAccountName(payeeName);
        addPayeeAddress(payeeAdd1, payeeAdd2);
        addPayeeCity(payeeCity);
        selectRandomPayeeState(payeeState, dropDownicon, dropDownItems);
        addPayeeZipCode(payeeZipCode);
        addPayeeTelephone(telephone);
        if (accountDetails.getAccountNumber().equals(toPayeeAccountNumber.getAttribute("value"))) {
            Reporter.log("Account Number is Matched :" + accountDetails.getAccountNumber());
        }
        return accountDetails;
    }

    /**
     * @author Ranadeep Banik Method for adding new Payee Name
     * 
     */
    private void addPayeeName(final String payeeName) {
        wait.until(ExpectedConditions.visibilityOf(addManualPayeeName));
        addManualPayeeName.sendKeys(payeeName);
    }

    /**
     * @author Ranadeep Banik Method for adding New Payee Address
     * 
     */
    private void addPayeeAddress(final String address1, final String address2) {
        addPayeeFirstAddress.sendKeys(address1);
        addPayeeSecondAddress.sendKeys(address2);
    }

    /**
     * @author Ranadeep Banik Method for Adding new Payee City
     * 
     */
    private void addPayeeCity(final String city) {
        addManuallyPayeeCity.sendKeys(city);
    }

    /**
     * @author Ranadeep Banik Method for Adding new PayeeZip
     * 
     */
    private void addPayeeZipCode(final String zip) {
        addManuallyPayeeZip.sendKeys(zip);
    }

    /**
     * @author Ranadeep Banik Method for adding new Payee Telephone
     * 
     */
    private void addPayeeTelephone(final String telephone) {
        addManuallyPayeeTelephone.sendKeys(telephone);
    }

    /**
     * @author Ranadeep Banik
     * 
     * 
     */
    public int getRandomPayeeNumber(final List<WebElement> payeelist) {
        return payeelist.size() > 1 ? RandomUtil.generateIntNumber(MoveMoneyCapturePageModel.DEFAULT_LIST_STARTING_INDEX,
            payeelist.size() - 1) : 0;
    }

    /**
     * @author Ranadeep Banik Method created for adding new existing searched
     *         Payee According to US requirements
     */
    public AccountDetails addExistingSearchedPayee(final String entity, final List<WebElement> payeelist,
        final List<WebElement> addPayeebutton, final AccountDetails accountDetails) {
        String telephone = FileUtil.getConfigProperties(entity).get("Telephone");
        Assert.assertTrue(!payeelist.isEmpty(), "Searched payee list not displayed");
        int index = getRandomPayeeNumber(payeelist);
        jsx.executeScript(MoveMoneyCapturePage.SCROLL_TO_VIEW, payeelist.get(index));
        wait.until(ExpectedConditions.elementToBeClickable(addPayeebutton.get(index)));
        addPayeebutton.get(index).click();
        wait.until(ExpectedConditions.visibilityOf(payeeNameValue));
        accountDetails.setAccountName(payeeNameValue.getText());
        this.enterPayeeTelephoneNumber(telephone);
        return accountDetails;
    }

    /**
     * @author Ranadeep Banik
     * 
     * 
     */

    private AccountDetails selectAddPayeeProcess(final int startingIndex, final String entity, final List<WebElement> payeelist,
        final List<WebElement> addPayeebutton, final AccountDetails accountDetails, final WebElement dropDownIcon,
        final List<WebElement> dropDownList) {
        int randomNumber = RandomUtil.generateIntNumber(startingIndex, 100);
        switch (randomNumber % 2) {
            case 0:
                return addExistingSearchedPayee(entity, payeelist, addPayeebutton, accountDetails);
            case 1:
                return addManualPayee(entity, dropDownIcon, dropDownList, accountDetails);
            default:
                return addExistingSearchedPayee(entity, payeelist, addPayeebutton, accountDetails);
        }
    }


    /**
     * @author Ranadeep Banik
     * 
     * 
     */
    private void enterCompanyAccountNumber(final String accNum) {
        accountNumberTxt.clear();
        accountNumberTxt.sendKeys(accNum);
        accountNumberTxt.sendKeys(Keys.RETURN);
        if (confirmAccountNumberTxt.isDisplayed()) {
            confirmAccountNumberTxt.clear();
            confirmAccountNumberTxt.sendKeys(accNum);
            confirmAccountNumberTxt.sendKeys(Keys.RETURN);
        }
    }

    /**
     * @author Ranadeep Banik
     * 
     * 
     */
    private void enterCompanyName(final String compName) {
        companyNameTxt.sendKeys(compName);
    }

    /**
     * @author Ranadeep Banik
     * 
     * 
     */
    private void enterCompanyAddressZip(final String zip) {
        companyZipTxt.sendKeys(zip);
    }

    /**
     * @author Ranadeep Banik
     * 
     * 
     */
    private void clickAddPayeeManuallyButton() {
        wait.until(ExpectedConditions.elementToBeClickable(addPayeeManuallyBtn));
        addPayeeManuallyBtn.click();
    }

    /**
     * @author Ranadeep Banik
     * 
     * 
     */
    private void enterPayeeTelephoneNumber(final String telephone) {
        wait.until(ExpectedConditions.visibilityOf(payeeTelephoneNumberTxt));
        payeeTelephoneNumberTxt.clear();
        payeeTelephoneNumberTxt.sendKeys(telephone);
    }

    /**
     * @author Ranadeep Banik
     * 
     * 
     */
    private void clickSearchPayeeTab() {
        WebElement searchTab = searchPayeeBtn.isDisplayed() ? searchPayeeBtn : searchCompanyPayeeBtn;
        wait.until(ExpectedConditions.elementToBeClickable(searchTab));
        searchTab.click();
    }

    /**
     * @author Ranadeep Banik
     * 
     * 
     */
    private void selectRandomPayeeState(final String payeeState, final WebElement dropDownIcon, final List<WebElement> dropDownItems) {
        dropDownIcon.click();
        for (WebElement state : dropDownItems) {
            jsx.executeScript(MoveMoneyCapturePage.SCROLL_TO_VIEW, state);
            if (state.getText().contains(payeeState)) {
                state.click();
            }
        }
    }

    /**
     * @author Ranadeep Banik
     * 
     * 
     */
    @Override
    protected String getEntityBankCountry() {
        return MoveMoneyCapturePage.ENTITY_BANK_COUNTRY;
    }

    @Override
    public String selectTransactionEnddate() {
        String endDateDropDownValue = selectRandamValue(transactionEndDateDropIcon, listDropdown);
        Reporter.log("Frequency value selected is :" + endDateDropDownValue);
        return endDateDropDownValue;
    }

    @Override
    public String selectTransactionEnddateUntilFurtherNotice() {
        String endDateDropDownValue = selectUntilFurtherFromRandamValue(transactionEndDateDropIcon, listDropdown);
        MoveMoneyCapturePage.logger.info("Frequency value selected is :" + endDateDropDownValue);
        return endDateDropDownValue;
    }

    @Override
    public String selectLanguajeEnglish() {
        return selectRandamValue(languageNotification, listDropdown);
    }

    @Override
    public String verifyNumberOfPayements() {
        String noOfPayements = null;
        if (numberOfPaymentsText.isDisplayed()) {
            noOfPayements = RandomUtil.generateIntNumber(2);
            numberOfPaymentsText.sendKeys(noOfPayements);
            return noOfPayements;
        } else {
            return noOfPayements;
        }
    }

    @Override
    public void inputEmailaddress() {
        emailAddress.clear();
        emailAddress.sendKeys(MoveMoneyCapturePage.VALIDEMAILADDRESS);
    }


    private String selectUntilFurtherFromRandamValue(final WebElement dropDownIcon, final WebElement dropDownItems) {
        dropDownIcon.click();
        wait.until(ExpectedConditions.visibilityOf(dropDownItems));
        List<WebElement> valueElements = dropDownItems.findElements(menuText).isEmpty() ? dropDownItems.findElements(menuPopup)
            : dropDownItems.findElements(menuText);
        WebElement untilfurther = null;
        for (WebElement value : valueElements) {
            if (value.getText().equals(MoveMoneyCapturePage.UNTILFURTHERNOTICE)) {
                untilfurther = value;
                break;
            }
        }
        if (untilfurther != null) {
            jsx.executeScript(MoveMoneyCapturePage.SCROLL_TO_VIEW, untilfurther);
            String selectedValue = untilfurther.getText();
            wait.until(ExpectedConditions.elementToBeClickable(untilfurther));
            untilfurther.click();
            Reporter.log("Item Selected:" + selectedValue);
            return selectedValue;
        } else {
            Reporter.log("Null result found for until further element selection.");
        }
        return null;

    }

    @Override
    public String selectReasonForTransaction(Transaction transaction) {
        wait.until(ExpectedConditions.visibilityOf(reasonForTransactionIcon));
        return otherRandamValue(reasonForTransactionIcon, listDropdown, "Select");
    }
}
