/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.prd;


import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.models.Transaction;
import com.hsbc.digital.testauto.pageobject.LandingPageModel;


/**
 * <p>
 * <b> This class will hold locators and functionality related methods for
 * Account Summary & overview story 34 & 35 specific to Canada Entity </b>
 * </p>
 * 
 * @author Deepti Patil
 * 
 */
public class LandingPage extends LandingPageModel {

    private final WebDriverWait wait;
    private final JavascriptExecutor jsx;

    // Locators for elements on Account Summary Section
    @FindBy(xpath = "//span[text()='Balance summary']")
    private WebElement balanceSummary;

    @FindBy(xpath = "//div[contains(@class,'currencyType')]")
    private WebElement currencyType;

    // Locators for account information on overview section of Mortgage account
    @FindBy(xpath = "//span[text()='Overdue interest']")
    private WebElement mortgageAccountOverdueInterest;

    @FindBy(xpath = "//span[contains(text(),'overdue payment')]")
    private WebElement mortgageAccountOverduePayment;

    @FindBy(xpath = "//span[text()='Overdue balance']")
    private WebElement mortgageAccountOverdueBalance;

    // Locators for account information on overview section of Settlement
    // account
    @FindBy(xpath = "//span[text()='Available balance']")
    private WebElement accountAvailableBalance;

    // Locators for account information on overview section of Loan account
    @FindBy(xpath = "//span[text()='Next payment date']")
    private WebElement nextPaymentDate;

    // Locators for account information on overview section of TD account
    @FindBy(xpath = "//span[text()='Term ']")
    private WebElement term;

    @FindBy(xpath = "//span[text()='Maturity date']")
    private WebElement maturityDate;

    /*@FindBy(xpath = "//div[contains(@id, '_ContentPane') and contains(@class, 'accountContentPane')]")
    private WebElement leftHandMenuMyAccount;*/

    @FindBy(xpath = "//button[contains(@class, 'accordionAccountItem')]")
    private List<WebElement> accountRowsLeftHandMenu;

    private final By locatorAccountName = By.xpath(".//span[contains(@class, 'itemTitle')]");

    private final By locatorAccountNumber = By.xpath(".//span[contains(@class, 'itemName')]");

    private final By locatorAmount = By.cssSelector("td.gridxCell.amount");

    private final By locatorBalance = By.cssSelector("td.gridxCell.balance");


    private static final String[] currentAccountExpectedLabels = {"Credit interest accrued", "Total hold", ""};
    private static final String[] mortgageAccountExpectedLabels = {"Debit interest", "Next payment date", "", "Mortgage term"};
    private static final String[] tdAccountExpectedLabels = {"Maturity amount", "Start date", "Maturity instructions",
        "Interest rate", "Interest at maturity", ""};
    private static final String[] savingsAccountExpectedLabels = {"Credit interest accrued", "Total hold", ""};
    private static final String[] loanAccountExpectedLabels = {"Interest rate", "Next payment date", "Next payment", "",
        "Last payment"};

    public LandingPage(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, 30000);
        jsx = (JavascriptExecutor) driver;
    }


    /**
     * Method to verify multiple entity accounts in summary section.
     * 
     */
    @Override
    public void verifyMultipleEntityAccounts() {
        if (linkedEntities.size() > 1 || arrowButton.size() > 0) {
            Reporter.log("Profile linked with multiple entities");
            int randomIndex = RandomUtil.generateIntNumber(1, linkedEntities.size());
            WebElement element = arrowButton.get(randomIndex);
            element.click();
            verifySingleEntityOverviewSection(otherEntityAccountLists);
            AccountDetails accountDetails = selectOtherEntityAccount();
            verifyOtherEntityAccountOverview(accountDetails);
        } else {
            Reporter.log("Linked entities not found.");
        }
    }

    /**
     * Method to verify accounts are displayed for other entity.
     * 
     * @return
     * 
     */
    private void verifyOtherEntityAccountOverview(AccountDetails accountDetails) {
        verifyAccountOverview(accountDetails);
        isElementDisplayed(otherEntityLoginButton);
        Reporter.log("Login button for other entity account is displayed");
    }


    /**
     * Method to verify accounts are displayed for other entity.
     * 
     * @return
     * 
     */
    public AccountDetails selectOtherEntityAccount() {
        if (otherEntityAccountLists.size() > 0) {
            AccountDetails accountDetails = new AccountDetails();
            String accDetail = selectAccount(null, otherEntityAccountLists);
            String[] details = accDetail.split("\\r?\\n");
            accountDetails.setAccountName(details[0]);
            accountDetails.setAccountNumber(details[1]);
            accountDetails.setCurrency(details[3]);
            Reporter.log("Account :" + details[0] + " selected from account summary list");
            return accountDetails;
        }
        return null;
    }

    /**
     * Method to verify fields displayed on account summary section.
     * 
     */
    @Override
    public void verifyAccountSummarySection() {
        isElementDisplayed(balanceSummary);
        Reporter.log("Total Balance on Summary section displayed");
        isElementDisplayed(currencyType);
        Reporter.log("Currency on Summary section displayed");
    }

    /**
     * Method to verify Mortgage Account Overview section.
     * 
     */
    @Override
    public void verifyMortgageAccountOverviewInfo(AccountDetails accountDetails) {
        verifyAccountInfo(accountDetails);
        isElementDisplayed(nextPaymentDate);
        Reporter.log("Next Payment Date on overview section displayed");
    }


    /**
     * Method to verify Loan Account Overview section.
     * 
     */
    @Override
    public void verifyLoanAccountOverviewInfo(AccountDetails accountDetails) {
        verifyAccountInfo(accountDetails);

        // complete coding once data is available
    }

    /**
     * Method to verify Settlement, Current & Savings Account Overview section.
     * 
     */
    @Override
    public void verifyAccountOverviewInfo(AccountDetails accountDetails) {

        verifyAccountInfo(accountDetails);
        isElementDisplayed(accountAvailableBalance);
        Reporter.log("Available Balnace on overview section displayed");
        isElementDisplayed(manageButton);
        Reporter.log("Manage Button on overview section displayed");
        isElementDisplayed(detailsButton);
        Reporter.log("Details Button on overview section displayed");
    }

    /**
     * Method to verify TD Account Overview section.
     * 
     */
    @Override
    public void verifyTDAccountOverviewInfo(AccountDetails accountDetails) {
        verifyAccountInfo(accountDetails);
        isElementDisplayed(manageButton);
        Reporter.log("Manage Button on overview section displayed");
        isElementDisplayed(detailsButton);
        Reporter.log("Details Button on overview section displayed");
        isElementDisplayed(term);
        Reporter.log("Term Field on overview section displayed");
        isElementDisplayed(maturityDate);
        Reporter.log("Maturity Date on overview section displayed");
    }


    /**
     * Method to add labels in details section of current account in a list.
     * 
     */
    public List<String> addLabelsInCurrentAccountDetails() {
        return Arrays.asList(currentAccountExpectedLabels);
    }

    /**
     * Method to add labels in details section of Mortgage account in a list.
     * 
     */
    public List<String> addLabelsInMortgageAccountDetails() {
        return Arrays.asList(mortgageAccountExpectedLabels);
    }

    /**
     * Method to add labels in details section of TD account in a list.
     * 
     */
    public List<String> addLabelsInTDAccountDetails() {
        return Arrays.asList(tdAccountExpectedLabels);
    }

    /**
     * Method to add labels in details section of Savings account in a list.
     * 
     */
    public List<String> addLabelsInSavingsAccountDetails() {
        return Arrays.asList(savingsAccountExpectedLabels);
    }

    /**
     * Method to add labels in details section of Loan account in a list.
     * 
     */
    public List<String> addLabelsInLoanAccountDetails() {
        return Arrays.asList(loanAccountExpectedLabels);
    }

    /**
     * Method to verify Current Account Details section.
     * 
     */
    @Override
    public void verifyCurrentAccountDetails() {
        verifyFields(addLabelsInCurrentAccountDetails(), detailsLabels);
    }

    /**
     * Method to verify Savings Account Details section.
     * 
     */
    @Override
    public void verifySavingsAccountDetails() {
        verifyFields(addLabelsInSavingsAccountDetails(), detailsLabels);
    }

    /**
     * Method to verify TD Account Details section.
     * 
     */
    @Override
    public void verifyTDAccountDetails() {
        verifyFields(addLabelsInTDAccountDetails(), detailsLabels);
    }

    /**
     * Method to verify Mortgage Account Details section.
     * 
     */
    @Override
    public void verifyMortgageAccountDetails() {
        verifyFields(addLabelsInMortgageAccountDetails(), detailsLabels);
    }

    /**
     * Method to verify Loan Account Details section.
     * 
     */
    @Override
    public void verifyLoanAccountDetails() {
        verifyFields(addLabelsInMortgageAccountDetails(), detailsLabels);
    }

    @Override
    public void verifyOrderOfAccounts() {
        // need to write code for prd
    }

    @Override
    public void selectAccountOnDashboardByNameAndNumber(final AccountDetails accountDetail) {
        wait.until(ExpectedConditions.visibilityOf(leftHandMenuMyAccount));
        for (WebElement accountRow : accountRowsLeftHandMenu) {
            jsx.executeScript("arguments[0].scrollIntoView(true);", accountRow);
            String currentAccountName = accountRow.findElement(locatorAccountName).getText();
            String currentAccountNumber = accountRow.findElement(locatorAccountNumber).getText();
            if (currentAccountName.contains(accountDetail.getAccountName())
                && currentAccountNumber.contains(accountDetail.getAccountNumber())) {
                accountRow.click();
                break;
            }
        }
    }

    @Override
    public void isImmediateTransactionPosted(final Transaction transaction) {
        if (!transactionDetailDisplayElements.isEmpty()) {
            String amountValue = transactionDetailDisplayElements.get(0).findElement(locatorAmount).getText();
            String balanceValue = transactionDetailDisplayElements.get(0).findElement(locatorBalance).getText();
            Double updatedBalance = Double.parseDouble(balanceValue.replace(",", ""));
            String transactionAmount = RandomUtil.formatDouble(
                (transaction.getFromAccount().getDoubleAccountBalance() - updatedBalance),
                RandomUtil.getDecimalFormat(LandingPageModel.DEFAULT_DECIMAL_PLACES));
            Assert.assertTrue(amountValue.equals("-" + transactionAmount), "The Transaction entry with amount value : "
                + amountValue + " is not found on Dashboard.");
        }
    }


}
