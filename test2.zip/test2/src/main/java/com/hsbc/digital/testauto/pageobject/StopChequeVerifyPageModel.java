package com.hsbc.digital.testauto.pageobject;

import java.text.ParseException;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.DateUtil;
import com.hsbc.digital.testauto.models.StopChequeDetails;
import com.hsbc.digital.testauto.ui.library.UICommonUtil;

/**
 * <p>
 * <b> Stop Cheque Verify page object model to hold generic function and
 * locators for story stop cheque</b>
 * </p>
 * 
 * @version 1.0.0
 * @author Neeraj Kumar
 */

public class StopChequeVerifyPageModel {

    protected final WebDriverWait wait;
    protected UICommonUtil uiCommonUtil;

    /**
     * Field Label on Verify page
     */
    protected static final String LABEL_ACCOUNT = "Account";
    protected static final String LABEL_PAYEE_NAME = "Payee name";
    protected static final String LABEL_CHEQUE_NUMBER = "Cheque number";
    protected static final String LABEL_AMOUNT = "Amount";
    protected static final String LABEL_CHEQUE_RANGE = "Cheque range";
    private static final String LABEL_ISSUE_DATE = "Issue date";
    private static final String LABEL_REASON_TO_STOP_CHEQUE = "Reason to stop cheque";
    private static final String TITLE_REVIEW_PAGE = "Verify";

    protected String getLabelChequeRange() {
        return LABEL_CHEQUE_RANGE;
    }

    @FindBy(xpath = "//div[contains(@id, 'StopCheque')]//div[contains(@class, 'steptracker-heading')]//*[contains(@data-dojo-attach-point, 'dapPageTitle')]")
    protected WebElement verifyPageTitle;

    @FindBy(xpath = "//div[contains(@class, 'submitButtonsPanel')]//*[contains(@data-dojo-attach-point, 'dapConfirmBtn')]")
    private WebElement confirmButton;

    @FindBy(xpath = "//div[contains(@class, 'submitButtonsPanel')]//*[contains(@data-dojo-attach-point, 'CancelDialog')]")
    private WebElement cancelButton;

    @FindBy(xpath = "//div[contains(@id, 'Verify')]//*[contains(@data-dojo-attach-point, 'dapEditDetails')]")
    private WebElement editDetailsButton;

    @FindBy(xpath = "//div[contains(@id, 'Dialog') and contains(@class, 'dijitDialogFixed')]//*[contains(@data-dojo-attach-point, '_verifyCancelDialogYesBtn')]")
    private WebElement cancelPopUpDialogButton;

    @FindBy(xpath = "//div[contains(@id, 'Dialog') and contains(@class, 'dijitDialogFixed')]//*[contains(@class, 'btnTertiary')]")
    private WebElement continuePopUpDialogButton;

    @FindBy(xpath = "//li[@class='error']")
    private WebElement duplicateChequeErrorMessage;

    private final By cancelDialog = By.xpath("//div[contains(@id,'Dialog')]");

    public StopChequeVerifyPageModel(final WebDriver driver) {
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, 30000);
        uiCommonUtil = new UICommonUtil(driver);
    }

    public void verifyPageTitle() {
        wait.until(ExpectedConditions.visibilityOf(verifyPageTitle));
        Assert.assertTrue(verifyPageTitle.isDisplayed(), "Stop Cheque verify page is not displayed");
        Reporter.log("Stop Cheque verify page is displayed.");
    }

    public void clickConfirmButton() {
        wait.until(ExpectedConditions.elementToBeClickable(confirmButton));
        confirmButton.click();
        Reporter.log("Confirm button clicked");
    }

    public void clickCancelButton() {
        wait.until(ExpectedConditions.elementToBeClickable(cancelButton));
        cancelButton.click();
        Reporter.log("Cancel button clicked");
    }

    public void clickCancelPopUpCancelButton() {
        wait.until(ExpectedConditions.visibilityOf(uiCommonUtil.activeElement(cancelDialog)));
        cancelPopUpDialogButton.click();
        Reporter.log("Cancel Button on Cancel Dialog is clicked.");
    }

    public void clickContinuePopUpCancelButton() {
        wait.until(ExpectedConditions.visibilityOf(uiCommonUtil.activeElement(cancelDialog)));
        continuePopUpDialogButton.click();
        Reporter.log("Continue Button on Cancel Dialog is clicked.");
    }

    public void clickEditDetailsButton() {
        wait.until(ExpectedConditions.elementToBeClickable(editDetailsButton));
        editDetailsButton.click();
        Reporter.log("Edit details button clicked.");
    }

    protected void isPageTitleDisplayed(final WebElement pageTitle) {
        Assert.assertTrue(pageTitle.getText().equalsIgnoreCase(TITLE_REVIEW_PAGE), "Page Title does not match.");
        Reporter.log("Page title is displayed as :" + pageTitle.getText());
    }

    protected void isIssueChequeAccountNameDisplayed(final StopChequeDetails stopChequeDetails) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_ACCOUNT, stopChequeDetails.getIssueChequeAccount()
            .getAccountName(), UICommonUtil.verifyPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
            "Given Issue Cheque Account Name not found.");
        Reporter.log("Issue Cheque Account Name displayed is :" + stopChequeDetails.getIssueChequeAccount().getAccountName());
    }

    protected void isIssueChequeAccountNumberDisplayed(final StopChequeDetails stopChequeDetails) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_ACCOUNT, stopChequeDetails.getIssueChequeAccount()
            .getAccountNumber(), UICommonUtil.verifyPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
            "Given Issue Cheque Account Number not found.");
        Reporter.log("Issue Cheque Account Number displayed is :" + stopChequeDetails.getIssueChequeAccount().getAccountNumber());
    }

    protected void isPayeeNameDisplayed(final StopChequeDetails stopChequeDetails) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_PAYEE_NAME, stopChequeDetails.getPayeeName(),
            UICommonUtil.verifyPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Payee Name not found.");
        Reporter.log("Payee Name displayed is :" + stopChequeDetails.getPayeeName());
    }

    protected void isChequeNumberDisplayed(final StopChequeDetails stopChequeDetails) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_AMOUNT, stopChequeDetails.getChequeNumber(),
            UICommonUtil.verifyPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Cheque Number not found.");
        Reporter.log("Cheque Number displayed is :" + stopChequeDetails.getChequeNumber());
    }

    protected void isChequeRangeDisplayed(final StopChequeDetails stopChequeDetails) {
        String chequeRange = stopChequeDetails.getChequeNumber() + " � " + stopChequeDetails.getChequeEndNumber();
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(getLabelChequeRange(), chequeRange, UICommonUtil.verifyPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Cheque Range not found.");
        Reporter.log(getLabelChequeRange() + "displayed is :" + chequeRange);
    }

    protected void isAmountDisplayed(final StopChequeDetails stopChequeDetails) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_AMOUNT, stopChequeDetails.getAmount(), UICommonUtil.verifyPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Transfer Amount not found.");
        Reporter.log("Amount displayed is :" + stopChequeDetails.getAmount());
    }

    protected void isChequeIssueDateDisplayed(final StopChequeDetails stopChequeDetails) throws ParseException {
        Date parseDate = DateUtil.getStringToDate(DateUtil.DATE_FORMAT_MMDDYYYY, stopChequeDetails.getIssueDate());
        String chequeIssueDate = DateUtil.getDateToString(DateUtil.DATE_FORMAT_DDMMMYYYY, parseDate);
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_ISSUE_DATE, chequeIssueDate, UICommonUtil.verifyPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Cheque Issue Date not found.");
        Reporter.log("Cheque Issue Dated displayed is :" + stopChequeDetails.getIssueDate());
    }

    protected void isReasonToStopChequeDisplayed(final StopChequeDetails stopChequeDetails) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_REASON_TO_STOP_CHEQUE,
            stopChequeDetails.getReasonToStopCheque(), UICommonUtil.verifyPage, UICommonUtil.pageFieldName,
            UICommonUtil.pageFieldValue), "Given Reason To StopCheque not found.");
        Reporter.log("Reason To StopCheque displayed is :" + stopChequeDetails.getAmount());
    }

    public void validateReviewPageWithChequeNumber(final StopChequeDetails stopChequeDetails) throws ParseException {
        wait.until(ExpectedConditions.visibilityOf(verifyPageTitle));
        isIssueChequeAccountNameDisplayed(stopChequeDetails);
        isIssueChequeAccountNumberDisplayed(stopChequeDetails);
        isPayeeNameDisplayed(stopChequeDetails);
        isChequeNumberDisplayed(stopChequeDetails);
        isAmountDisplayed(stopChequeDetails);
    }

    public void validateReviewPageWithChequeRange(final StopChequeDetails stopChequeDetails) throws ParseException {
        wait.until(ExpectedConditions.visibilityOf(verifyPageTitle));
        isPageTitleDisplayed(verifyPageTitle);
        isIssueChequeAccountNameDisplayed(stopChequeDetails);
        isIssueChequeAccountNumberDisplayed(stopChequeDetails);
        isChequeRangeDisplayed(stopChequeDetails);
    }

    public void verifyDuplicateChequeError() {
        Assert.assertTrue(duplicateChequeErrorMessage.isDisplayed(), "Error Message is not displayed for duplicate cheque");
        Reporter.log("Error message is displayed as :" + duplicateChequeErrorMessage.getText());
    }

}
