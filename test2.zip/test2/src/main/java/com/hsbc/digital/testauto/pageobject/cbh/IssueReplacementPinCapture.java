/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.cbh;

import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.pageobject.IssueReplacementPinCaptureModel;

/**
 * <p>
 * <b> This class will hold locators and specific implementation for CBH
 * entity. </b>
 * </p>
 */
public class IssueReplacementPinCapture extends IssueReplacementPinCaptureModel {

    @FindBy(xpath = "//input[@name='terms']")
    private WebElement termsAndConditions;

    @FindBy(xpath = "//input[contains(@id,'arrowid') and contains(@id,'AccountSelect')]")
    private WebElement dropdownIcon;

    @FindBy(xpath = "//td[contains(@id,'dijit_MenuItem') and contains(@id,'text')]")
    private List<WebElement> accountsList;

    @FindBy(xpath = "//div[@class='row submitButtonsPanel ']/button[@title='Cancel']")
    private WebElement cancelDialogYes;

    @FindBy(xpath = "//div[@class='row submitButtonsPanel ']/button[@title=\"Don't Cancel\"]")
    private WebElement cancelDialogNo;

    @FindBy(xpath = "//*[@id='_dashboardHeading']/h1/span[text()='My accounts - Dashboard']")
    private WebElement dashboardPage;

    private JavascriptExecutor scriExecutor;

    public IssueReplacementPinCapture(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
        scriExecutor = (JavascriptExecutor) driver;
    }

    public void clickContinueButton() {
        // checkTermsCheckbox();
        super.clickContinueButton();
    }

    private void checkTermsCheckbox() {
        termsAndConditions.click();
    }

    public String selectAccount() {
        dropdownIcon.click();
        int randomIndex = RandomUtil.generateIntNumber(0, accountsList.size());
        WebElement account = accountsList.get(randomIndex);
        scriExecutor.executeScript("arguments[0].scrollIntoView(true);", account);
        account.click();
        return "";
    }

    public void clickCancelButton(final boolean isCancel) {
        wait.until(ExpectedConditions.elementToBeClickable(cancelButton));
        cancelButton.click();
        if (isCancel) {
            cancelDialogYes.click();
            dashboardPage.isDisplayed();
            Reporter.log("Cancel button - Yes clicked and Dashboard page shown.");
        } else {
            cancelDialogNo.click();
            Reporter.log("Cancel button - No clicked and user is on same page.");
        }
    }

}
