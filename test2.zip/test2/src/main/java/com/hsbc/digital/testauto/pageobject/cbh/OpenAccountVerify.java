/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.cbh;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.models.OpenAccountDetails;
import com.hsbc.digital.testauto.pageobject.OpenAccountVerifyModel;

/**
 * <p>
 * <b> This class will hold locators and specific implementation for Canada
 * entity. </b>
 * </p>
 */
public class OpenAccountVerify extends OpenAccountVerifyModel {

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(OpenAccountVerify.class);

    @FindBy(xpath = "//dt[text()='Account to be debited']/following::div[1]//span")
    private WebElement debitedAccountReview;

    @FindBy(xpath = "//dt[text()='Total deposit']/following-sibling::dd[1]//descendant::span[2]")
    private WebElement totalDepositReview;

    @FindBy(xpath = "//dt[text()='Reason for opening account']/following-sibling::dd[1]")
    private WebElement reasonOpeningAccountReview;

    @FindBy(xpath = "//a//span[text()='Edit these details']")
    private WebElement editDetailsButton;

    @FindBy(xpath = "//input[contains(@id,'TermsAndConditions')]")
    private WebElement termAndConditionCheckBoxReview;

    @FindBy(xpath = "//span[text()='Confirm']")
    private WebElement confirmButton;

    @FindBy(xpath = "//input[@value='Cancel']")
    private WebElement cancelButton;

    @FindBy(xpath = "//div[contains(@class,'dijitDialogFixed')]//button[text()='Yes']")
    private WebElement yesButtonOnCancelPopUp;

    @FindBy(xpath = "//div[text()='Credit cards']")
    private WebElement creditCardLink;

    @FindBy(xpath = " //h2[contains(text(),'Options')]")
    private WebElement optionHeading;


    public OpenAccountVerify(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }


    @Override
    public void clickTnCCheckbox() {
        // Do nothing Because not in CA
    }

    @Override
    public void verifyReviewPageForSaving(final OpenAccountDetails objOpenAccountDetails) {

        Assert.assertTrue(debitedAccountReview.getText().contains(objOpenAccountDetails.getDebitAccountCbh()),
            "Debit account does not match on Verify Page");
        Assert.assertTrue(totalDepositReview.getText().contains(objOpenAccountDetails.getDepositAmount()),
            "Deposit Amount does not match on Verify Page");
        Assert.assertTrue(reasonOpeningAccountReview.getText().contains(objOpenAccountDetails.getReason()),
            "Reason does not match on Verify Page");
        selectTermAndConditionVerifyPage();
        clicksConfirmButton();
    }

    @Override
    public void verifyReviewPageForTermDeposit(final OpenAccountDetails objOpenAccountDetails) {
        Assert.assertTrue(debitedAccountReview.getText().contains(objOpenAccountDetails.getDebitAccountCbh()),
            "Debit account does not match on Verify Page");
        String amountValueString = totalDepositReview.getText();
        Integer actualAmount = Integer.valueOf(amountValueString.replace(",", "").replace(".00", ""));
        Assert.assertTrue(Integer.toString(actualAmount).equals(objOpenAccountDetails.getDepositAmount()),
            "Deposit Amount does not match on Verify Page");
        selectTermAndConditionVerifyPage();
        clicksConfirmButton();
    }

    public void selectTermAndConditionVerifyPage() {
        Assert
            .assertTrue(termAndConditionCheckBoxReview.isDisplayed(), "Term and Condition check box not displayed on Verify Page");
        termAndConditionCheckBoxReview.click();
        Reporter.log("Select Term and Condition on Review page");
    }

    @Override
    public void clicksConfirmButton() {
        Assert.assertTrue(confirmButton.isDisplayed(), "Confirm button is not displayed");
        confirmButton.click();
        Reporter.log("Click on Confirm button");
    }

    @Override
    public void cancelFlowFromVerify() {
        Assert.assertTrue(cancelButton.isDisplayed(), "Cancel button is not displayed");
        cancelButton.click();
        Reporter.log("Click on Cancel button on Verify page");

        Assert.assertTrue(yesButtonOnCancelPopUp.isDisplayed(), "Yes button is not displayed on Confirm pop up");
        yesButtonOnCancelPopUp.click();
        Reporter.log("Click on Yesy buttton on Confirm popup");

        Assert.assertTrue(creditCardLink.isDisplayed(), "Flow is not cancelled properly");
    }

    @Override
    public void clickEditDetailsButton() {

        Assert.assertTrue(editDetailsButton.isDisplayed(), "Edit Details button is not displayed");
        editDetailsButton.click();
        Reporter.log("Click on Edit Details button on Verify page");

        Assert.assertTrue(optionHeading.isDisplayed(), "Edit details functionality not working properly");


    }

}