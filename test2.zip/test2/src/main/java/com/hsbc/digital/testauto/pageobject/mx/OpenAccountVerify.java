/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.mx;

import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.models.OpenAccountDetails;
import com.hsbc.digital.testauto.pageobject.OpenAccountVerifyModel;

/**
 * <p>
 * <b> This class will hold locators and specific implementation for Mexico
 * entity. </b>
 * </p>
 */
public class OpenAccountVerify extends OpenAccountVerifyModel {

    @FindBy(xpath = "//span[@data-dojo-attach-point='_productName']")
    private WebElement appliedProductName;

    @FindBy(xpath = "//span[@data-dojo-attach-point='_investmentAccount']")
    private WebElement investmentAccountLabel;

    @FindBy(xpath = "//span[@data-dojo-attach-point='_accountTerm']")
    private WebElement accountTermLabel;

    @FindBy(xpath = "//span[@data-dojo-attach-point='_newAccountCurrency']")
    private WebElement accountCurrencyLabel;

    @FindBy(xpath = "//span[@data-dojo-attach-point='_amountToDeposit']")
    private WebElement amountToDeposit;

    @FindBy(xpath = "//p[@data-dojo-attach-point='maturityDescription1']")
    private WebElement maturityInstructionLabel;

    @FindBy(xpath = "//span[@data-dojo-attach-point='_maturityDatedt']")
    private WebElement maturityDateLabel;

    @FindBy(xpath = "//span[@data-dojo-attach-point='_interestRate']")
    private WebElement interestRateLabel;

    @FindBy(xpath = "//span[@data-dojo-attach-point='_additionalOnlineRate']")
    private WebElement additionalOnlineRateLabel;

    @FindBy(xpath = "//span[@data-dojo-attach-point='_totalRate']")
    private WebElement totalRateLabel;

    private static final String SCROLL_TO_VIEW = "arguments[0].scrollIntoView(true);";

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(OpenAccountVerify.class);

    public OpenAccountVerify(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    /* (non-Javadoc)
     * @see com.hsbc.digital.testauto.pageobject.OpenAccountVerifyModel#openTDProductVerifyPage(com.hsbc.digital.testauto.models.OpenAccountDetails, java.util.Map)
     */
    @Override
    public void openTDProductVerifyPage(OpenAccountDetails openAccount, Map<String, String> envProperties) {
        super.verifyDetails(openAccount, envProperties);
        clickConfirmButton();
    }

    /* (non-Javadoc)
     * @see com.hsbc.digital.testauto.pageobject.OpenAccountVerifyModel#validateDebitAccount(com.hsbc.digital.testauto.pageobject.AccountDetails)
     */
    @Override
    public void validateDebitAccount(AccountDetails debitAccount) {
        Assert.assertTrue(isAccountNumberCorrect(debitAccount, super.debitAccountNumber),
            "Debit Account Number is Not Same, Expected: " + debitAccount.getAccountNumber() + " & Actual is:-"
                + super.debitAccountNumber.getText());
        Reporter.log("Debit Account Details matched. | ");
    }

    /**
     * This is Generic Method to Verify Account Details
     * 
     * @param accountDetails
     *            : AccountDetails
     * @param accountNumber
     *            : WebElement
     * @return <b> true/false <b>
     */
    private boolean isAccountNumberCorrect(AccountDetails accountDetails, WebElement accountNumber) {
        super.jsx.executeScript(SCROLL_TO_VIEW, accountNumber);
        return accountDetails.getAccountNumber().equalsIgnoreCase(accountNumber.getText());
    }

    /* (non-Javadoc)
     * @see com.hsbc.digital.testauto.pageobject.OpenAccountVerifyModel#validateInvestmentAccount(java.lang.String)
     */
    @Override
    protected void validateInvestmentAccount(String selectedInvestmentAccount) {
        Assert.assertTrue(
            super.isValueCorrect(selectedInvestmentAccount, investmentAccountLabel, false),
            "Investment account is not same, Expected:- " + selectedInvestmentAccount + " & Actual is:- "
                + investmentAccountLabel.getText());
        Reporter.log("Investment account matched. | ");
    }

    /* (non-Javadoc)
     * @see com.hsbc.digital.testauto.pageobject.OpenAccountVerifyModel#validateSelectedTerm(java.lang.String, boolean)
     */
    @Override
    public void validateSelectedTerm(final String selectedTerm, Boolean isTermInMonths) {
        if (isTermInMonths == null) {
            Assert.assertTrue(super.isValueCorrect(selectedTerm, accountTermLabel, false),
                "Account Term is not correct, Expected:- " + selectedTerm + " & Actual is:- " + accountTermLabel.getText());
            Reporter.log("Term duration matched. | ");
        } else {
            Assert.fail("isTermInMonths parameter should be null only. | ");
        }
    }

    @Override
    public void validateSelectedAmount(Double selectedAmount) {
        if (selectedAmount != null) {
            Assert.assertTrue(isAmountCorrect(selectedAmount, amountToDeposit), "Amount is not same, Expected:- " + selectedAmount
                + " & Actual is:- " + amountToDeposit.getText());
            Reporter.log("Amount matched. | ");
        }
    }

    @Override
    protected void validateMaturityInstruction(String maturityInstruction) {
        Assert.assertTrue(
            super.isValueCorrect(maturityInstruction, maturityInstructionLabel, false),
            "Maturity Instruction is not same, Expected:- " + maturityInstruction + " & Actual is:- "
                + maturityInstructionLabel.getText());
        Reporter.log("Maturity Instruction matched. | ");
    }

    /* (non-Javadoc)
     * @see com.hsbc.digital.testauto.pageobject.OpenAccountVerifyModel#validateMaturityDate(java.lang.String)
     */
    @Override
    protected void validateMaturityDate(String maturityDate) {
        Assert.assertTrue(super.isValueCorrect(maturityDate, maturityDateLabel, false), "Maturity Date is not same, Expected:- "
            + maturityDate + " & Actual is:- " + maturityDateLabel.getText());
        Reporter.log("Maturity Date matched. | ");
    }

    /* (non-Javadoc)
     * @see com.hsbc.digital.testauto.pageobject.OpenAccountVerifyModel#validateEffectiveDate(java.util.Map)
     */
    @Override
    public void validateEffectiveDate(Map<String, String> envProperties) {
        // Do Nothing because not in Mexico.
    }

    @Override
    protected void validateAdditionalOnlineRate(String additionalOnlineRate) {
        Assert.assertTrue(isValueCorrect(additionalOnlineRate, additionalOnlineRateLabel, false),
            "Additional Online Rate is not same, Expected:- " + additionalOnlineRate + " & Actual is:- "
                + additionalOnlineRateLabel.getText());
        Reporter.log("Additional Online Rate matched. | ");
    }

    @Override
    protected void validateTotalRate(String totalRate) {
        Assert.assertTrue(isValueCorrect(totalRate, totalRateLabel, false), "Total Rate is not same, Expected:- " + totalRate
            + " & Actual is:- " + totalRateLabel.getText());
        Reporter.log("Total Rate matched. | ");
    }

    @Override
    protected void validateInterestPaid(String interestPaidInterval) {
        // Do Nothing because not in Mexico.
    }

    @Override
    protected void validateCreditAccount(AccountDetails creditAccount) {
        // Do Nothing because not in Mexico.
    }

    /**
     * This is generic method to verify amount value
     * 
     * @param savedValue
     * @param presentValue
     * @return <b> true/false <b>
     */
    private boolean isAmountCorrect(Double savedValue, WebElement presentValue) {
        jsx.executeScript(SCROLL_TO_VIEW, presentValue);
        return savedValue == Double.parseDouble(presentValue.getText().replace(",", ""));
    }

    /* (non-Javadoc)
     * @see com.hsbc.digital.testauto.pageobject.OpenAccountVerifyModel#getProductName()
     */
    @Override
    protected WebElement getProductNameElement() {
        return appliedProductName;
    }

    /* (non-Javadoc)
     * @see com.hsbc.digital.testauto.pageobject.OpenAccountVerifyModel#getAccountCurrency()
     */
    @Override
    protected WebElement getAccountCurrencyElement() {
        return accountCurrencyLabel;
    }

    /* (non-Javadoc)
     * @see com.hsbc.digital.testauto.pageobject.OpenAccountVerifyModel#getInterestRateElement()
     */
    @Override
    protected WebElement getInterestRateElement() {
        return interestRateLabel;
    }
}