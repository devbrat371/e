/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject;

import java.text.DecimalFormat;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.DateUtil;
import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.models.Transaction;


/**
 * <p>
 * <b> This model class will hold locators and functionality for Quick move
 * money widget.This widget is present on Dashboard page. </b>
 * </p>
 * 
 * @author Pramesh G
 * @version 1.0.0
 */
public abstract class QuickMoveMoneyCaptureModel {

    private final WebDriverWait wait;
    private final WebDriver driver;
    private static final String LARGEAMOUNT = "9999999999";
    private static final String FROM_ACCOUNT_TEXT = "From account";
    private static final String TO_ACCOUNT_TEXT = "To account";
    private static final String BALANCE_ZERO_STRING = "0.00";
    private static final String BALANCE_ONE_STRING = "1.00";

    @FindBy(xpath = "//div[contains(@id, 'dijit_layout_ContentPane') and @data-dojo-attach-point='_stage1']//h2")
    private WebElement widgetBanner;

    /* From Account Fields section */
    /**
     * From Account Name
     */
    @FindBy(xpath = "//div[starts-with(@id,'group_gpib_mvmny_bijit_SelectAccount_') and not(contains(@id,'_accountLabel'))][1]//div[contains(@class,'dijitSelectMenu')]/table//span[contains(@class,'title') and not(contains(@class,'noDisplay'))]")
    private WebElement fromAccountName;

    /**
     * From Account Number
     */
    @FindBy(xpath = "//div[starts-with(@id,'group_gpib_mvmny_bijit_SelectAccount_') and not(contains(@id,'_accountLabel'))][1]//table[contains(@id, 'SelectDropDown')]//span[@class='accountDetails accountDetailsactSlOption']")
    private WebElement fromAccountNumber;

    /**
     * From DropDown Icon
     */
    @FindBy(xpath = "//table[contains(@id, 'SelectDropDown')]//input[contains(@class, 'dijitArrowButtonInner')]")
    private WebElement fromDropDownIcon;

    /**
     * From Account Balance
     */
    @FindBy(xpath = "//table[contains(@id, 'SelectDropDown')]//span[@class='balance']")
    private WebElement fromAccountBalance;

    /**
     * Default From Account
     */
    @FindBy(xpath = "//div[starts-with(@id,'group_gpib_mvmny_bijit_SelectAccount_') and not(contains(@id,'_accountLabel'))][1]//div[contains(@class,'dijitSelectMenu')]/table//p[@class='selectPlaceHolder']")
    private WebElement defaultFromAccount;

    /*To Account Fields section */
    /**
     * To Account Name
     */
    @FindBy(xpath = "//div[starts-with(@id,'group_gpib_mvmny_bijit_SelectAccount_') and not(contains(@id,'_accountLabel'))][2]//div[contains(@class,'dijitSelectMenu')]/table//span[contains(@class,'title') and not(contains(@class,'noDisplay'))]")
    private WebElement toAccountName;

    /**
     * To Account Icon
     */
    @FindBy(xpath = "//table[contains(@id, 'SelectDropDown')]//following::table[contains(@id, 'SelectDropDown')]//input[contains(@class, 'dijitArrowButtonInner')]")
    private WebElement toDropDownIcon;

    /**
     * To Account Number
     */
    @FindBy(xpath = "//div[starts-with(@id,'group_gpib_mvmny_bijit_SelectAccount_') and not(contains(@id,'_accountLabel'))][2]//table[contains(@id, 'SelectDropDown')]//span[@class='accountDetails accountDetailsactSlOption']")
    private WebElement toAccountNumber;

    /**
     * To Account Balance
     */
    @FindBy(xpath = "//div[starts-with(@id,'group_gpib_mvmny_bijit_SelectAccount_') and not(contains(@id,'_accountLabel'))][2]//table[contains(@id, 'SelectDropDown')]//span[@class='balance']")
    private WebElement toAccountBalance;

    /**
     * Default To Account
     */
    @FindBy(xpath = "//div[starts-with(@id,'group_gpib_mvmny_bijit_SelectAccount_') and not(contains(@id,'_accountLabel'))][2]//div[contains(@class,'dijitSelectMenu')]/table//p[@class='selectPlaceHolder']")
    private WebElement defaultToAccount;

    /**
     * DropDown Item List
     */
    @FindBy(xpath = "//div[contains(@class,'dijitMenuActive')]")
    private WebElement dropDownItems;

    private final By accountsList = By.cssSelector("td[id$='_text']");

    /* All Button Fields section*/
    /**
     * TransferButton
     */
    @FindBy(xpath = "//button[text()='Transfer']")
    private WebElement transferButton;

    /**
     * Cancel Button/Reset button
     */
    @FindBy(xpath = "//div[contains(@id, 'dijit_layout_ContentPane') and @data-dojo-attach-point='_stage1']//button[text()='Cancel']")
    private WebElement cancelButton;


    /* All Text Fields section*/
    /**
     * Amount TextBox
     */
    @FindBy(xpath = "//input[@id='_quickTransfer_qmm_CurrencyTextBox']")
    private WebElement amountField;

    /* All Error Messages Fields section */
    /**
     * Error Container
     */
    @FindBy(xpath = "//div[contains(@id, 'dijit_layout_ContentPane') and @data-dojo-attach-point='_stage1']//div[contains(@class,'errorMsgDiv')]")
    private List<WebElement> errorContainer;

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(QuickMoveMoneyCaptureModel.class);

    public QuickMoveMoneyCaptureModel(final WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        this.wait = new WebDriverWait(driver, 30000);
    }

    /**
     * Scroll to QMM Widget
     */
    public void scrollToWidget() {
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", widgetBanner);
        Reporter.log("Moved to Quick transfer widget.");
    }

    /**
     * Check the Amount Field is Editable or Not
     */
    private void isAmountFieldEditable() {
        Assert.assertTrue(amountField.isEnabled(), "Amount field is not Editable or Enable");
    };

    /**
     * This is Generic method to select account on Quick move money widget.
     * 
     * @param dropDownIcon
     *            : Drop down Arrow Icon
     * @param dropDownItems
     *            : Items of Drop down.
     * @param accountDetails
     *            : Account to be selected if passed.
     */
    public void selectAccount(final WebElement dropDownIcon, final WebElement dropDownItems, final AccountDetails accountDetails) {
        dropDownIcon.click();
        wait.until(ExpectedConditions.visibilityOf(dropDownItems));
        List<WebElement> accountDropdownList = dropDownItems.findElements(accountsList);
        while (true) {
            int randomIndex = RandomUtil.generateIntNumber(1, accountDropdownList.size());
            for (int index = 1; index < accountDropdownList.size(); index++) {
                WebElement accountRow = accountDropdownList.get(index);
                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", accountRow);
                if ((accountDetails != null && accountRow.getText().contains(accountDetails.getAccountNumber()))
                    || (accountDetails == null && index == randomIndex)) {
                    accountRow.click();
                    Reporter.log("Account Selected:" + accountRow.getText());
                    break;
                }
            }
            if (BALANCE_ZERO_STRING.equals(fromAccountBalance.getText()) || !errorContainer.isEmpty()) {
                dropDownIcon.click();
            } else {
                break;
            }
        }
    }

    /**
     * Verify the Default Account is Selected or Not
     */
    public void validateResetWidget() {
        Assert.assertTrue(isDefaultFromAccountSelected(), "Default From Account is not selected");
        Reporter.log("Default From Account selected");
        Assert.assertTrue(isDefaultToAccountSelected(), "Default To Account is not selected");
        Reporter.log("Default To Account selected");
        Assert.assertTrue(isAmountFieldEmpty(), "Amount Field is Not reset");
        Reporter.log("Amout field reset is done.");
    }

    private boolean isAmountFieldEmpty() {
        return StringUtils.EMPTY.equals(amountField.getAttribute("value"));
    }

    /**
     * Check that Default From Account is Selected
     * 
     * @return whether default from account is selected or not
     */
    private boolean isDefaultFromAccountSelected() {
        return FROM_ACCOUNT_TEXT.equals(defaultFromAccount.getText());
    }

    /**
     * Check that Default To Account is selected
     * 
     * @return whether default to account is selected or not
     */
    private boolean isDefaultToAccountSelected() {
        return TO_ACCOUNT_TEXT.equals(defaultToAccount.getText());
    }

    /**
     * Reset all Field in QMM
     */
    public void resetWidget() {
        Assert.assertTrue(cancelButton.isEnabled(), "Cancel Button is Not Enabled");
        cancelButton.click();
        validateResetWidget();
    }

    /**
     * This Method validate the Balance after Transaction
     * 
     * @param fromAccDetails
     *            : From Details
     * @param toAccDetails
     *            : To Details
     * @param amount
     *            :Amount
     * @return :True if Balance is Correctly Update
     */
    public void checkBalance(final Transaction transaction) {
        boolean isVerified = false;
        DecimalFormat decimalFormat = new DecimalFormat(DateUtil.TWO_DECIMAL_PLACE_FORMATTER);
        Double beforeTransFromAcctBal = Double.parseDouble(transaction.getFromAccount().getFormattedAccountBal());
        Double beforeTransToAcctBal = Double.parseDouble(transaction.getToAccount().getFormattedAccountBal());
        AccountDetails newFromAcctDetails = selectFromAccount(transaction.getFromAccount());
        AccountDetails newToAcctDetails = selectToAccount(transaction.getToAccount());
        Double afterTransFromAcctBal = Double.parseDouble(newFromAcctDetails.getFormattedAccountBal());
        Double afterTransToAcctBal = Double.parseDouble(newToAcctDetails.getFormattedAccountBal());
        if (Double.compare(Double.valueOf(decimalFormat.format(beforeTransFromAcctBal - afterTransFromAcctBal)),
            Double.parseDouble(transaction.getAmount())) == 0
            && Double.compare(Double.valueOf(decimalFormat.format(afterTransToAcctBal - beforeTransToAcctBal)),
                Double.parseDouble(transaction.getAmount())) == 0) {
            isVerified = true;
        }
        Assert.assertTrue(isVerified, "Balance is Not Correctly Updated");
        Reporter.log("Balance is Updated Correctly");
    }


    /**
     * Select the From Account Based on Details
     * 
     * @param accountDetails
     *            :AccountDetails Object
     * @return AccountDetails Object
     */
    public AccountDetails selectFromAccount(final AccountDetails accountDetails) {
        AccountDetails accDetails = new AccountDetails();
        selectAccount(fromDropDownIcon, dropDownItems, accountDetails);
        accDetails.setAccountBalance(fromAccountBalance.getText());
        return accDetails;
    }

    /**
     * Select the To Account Based on Details
     * 
     * @param accountDetails
     *            :AccountDetails Object
     * @return AccountDetails Object
     */
    public AccountDetails selectToAccount(final AccountDetails accountDetails) {
        AccountDetails accDetails = new AccountDetails();
        selectAccount(toDropDownIcon, dropDownItems, accountDetails);
        accDetails.setAccountBalance(toAccountBalance.getText());
        return accDetails;
    }

    /**
     * Select the From Account Randomly and set
     * AccountName,AccountNumber,Balance
     * 
     * @return AccountDetails Object
     */
    public AccountDetails selectFromAccount() {
        AccountDetails accountDetails = new AccountDetails();
        selectAccount(fromDropDownIcon, dropDownItems, null);
        accountDetails.setAccountName(fromAccountName.getText());
        accountDetails.setAccountNumber(fromAccountNumber.getText());
        accountDetails.setAccountBalance(fromAccountBalance.getText());
        Reporter.log("Account :" + fromAccountName.getText() + ":: " + fromAccountNumber.getText()
            + " selected in From Drop down :");
        return accountDetails;
    }


    /**
     * Select the To Account Randomly and set AccountName,AccountNumber and
     * Balance
     * 
     * @return AccountDetails Object
     */
    public AccountDetails selectToAccount() {
        AccountDetails accountDetails = new AccountDetails();
        selectAccount(toDropDownIcon, dropDownItems, null);
        accountDetails.setAccountName(toAccountName.getText());
        accountDetails.setAccountNumber(toAccountNumber.getText());
        accountDetails.setAccountBalance(toAccountBalance.getText());
        Reporter.log("Account :" + toAccountName.getText() + ":: " + toAccountNumber.getText() + " selected in To Drop down :");
        return accountDetails;
    }

    /**
     * Click the Transfer Button
     */
    public void clickTransferButton() {
        Assert.assertTrue(transferButton.isEnabled(), "Transfer Button is Not Enabled");
        transferButton.click();
        Reporter.log("Transfer button clicked.");
    }

    /**
     * Enter the Amount
     * 
     * @param amount
     *            :Amount
     */
    public String enterAmount(final Transaction transaction) {
        Double balance = Double.parseDouble(transaction.getFromAccount().getFormattedAccountBal()) / 10;
        String amount = balance.intValue() == 1 ? BALANCE_ONE_STRING : RandomUtil.generateDoubleNumber(1, balance.intValue(), 2);
        isAmountFieldEditable();
        this.amountField.clear();
        this.amountField.sendKeys(amount);
        Reporter.log("Amount Entered for Transfer is :" + amount);
        return amount;
    }

    public void enterLargeAmount() {
        isAmountFieldEditable();
        this.amountField.clear();
        this.amountField.sendKeys(LARGEAMOUNT);
        Reporter.log("Amount Entered for Transfer is :" + LARGEAMOUNT);
    }


}
