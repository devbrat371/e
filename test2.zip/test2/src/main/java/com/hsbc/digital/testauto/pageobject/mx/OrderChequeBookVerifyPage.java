/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.mx;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.pageobject.OrderChequeBookVerifyPageModel;

/**
 * <p>
 * <b> This class will hold locators and specific implementation for Order
 * Cheque Book for Mexico entity. </b>
 * </p>
 */
public class OrderChequeBookVerifyPage extends OrderChequeBookVerifyPageModel {

    /********************** Locators on Verify Page ******************************/

    // Locator for account number on verify Page
    @FindBy(xpath = "//dd[contains(@data-dojo-attach-point,'verifyAssociatedAccount')]/span[contains(@class,'verifyAccountNumber')]")
    private WebElement accountNumberVerifyPage;

    // Locator for number Of Cheque book pages on verify Page
    @FindBy(xpath = "//dd[@data-dojo-attach-point='_verifyNumberOfPagesInChequeBook']")
    private WebElement numberOfPagesVerifyPage;

    // Locator for delivery address
    @FindBy(xpath = "//dd[@data-dojo-attach-point='_verifyNumberOfPagesInChequeBook']/following-sibling::dt")
    private WebElement deliveryAddressVerifyPage;

    // Locator for Cancel message on Cancel dialog box
    @FindBy(xpath = "//div[@data-dojo-attach-point='_verifyCancelDialog']//div[@class='formWrapper']")
    private WebElement verifyPageCancelMessage2;

    // Locator for Disclaimer on Verify Page
    @FindBy(xpath = "//div[contains(@data-dojo-attach-point,'verify')]//div[contains(@class,'sectionedFooter')]/p")
    private WebElement disclaimerMessageVerifyPage;

    public OrderChequeBookVerifyPage(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    /**
     * Method to verify if Disclaimer Message is displayed on verify page.
     * 
     */
    @Override
    public void isDisclaimerMessageOnVerifyPageDisplayed() {
        Assert.assertTrue(disclaimerMessageVerifyPage.isDisplayed(), "Disclaimer Message On Verify Page is not displayed. ");
        Reporter.log("Disclaimer Message On Verify Page is displayed. ");
    }

    /**
     * Method to verify if delivery address is displayed on verify page.
     * 
     */
    @Override
    public void isDeliveryAddressOnVerifyPageDisplayed() {
        Assert.assertTrue(deliveryAddressVerifyPage.isDisplayed(), "Delivery Address is not displayed. ");
        Reporter.log("Delivery Address is displayed. ");
    }

    /**
     * Method to verify Number Of Pages in cheque book on verify page.
     * 
     * @param accountDetails
     */
    @Override
    public void verifyNumberOfPagesVerifyPage(final AccountDetails accountDetails) {
        Assert.assertTrue(accountDetails.getNumberOfPages().equals(numberOfPagesVerifyPage.getText()),
            "Number of Cheques on verify page does not match. ");
        Reporter.log("Number of Pages in Cheque Book on verify page are same as selected. ");
    }

    /**
     * Method to verify account selected on verify page
     * 
     * @param accountDetails
     */
    @Override
    public void verifyAccountDetailsVerifyPage(final AccountDetails accountDetails) {
        Assert.assertTrue(accountNameVerifyPage.getText().contains(accountDetails.getAccountName())
            && accountDetails.getAccountNumber().equals(accountNumberVerifyPage.getText()),
            "Account Details on verify page does not match. ");
        Reporter.log("Account Details on verify page are same as selected. ");
    }

    /**
     * Method to verify message on verify page cancel dialog box.
     * 
     */
    @Override
    public void isCancelMessageOnVerifyPageDisplayed() {
        Assert.assertTrue(verifyPageCancelMessage1.isDisplayed() && verifyPageCancelMessage2.isDisplayed()
            && !verifyPageCancelMessage1.getText().isEmpty() && !verifyPageCancelMessage2.getText().isEmpty(),
            "Cancel message on cancel dialog of verify page is not displayed. ");
        Reporter.log("Cancel message on cancel dialog of Verify Page is displayed. ");
    }

}
