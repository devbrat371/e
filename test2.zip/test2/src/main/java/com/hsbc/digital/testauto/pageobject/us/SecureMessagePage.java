/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.us;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.DateUtil;
import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.library.ScreenShot;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.models.SecureMessagingEnums;
import com.hsbc.digital.testauto.pageobject.SecureMessage;
import com.hsbc.digital.testauto.pageobject.SecureMessageModel;
import com.hsbc.digital.testauto.ui.library.UICommonUtil;

/**
 * <p>
 * <b>This class will have locators and specific behaviours for Canada for
 * Secure Messaging story. </b>
 * </p>
 */
public class SecureMessagePage extends SecureMessageModel {

    private final WebDriverWait wait;
    private final WebDriver driver;
    private int messageCount = 0;
    private String msgTitle = null;
    private String amountValueTxnSummary = null;
    private String selectedAccNm = null;
    private String selectedAccNum = null;
    private final JavascriptExecutor jsx;
    private static final String SCROLL_TO_VIEW = "arguments[0].scrollIntoView(true);";
    AccountDetails ad;
    SecureMessage smp;
    protected final UICommonUtil uiCommonUtil;

    @FindBy(xpath = "//h2[@data-dojo-attach-point='_heading']")
    public WebElement printPopUpHeading2;

    @FindBy(xpath = "//button[@data-dojo-attach-point='_printButton']")
    private WebElement printButton;

    @FindBy(xpath = "//button[@data-dojo-attach-point='printButton']")
    private WebElement printPopUpPrintButton;

    @FindBy(xpath = "//button[@data-dojo-attach-point='closeButton']")
    private WebElement printPopUpCancelButton;

    @FindBy(xpath = "//button[@data-dojo-attach-point='closeButton']")
    private WebElement logoPrintPrev;

    @FindBy(xpath = ".//*[@id='delete']")
    private WebElement deleteMessageButton;

    @FindBy(xpath = "//button[@data-dojo-attach-point='_deleteDialogYesBtn']")
    private WebElement deletePopupYesButton;

    @FindBy(xpath = "//button[@data-dojo-attach-point='_deleteDialogNoBtn']")
    private WebElement deletePopupNoButton;

    @FindBy(xpath = ".//*[@id='dijit_form_DropDownButton_0_label']")
    private WebElement messageCenterIcon;

    @FindBy(xpath = "//a[@class='viewAllLink' and @data-dojo-attach-point='_viewAllMessagesLink']")
    private WebElement viewAllMsgLink;

    private final By viewAllMgsLocator = By.xpath("//a[@class='viewAllLink' and @data-dojo-attach-point='_viewAllMessagesLink']");

    private final By messageListLoader = By.xpath("//div[@id='MsgsListSidebar']//li[contains(@class,'loading')]");

    private final By messageListContainer = By.xpath("//div[contains(@class,'scrollPaneWrapper')]//ul[@class='listbox']");

    private final By menuText = By.cssSelector("[id$='_text']");

    protected final By menuPopup = By.cssSelector("div.dijitReset.dijitMenuItem[id*='_popup']");

    @FindBy(xpath = "//span[@data-dojo-attach-point='_dapNickname']")
    public WebElement selectedAccNickname;

    @FindBy(xpath = "//p[@data-dojo-attach-point='_dapAccountNumber']")
    public WebElement selectedAccNumber;

    // @FindBy(xpath =
    // "//div[@aria-label='Transaction Summary']//div[@class='gridxMain']//tr[1]//a[contains(text(),'Report a problem')]")
    @FindBy(xpath = "//div[@aria-label='Transaction Summary']//div[@class='gridxMain']//tr[1]//a[contains(text(),'Need Help')]")
    public WebElement reportAProblemLink;

    @FindBy(xpath = "//div[@aria-label='Transaction Summary']//div[@class='gridxMain']//tr[1]//a[contains(text(),'Need Help')]")
    public List<WebElement> listReportAProblemLink;

    @FindBy(xpath = "//div[@aria-label='Transaction Summary']//div[@class='gridxMain']//tr[1]//span[@class='payeeItem0']")
    public WebElement firstTxnDetails;

    @FindBy(xpath = "//div[@aria-label='Transaction Summary']//div[@class='gridxMain']//tr[1]//td[@colid='colAmount']")
    public WebElement firstTxnAmount;

    @FindBy(xpath = "//div[contains(@id,'ReportTransactionDialog') and not(contains(@style,'display: none')) and @role='dialog']")
    public WebElement reportingProblemDialog;

    @FindBy(xpath = "//div[@class='scrollWindow']//span[contains(@class,'row')]//span[@class='itemDetails'][contains(.,'CHECKING') or contains(.,'HSBC')]")
    public List<WebElement> listCheckingAcc;

    @FindBy(xpath = "//h1//span[text()='My accounts']")
    public WebElement dashboardPageTitle;

    // Submit billing dispute
    @FindBy(xpath = "//button[text()='Bill pay problem']")
    protected WebElement billPayProblemButton;

    @FindBy(xpath = "//h2[@data-dojo-attach-point='_submitBillingDisputeheading']")
    protected WebElement submitBillingDisputeTitle;

    @FindBy(xpath = "//div[contains(@class,'dijitMenuActive')]")
    protected WebElement activeMenuDropdown;

    @FindBy(xpath = "//input[contains(@id,'reasonForDispute')]")
    protected WebElement problemReasonArrow;

    @FindBy(xpath = "//input[contains(@id,'mername')]")
    protected WebElement payeeNameInput;

    @FindBy(xpath = "//textarea[contains(@id,'additionalComments')]")
    protected WebElement additionalCommentsBillingInput;

    @FindBy(xpath = "//label[@data-dojo-attach-point='additionalCommentLbl']")
    protected WebElement additionalCommentsLabel;

    protected static final By visibleParentElement = By.xpath("//div[contains(@class,'dijitVisible')]");

    /******** Page Elements *******/
    protected final By pageFieldValue = By.xpath("//dd");

    protected final By pageFieldName = By.xpath("//dt");

    // Report a Transaction Problem
    @FindBy(xpath = "//button[text()='Other problem']")
    protected WebElement otherProblemButton;

    @FindBy(xpath = "//h2[@data-dojo-attach-point='mainHeading'][contains(text(),'Report a problem')]")
    protected WebElement reportAProblemTitle;

    @FindBy(xpath = "//input[contains(@id,'transactionType')]")
    protected WebElement typeOfTransactionArrow;

    @FindBy(xpath = "//input[contains(@id,'problemReason')]")
    protected WebElement problemWithTxnArrow;

    @FindBy(xpath = "//div[text()='Payment amount' or text()='Amount']//following-sibling::div//span[@name='currencyField1ReadOnly']")
    protected WebElement amountValue;

    @FindBy(xpath = "//textarea[contains(@id,'additionalComments')]")
    protected WebElement additionalCommentsInput;

    @FindBy(xpath = "//button[text()='Continue']")
    protected WebElement continueButton;

    @FindBy(xpath = "//div[contains(@class,'dijitVisible')]//button[@data-dojo-attach-point='cancelCaptureBtn' or @data-dojo-attach-point='cancelVerifyBtn']")
    protected WebElement cancelButton;

    @FindBy(xpath = "//div[contains(@class,'dijitDialogFixed') and not(contains(@style,'display: none'))]")
    protected List<WebElement> listCancelDialog;

    @FindBy(xpath = "//div[contains(@class,'dijitDialogFixed')]//button[@data-dojo-attach-point='cancelCaptureDialogYes' or @data-dojo-attach-point='cancelVerifyDialogYes']")
    protected WebElement cancelPopUpYesButton;

    @FindBy(xpath = "//div[contains(@class,'dijitDialogFixed')]//button[@data-dojo-attach-point='cancelCaptureDialogNo' or @data-dojo-attach-point='cancelVerifyDialogNo']")
    protected WebElement cancelPopUpNoButton;

    @FindBy(xpath = "//span[contains(@data-dojo-attach-point,'requiredCommentMessage')]")
    protected WebElement errorMandatoryComment;

    // Verify page
    @FindBy(xpath = "//span[text()='Edit']//ancestor::span[contains(@id,'Button') and @role='button']")
    protected WebElement editButton;

    @FindBy(xpath = "//button[@data-dojo-attach-point='sendVerifyBtn']")
    protected WebElement sendButton;

    @FindBy(xpath = "//button[@data-dojo-attach-point='dashboardBtn']")
    protected WebElement myAccountsBtn;

    // smart search
    // @FindBy(xpath =
    // "//span[@title='Search']//ancestor::span[1][contains(@class,'Button')]")
    @FindBy(xpath = "//span[@title='Search'][@class='icon']")
    protected WebElement searchBtnDashbrd;

    @FindBy(xpath = "//input[contains(@id,'fromAmount') and contains(@id,'CurrencyTextBox')]")
    protected WebElement fromAmountInput;

    @FindBy(xpath = "//input[contains(@id,'toAmount') and contains(@id,'CurrencyTextBox')]")
    protected WebElement toAmountInput;

    @FindBy(xpath = "//button[@title='View results']")
    protected WebElement viewResultsBtn;

    @FindBy(xpath = "//button[@data-dojo-attach-point='_reviewtransnotlisted']")
    protected WebElement transactionNtListedBtn;

    // Report a problem with a bill payment page with smart search
    @FindBy(xpath = "//div[contains(@class,'dijitVisible')]//input[contains(@id,'SecureMsgsAccountSelect')]")
    protected WebElement accountDropArrow;

    @FindBy(xpath = "//div[contains(@class,'dijitVisible')]//input[contains(@id,'transactionDate') and contains(@class,'dijitArrowButtonInner')]")
    protected WebElement transactionDateIcon;

    @FindBy(xpath = "//div[contains(@class,'dijitVisible')]//input[contains(@id,'postingdate') and contains(@class,'dijitArrowButtonInner')]")
    protected WebElement apprPostingDateIcon;

    @FindBy(xpath = "//div[contains(@class,'dijitVisible')]//div[text()='Payment frequency (optional)']//following-sibling::div//input[contains(@id,'Select')]")
    protected WebElement paymentFreqDropArrow;

    @FindBy(xpath = "//table[contains(@id,'postingdate_popup')]")
    protected WebElement approPostingDateTable;

    @FindBy(xpath = "//div[contains(@class,'dijitVisible')]//input[contains(@id,'transactionAmountOptional_CurrencyTextBox')]")
    protected WebElement paymentAmountInput;

    @FindBy(xpath = "//div[contains(@class,'dijitVisible')]//input[contains(@id,'transactionAmountOptional_CurrencyTextBox')]")
    protected WebElement selectedAcctName;

    @FindBy(xpath = "//div[contains(@class,'dijitVisible')]//input[contains(@id,'transactionAmountOptional_CurrencyTextBox')]")
    protected WebElement selectedAcctNumber;

    @FindBy(xpath = "//div[contains(@class,'dijitVisible')]//input[contains(@id,'postingdate') and @role='textbox']//following-sibling::input")
    protected WebElement dateDisplayedValue;

    @FindBy(xpath = "//div[contains(@class,'dijitVisible')]//label[text()='Approximate posting date']")
    protected WebElement apprPostingDateLabel;

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(SecureMessagePage.class);

    public SecureMessagePage(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
        this.driver = driver;
        wait = new WebDriverWait(driver, 30);
        jsx = (JavascriptExecutor) driver;
        smp = new SecureMessage();
        uiCommonUtil = new UICommonUtil(driver);
    }

    public String selectAccountDashboard(final AccountDetails accountDetails, final List<WebElement> list) {
        int randomIndex = RandomUtil.generateIntNumber(1, list.size());
        String accountText = StringUtils.EMPTY;
        for (int index = 0; index < list.size(); index++) {
            WebElement element = list.get(index);
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
            if ((accountDetails != null && element.getText().contains(accountDetails.getAccountNumber()))
                || (accountDetails == null && index == randomIndex)) {
                accountText = element.getText();
                element.click();
                break;
            }
        }
        return accountText;
    }

    protected void selectValueDropdown(final WebElement arrowDrop, final WebElement menuDrop, final String valueToSelect) {
        arrowDrop.click();
        wait.until(ExpectedConditions.visibilityOf(menuDrop));
        List<WebElement> valueElements = menuDrop.findElements(menuText).isEmpty() ? menuDrop.findElements(menuPopup) : menuDrop
            .findElements(menuText);
        for (WebElement valueElement : valueElements) {
            jsx.executeScript(SCROLL_TO_VIEW, valueElement);
            if (valueElement.getText().contains(valueToSelect)) {
                wait.until(ExpectedConditions.elementToBeClickable(valueElement));
                valueElement.click();
                Reporter.log(valueToSelect + " is selected in dropdown.");
                break;
            }
        }
    }

    @Override
    public void printMessage() {
        try {
            printButton.click();
            wait.until(ExpectedConditions.visibilityOf(printPopUpHeading2));
            Reporter.log("Print pop up displayed");
            if (printPopUpPrintButton.isDisplayed() && printPopUpCancelButton.isDisplayed()) {
                Reporter.log("Print and Cancel buttons are displayed");
                ScreenShot.takeScreenShot(driver);
                printPopUpCancelButton.click();
            } else {
                Reporter.log("Print and Cancel buttons are not displayed");
                Assert.fail("Print pop up not verified.");
            }
        } catch (Exception e) {
            logger.info("Exception occurred" + e);
        }
    }

    @Override
    public void deleteCurrentMessage(final boolean deleteConfirmation) {
        msgTitle = super.readMessage();
        String xpath = "//span[@class='subject']//span[contains(text(),'" + msgTitle + "')]";
        messageCount = driver.findElements(By.xpath(xpath)).size();
        deleteMessageButton.click();
        if (deletePopupYesButton.isDisplayed() && deletePopupNoButton.isDisplayed()) {
            logger.info("Delete message pop up verified.");
        }
        ScreenShot.takeScreenShot(driver);
        if (deleteConfirmation) {
            deletePopupYesButton.click();
            Reporter.log("Yes button is clicked on Delete confirmation.");
        } else {
            deletePopupNoButton.click();
            logger.info("No button is clicked on Delete confirmation.");
        }
    }

    @Override
    public void isMessageExist(final String messageTitle) {
        String xpath = "//span[@class='subject']//span[contains(text(),'" + msgTitle + "')]";
        int oldCount = messageCount;
        messageCount = driver.findElements(By.xpath(xpath)).size();
        if (messageCount == oldCount) {
            Assert.fail("Deleted Message exist");
        } else {
            logger.info("Message deleted successfully :" + messageTitle);
        }
    }

    @Override
    public void navigateToMessageCenter() {
        messageCenterIcon.click();
        wait.until(ExpectedConditions.presenceOfElementLocated(viewAllMgsLocator));
        viewAllMsgLink.click();
        wait.until(ExpectedConditions.presenceOfElementLocated(messageListContainer));
        wait.until(ExpectedConditions.invisibilityOfElementLocated(messageListLoader));
    }

    @Override
    public void navigateToReportProblem(SecureMessage sm, WebElement btn) {
        try {
            selectAccountDashboard(ad, listCheckingAcc);
            while (listReportAProblemLink.isEmpty()) {
                selectAccountDashboard(ad, listCheckingAcc);
            }
            selectedAccNm = selectedAccNickname.getText().trim();
            selectedAccNum = selectedAccNumber.getText().trim();
            sm.setAccountName(selectedAccNm);
            sm.setAccountNumber(selectedAccNum);
            reportAProblemLink.click();
            amountValueTxnSummary = firstTxnAmount.getText();
            sm.setPaymentAmount(amountValueTxnSummary);
            wait.until(ExpectedConditions.visibilityOf(reportingProblemDialog));
            if (btn.equals(billPayProblemButton)) {
                billPayProblemButton.click();
                wait.until(ExpectedConditions.visibilityOf(submitBillingDisputeTitle));
                ScreenShot.takeScreenShot(driver);
            } else if (btn.equals(otherProblemButton)) {
                otherProblemButton.click();
                wait.until(ExpectedConditions.visibilityOf(reportAProblemTitle));
                ScreenShot.takeScreenShot(driver);
            }
        } catch (Exception e) {
            logger.error("Exception occurred in navigateToReportProblem!!" + e);
            ScreenShot.takeScreenShot(driver);
        }
    }

    @Override
    public void enterBillingDisputeDetailsTxnSummary(SecureMessage sm, String problemReason, String payeeName,
        String additionalComments) {
        try {
            sm.setProblemReason(problemReason);
            sm.setPayeeName(payeeName);
            sm.setAdditionalComments(additionalComments);
            selectValueDropdown(problemReasonArrow, activeMenuDropdown, problemReason);
            if (amountValue.getText().equalsIgnoreCase(amountValueTxnSummary)) {
                logger.info("Amount value displayed as per the amount displayed on Transaction summary");
            } else
                logger.error("Amount value is not displayed as per the amount displayed on Transaction summary");
            payeeNameInput.clear();
            payeeNameInput.sendKeys(payeeName);
            if (problemReason.equals(SecureMessagingEnums.problemReason.OTHER_PAY_PROB.getValue())) {
                continueButton.click();
                wait.until(ExpectedConditions.visibilityOf(errorMandatoryComment));
                if (errorMandatoryComment.isDisplayed())
                    logger.info(errorMandatoryComment.getText() + " error displayed");
                else
                    logger.error("No error displayed");
                ScreenShot.takeScreenShot(driver);
                additionalCommentsBillingInput.sendKeys(additionalComments);
                additionalCommentsLabel.click();
            }
        } catch (Exception e) {
            logger.error("Exception occurred in enterBillingDisputeDetails!!" + e);
            ScreenShot.takeScreenShot(driver);
        }
    }

    @Override
    public void clickContinueButton(WebElement pageTitle) {
        try {
            continueButton.click();
            wait.until(ExpectedConditions.visibilityOf(pageTitle));
        } catch (Exception e) {
            logger.error("Exception occurred in clickContinueButton! " + e);
        }
    }

    @Override
    public void clickEditButton() {
        try {
            editButton.click();
        } catch (Exception e) {
            logger.error("Exception occurred in clickEditButton! " + e);
        }
    }

    @Override
    public void clickSendButton(WebElement pageTitle) {
        try {
            sendButton.click();
            wait.until(ExpectedConditions.visibilityOf(pageTitle));
        } catch (Exception e) {
            logger.error("Exception occurred in clickSendButton! " + e);
        }
    }

    @Override
    public void clickMyAccounts() {
        try {
            myAccountsBtn.click();
            wait.until(ExpectedConditions.visibilityOf(dashboardPageTitle));
            logger.info("Navigated to Dashboard page");
        } catch (Exception e) {
            logger.error("Exception occurred in clickMyAccounts! " + e);
        }
    }

    @Override
    public void enterReportProblemDetailsTxnSummary(SecureMessage sm, String typeOfTxn, String problemWithTxn,
        String additionalComments) {
        try {
            sm.setTypeOfTxn(typeOfTxn);
            sm.setProblemWithTxn(problemWithTxn);
            sm.setAdditionalComments(additionalComments);
            selectValueDropdown(typeOfTransactionArrow, activeMenuDropdown, typeOfTxn);
            selectValueDropdown(problemWithTxnArrow, activeMenuDropdown, problemWithTxn);
            if (amountValue.getText().equalsIgnoreCase(amountValueTxnSummary)) {
                logger.info("Amount value displayed as per the amount displayed on Transaction summary");
            } else
                logger.error("Amount value is not displayed as per the amount displayed on Transaction summary");
            if (problemWithTxn.equals(SecureMessagingEnums.problemWithTxnArray.OTHER.getValue())) {
                continueButton.click();
                wait.until(ExpectedConditions.visibilityOf(errorMandatoryComment));
                if (errorMandatoryComment.isDisplayed())
                    logger.info(errorMandatoryComment.getText() + " error displayed");
                else
                    logger.error("No error displayed");
                ScreenShot.takeScreenShot(driver);
                additionalCommentsInput.sendKeys(additionalComments);
                additionalCommentsLabel.click();
            }
        } catch (Exception e) {
            logger.error("Exception occurred in enterBillingDisputeDetails!!" + e);
            ScreenShot.takeScreenShot(driver);
        }
    }

    @Override
    public void cancelBillingDispute(final boolean isConfirm) {
        cancelProblem(isConfirm);
    }

    @Override
    public void cancelProblem(final boolean isConfirm) {
        cancelButton.click();
        if (listCancelDialog.isEmpty())
            cancelButton.click();
        else
            ;
        if (isConfirm) {
            cancelPopUpYesButton.click();
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By
                .xpath("//div[contains(@class,'dijitDialogFixed') and not(contains(@style,'display: none'))]")));
            logger.info("Cancel button clicked from Pop up.");
        } else {
            cancelPopUpNoButton.click();
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By
                .xpath("//div[contains(@class,'dijitDialogFixed') and not(contains(@style,'display: none'))]")));
            logger.info("Don't Cancel button clicked from Pop up.");
        }
    }

    @Override
    public void verifyProblem(final WebElement pageTitle, final boolean isCancel) {
        if (isCancel && dashboardPageTitle.isDisplayed()) {
            Reporter.log("Older session doesnot exists and Cancel successful");
        } else if (!isCancel && pageTitle.isDisplayed()) {
            Reporter.log("Older session exists");
        } else {
            Assert.fail("Report problem cancellation not worked");
        }
    }

    @Override
    public void validateSubmitBillingDispute(SecureMessage sm, WebElement elem) {
        wait.until(ExpectedConditions.visibilityOf(elem));
        isAccountNumberDisplayed(sm);
        isAccountNameDisplayed(sm);
        isProblemReasonDisplayed(sm);
        isPaymentAmountDisplayed(sm);
        isPayeeNameDisplayed(sm);
        ScreenShot.takeScreenShot(driver);
    }

    @Override
    public void validateReportTxnProblem(SecureMessage sm, WebElement elem) {
        wait.until(ExpectedConditions.visibilityOf(elem));
        isAccountNumberDisplayed(sm);
        isAccountNameDisplayed(sm);
        isTypeOfTxnDisplayed(sm);
        isAmountDisplayed(sm);
        isProblemWithTxnDisplayed(sm);
        ScreenShot.takeScreenShot(driver);
    }

    @Override
    public void navigateToRprtPrblmSmartSearch(SecureMessage sm, WebElement btn) {
        try {
            selectAccountDashboard(ad, listCheckingAcc);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By
                .xpath("//span[@class='ajaxLoader'][@style='display: inline-block;']")));
            searchBtnDashbrd.click();
            if (!fromAmountInput.isDisplayed())
                searchBtnDashbrd.click();
            wait.until(ExpectedConditions.visibilityOf(fromAmountInput));
            fromAmountInput.sendKeys("0");
            toAmountInput.sendKeys("100");
            viewResultsBtn.click();
            wait.until(ExpectedConditions.visibilityOf(transactionNtListedBtn));
            transactionNtListedBtn.click();
            wait.until(ExpectedConditions.visibilityOf(reportingProblemDialog));
            if (btn.equals(billPayProblemButton)) {
                billPayProblemButton.click();
                wait.until(ExpectedConditions.visibilityOf(submitBillingDisputeTitle));
                ScreenShot.takeScreenShot(driver);
            } else if (btn.equals(otherProblemButton)) {
                otherProblemButton.click();
                wait.until(ExpectedConditions.visibilityOf(reportAProblemTitle));
                ScreenShot.takeScreenShot(driver);
            }
        } catch (Exception e) {
            logger.error("Exception occurred in navigateToRprtPrblmSmartSearch!!" + e);
            ScreenShot.takeScreenShot(driver);
        }
    }

    public Date enterPrevDate(final Map<String, String> envProperties) throws ParseException {
        return uiCommonUtil.selectDate(apprPostingDateIcon, approPostingDateTable, prevDate(envProperties));
    }

    @Override
    public void enterBillingDisputeDetailsSmartSearch(final Map<String, String> envProperties, SecureMessage sm,
        String problemReason, String paymentFreq, String paymentAmount, String payeeName, String additionalComments) {
        try {
            String accountName;
            String accountNumber;
            String dateDisplayed;
            sm.setProblemReason(problemReason);
            sm.setPayeeName(payeeName);
            sm.setAdditionalComments(additionalComments);
            sm.setPaymentFreq(paymentFreq);
            accountName = selectedAcctName.getText();
            accountNumber = selectedAcctNumber.getText();
            sm.setAccountName(accountName);
            sm.setAccountNumber(accountNumber);
            selectValueDropdown(problemReasonArrow, activeMenuDropdown, problemReason);
            enterPrevDate(envProperties);
            apprPostingDateLabel.click();
            dateDisplayed = dateDisplayedValue.getAttribute("value");
            sm.setApprPostingDate(dateDisplayed);
            selectValueDropdown(paymentFreqDropArrow, activeMenuDropdown, paymentFreq);
            paymentAmountInput.clear();
            paymentAmountInput.sendKeys(paymentAmount);
            payeeNameInput.clear();
            payeeNameInput.sendKeys(payeeName);
            if (problemReason.equals(SecureMessagingEnums.problemReason.OTHER_PAY_PROB.getValue())) {
                continueButton.click();
                wait.until(ExpectedConditions.visibilityOf(errorMandatoryComment));
                if (errorMandatoryComment.isDisplayed())
                    logger.info(errorMandatoryComment.getText() + " error displayed");
                else
                    logger.error("No error displayed");
                ScreenShot.takeScreenShot(driver);
                additionalCommentsBillingInput.sendKeys(additionalComments);
                additionalCommentsLabel.click();
            }
        } catch (Exception e) {
            logger.error("Exception occurred in enterBillingDisputeDetails!!" + e);
            ScreenShot.takeScreenShot(driver);
        }
    }

    /**
     * Method to return valid later or recurring date, avoiding Saturday/Sunday
     * 
     * @throws ParseException
     */
    private Date prevDate(final Map<String, String> envProperties) throws ParseException {
        Date parseDate = validDate(envProperties);
        Calendar cal = Calendar.getInstance();
        cal.setTime(parseDate);
        cal.add(Calendar.DAY_OF_YEAR, SecureMessageModel.DEFAULT_DAYS_TO_SUB_FOR_VALID_PREV_DATE);
        int dayofWeek = cal.get(Calendar.DAY_OF_WEEK);
        if (dayofWeek == Calendar.SATURDAY) {
            cal.add(Calendar.DAY_OF_YEAR, SecureMessageModel.DEFAULT_DAYS_TO_SUB_TO_AVOID_SATURDAY);
            parseDate = cal.getTime();
        } else if (dayofWeek == Calendar.SUNDAY) {
            cal.add(Calendar.DAY_OF_YEAR, SecureMessageModel.DEFAULT_DAYS_TO_SUB_TO_AVOID_SUNDAY);
            parseDate = cal.getTime();
        } else {
            parseDate = cal.getTime();
        }
        return parseDate;
    }

    /**
     * Method to return hub date and if its not specified, return system date
     * 
     * @throws ParseException
     */
    private static Date validDate(final Map<String, String> envProperties) throws ParseException {
        if (!envProperties.get(SecureMessageModel.HUB_DATE).trim().isEmpty()) {
            return DateUtil.getStringToDate(envProperties.get(SecureMessageModel.HUB_DATE_FORMAT),
                envProperties.get(SecureMessageModel.HUB_DATE));
        } else {
            return new Date();
        }
    }

    @Override
    public void validateBillingDisputeSmartSearch(SecureMessage sm, WebElement elem) {
        wait.until(ExpectedConditions.visibilityOf(elem));
        isAccountNumberDisplayed(sm);
        isAccountNameDisplayed(sm);
        isProblemReasonDisplayed(sm);
        isPaymentFrequency(sm);
        isPaymentAmountDisplayed(sm);
        isPayeeNameDisplayed(sm);
        ScreenShot.takeScreenShot(driver);
    }

    @Override
    protected void isAccountNumberDisplayed(SecureMessage sm) {
        Assert.assertTrue(this.uiCommonUtil.textByParentAndSibling(LABEL_ACCOUNT, sm.getAccountNumber(), visibleParentElement,
            this.pageFieldName, this.pageFieldValue), "Account number not found.");
        SecureMessagePage.logger.info("Account Number displayed is :" + sm.getAccountNumber());
        Reporter.log("Account Number displayed is :" + sm.getAccountNumber());
    }

    @Override
    protected void isAccountNameDisplayed(SecureMessage sm) {
        Assert.assertTrue(this.uiCommonUtil.textByParentAndSibling(LABEL_ACCOUNT, sm.getAccountName(), visibleParentElement,
            this.pageFieldName, this.pageFieldValue), "Account Name not found.");
        SecureMessagePage.logger.info("Account Name displayed is :" + sm.getAccountName());
        Reporter.log("Account Name displayed is :" + sm.getAccountName());
    }

    @Override
    protected void isProblemReasonDisplayed(SecureMessage sm) {
        Assert.assertTrue(this.uiCommonUtil.textByParentAndSibling(LABEL_PROBLEM_REASON, sm.getProblemReason(),
            visibleParentElement, this.pageFieldName, this.pageFieldValue), "Problem reason not found.");
        SecureMessagePage.logger.info("Problem reason displayed is :" + sm.getProblemReason());
        Reporter.log("Problem reason displayed is :" + sm.getProblemReason());
    }

    @Override
    protected void isPaymentAmountDisplayed(SecureMessage sm) {
        Assert.assertTrue(this.uiCommonUtil.textByParentAndSibling(LABEL_PAYMENT_AMOUNT, sm.getPaymentAmount(),
            visibleParentElement, this.pageFieldName, this.pageFieldValue), "Payment amount not found.");
        SecureMessagePage.logger.info("Payment amount displayed is :" + sm.getPaymentAmount());
        Reporter.log("Payment amount displayed is :" + sm.getPaymentAmount());
    }

    @Override
    protected void isPayeeNameDisplayed(SecureMessage sm) {
        Assert.assertTrue(this.uiCommonUtil.textByParentAndSibling(LABEL_PAYEE_NAME, sm.getPayeeName(), visibleParentElement,
            this.pageFieldName, this.pageFieldValue), "Payee name not found.");
        SecureMessagePage.logger.info("Payee name displayed is :" + sm.getPayeeName());
        Reporter.log("Payee name displayed is :" + sm.getPayeeName());
    }

    @Override
    public void isAdditionalCommentsDisplayed(SecureMessage sm) {
        Assert.assertTrue(this.uiCommonUtil.textByParentAndSibling(LABEL_ADDITIONAL_COMMENTS, sm.getAdditionalComments(),
            visibleParentElement, this.pageFieldName, this.pageFieldValue), "Additional Comment not found.");
        SecureMessagePage.logger.info("Additional comment displayed is :" + sm.getAdditionalComments());
        Reporter.log("Additional comment displayed is :" + sm.getAdditionalComments());
    }

    @Override
    protected void isAmountDisplayed(SecureMessage sm) {
        Assert.assertTrue(this.uiCommonUtil.textByParentAndSibling(LABEL_AMOUNT, sm.getPaymentAmount(), visibleParentElement,
            this.pageFieldName, this.pageFieldValue), "Amount not found.");
        SecureMessagePage.logger.info("Amount displayed is :" + sm.getPaymentAmount());
        Reporter.log("Amount displayed is :" + sm.getPaymentAmount());
    }

    @Override
    protected void isTypeOfTxnDisplayed(SecureMessage sm) {
        Assert.assertTrue(this.uiCommonUtil.textByParentAndSibling(LABEL_TYPE_OF_TXN, sm.getTypeOfTxn(), visibleParentElement,
            this.pageFieldName, this.pageFieldValue), "Type of Transaction not found.");
        SecureMessagePage.logger.info("Type of Transaction displayed is :" + sm.getTypeOfTxn());
        Reporter.log("Type of Transaction displayed is :" + sm.getTypeOfTxn());
    }

    @Override
    protected void isProblemWithTxnDisplayed(SecureMessage sm) {
        Assert.assertTrue(this.uiCommonUtil.textByParentAndSibling(LABEL_PROBLEM_WITH_TXN, sm.getProblemWithTxn(),
            visibleParentElement, this.pageFieldName, this.pageFieldValue), "Problem with Transaction not found.");
        SecureMessagePage.logger.info("Problem with Transaction displayed is :" + sm.getProblemWithTxn());
        Reporter.log("Problem with Transaction displayed is :" + sm.getProblemWithTxn());
    }

    @Override
    protected void isPaymentFrequency(SecureMessage sm) {
        Assert.assertTrue(this.uiCommonUtil.textByParentAndSibling(LABEL_PAYMENT_FREQUENCY, sm.getPaymentFreq(),
            visibleParentElement, this.pageFieldName, this.pageFieldValue), "Payment Frequency not found.");
        SecureMessagePage.logger.info("Payment Frequency displayed is :" + sm.getPaymentFreq());
        Reporter.log("Payment Frequency displayed is :" + sm.getPaymentFreq());
    }
}
