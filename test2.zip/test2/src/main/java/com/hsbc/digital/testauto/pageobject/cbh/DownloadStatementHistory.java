package com.hsbc.digital.testauto.pageobject.cbh;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.DateUtil;
import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.pageobject.DownloadStatementHistoryModel;

/**
 * <p>
 * <b> This class will hold locators and specific implementation for Download
 * Statement History for Srilanka entity. </b>
 * </p>
 */
public class DownloadStatementHistory extends DownloadStatementHistoryModel {


    @FindBy(xpath = "//input[contains(@id,'arrowid') and contains(@id,'AccountSelect')]")
    private WebElement accountDropDownIcon;

    @FindBy(xpath = "//input[contains(@id,'arrowid') and contains(@id,'form_Select')]")
    private WebElement dateDropDownIcon;

    @FindBy(xpath = "//div[contains(@id,'form_Select') and contains(@id,'menu')]//td[contains(@id,'MenuItem') and contains(@id,'text')]")
    private List<WebElement> dateDropDownItems;

    @FindBy(xpath = "//*[contains(@class,'iconButton viewDownload')]")
    private List<WebElement> downloadStatementButtons;

    @FindBy(xpath = ".//*[@id='notificationMessageId']/div")
    private WebElement confirmMessage;

    @FindBy(xpath = "//div[@data-dojo-attach-point='noStatementsNotification']")
    private WebElement noStatementDiv;

    private static final String NO_TRANSACTION_MEG = "There are no statements available to view.";

    public DownloadStatementHistory(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    public void selectAccountFromDropDownList() {
        selectFromDropDown(accountDropDownIcon, tempDropdownList);
    }

    public AccountDetails selectYearFromDropdown() {
        AccountDetails accountDetails = new AccountDetails();
        selectedYear = selectYearFromDropDownList(dateDropDownItems);
        accountDetails.setSelectedYear(selectedYear);
        Reporter.log("Year: " + selectedYear + " selected from Search By Date List");
        return accountDetails;
    }


    public String selectYearFromDropDownList(final List<WebElement> dateList) {
        dateDropDownIcon.click();
        String selectedDate = StringUtils.EMPTY;
        int datelistCount = dateList.size();
        int selectedElementNumber = RandomUtil.generateIntNumber(0, datelistCount);
        for (int count = 0; count < datelistCount; count++) {
            WebElement tempAccDropDown = dateList.get(count);
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", tempAccDropDown);
            if (count == selectedElementNumber) {
                selectedDate = tempAccDropDown.getText();
                Reporter.log("Dropdown Selected:" + selectedDate);
                tempAccDropDown.click();
                break;
            }
        }
        return selectedDate;
    }

    public void verifyNoTransactionHistoryMessage() {
        if (noStatementDiv.isDisplayed() && !noStatementDiv.getText().isEmpty() && confirmMessage.isDisplayed()
            && confirmMessage.getText().equals(NO_TRANSACTION_MEG)) {
            Reporter.log("There are no transactions present for selected account and date.");
        } else {
            Reporter.log("There is Statement history available for account.");
        }
    }


    @Override
    public void clickAndVerifyDownloadTransaction() {
        int currentWindowCount = driver.getWindowHandles().size();
        if (!downloadStatementButtons.isEmpty()) {
            int index = RandomUtil.generateIntNumber(0, downloadStatementButtons.size());
            downloadStatementButtons.get(index).click();
            int newWindowCount = driver.getWindowHandles().size();
            Assert.assertTrue(newWindowCount > currentWindowCount, "DownLoad Page Opened");
        } else {
            Reporter.log("No Transaction statements to download.");
        }
    }


    public void verifyDateDropDownList() {
        dateDropDownIcon.click();
        for (WebElement dates : dateDropDownItems) {
            Reporter.log("Date DropDown Options: " + dates.getText());
        }
    }

    public void verifyOrderofDisplay() {
        if (resultedList.size() <= 1) {
            Reporter.log("Not enough statements to check for display order.");
        }
        for (int i = 0; i < resultedList.size() - 1; i++) {
            String firstDateDisplayes = resultedList.get(i).findElement(By.tagName("span")).getText();
            String nextDateDisplayes = resultedList.get(i + 1).findElement(By.tagName("span")).getText();
            try {
                Date firstDate = DateUtil.getStringToDate(getOutputFormat(), firstDateDisplayes);
                Date nextDate = DateUtil.getStringToDate(getOutputFormat(), nextDateDisplayes);
                logger.info("Dates are: firstDate:" + firstDate + " nextDate:" + nextDate);
                if (firstDate.after(nextDate) || firstDate.equals(nextDate)) {
                    Reporter.log("Statement History Displayed in correct Order");
                } else {
                    Reporter.log("Statement History Displayed is not in correct Order");
                    Assert.fail("Statemetn history dates are not in order.");
                }
            } catch (ParseException e) {
                DownloadStatementHistoryModel.logger.error("Date Format Conversion Error", e);
                Assert.fail("Date Parsing error occured.");
            }
        }
    }


    public String getOutputFormat() {
        return DateUtil.DATE_FORMAT_MMMDDYYYY_SPACE;
    }
}