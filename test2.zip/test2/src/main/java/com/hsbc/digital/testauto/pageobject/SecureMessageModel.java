/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.exceptions.SecureMessageNotFoundException;
import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.library.ScreenShot;

/**
 * <p>
 * <b>This class will have locators and behaviours for secure messaging.</b>
 * </p>
 */
public abstract class SecureMessageModel {

    protected String LABEL_ACCOUNT = "Account";
    protected String LABEL_PROBLEM_REASON = "Problem reason";
    protected String LABEL_PAYMENT_AMOUNT = "Payment amount";
    protected String LABEL_AMOUNT = "Amount";
    protected String LABEL_TYPE_OF_TXN = "Type of transaction";
    protected String LABEL_PROBLEM_WITH_TXN = "Problem with transaction";
    protected String LABEL_PAYEE_NAME = "Payee name";
    protected String LABEL_ADDITIONAL_COMMENTS = "Additional comments";
    protected String LABEL_APPROX_POSTING_DATE = "Approximate posting date";
    protected String LABEL_PAYMENT_FREQUENCY = "Payment frequency";
    protected static final int DEFAULT_DAYS_TO_SUB_FOR_VALID_PREV_DATE = -2;
    protected static final int DEFAULT_DAYS_TO_SUB_TO_AVOID_SATURDAY = -1;
    protected static final int DEFAULT_DAYS_TO_SUB_TO_AVOID_SUNDAY = -2;
    protected static final String HUB_DATE = "hubDate";
    protected static final String HUB_DATE_FORMAT = "hubFormat";
    public static final String DEFAULT_PAYMENT_AMOUNT = "10";

    @FindBy(xpath = ".//*[@id='dijit_form_DropDownButton_0_label']")
    private WebElement messageCenterIcon;

    @FindBy(xpath = "//a[@class='viewAllLink' and @data-dojo-attach-point='_viewAllMessagesLink']")
    private WebElement viewAllMsgLink;

    @FindBy(xpath = "//span[@data-dojo-attach-point='_unreadMessage']")
    private WebElement notificationIcon;

    @FindBy(xpath = "//a[@data-dojo-attach-point='_composeButtonUnLocked']")
    private WebElement sendMessageLinkMenu;

    private final By sendMessageLinkMenuLocator = By.xpath("//a[@data-dojo-attach-point='_composeButtonUnLocked']");

    private final By viewAllMgsLocator = By.xpath("//a[@class='viewAllLink' and @data-dojo-attach-point='_viewAllMessagesLink']");

    private final By messageListLoader = By.xpath("//div[@id='MsgsListSidebar']//li[contains(@class,'loading')]");

    private final By messageListContainer = By.xpath("//div[@class='scrollPaneWrapper']//ul[@class='listbox']");

    private final By inputTextAreaLocator = By.xpath(".//*[@id='group_gpib_msgs_bijit_MsgsComposer_0_ariaTextareaLabel']");

    @FindBy(xpath = "//ul[@class='listbox']/li[@data-dojo-attach-point='_msgItemText']/a")
    private List<WebElement> messageList;

    private final By messageSubject = By.xpath("//span[contains(@class,'subject')]");

    @FindBy(xpath = "//button[@data-dojo-attach-point='_replyButton']")
    private WebElement replyButton;

    @FindBy(xpath = "//button[@data-dojo-attach-point='_printButton']")
    private WebElement printButton;

    @FindBy(xpath = "//button[@data-dojo-attach-point='_composeButton']")
    private WebElement sendUsMessageButton;

    @FindBy(xpath = ".//*[@id='delete']")
    private WebElement deleteMessageButton;

    @FindBy(xpath = ".//*[@id='MessageCentreReaderAndComposer_id']//h2[@data-dojo-attach-point='_messageDetailSubjectNode']")
    private WebElement currentMessageTitle;

    @FindBy(xpath = "//dd[@data-dojo-attach-point='_messageContentNode']")
    private WebElement currentMessageBody;

    @FindBy(xpath = ".//*[@id='group_gpib_msgs_bijit_MsgsComposer_0_ariaTextareaLabel']")
    private WebElement inputTextArea;

    @FindBy(xpath = ".//*[@id='dijit_form_Form_0']/div[3]/button[1]")
    private WebElement sendButton;

    @FindBy(xpath = ".//*[@id='MessageCentreReaderAndComposer_id']/div[2]/div[5]/div[1]/p")
    private WebElement confirmationMessage;

    @FindBy(xpath = "//button[@data-dojo-attach-point='_backToMessagesButton']")
    private WebElement backToMessagesButton;

    @FindBy(xpath = ".//*[@id='arrowid_MessageCentreReaderAndComposer_id-subject']")
    private WebElement inquirySubjectDropDownArrow;

    @FindBy(xpath = "//div[@id='MessageCentreReaderAndComposer_id-subject_menu']//td[contains(@id,'dijit_MenuItem_') and contains(@id,'text')]")
    private List<WebElement> inquirySubjectDropDownItems;

    @FindBy(xpath = "//button[@data-dojo-attach-point='_deleteDialogYesBtn']")
    private WebElement deletePopupYesButton;

    @FindBy(xpath = "//button[@data-dojo-attach-point='_deleteDialogNoBtn']")
    private WebElement deletePopupNoButton;

    @FindBy(xpath = "//h1[@data-dojo-attach-point='_heading']")
    private WebElement printPopUpHeading;

    @FindBy(xpath = "//button[@data-dojo-attach-point='printButton']")
    private WebElement printPopUpPrintButton;

    @FindBy(xpath = "//button[@data-dojo-attach-point='closeButton']")
    private WebElement printPopUpCancelButton;

    @FindBy(xpath = "//button[@data-dojo-attach-point='_cancelButton']")
    private WebElement cancelButton;

    @FindBy(xpath = "//button[@data-dojo-attach-point='_cancelDialogYesBtn']")
    protected WebElement cancelPopUpYesButton;

    @FindBy(xpath = "//button[@data-dojo-attach-point='_cancelDialogNoBtn']")
    protected WebElement cancelPopUpNoButton;

    @FindBy(xpath = "//span[@data-dojo-attach-point='_messageReplySubjectNode']")
    private WebElement replyMessageTitle;

    @FindBy(xpath = "//button[text()='Bill pay problem']")
    public WebElement billPayProblemButton;

    @FindBy(xpath = "//button[text()='Other problem']")
    public WebElement otherProblemButton;

    @FindBy(xpath = "//h2[@data-dojo-attach-point='_submitBillingDisputeheading']")
    public WebElement submitBillingDisputeTitle;

    @FindBy(xpath = "//h2[@data-dojo-attach-point='mainHeading'][contains(text(),'Report a problem')]")
    public WebElement reportAProblemTitle;

    @FindBy(xpath = "//h2[@data-dojo-attach-point='_submitBillingDisputeheading']")
    public WebElement reviewBillingDisputeTitle;

    @FindBy(xpath = "//h2[@data-dojo-attach-point='mainHeading' and @class='verifyHeader']")
    public WebElement reviewTxnProbReportTitle;

    @FindBy(xpath = "//h2[@data-dojo-attach-point='_submitBillingDisputeheading'][text()='Confirmation']")
    public WebElement confirmBillingDisputeTitle;

    @FindBy(xpath = "//h2[@data-dojo-attach-point='mainHeading'][text()='Confirmation']")
    public WebElement confirmReportTxnPrbmTitle;

    @FindBy(xpath = "//div[contains(@id,'SubmitDisputeConfirm')]//p[text()='Your bill payment problem report has been sent']")
    public WebElement successMessageBillingDispute;

    @FindBy(xpath = "//div[contains(@id,'ReportProblemConfirm')]//p[text()='Your transaction problem report has been sent']")
    public WebElement successMessageTxnProblm;

    protected WebDriverWait wait;

    private final WebDriver driver;

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(QuickMoveMoneyCaptureModel.class);

    public SecureMessageModel(final WebDriver driver) {
        PageFactory.initElements(driver, this);
        this.driver = driver;
        wait = new WebDriverWait(driver, 30);
    }

    public void navigateToMessageCenter() {
        messageCenterIcon.click();
        wait.until(ExpectedConditions.presenceOfElementLocated(viewAllMgsLocator));
        viewAllMsgLink.click();
        wait.until(ExpectedConditions.presenceOfElementLocated(messageListContainer));
        wait.until(ExpectedConditions.invisibilityOfElementLocated(messageListLoader));
    }

    public void navigateToMessageCenterSendMessage() {
        messageCenterIcon.click();
        wait.until(ExpectedConditions.presenceOfElementLocated(sendMessageLinkMenuLocator));
        sendMessageLinkMenu.click();
        wait.until(ExpectedConditions.presenceOfElementLocated(inputTextAreaLocator));
        wait.until(ExpectedConditions.visibilityOf(inputTextArea));
    }

    public String readMessage() {
        if (messageList.isEmpty()) {
            throw new SecureMessageNotFoundException("No Messages to Read in inbox.");
        }
        String messageSubjectText = selectMessage();
        Reporter.log("Random message selected:" + messageSubjectText);
        if (readMessageContent(messageSubjectText)) {
            Reporter.log("Message boy has been read");
        } else {
            Reporter.log("Not able to read message body");
        }
        return messageSubjectText;
    }

    private String selectMessage() {
        int index = RandomUtil.generateIntNumber(0, messageList.size());
        WebElement messageSubjectRow = messageList.get(index);
        messageSubjectRow.click();
        return messageSubjectRow.findElement(messageSubject).getText();
    }

    private String selectMessage(final String messageTitle) {
        String messageText = StringUtils.EMPTY;
        for (WebElement messages : messageList) {
            if (messages.getText().contains(messageTitle)) {
                messages.click();
                SecureMessageModel.logger.info("Messaged Clicked Successfully");
                messageText = messages.findElement(messageSubject).getText();
                break;
            }
        }
        return messageText;
    }

    private boolean readMessageContent(final String messageSubjectText) {
        boolean isRead = false;
        if (messageSubjectText.equals(currentMessageTitle.getText())) {
            Reporter.log("Message subject title matched.");
        }
        wait.until(ExpectedConditions.visibilityOf(currentMessageBody));
        Reporter.log("Current Message text:" + currentMessageBody.getText());
        return isRead;
    }

    public void replyToMessage(final String messageSubject) {
        Reporter.log("Replying on message :" + messageSubject);
        selectMessage(messageSubject);
        replyButton.click();
        SecureMessageModel.logger.info("reply button clicked");
        typeAndSendMessage(RandomUtil.generateAlphabatic(20));
        checkSuccessMessage();
        Reporter.log("Reply message validation step");
        ScreenShot.takeScreenShot(driver);
    }

    public void backToMessages() {
        backToMessagesButton.click();
    }

    public void checkSuccessMessage() {
        if (confirmationMessage.isDisplayed()) {
            Reporter.log("Message send successfully :" + confirmationMessage.getText());
        } else {
            Reporter.log("Message send operation failed");
            Assert.fail("Success message not received");
        }
    }

    public void typeAndSendMessage(final String message) {
        typeMessage(message);
        ScreenShot.takeScreenShot(driver);
        sendButton.click();
        Reporter.log("Clicked on Send Button");
    }

    private void typeMessage(final String message) {
        inputTextArea.clear();
        inputTextArea.sendKeys(message);
        Reporter.log("Entering message:" + message);
    }

    public void typeReplyMessage() {
        replyButton.click();
        typeMessage(RandomUtil.generateAlphaNumericText(20));
    }

    public void verifyMessage(final String messageTitle, final boolean isCancel) {
        if (isCancel && !replyMessageTitle.isDisplayed()) {
            Reporter.log("Reply message session does not exist.");
        } else if (!isCancel && replyMessageTitle.isDisplayed() && replyMessageTitle.getText().contains(messageTitle)) {
            Reporter.log("Reply message session exist.");
        } else {
            Assert.fail("Message cancellation did not worked.");
        }
    }

    public void cancelReplyMessage(final boolean isConfirm) {
        cancelMessage(isConfirm);
    }

    private void cancelMessage(final boolean isConfirm) {
        cancelButton.click();
        if (isConfirm) {
            cancelPopUpYesButton.click();
            Reporter.log("Cancel button clicked from Pop up.");
        } else {
            cancelPopUpNoButton.click();
            Reporter.log("Don't Cancel button clicked from Pop up.");
        }
    }

    public void printMessage() {
        printButton.click();
        wait.until(ExpectedConditions.visibilityOf(printPopUpHeading));
        Reporter.log("Print pop up displayed");
        if (printPopUpPrintButton.isDisplayed() && printPopUpCancelButton.isDisplayed()) {
            Reporter.log("Print and Cancel buttons are displayed");
            ScreenShot.takeScreenShot(driver);
            printPopUpCancelButton.click();
        } else {
            Reporter.log("Print and Cancel buttons are not displayed");
            Assert.fail("Print pop up not verified.");
        }
    }

    public void deleteCurrentMessage(final boolean deleteConfirmation) {
        deleteMessageButton.click();
        if (deletePopupYesButton.isDisplayed() && deletePopupNoButton.isDisplayed()) {
            Reporter.log("Delete message pop up verified.");
        }
        ScreenShot.takeScreenShot(driver);
        if (deleteConfirmation) {
            deletePopupYesButton.click();
            Reporter.log("Yes button is clicked on Delete confirmation.");
        } else {
            deletePopupNoButton.click();
            Reporter.log("No button is clicked on Delete confirmation.");
        }
    }

    public void isMessageExist(final String messageTitle) {
        boolean isMessageExist = false;
        for (WebElement messages : messageList) {
            if (messages.getText().contains(messageTitle)) {
                isMessageExist = true;
            }
        }
        if (isMessageExist) {
            Assert.fail("Deleted Message exist");
        } else {
            Reporter.log("Message deleted successfully :" + messageTitle);
        }

    }

    public void sendMessage() {
        String randomMessage = RandomUtil.generateAlphabatic(20);
        sendUsMessageButton.click();
        selectInquirySubject();
        Reporter.log("send us message button clicked");
        typeAndSendMessage(randomMessage);
        checkSuccessMessage();
    }

    public void sendMessageFromLink() {
        String randomMessage = RandomUtil.generateAlphabatic(20);
        selectInquirySubject();
        Reporter.log("send us message button clicked");
        typeAndSendMessage(randomMessage);
        checkSuccessMessage();
    }

    private void selectInquirySubject() {
        inquirySubjectDropDownArrow.click();
        int randomIndex = RandomUtil.generateIntNumber(0, inquirySubjectDropDownItems.size());
        WebElement subject = inquirySubjectDropDownItems.get(randomIndex);
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", subject);
        subject.click();
    }

    public void typeNewMessage() {
        sendUsMessageButton.click();
        typeMessage(RandomUtil.generateAlphaNumericText(20));
    }

    public void cancelSendMessage(final boolean isConfirm) {
        cancelMessage(isConfirm);
    }

    public void checkSendMessageCancel(final boolean isConfirm) {
        if (!isConfirm && sendButton.isDisplayed()) {
            Reporter.log("Cancel message session exist.");
        } else if (isConfirm && !sendButton.isDisplayed()) {
            Reporter.log("Cancel message session does not exist.");
        } else {
            Assert.fail("Cancel functionality is not working.");
        }
        ScreenShot.takeScreenShot(driver);
    }

    public void checkMessageNotification() {
        if (notificationIcon.isDisplayed()) {
            Reporter.log("Notification icon is shown :no of unread messages are :" + notificationIcon.getText());
            ScreenShot.takeScreenShot(driver);
        } else {
            Reporter.log("Notification icon not shown.");
        }
    }

    public void navigateToReportProblem(SecureMessage sm, WebElement btn) {};

    public void cancelBillingDispute(final boolean isConfirm) {};

    public void enterBillingDisputeDetailsTxnSummary(SecureMessage sm, String problemReason, String payeeName,
        String additionalComments) {};

    public void enterReportProblemDetailsTxnSummary(SecureMessage sm, String typeOfTxn, String problemWithTxn,
        String additionalComments) {};

    public void cancelProblem(final boolean isConfirm) {};

    public void verifyProblem(final WebElement pageTitle, final boolean isCancel) {}

    protected void isAccountNumberDisplayed(SecureMessage sm) {}

    protected void isAccountNameDisplayed(SecureMessage sm) {}

    protected void isProblemReasonDisplayed(SecureMessage sm) {}

    protected void isPaymentAmountDisplayed(SecureMessage sm) {}

    protected void isPayeeNameDisplayed(SecureMessage sm) {}

    public void isAdditionalCommentsDisplayed(SecureMessage sm) {}

    public void clickContinueButton(WebElement pageTitle) {}

    public void validateSubmitBillingDispute(SecureMessage sm, WebElement elem) {}

    public void clickEditButton() {}

    public void clickSendButton(WebElement ele) {}

    protected void isAmountDisplayed(SecureMessage sm) {}

    protected void isTypeOfTxnDisplayed(SecureMessage sm) {}

    protected void isProblemWithTxnDisplayed(SecureMessage sm) {}

    public void validateReportTxnProblem(SecureMessage sm, WebElement elem) {}

    public void clickMyAccounts() {}

    public void navigateToRprtPrblmSmartSearch(SecureMessage sm, WebElement btn) {}

    public void enterBillingDisputeDetailsSmartSearch(final Map<String, String> envProperties, SecureMessage sm,
        String problemReason, String paymentFreq, String paymentAmount, String payeeName, String additionalComments) {}

    protected void isPaymentFrequency(SecureMessage sm) {}

    public void validateBillingDisputeSmartSearch(SecureMessage sm, WebElement elem) {};

}
