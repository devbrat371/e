/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.digital.testauto.pageobject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.models.AccountDetails;

/**
 * <p>
 * <b> This Model class will hold locators and functionality related methods
 * for Story Order Cheque Book Verify Page that can be used around all entities
 * </b>
 * </p>
 * 
 * @version 1.0.0
 * @author Deepti Patil
 */

public abstract class OrderChequeBookVerifyPageModel {

    protected final WebDriver driver;

    /********************** Locators on Verify Page ******************************/
    // Locator for order cheque book page heading
    @FindBy(xpath = "//div[@id='orderChequeBookId']//h2")
    private WebElement orderChequeBookVerifyPage;

    // Locator for account number on verify Page
    @FindBy(xpath = "//dd[contains(@class,'accountInfoPadding')]/span[contains(@class,'verifyAccountNumber')]")
    private WebElement accountNumberVerifyPage;

    // Locator for account name on verify Page
    @FindBy(xpath = "//dd[@data-dojo-attach-point='_verifyAssociatedAccount']")
    protected WebElement accountNameVerifyPage;

    // Locator for number Of Cheque books on verify Page
    @FindBy(xpath = "//dd[@data-dojo-attach-point='_verifyNumberOfChequeBook']")
    protected WebElement numberOfChequeBookVerifyPage;

    // Locator for Edit Details on verify Page
    @FindBy(xpath = "//span[contains(text(),'Edit') and contains(text(),'details')]")
    private WebElement editDetailsButton;

    // Locator for Edit Details on verify Page
    @FindBy(xpath = "//div[contains(@class,'Panel')]/div[@class='acceptTermsRow']/following-sibling::span//span[contains(@id,'label')]")
    private WebElement confirmButton;

    // Locator for Cancel button
    @FindBy(xpath = "//button[@data-dojo-attach-point='_verifyCancelButton']")
    private WebElement cancelButtonVerifyPage;

    // Locator for Cancel button on Cancel dialog box
    @FindBy(xpath = "//button[@data-dojo-attach-point='_verifyCancelDialogYesBtn' and text()='Cancel']")
    private WebElement verifyPageSecondaryCancelButton;

    // Locator for Cancel message on Cancel dialog box
    @FindBy(xpath = "//div[@data-dojo-attach-point='_verifyCancelDialog']//p")
    private WebElement verifyPageCancelMessage2;

    // Locator for Cancel message on Cancel dialog box
    @FindBy(xpath = "//h2[@data-dojo-attach-point='verifyCancelDialogTitle']")
    protected WebElement verifyPageCancelMessage1;

    // Locator for Disclaimer on Verify Page
    @FindBy(xpath = "//div[contains(@data-dojo-attach-point,'verify')]//div[contains(@class,'disclaimer')]/p")
    protected WebElement disclaimerMessageVerifyPage;

    private static final String EXPECTED_VERIFY_PAGE_TITLE = "Verify";

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(OrderChequeBookVerifyPageModel.class);

    public OrderChequeBookVerifyPageModel(final WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void verifyNumberOfChequeBookVerifyPage(final AccountDetails accountDetails) {}

    public void verifyNumberOfPagesVerifyPage(final AccountDetails accountDetails) {}

    public void isDeliveryAddressOnVerifyPageDisplayed() {}

    public void isDisclaimerMessageOnVerifyPageDisplayed() {}

    public void verifyPageCancelFlow() {
        isOrderChequeVerifyPageDisplayed();
        clickVerifyPageCancelButton();
        isCancelMessageOnVerifyPageDisplayed();
        clickVerifyPageSecondaryCancelButton();
    }

    public void verifyEditDetailsFlow(final AccountDetails accountDetails) {
        verifyDetailsOnVerifyPage(accountDetails);
        clickEditDetailsButton();
    }

    public void verifyPageDetails(final AccountDetails accountDetails) {
        verifyDetailsOnVerifyPage(accountDetails);
        clickConfirmButton();
    }

    /**
     * Method to verify details on verify page
     * 
     * @param account
     *            details
     */
    public void verifyDetailsOnVerifyPage(final AccountDetails accountDetails) {
        isOrderChequeVerifyPageDisplayed();
        verifyAccountDetailsVerifyPage(accountDetails);
        verifyNumberOfChequeBookVerifyPage(accountDetails);
        verifyNumberOfPagesVerifyPage(accountDetails);
        isDeliveryAddressOnVerifyPageDisplayed();
        isDisclaimerMessageOnVerifyPageDisplayed();
    }

    /**
     * Method to verify account selected on verify page
     * 
     * @param accountDetails
     */
    public void verifyAccountDetailsVerifyPage(final AccountDetails accountDetails) {
        Assert.assertTrue(accountNameVerifyPage.getText().contains(accountDetails.getAccountName())
            && accountDetails.getAccountNumber().equals(accountNumberVerifyPage.getText()),
            "Account Details on verify page does not match. ");
        Reporter.log("Account Details on verify page are same as selected. ");
    }

    /**
     * Method to click on Edit Details button on verify page.
     * 
     */
    public void clickEditDetailsButton() {
        editDetailsButton.click();
        Reporter.log("Edit Details button clicked. ");
    }

    /**
     * Method to click on confirm button on verify page.
     * 
     */
    public void clickConfirmButton() {
        confirmButton.click();
        Reporter.log("Confirm button clicked. ");
    }

    /**
     * Method to click on cancel button on verify page.
     * 
     */
    public void clickVerifyPageCancelButton() {
        cancelButtonVerifyPage.click();
        Reporter.log("Cancel button on verify page clicked. ");
    }

    /**
     * Method to click on cancel button on verify page cancel dialog box.
     * 
     */
    public void clickVerifyPageSecondaryCancelButton() {
        verifyPageSecondaryCancelButton.click();
        Reporter.log("Cancel button clicked. ");
    }

    /**
     * Method to verify verify page is displayed.
     * 
     */
    public void isOrderChequeVerifyPageDisplayed() {
        Assert.assertTrue(
            orderChequeBookVerifyPage.isDisplayed()
                && orderChequeBookVerifyPage.getText().equalsIgnoreCase(EXPECTED_VERIFY_PAGE_TITLE),
            "Order Cheque Book Verify Page is not displayed or displayed title does not match with expected title. ");
        Reporter.log("Order Cheque Book Verify Page is displayed and displayed title matches with expected title. ");
    }

    /**
     * Method to verify message on verify page cancel dialog box.
     * 
     */
    public void isCancelMessageOnVerifyPageDisplayed() {
        Assert.assertTrue(verifyPageCancelMessage1.isDisplayed() && verifyPageCancelMessage2.isDisplayed()
            && !verifyPageCancelMessage1.getText().isEmpty() && !verifyPageCancelMessage2.getText().isEmpty(),
            "Cancel message on cancel dialog of verify page is not displayed. ");
        Reporter.log("Cancel message on cancel dialog of Verify Page is displayed. ");
    }

    /**
     * Method to verify duplicate error message is displayed.
     * 
     */
    public void isDuplicateErrorMessage() {}
}
