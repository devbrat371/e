/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.library;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;

/**
 * <p>
 * <b> Class to read data from XML and get required inforamtion. </b>
 * </p>
 */
public class XMLUtil {

    private static DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();

    private static XPath xPath = XPathFactory.newInstance().newXPath();

    private static final String PROFILE_MAPPING_XML = "ProfileMappings.xml";

    private static final String MAPPING_XML_PATH = "src/main/resources/";

    private static final String MAPPING_EXP = "/TESTSCRIPT//TESTCLASS[@NAME='%s']//METHOD[@NAME='%s']//ENTITY_PROFILE[@NAME='%s']/@PROFILE";


    private static Document getXMLDocument(final File xmlFile) throws SAXException, IOException, ParserConfigurationException {
        return XMLUtil.builderFactory.newDocumentBuilder().parse(xmlFile);
    }

    public static String getProfileName(final Method method, final String entity) throws SAXException, IOException,
        ParserConfigurationException, XPathExpressionException {
        Document xmlDocument = getXMLDocument(new File(XMLUtil.MAPPING_XML_PATH + XMLUtil.PROFILE_MAPPING_XML));
        return getProfileName(method, entity, xmlDocument);
    }

    public static String getProfileName(final Method method, final String entity, final Document xmlDocument)
        throws XPathExpressionException {
        return XMLUtil.xPath.compile(
            String.format(XMLUtil.MAPPING_EXP, method.getDeclaringClass().getName(), method.getName(), entity)).evaluate(
            xmlDocument);
    }

    public static Document getProfileMappingXML() throws SAXException, IOException, ParserConfigurationException {
        return getXMLDocument(new File(XMLUtil.MAPPING_XML_PATH + XMLUtil.PROFILE_MAPPING_XML));
    }
}
