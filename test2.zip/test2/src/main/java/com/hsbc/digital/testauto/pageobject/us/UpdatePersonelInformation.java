package com.hsbc.digital.testauto.pageobject.us;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.hsbc.digital.testauto.pageobject.UpdatePersonelInformationModel;

/**
 * <p>
 * <b> This class will hold locators and specific implementation for Update
 * Personal Information details US entity. </b>
 * </p>
 */
public class UpdatePersonelInformation extends UpdatePersonelInformationModel {

    public UpdatePersonelInformation(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }
}
