/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.mx;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.pageobject.ChangeIBLimitsCaptureModel;

/**
 * <p>
 * <b> This class will hold locators and specific implementation for Mexico
 * entity. </b>
 * </p>
 */
public class ChangeIBLimitsCapture extends ChangeIBLimitsCaptureModel {

    @FindBy(xpath = "//div[contains(@class,'changeLimitsTable') and not(contains(@class,'noDisplay'))]//input[contains(@id,'CurrencyTextBox')]/following-sibling::input")
    private List<WebElement> currentLimits;

    @FindBy(xpath = "//div[contains(@class,'changeLimitsTable') and not(contains(@class,'noDisplay'))]//input[contains(@id,'EditBankingLimits') and contains(@id,'CurrencyTextBox')]")
    private List<WebElement> inputTextFields;

    @FindBy(xpath = "//button[@class='btnSecondary' and @title='Cancel']")
    private WebElement cancelDialogYes;

    @FindBy(xpath = "//button[@class='btnTertiary' and @title=\"Don't Cancel\"]")
    private WebElement cancelDialogNo;

    @FindBy(xpath = "//*[@id='_dashboardHeading']/h1/span[text()='My accounts - Dashboard']")
    private WebElement dashboardPage;

    @FindBy(xpath = "//span[contains(@id,'CurrencyTextBox_validationMessage')]")
    private List<WebElement> errorMessages;

    @FindBy(xpath = "//a[@class='tramsandConditions']")
    private WebElement termsAndConditionLink;

    @FindBy(xpath = "//button[@data-dojo-attach-point='submitFormBtn']")
    private WebElement continueButton;

    private static final String INVALID_AMOUNT_RANGE = "1000003";

    private static final int MAX_AMOUNT_RANGE = 1000001;

    private static final String LIMIT_MSG = "Maximum daily limit is";

    public ChangeIBLimitsCapture(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    @Override
    public List<Double> enterLimits() {
        List<Double> newLimits = new ArrayList<>();
        for (int i = 0; i < inputTextFields.size(); i++) {
            String newLimit = Integer.toString(RandomUtil.generateIntNumber(1, MAX_AMOUNT_RANGE));
            inputTextFields.get(i).clear();
            inputTextFields.get(i).sendKeys(newLimit);
            newLimits.add(Double.parseDouble(newLimit));
        }
        Reporter.log("New limit values entered.");
        return newLimits;
    }

    @Override
    public void clickCancelButton(final boolean value) {
        wait.until(ExpectedConditions.elementToBeClickable(cancelButton));
        cancelButton.click();
        if (value) {
            cancelDialogYes.click();
            wait.until(ExpectedConditions.visibilityOf(dashboardPage));
            Reporter.log("Cancel button - Yes clicked and Dashboard page shown. ");
        } else {
            cancelDialogNo.click();
            if (changeIBlimitForm.isDisplayed()) {
                Reporter.log("User is on change internet banking limits page. ");
            } else {
                Reporter.log("User is not on change internet banking limits page. ");
                Assert.fail();
            }
        }
    }

    @Override
    public void clickContinueButtonWithoutChange() {
        Reporter.log("Continue without changes : Not applicable in mexico. ");
    }

    @Override
    public void enterIncorrectLimits() {
        for (int i = 0; i < inputTextFields.size(); i++) {
            inputTextFields.get(i).clear();
            inputTextFields.get(i).sendKeys(INVALID_AMOUNT_RANGE);
        }
    }

    @Override
    public void verifyErrorMessages() {
        for (WebElement errorMessage : errorMessages) {
            if (!errorMessage.getText().contains(ChangeIBLimitsCapture.LIMIT_MSG)) {
                Assert.fail("Limit message did not matched. ");
            }
        }
        Reporter.log("Error messages displayed correctly. ");
    }

    @Override
    public void clickContinueButtonForValidation() {
        Reporter.log("No operation required to continue for mexico if there is validation errors. ");
    }

    @Override
    public void isTermsAndConditionsLinkDisplayed() {
        Assert.assertTrue(termsAndConditionLink.isDisplayed() && termsAndConditionLink.isEnabled(),
            "Terms & Conditions Link not displayed. ");
        Reporter.log("Terms & Conditions Link displayed. ");
    }

    @Override
    public void clickContinueButton() {
        wait.until(ExpectedConditions.elementToBeClickable(continueButton));
        continueButton.click();
        Reporter.log("Continue button clicked on capture page.");
    }

}