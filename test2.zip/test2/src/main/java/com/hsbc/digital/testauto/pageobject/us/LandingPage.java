/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.us;


import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.DateUtil;
import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.models.AccountTypes;
import com.hsbc.digital.testauto.pageobject.LandingPageModel;


/**
 * <p>
 * <b> This class will hold locators and functionality related methods for
 * Account Summary and Overview story 34 & 35 specific to USA Entity </b>
 * </p>
 * 
 * @author
 * 
 */
public class LandingPage extends LandingPageModel {

    JavascriptExecutor jsx;
    WebDriverWait wait;

    // Locator for list of Bundled Accounts in Account Summary Section
    @FindBy(xpath = "//div[contains(@class,'bundledAccountTitle')]/span[@class='row' and @isgspentity='yes']")
    private List<WebElement> bundledAccountsLists;

    // Locator for list of accounts in a Bundled Account in Account Summary
    // Section
    private final By bundledAccountsLocator = By
        .xpath("./parent::div/following::div[contains(@class,'bundledAccountContent')]/span");

    // Locator for list of Account names in Account Summary Section
    @FindBy(xpath = "//div[contains(@id,'TitlePane') or contains(@class,'bundledAccountTitle')]/span[@isgspentity='yes']//span[contains(@class,'itemTitle')]")
    protected List<WebElement> accountsNameLists;

    // TODO
    @FindBy(xpath = "//div[contains(@id,'TitlePane')]//span[contains(@unique-account-number,'|')]")
    private List<WebElement> Accountdetails;

    // Locators for account information on Account Overview Section
    @FindBy(xpath = "//div[(contains(@id,'accountsummary') or contains(@id,'nonGSPTransaction')) and  not(contains(@class,'dijitHidden'))]//*[@data-dojo-attach-point='_dapNickname' or @data-dojo-attach-point='_title' ]")
    protected WebElement accountDescription;

    @FindBy(xpath = "//div[(contains(@id,'accountsummary') or contains(@id,'nonGSPTransaction')) and  not(contains(@class,'dijitHidden'))]//*[@data-dojo-attach-point='_dapAccountNumber' or @data-dojo-attach-point='_accountNumber' ]")
    private WebElement overviewAccountNumber;

    @FindBy(xpath = "//div[(contains(@id,'accountsummary') or contains(@id,'nonGSPTransaction')) and  not(contains(@class,'dijitHidden'))]//*[@data-dojo-attach-point='_dapCurrencyType' or @data-dojo-attach-point='_acctCcy' ]")
    private WebElement accountCurrency;

    @FindBy(xpath = "//h2[contains(@class,'accountBalance')]//span[@class='label']")
    private WebElement availableBalance;

    @FindBy(xpath = "  .//h2[contains(@class,'accountBalance')]//following-sibling::span[3]")
    private WebElement balanceAmount;

    @FindBy(xpath = "//*[contains(text(),'Ledger balance')]")
    private WebElement ledgerBalance;

    @FindBy(xpath = "//*[contains(@class,'accountBalance')]//span[contains(text(),'Balance as of')]")
    private WebElement balanceAsOf;

    @FindBy(xpath = "//p[contains(@class,'accountBalance')]/span[@class='label' and contains(text(),'Balance as of')]/following-sibling::span[@class='funds']")
    private WebElement balanceAsOfDate;

    @FindBy(xpath = "//*[contains(@class,'accountBalance')]//span[contains(text(),'Balance')]")
    private WebElement availableBalanceField;

    @FindBy(xpath = "//*[contains(@class,'accountBalance')]//span[contains(text(),'Credit limit')]")
    private WebElement creditLimit;

    @FindBy(xpath = "//*[contains(@class,'accountBalance')]//span[contains(text(),'Available credit')]")
    private WebElement availableCredit;

    @FindBy(xpath = "//p[contains(@class,'dueChargeLink')]/a")
    private List<WebElement> rewardPointsLinkList;

    @FindBy(xpath = "//*[contains(@class,'accountBalance')]//span[contains(text(),'Dividends year to date')]")
    private WebElement dividentsYearToDate;

    @FindBy(xpath = "//*[contains(@class,'accountBalance')]//span[contains(text(),'Market value change amount')]")
    private WebElement marketValueChangeAmount;

    @FindBy(xpath = "//div[contains(@id,'NonGSPTransactions')]")
    private WebElement nonGSPAccountContent;

    // Locators for account information on overview section of retirement
    // account
    @FindBy(xpath = "//p[contains(text(),'Plan number')]")
    private WebElement retirementAccountPlanNumber;

    @FindBy(xpath = "//p[contains(text(),'Plan Type')]")
    private WebElement retirementAccountPlanType;

    @FindBy(xpath = "//span[contains(text(),'Plan Holder')]")
    private WebElement retirementAccountPlanHolder;

    @FindBy(xpath = "//span[contains(text(),'Contributor')]")
    private WebElement retirementAccountPlanContributer;

    @FindBy(xpath = "//span[contains(text(),'Beneficiary information')]")
    private WebElement retirementAccountBeneficiary;

    @FindBy(xpath = "//a[@id='dapAcctDtlsPrintBtn']")
    private WebElement retirementAccountPrintButton;

    @FindBy(xpath = "//div[contains(@id,'CertificateListItem')]")
    private List<WebElement> accountOverviewRetirementAccountTransactions;

    // Locators on print preview page of retirement account
    @FindBy(xpath = "//div[contains(@id,'CertificateListItem')]")
    private List<WebElement> printPreviewRetirementAccountTransactions;

    // Locators for RRSP account transaction table headers
    @FindBy(xpath = "//div[contains(@id,'RRSPTransactionGrid')]//div[@role='columnheader']")
    public List<WebElement> rrspTransactionTableHeaders;

    // Locators for buttons on overview section of retirement account
    @FindBy(xpath = "//ul[contains(@id,'makeAContribution')]//span[text()='Make a contribution']")
    private WebElement makeContributionButton;

    @FindBy(xpath = "//ul[contains(@id,'ourRates')]//span[text()='Our rates']")
    private WebElement ourRatesButton;

    @FindBy(xpath = "//span[@id='dapViewAcctDetlsLabel']")
    private WebElement viewAccountDetailsOrTrading;

    // Locators for account information on overview section of Mortgage account
    @FindBy(xpath = "//span[text()='Overdue interest']")
    private WebElement mortgageAccountOverdueInterest;

    @FindBy(xpath = "//span[contains(text(),'overdue payment')]")
    private WebElement mortgageAccountOverduePayment;

    @FindBy(xpath = "//span[text()='Overdue balance']")
    private WebElement mortgageAccountOverdueBalance;

    // Locators for Rename Link in details section
    @FindBy(xpath = "//a[text()='Rename Account']")
    private WebElement renameAccountLink;

    // Locators for Rename account text box in details section
    @FindBy(xpath = "//input[contains(@id,'EditNickname')]")
    private WebElement renameAccountTextBox;

    // Locators for Account Nickname in details section
    @FindBy(xpath = "//div[contains(@id,'EditNickname')]//p")
    private WebElement accountNickname;

    // Locators for Account Nickname label in details section
    @FindBy(xpath = "//dt[contains(@class,'nickname')]")
    private WebElement accountNicknameLabel;

    // Locators for links in manage section of overview
    @FindBy(xpath = "//div[contains(@id,'dapManageAccContainer')]//a")
    private List<WebElement> accountManageLinks;

    // xpath to get list of description name
    @FindBy(xpath = "//div[starts-with(@id,'gridx_Grid_')]//span[contains(@class,'payeeItem')][1]")
    private List<WebElement> transactionDetailsDescription;

    // No Transaction error message
    @FindBy(xpath = "//div[@class='alertPanel error']//span[contains(text(),'no historic transactions')]")
    private WebElement errorMessageText;

    // View More button on Transaction History Widget
    @FindBy(xpath = "//button[contains(@class,'viewMoreBtn') and @aria-hidden='false']")
    private List<WebElement> viewMoreButtonList;

    @FindBy(xpath = "//div[@class='gridxSortNode' and contains(text(),'Amount')]")
    private WebElement balanceSort;

    @FindBy(xpath = "//div[@class='manageContainer']//a[text()='Stop a cheque']")
    private List<WebElement> stopChequeLinkManageMenuList;

    // Error for Invalid Account name
    @FindBy(xpath = "  //span[contains(text(),'No transactions')]")
    private WebElement errorInvalidAccountName;

    @FindBy(xpath = "//span[@id='dapMoveMoneyLabel' and @title='Move money']")
    private WebElement moveMoneyButton;

    @FindBy(xpath = "//div[contains(@id,'accountDetails_')]//p[contains(@class,'paragraph')]")
    private WebElement disclaimerTextDetails;

    @FindBy(xpath = "//a[@id='helpIconLink']")
    private List<WebElement> helpButtonAccountOverview;

    @FindBy(xpath = "//div[contains(@id,'HelpLinkDialog')]//button[contains(@class,'btnSecondary')]")
    private WebElement cancelButtonHelpPopup;

    @FindBy(xpath = "//div[@class='alertPanel error']//span[contains(text(),'no historic transactions')]")
    private List<WebElement> errorMessageList;

    /*
     * List of Expected labels in the Details Section
     */
    private static final String[] CURRENTACCOUNT_EXPECTEDLABELS = {"Account name", "Status of account", "Last Statement",
        "Interest Credited Year to Date", "Statement Balance"};
    private static final String[] TDACCOUNT_EXPECTEDLABELS = {"Account name", "Interest rate", "Maturity date", "Status of account"};
    private static final String[] SELECTCREDIT_EXPECTEDLABELS = {"Account name", "Last statement balance",
        "Current minimum payment due", "Last payment amount", "Overdue balance", "Last payment date"};
    private static final String[] CREDITCARD_EXPECTEDLABELS = {"Account name", "Last statement balance",
        "Current minimum payment due", "Last payment amount", "Overdue balance", "Outstanding cash advance balance"};
    private static final String[] SAVINGSACCOUNT_EXPECTEDLABELS = {"Account name", "Status of account", "Last Statement",
        "Interest Credited Year to Date"};
    private static final String[] LOANACCOUNT_EXPECTEDLABELS = {"Account name", "Debit interest rate", "Next payment date",
        "Next balance payment", "Last payment amount", "Total number of remaining instalments", "Last update time",
        "Original Loan Amount", "Original Repayment Period", "Loan Start Date"};
    private static final String[] MORTGAGEACCOUNT_EXPECTEDLABELS = {"Debit interest", "Next payment date", "", "Mortgage term"};
    private static final String[] RRSPTRANSACTIONHEADERS_EXPECTEDLABELS = {" Issue Date ", " Certificate Number ", " Issue Value ",
        " Current Value ", " Maturity Value "};

    /*
     * List of Expected Links in the Manage Section
     */
    private static final String[] SAVINGSACCOUNT_EXPECTEDLINKS = {"Travel notification", "View and print statements",
        "Statement delivery options", "Request for previous statements", "Report a transactional problem"};
    private static final String[] CURRENTACCOUNT_EXPECTEDLINKS = {"Travel notification", "Order check book", "Stop check",
        "View and print statements", "Statement delivery options", "Request for previous statements",
        "Report a transactional problem"};
    private static final String[] TDACCOUNT_EXPECTEDLINKS = {"View and print statements", "Statement delivery options",
        "Request for previous statements"};
    private static final String[] LOANACCOUNT_EXPECTEDLINKS = {"Request for previous statements", "Report a transactional problem"};
    private static final String[] MORTGAGEACCOUNT_EXPECTEDLINKS = {"Request for previous statements",
        "Report a transactional problem"};
    private static final String[] CREDITCARD_EXPECTEDLINKS = {"Travel notification", "View and print statements",
        "Statement delivery options", "Request for previous statements", "Submit a billing dispute"};

    private static final String[] TRANSACTION_HEADERS_EXPECTED = {"Date", "Description", "Amount", "Balance"};

    private static final Map<String, Integer> EXPECTED_ACCOUNTTYPE_ORDER = new HashMap<>();

    // constants
    protected static final String SCROLL_TO_VIEW = "arguments[0].scrollIntoView(true);";

    private static int bundled_AccountSize = 0;
    private static final String INVALID_FROMDATE = "14 02 2016";
    private static final String INVALID_TODATE = "15 02 2016";

    static {
        EXPECTED_ACCOUNTTYPE_ORDER.put("Performance Statement", 1);
        EXPECTED_ACCOUNTTYPE_ORDER.put("HSBC Advance Chequing", 2);
        EXPECTED_ACCOUNTTYPE_ORDER.put("Regular Savings", 3);
        EXPECTED_ACCOUNTTYPE_ORDER.put("Term Deposit", 4);
        EXPECTED_ACCOUNTTYPE_ORDER.put("Credit Card", 5);
        EXPECTED_ACCOUNTTYPE_ORDER.put("Loans", 6);
        EXPECTED_ACCOUNTTYPE_ORDER.put("Mortgages", 7);
        EXPECTED_ACCOUNTTYPE_ORDER.put("Mutual Funds", 8);
        EXPECTED_ACCOUNTTYPE_ORDER.put("RRSP", 9);
        EXPECTED_ACCOUNTTYPE_ORDER.put("TFSA Savings", 10);
        EXPECTED_ACCOUNTTYPE_ORDER.put("TFSA TD", 11);
    }

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(LandingPage.class);

    public LandingPage(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, 30);
        jsx = (JavascriptExecutor) driver;
    }

    /**
     * Method to verify multiple entity accounts.
     * 
     */
    @Override
    public void verifyMultipleEntityAccounts() {
        // not applicable for US as of now
    }

    /**
     * Method to set account details of selected account.
     * 
     * @param account
     *            details
     * 
     */
    @Override
    public AccountDetails setAccountInfo(final String accountText) {
        AccountDetails accountDetails = new AccountDetails();
        String[] details = accountText.split("\\r?\\n");
        accountDetails.setAccountName(details[0]);
        accountDetails.setAccountNumber(details[1]);
        accountDetails.setAccountBalance(details[2]);
        accountDetails.setCurrency(details[3]);
        accountDetails.setBalanceAsOf(details[4]);
        return accountDetails;
    }

    /**
     * Method to verify summary section for Bundled accounts and also overview
     * details.
     */
    @Override
    public void verifyBundledAccountSummary() {
        if (!bundledAccountsLists.isEmpty()) {
            bundled_AccountSize = bundledAccountsLists.size();
            for (WebElement bundledAccount : bundledAccountsLists) {
                jsx.executeScript(SCROLL_TO_VIEW, bundledAccount);
                bundledAccount.click();
                driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
                List<WebElement> accountList = bundledAccount.findElements(bundledAccountsLocator);
                bundled_AccountSize = bundled_AccountSize + accountList.size();
                for (WebElement account : accountList) {
                    jsx.executeScript(SCROLL_TO_VIEW, account);
                    String accountText = account.getText();
                    account.click();
                    verifyAccountSummaryInfo();
                    AccountDetails accDetail = setAccountInfo(accountText);
                    verifyAccountOverview(accDetail);
                    verifyRealTimeUpdate(accDetail);
                }
            }
        } else {
            Reporter.log("No bundled accounts present in Account summary");
        }
    }

    /**
     * Method to verify fields on account summary section.
     * 
     */
    @Override
    public void verifyAccountSummarySection() {
        isElementDisplayed(accountSummaryTitle);
        Reporter.log("Summary Section Title is displayed. ");
    }

    /**
     * Method to verify account description/type/name on account overview
     * section.
     * 
     * @param object
     *            of AccountDetails class
     */
    @Override
    public void verifyAccountDescription(final AccountDetails accountDetails) {
        jsx.executeScript(SCROLL_TO_VIEW, accountDescription);
        Assert.assertTrue(
            accountDescription.isDisplayed() && accountDetails.getAccountName().equalsIgnoreCase(accountDescription.getText()),
            "Account description not displayed and incorrect");
        Reporter.log("Account Name: " + accountDescription.getText() + " displayed and verified. ");
    }

    /**
     * Method to verify account number on account overview section.
     * 
     * @param object
     *            of AccountDetails class
     */
    @Override
    public void verifyAccountNumber(final AccountDetails accountDetails) {
        Assert.assertTrue(
            overviewAccountNumber.isDisplayed()
                && accountDetails.getAccountNumber().equalsIgnoreCase(overviewAccountNumber.getText()),
            "Account Number not displayed and incorrect");
        Reporter.log("Account Number: " + overviewAccountNumber.getText() + " displayed and verified. ");
    }

    /**
     * Method to verify account Currency on account overview section.
     * 
     * @param object
     *            of AccountDetails class
     */
    @Override
    public void verifyAccountCurrency(final AccountDetails accountDetails) {
        Assert.assertTrue(
            accountCurrency.isDisplayed() && accountDetails.getCurrency().equalsIgnoreCase(accountCurrency.getText()),
            "Account Currency not displayed");
        Reporter.log("Account Currency: " + accountCurrency.getText() + " displayed and verified. ");
    }

    /**
     * Method to verify Mortgage Account Overview section.
     * 
     */
    @Override
    public void verifyMortgageAccountOverviewInfo(final AccountDetails accountDetails) {
        isElementDisplayed(mortgageAccountOverdueInterest);
        Reporter.log("Overdue Interest on overview section displayed. ");
        isElementDisplayed(mortgageAccountOverduePayment);
        Reporter.log("Overdue Payment on overview section displayed. ");
        isElementDisplayed(mortgageAccountOverdueBalance);
        Reporter.log("Overdue Balance on overview section displayed. ");
    }

    /**
     * Method to verify Retirement Account Overview section.
     * 
     */
    @Override
    public void verifyRetirementAccountOverviewInfo(final AccountDetails accountDetails) {
        isElementDisplayed(retirementAccountPlanNumber);
        Reporter.log("Plan number on overview section displayed. ");
        isElementDisplayed(retirementAccountPlanType);
        Reporter.log("Plan type on overview section displayed. ");
        isElementDisplayed(retirementAccountPlanHolder);
        Reporter.log("Plan holder on overview section displayed. ");
        isElementDisplayed(retirementAccountPlanContributer);
        Reporter.log("Plan contributer on overview section displayed. ");
        isElementDisplayed(retirementAccountBeneficiary);
        Reporter.log("Account Beneficiary on overview section displayed. ");
        isElementDisplayed(makeContributionButton);
        Reporter.log("Make Contribution Button on overview section displayed. ");
        isElementDisplayed(ourRatesButton);
        Reporter.log("Our Rates Button on overview section displayed. ");

        verifyFields(Arrays.asList(RRSPTRANSACTIONHEADERS_EXPECTEDLABELS), rrspTransactionTableHeaders);
    }


    /**
     * Method to verify the Brokerage Account Info
     * 
     */
    @Override
    public void verifyBrokerageAccountInfo(final AccountDetails accountDetails) {
        verifyAccountInfo(accountDetails);
        isElementDisplayed(viewAccountDetailsOrTrading);
        Reporter.log("View account details/ trading on overview section displayed.");
    }

    /**
     * Method to verify Loan Account Overview section.
     * 
     */
    @Override
    public void verifyLoanAccountOverviewInfo(final AccountDetails accountDetails) {
        verifyAccountInfo(accountDetails);
        isElementDisplayed(nonGSPAccountContent);
        Reporter.log("Non GSP content on overview section displayed. ");
        isElementDisplayed(detailsButton);
        Reporter.log("Details Button on overview section displayed. ");
    }

    /**
     * Method to verify Savings and Current Account Overview section.
     * 
     */
    @Override
    public void verifyAccountOverviewInfo(final AccountDetails accountDetails) {
        verifyAccountInfo(accountDetails);
        isLedgerBalanceDisplayed();
        Reporter.log("Ledger Balance on overview Page displayed. ");
        isBalabceAsOfFieldDispalyed(accountDetails);
        Reporter.log("Balance as of today on overview Page displayed. ");
        isElementDisplayed(moveMoneyButtons.get(0));
        Reporter.log("Move Money Button on overview section displayed. ");
        isElementDisplayed(manageButton);
        Reporter.log("Manage Button on overview section displayed. ");
        isElementDisplayed(searchButton);
        Reporter.log("Search Button on overview section displayed. ");
        isElementDisplayed(detailsButton);
        Reporter.log("Details Button on overview section displayed. ");
    }

    /**
     * Method to verify account information on account overview section.
     * 
     * @param object
     *            of AccountDetails class
     */
    @Override
    public void verifyAccountInfo(final AccountDetails accountDetails) {
        verifyAccountDescription(accountDetails);
        verifyAccountNumber(accountDetails);
        verifyAccountCurrency(accountDetails);
        isBalanceDisplayed(accountDetails);
        Reporter.log("Balance on overview Page displayed. ");
        if (!transactionGrid.isEmpty()) {
            verifyTransactionHistoryWidget();
        } else {
            Reporter.log("There are no transactions performed for this account. ");
        }
    }

    /**
     * To verify the Transaction Header Column Names and the View more button
     */
    @Override
    public void verifyTransactionHistoryWidget() {
        if (!transactionTableHeaders.isEmpty()) {
            verifyFields(Arrays.asList(TRANSACTION_HEADERS_EXPECTED), transactionTableHeaders);
        }
        if (dateColumnAll.size() > 5) {
            verifyViewMoreFunctionality(dateColumnAll.size());
        } else if (dateColumnAll.size() < 5) {
            Assert.assertTrue(viewMoreButtonList.isEmpty(), "View More Button is Displayed");
            Reporter.log("Transactions in history are less then 5. Hence, View More button is not displayed. ");
        }

    }

    @Override
    public void verifyViewMoreFunctionality(final int size) {
        isElementDisplayed(viewMoreButtonList.get(0));
        Reporter.log("View more button is displayed. ");
        while (!viewMoreButtonList.isEmpty()) {
            viewMoreButtonList.get(0).click();
        }
        if (dateColumnAll.size() > size) {
            Reporter.log("More Transactions are displayed. View More Button Functionality is working");
        }

    }

    @Override
    public void verifyTDManageLinks() {
        manageButton.click();
        Reporter.log("Manage Button Clicked. ");
        verifyFields(Arrays.asList(TDACCOUNT_EXPECTEDLINKS), accountManageLinks);
    }

    @Override
    public void verifyMortgageManageLinks() {
        manageButton.click();
        Reporter.log("Manage Button Clicked. ");
        verifyFields(Arrays.asList(MORTGAGEACCOUNT_EXPECTEDLINKS), accountManageLinks);
    }

    @Override
    public void verifyCreditCardManageLinks() {
        manageButton.click();
        Reporter.log("Manage Button Clicked. ");
        verifyFields(Arrays.asList(CREDITCARD_EXPECTEDLINKS), accountManageLinks);
    }

    @Override
    public void verifyLoanManageLinks() {
        manageButton.click();
        Reporter.log("Manage Button Clicked. ");
        verifyFields(Arrays.asList(LOANACCOUNT_EXPECTEDLINKS), accountManageLinks);
    }

    @Override
    public void verifyCurrentManageLinks() {
        manageButton.click();
        Reporter.log("Manage Button Clicked. ");
        verifyFields(Arrays.asList(CURRENTACCOUNT_EXPECTEDLINKS), accountManageLinks);
    }

    @Override
    public void verifySavingsManageLinks() {
        manageButton.click();
        Reporter.log("Manage Button Clicked. ");
        verifyFields(Arrays.asList(SAVINGSACCOUNT_EXPECTEDLINKS), accountManageLinks);
    }

    /**
     * Method to verify TD Account Overview section.
     * 
     * @param accountDetails
     */
    @Override
    public void verifyTDAccountOverviewInfo(final AccountDetails accountDetails) {
        verifyAccountInfo(accountDetails);
        isBalabceAsOfFieldDispalyed(accountDetails);
        isLedgerBalanceDisplayed();
        Reporter.log("Ledger balance on overview section displayed. ");
        isElementDisplayed(manageButton);
        Reporter.log("Manage Button on overview section displayed. ");
        isElementDisplayed(detailsButton);
        Reporter.log("Details Button on overview section displayed. ");
    }

    /**
     * Method to verify Investment Account Overview section
     * 
     * @param accountDetails
     */
    @Override
    public void verifyInvestmentAccountOverviewInfo(final AccountDetails accountDetails) {
        verifyAccountInfo(accountDetails);
        isElementDisplayed(dividentsYearToDate);
        Reporter.log("Dividends year to date on overview section displayed. ");
        isElementDisplayed(marketValueChangeAmount);
        Reporter.log("Market value change amount on overview section displayed. ");
    }

    /**
     * Method to verify Credit card Account Overview section.
     */
    @Override
    public void verifyCreditCardAccountOverviewInfo(final AccountDetails accountDetails) {
        verifyAccountInfo(accountDetails);
        isBalabceAsOfFieldDispalyed(accountDetails);
        isElementDisplayed(creditLimit);
        Reporter.log("Credit Limit on overview section displayed. ");
        isElementDisplayed(availableCredit);
        Reporter.log("Available Credit on overview section displayed. ");
        isElementDisplayed(balanceAsOf);
        Reporter.log("Balance As of field displayed on overview section displayed. ");
        isRewardPointsLinkDisplayed();
        Reporter.log("Premier Reward Points link on overview section displayed. ");
        isElementDisplayed(moveMoneyButtons.get(0));
        Reporter.log("Move Money Button on overview section displayed. ");
        isElementDisplayed(manageButton);
        Reporter.log("Manage Button on overview section displayed. ");
        isElementDisplayed(searchButton);
        Reporter.log("Search Button on overview section displayed. ");
        isElementDisplayed(detailsButton);
        Reporter.log("Details Button on overview section displayed. ");
    }

    /**
     * Method to verify summary section for Bundled accounts and also overview
     * details.
     */
    @Override
    public void verifyBundledAccountOverviewSection() {
        if (!bundledAccountsLists.isEmpty()) {
            int totalBundledAccounts = bundledAccountsLists.size();
            int bundledAccount = 0;
            int subBundledAccount = 0;
            while (true) {
                WebElement bundledAccountElement = bundledAccountsLists.get(bundledAccount);
                jsx.executeScript(SCROLL_TO_VIEW, bundledAccountElement);
                bundledAccountElement.click();
                driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
                List<WebElement> subBundledAccountList = bundledAccountElement.findElements(bundledAccountsLocator);
                int totalSubBundledAccount = subBundledAccountList.size();
                WebElement subBundledAccountElement = subBundledAccountList.get(subBundledAccount);
                jsx.executeScript(SCROLL_TO_VIEW, subBundledAccountElement);
                String accountText = subBundledAccountElement.getText();
                subBundledAccountElement.click();
                AccountDetails accountDetail = setAccountInfo(accountText);
                verifyAccountDetails(accountDetail);
                verifyRealTimeUpdate(accountDetail);
                verifyAccountOverviewPrint(accountDetail);
                verifyMoveMoneyNavigation(accountDetail);
                subBundledAccount++;
                if (subBundledAccount == totalSubBundledAccount) {
                    bundledAccount++;
                }
                if (bundledAccount == totalBundledAccounts) {
                    break;
                }
            }
        } else {
            Reporter.log("No bundled accounts present in Account summary section.");
        }
    }


    /**
     * Method to verify Move money button on account overview section.
     * 
     * @param accountDetails
     * 
     */
    @Override
    public void verifyMoveMoneyNavigation(final AccountDetails accountDetails) {
        AccountTypes accountTypes = checkAccountType(accountDetails);
        if (!(accountTypes.equals(AccountTypes.BROKERAGE) || accountTypes.equals(AccountTypes.LOAN) || accountTypes
            .equals(AccountTypes.INVESTMENT))) {
            if (!moveMoneyButtons.isEmpty()) {
                clickElement(moveMoneyButtons.get(0));
                Reporter.log("Move Money Button is clicked. ");
                clickElement(primaryTransactionCancelButton);
                Reporter.log("New Transaction Cancel Button is clicked. ");
                clickElement(secondaryTransactionCancelButton);
                Reporter.log("Transaction Cancel Button is clicked to return to 'My Accounts' page. ");
            } else {
                Assert.fail("Move Money button not Displayed");
            }
        } else {
            if (moveMoneyButtons.isEmpty()) {
                Reporter.log("Selected Account does not support Move Money navigation. Hence Button is hidden");
            } else {
                Assert.fail("Selected Account does not support Move Money navigation. Still Move Money button Displayed");
            }
        }

    }

    /**
     * Method to verify Current Account Details section.
     * 
     */
    @Override
    public void verifyCurrentAccountDetails() {
        verifyFields(Arrays.asList(CURRENTACCOUNT_EXPECTEDLABELS), detailsLabels);
    }


    /**
     * Method to verify Select Credit Details section.
     * 
     */
    @Override
    public void verifySelectCreditDetails() {
        verifyFields(Arrays.asList(SELECTCREDIT_EXPECTEDLABELS), detailsLabels);
    }

    /**
     * Method to verify Credit Card Details section.
     * 
     */
    @Override
    public void verifyCreditCardDetails() {
        verifyFields(Arrays.asList(CREDITCARD_EXPECTEDLABELS), detailsLabels);
    }

    /**
     * Verify the disclaimer displayed in the details section
     */
    @Override
    public void verifyDisclaimerDisplayedInDetailsSection() {
        Assert.assertTrue(disclaimerTextDetails.isDisplayed(), "Disclaimer is not displayed in the Details Section.");
        Reporter.log("Disclaimer is displayed. Message is: " + disclaimerTextDetails.getText());
    }

    /**
     * Method to verify Savings Account Details section.
     * 
     */
    @Override
    public void verifySavingsAccountDetails() {
        verifyFields(Arrays.asList(SAVINGSACCOUNT_EXPECTEDLABELS), detailsLabels);
    }

    /**
     * Method to verify TD Account Details section.
     * 
     */
    @Override
    public void verifyTDAccountDetails() {
        verifyFields(Arrays.asList(TDACCOUNT_EXPECTEDLABELS), detailsLabels);
    }

    /**
     * Method to verify Mortgage Account Details section.
     * 
     */
    @Override
    public void verifyMortgageAccountDetails() {
        verifyFields(Arrays.asList(MORTGAGEACCOUNT_EXPECTEDLABELS), detailsLabels);
    }

    /**
     * Method to verify Loan Account Details section.
     * 
     */
    @Override
    public void verifyLoanAccountDetails() {
        verifyFields(Arrays.asList(LOANACCOUNT_EXPECTEDLABELS), detailsLabels);
    }

    /**
     * Method to verify Retirement Account Details section.
     * 
     */
    @Override
    public void verifyRetirementAccountDetails() {
        Assert.assertFalse(!detailsButtons.isEmpty() && detailsButton.isEnabled(), "Details button is displayed and enabled");
        Reporter.log("Details Button is not displayed and enabled for Retirement account. ");
    }

    /**
     * Method to verify real time update on overview section.
     * 
     * @param AccountDetails
     */
    @Override
    public void verifyRealTimeUpdate(final AccountDetails accountDetails) {
        AccountTypes accountTypes = checkAccountType(accountDetails);
        if (accountTypes.equals(AccountTypes.SAVINGS) || accountTypes.equals(AccountTypes.CURRENT)) {
            detailsButton.click();
            Reporter.log("Details Button clicked. ");
            renameAccountLink.click();
            Reporter.log("Rename Account Link clicked. ");
            enterNickname();
            verifyAccountNickname();
            detailsButton.click();
            Reporter.log("Details Button clicked. ");
        }
    }

    /**
     * Method to verify real time update on overview section.
     * 
     * @param AccountDetails
     */
    @Override
    public void verifyAccountOverviewHelp(final AccountDetails accountDetails) {
        AccountTypes accountTypes = checkAccountType(accountDetails);
        if (accountTypes.equals(AccountTypes.SAVINGS) || accountTypes.equals(AccountTypes.CURRENT)) {
            helpButtonAccountOverview.get(0).click();
            Reporter.log("Help Button is clicked.");
            Assert.assertTrue(cancelButtonHelpPopup.isDisplayed(), "Help Popup is not displayed.");
            Reporter.log("Help Popup is displayed.");
            cancelButtonHelpPopup.click();
            Reporter.log("Cancel button is clicked in Help popup");
        } else if (helpButtonAccountOverview.isEmpty()) {
            Reporter.log("Help Button is not displayed for the Selected Account.");
        } else {
            Assert.fail("Help Button is displayed for Selected Account that does not support.");
        }
    }

    /**
     * Method to verify fields in details section.
     * 
     * @param expectedLabels
     */
    @Override
    public void verifyFields(final List<String> expectedLabels, final List<WebElement> actualLabelList) {
        List<String> actualLabels = new ArrayList<>();
        for (WebElement actualLabel : actualLabelList) {
            if (!actualLabel.getText().trim().isEmpty()) {
                actualLabels.add(actualLabel.getText());
            }
        }
        if (expectedLabels.size() == actualLabels.size() && expectedLabels.containsAll(actualLabels)) {
            Reporter.log("Field labels are displayed as expected: " + expectedLabels);
        } else {
            Reporter.log("There is a mismatch in the Expected and Actual List in the section.");
            Reporter.log("The number of fields in the Expected List: " + expectedLabels.size());
            Reporter.log("The number of fields in the Actual List: " + actualLabels.size());
            Reporter.log("The Expected List: " + expectedLabels);
            Reporter.log("The Actual List: " + actualLabels);
            Assert.fail("Mismatch in Labels in Section");
        }
    }

    /**
     * Method to verify Print button on account overview section.
     * 
     * @param object
     *            of AccountDetails class
     */
    @Override
    public void verifyAccountOverviewPrint(final AccountDetails accountDetails) {
        AccountTypes accountTypes = checkAccountType(accountDetails);
        if (!accountTypes.equals(AccountTypes.BROKERAGE)) {
            if (!accountTypes.equals(AccountTypes.RETIREMENT)) {
                verifyAccountOverviewPrintPreviewPage(accountDetails);
            } else {
                verifyRetirementAccountPrint(accountDetails);
            }
        } else {
            Reporter.log("Selected Account is Brokerage Account and Print Option is not avialable.");
        }
    }

    /**
     * Method to verify Available Balance on account overview section.
     * 
     */
    @Override
    public void isBalanceDisplayed(final AccountDetails accountDetails) {
        Assert.assertTrue(
            availableBalance.isDisplayed() && accountDetails.getAccountBalance().equalsIgnoreCase(balanceAmount.getText()),
            "Account balance not displayed and incorrect");
        Reporter.log("Account balance: " + balanceAmount.getText() + " displayed and verified. ");
    }

    /**
     * Method to verify Ledger Balance on account overview section.
     */
    public void isLedgerBalanceDisplayed() {
        Assert.assertTrue(ledgerBalance.isDisplayed(), "Ledger Balance not displayed");
        Reporter.log("Ledger Balance displayed and verified. ");
    }

    /**
     * Method to verify Balance As Of Today field on account overview section.
     * 
     */
    public void isBalabceAsOfFieldDispalyed(final AccountDetails accountDetails) {
        try {
            Assert.assertTrue(
                balanceAsOf.isDisplayed()
                    && accountDetails.getBalanceAsOf().contains(
                        DateUtil.getDateToString("d MMM yyyy", DateUtil.getStringToDate("d MMM yyyy", balanceAsOfDate.getText()))),
                "Balance As of today is not displayed and incorrect");
            Reporter.log("Account balance as of  today: " + balanceAsOfDate.getText() + " displayed and verified. ");
        } catch (ParseException e) {
            LandingPage.logger.error("Date Format Conversion Error", e);
        }
    }

    /**
     * Method to verify Premier Reward Points on account overview section.
     */
    public void isRewardPointsLinkDisplayed() {
        if (!rewardPointsLinkList.isEmpty()) {
            Assert.assertTrue(rewardPointsLinkList.get(0).isDisplayed(), "Premier Reward Points Link is not displayed");
            Assert.assertTrue(rewardPointsLinkList.get(0).isEnabled(), "Premier Reward Points Link is not enabled");
            Reporter.log(rewardPointsLinkList.get(0).getText() + "is dispalyed and enabled");
        } else {
            Reporter.log("Rewards Point link is not  dispalyed and enabled");
        }
    }


    /**
     * Method to enter nickname in details section.
     * 
     * 
     */
    public void enterNickname() {
        int maxlength = Integer.parseInt(renameAccountTextBox.getAttribute("maxlength"));
        String randomText = RandomUtil.generateAlphaNumericText(maxlength);
        renameAccountTextBox.clear();
        renameAccountTextBox.sendKeys(randomText);
        renameAccountTextBox.click();
        accountNicknameLabel.click();
    }

    /**
     * Method to verify if nickname is updated in overview section
     * 
     */
    public void verifyAccountNickname() {
        Assert.assertTrue(accountDescription.getText().equals(accountNickname.getText()), "nickname not updated");
        Reporter.log("Nickname updated properly. ");
        renameAccountLink.click();
        renameAccountTextBox.clear();
        renameAccountTextBox.click();
        accountNicknameLabel.click();
    }

    /**
     * Method to verify Print button on Account Summary section.
     * 
     */
    @Override
    public void verifyAccountSummaryPrint() {
        int size = accountsLists.size();
        accountSummaryPrintButton.click();
        Reporter.log("Print Button is clicked");
        verifyAccountSummaryPrintPreviewDetails(size + bundled_AccountSize);
        verifyAccountSummaryPrintPreviewPage();
    }


    /**
     * Method to verify if print for retirement account overview section
     * 
     */
    @Override
    public void verifyRetirementAccountPrint(final AccountDetails accountDetails) {
        int size = accountOverviewRetirementAccountTransactions.size();
        retirementAccountPrintButton.click();
        Reporter.log("Retirement account print button clicked. ");
        verifyRetirementPrintPreviewDetails(accountDetails, size);
        isAccountOverviewPrintPreviewButtonsDisplayed();
    }

    /**
     * Method to verify details on Print Preview Page of retirement account.
     * 
     */
    public void verifyRetirementPrintPreviewDetails(final AccountDetails accountDetails, final int size) {
        Assert.assertTrue(accountDetails.getAccountNumber().equalsIgnoreCase(accountOverviewPrintPreviewAccountNumber.getText())
            && accountDetails.getAccountName().equalsIgnoreCase(accountOverviewPrintPreviewAccountName.getText())
            && size == printPreviewRetirementAccountTransactions.size(), "Details on preview page not verified");
        Reporter.log("Details on preview page verified. ");
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Override
    public void verifyOrderOfAccounts() {

        List<Integer> actualList = new ArrayList<>();
        for (WebElement account : accountsNameLists) {
            jsx.executeScript(SCROLL_TO_VIEW, account);
            AccountDetails accDetail = new AccountDetails();
            accDetail.setAccountName(account.getText());
            String bundledString = account.getAttribute("class");
            accDetail.setBundledAccount(bundledString.contains("arrowBundle"));
            AccountTypes accountTypes = checkAccountType(accDetail);
            switch (accountTypes) {
            case CURRENT:
                actualList.add(1);
                break;
            case SAVINGS:
                actualList.add(2);
                break;
            case TERMDEPOSIT:
                actualList.add(3);
                break;
            case CREDIT:
                actualList.add(4);
                break;
            case LOAN:
                actualList.add(5);
                break;
            case MORTGAGE:
                actualList.add(6);
                break;
            case BUNDLED:
                actualList.add(7);
                break;
            case BROKERAGE:
                actualList.add(8);
                break;
            case INVESTMENT:
                actualList.add(9);
                break;
            default:
                actualList.add(10);
                break;
            }
        }
        Assert.assertTrue(isSorted(actualList), "Accounts are not in order");

        Map<String, String> RawMap = new LinkedHashMap<String, String>();
        Map<String, ArrayList<String>> SortedMap = new LinkedHashMap<String, ArrayList<String>>();
        Map<String, String> ResultMap = new LinkedHashMap<String, String>();
        String AccountNumber = null;
        String AccountType = null;
        Boolean result = false;

        for (WebElement account : this.Accountdetails) {
            ((JavascriptExecutor) this.driver).executeScript(SCROLL_TO_VIEW, account);
            String sample = account.getAttribute("unique-account-number");
            String[] sampleArray = sample.split("\\|\\|");
            AccountNumber = sampleArray[0];
            AccountType = sampleArray[2];
            RawMap.put(AccountNumber, AccountType);
        }

        Iterator<Entry<String, String>> itr = RawMap.entrySet().iterator();
        while (itr.hasNext()) {
            Map.Entry<String, String> me = itr.next();
            ArrayList<String> list;
            if (SortedMap.containsKey(me.getValue())) {
                list = SortedMap.get(me.getValue());
                list.add((String) me.getKey());
                Collections.sort(list);
            } else {
                list = new ArrayList<String>();
                list.add((String) me.getKey());
                SortedMap.put((String) me.getValue(), list);
            }
        }

        Iterator<Entry<String, ArrayList<String>>> itr2 = SortedMap.entrySet().iterator();
        while (itr2.hasNext()) {
            ArrayList<String> list;
            Map.Entry mesorted = itr2.next();
            list = (ArrayList<String>) mesorted.getValue();
            for (int i = 0; i < list.size(); i++) {
                ResultMap.put(list.get(i), mesorted.getKey().toString());
            }
        }

        result = equalMaps(RawMap, ResultMap);
        Assert.assertTrue(result.booleanValue(), "Multiple Accounts with same type are not in order. ");
        Reporter.log("Accounts are in order. ");
    }

    @Override
    public boolean equalMaps(final Map<String, String> m1, final Map<String, String> m2) {
        if (m1.size() != m2.size()) {
            return false;
        }
        for (String key : m1.keySet()) {
            if (!m1.get(key).equals(m2.get(key))) {
                return false;
            }

        }
        return true;
    }

    @Override
    public boolean isSorted(final List<Integer> list) {
        boolean sorted = true;
        for (int i = 1; i < list.size(); i++) {
            if (list.get(i).compareTo(list.get(i - 1)) < 0) {
                return false;
            }
        }
        return sorted;
    }

    @Override
    protected String getInputDateFormat() {
        return DateUtil.DATE_FORMAT_MMDDYYYY;
    }

    @Override
    public String getFromDate() throws ParseException {
        String strFromDate = StringUtils.EMPTY;
        Date dateFromDate = DateUtil.getStringToDate(super.getDisplayDateFormat(), dateColumnAll.get(dateColumnAll.size() - 1)
            .getText());
        dateFromDate = DateUtil.addDays(dateFromDate, -1);
        strFromDate = DateUtil.getDateToString(getInputDateFormat(), dateFromDate);
        return strFromDate;
    }

    @Override
    public void verifyTransactionHistoryInDateRage(final String fromDate, final String toDate) {
        super.checkTransactionAvailability();
        try {
            Date dateFromDate = DateUtil.getStringToDate(getInputDateFormat(), fromDate);
            Date dateToDate = DateUtil.getStringToDate(getInputDateFormat(), toDate);
            super.checkDateBetweenRange(super.getDisplayDateFormat(), DateUtil.addDays(dateFromDate, 1), dateToDate);
        } catch (ParseException e) {
            LandingPage.logger.error("Date parsing Exception for verifyTransactionHistoryInDateRage", e);
            Assert.fail("Date parsing Exception for verifyTransactionHistoryInDateRage", e);
        }
    }

    /**
     * This method is to sort the transactions by date
     */
    @Override
    public boolean dateSorting() {
        boolean flag = false;
        try {
            List<Date> beforeSort = new ArrayList<>();
            for (WebElement element : super.dateColumnAll) {
                beforeSort.add(DateUtil.getStringToDate(DateUtil.DATE_FORMAT_DDMMMYYYY, element.getText()));
            }
            Collections.sort(beforeSort);
            dateSortArrowButton.click();
            Reporter.log("Clicked on Date column for sort.");
            List<Date> afterSort = new ArrayList<>();
            for (WebElement element : super.dateColumnAll) {
                jsx.executeScript(SCROLL_TO_VIEW, element);
                afterSort.add(DateUtil.getStringToDate(DateUtil.DATE_FORMAT_DDMMMYYYY, element.getText()));
            }
            Iterator<Date> targetIt = beforeSort.iterator();
            for (Date uiSortedDate : afterSort) {
                if (uiSortedDate.equals(targetIt.next())) {
                    flag = true;
                }
            }
        } catch (ParseException e) {
            LandingPage.logger.error("Date Format Conversion Error: ", e);
            Assert.fail("Date Format Conversion Error." + e);
        }
        return flag;
    }

    /**
     * Compare results by name
     * 
     */
    @Override
    public void compareResultByName(final String expectedName) {
        super.checkTransactionAvailability();
        while (true) {
            for (WebElement eachTransaction : transactionDetailsDescription) {
                jsx.executeScript(SCROLL_TO_VIEW, eachTransaction);
                Assert.assertTrue(eachTransaction.getText().contains(expectedName), "Expected name: " + expectedName
                    + " Actual name: " + eachTransaction.getText());
            }
            if (!viewMoreButtonList.isEmpty() && viewMoreButtonList.get(0).isDisplayed()) {
                viewMoreButtonList.get(0).click();
            } else {
                break;
            }
        }
        Reporter.log("As expected historic transactions are displayed by account name filter");
    }

    @Override
    public void compareResultAmount(final int fromAmt, final int toAmt) {
        super.checkTransactionAvailability();
        while (true) {
            for (WebElement amountValue : super.transactionDetailsListAmountCol) {
                jsx.executeScript(SCROLL_TO_VIEW, amountValue);
                String amountValueString = amountValue.getText();
                Double actualAmount = Double.valueOf(amountValueString.replace("-", "").replace(",", ""));
                Assert.assertTrue(actualAmount >= fromAmt && actualAmount <= toAmt, "Amount: " + actualAmount
                    + " shown doesn't lie between + " + fromAmt + " and " + toAmt);
            }
            if (!viewMoreButtonList.isEmpty() && viewMoreButtonList.get(0).isDisplayed()) {
                viewMoreButtonList.get(0).click();
            } else {
                break;
            }
        }
        Reporter.log("Displayed Transactions Amounts lie between " + fromAmt + " and " + toAmt + " range. ");
    }

    @Override
    public void verifyPrintButtonOnPopup() {
        Assert.assertTrue(accountOverviewPreviewPrintButton.isDisplayed(), "Print button is not displayed on popup. ");
        Reporter.log("Print Popup shown. | ");
        accountOverviewPreviewPrintButton.click();
        Reporter.log("Print button clicked in Popup. | ");
        if (driver.getWindowHandles().size() > 1) {
            Reporter.log("Print preview Popup shown. | ");
        }
    }

    @Override
    public void verifyErrorMessageForInvalidDetails() {
        errorMessageText.isDisplayed();
        Reporter.log("\"No Transaction Error message\" is displayed. Error message is: " + errorMessageText.getText());
    }

    /**
     * Method to verify Transaction are sorted by Amount
     */
    @Override
    public boolean sortAmount() {
        boolean flag = true;
        List<Double> expectedAmount = new ArrayList<>();
        for (WebElement element : super.amountColAll) {
            String amount = element.getText();
            if (element.getText().contains(",")) {
                amount = amount.replace(",", "");
            }
            expectedAmount.add(Double.parseDouble(amount));
        }
        Collections.sort(expectedAmount);
        Iterator<Double> iteratorExpected = expectedAmount.iterator();
        getBalanceSort().click();
        Reporter.log("Click on Amount column for sort");
        for (WebElement element : super.amountColAll) {
            String amount = element.getText();
            if (element.getText().contains(",")) {
                amount = amount.replace(",", "");
            }
            if (!iteratorExpected.next().equals(Double.parseDouble(amount))) {
                flag = false;
                break;
            }
        }
        return flag;
    }

    /**
     * Method to verify Transactions are sorted by Description .
     */
    @Override
    public boolean sortDescriptions() {
        boolean flag = true;
        List<String> expecteddescription = new ArrayList<>();
        for (WebElement element : super.descriptionColumnAll) {
            expecteddescription.add(element.getText());
        }
        Collections.sort(expecteddescription);
        Iterator<String> iteratorExpected = expecteddescription.iterator();
        super.descriptionSort.click();
        Reporter.log("Click on Description column for sort");
        for (WebElement element : super.descriptionColumnAll) {
            if (!iteratorExpected.next().equalsIgnoreCase(element.getText())) {
                flag = false;
                break;
            }
        }
        return flag;
    }

    /**
     * Method to get web element.
     */
    @Override
    public WebElement getBalanceSort() {
        return balanceSort;
    }

    @Override
    public boolean isStopChequeLinkPresent() {
        return !stopChequeLinkManageMenuList.isEmpty();
    }

    @Override
    public void clickStopChequeLink() {
        stopChequeLinkManageMenuList.get(0).click();
    }

    /**
     * Method to get invalidFromDate as String.
     */
    @Override
    public String getInvalidFromDate() {
        return INVALID_FROMDATE;
    }

    /**
     * Method to get invalidToDate as String.
     */
    @Override
    public String getInvalidToDate() {
        return INVALID_TODATE;
    }

    /**
     * Method to verify No transaction message for invalid Account Name
     */
    @Override
    public void verifyErrorForInvalidAccountName() {
        Assert.assertTrue(errorInvalidAccountName.isDisplayed(), "Transactions displayed for invalid account. ");
        String errorMessage = errorInvalidAccountName.getText();
        Reporter.log("Error is displayed as :" + errorMessage);
    }

    @Override
    protected WebElement getMoveMoneyButton() {
        return moveMoneyButton;
    }

    @Override
    public void verifyVisibilityOfViewMoreButton() {
        if (super.descriptionColumnAll.size() < 5) {
            Assert.assertTrue(viewMoreButtonList.isEmpty(), "View More button is visible for less transaction");
            Reporter.log("View More button is not visible");
        } else {
            if (!viewMoreButtonList.isEmpty() && viewMoreButtonList.get(0).isDisplayed()) {
                viewMoreButtonList.get(0).click();
                Assert.assertTrue(super.descriptionColumnAll.size() > 5,
                    "View More button displayed even if the transactions are not more than 5");
                Reporter.log("As Expected View More button displayed. | ");
            } else {
                Reporter.log("As Expected View More button not displayed. | ");
            }
        }
    }

    @Override
    public void verifyClearSearchButton(final List<String> transactionsList) {
        Assert.assertTrue(super.clearSearchButton.isDisplayed(), "Clear Search button is not present");
        super.clearSearchButton.click();
        Reporter.log("Clear Search button clicked");
        super.defaultOrderCheck();
        List<String> transactionListAfterClear = super.transactionsList();
        if (super.transactionsList().size() <= 5 && transactionsList.equals(transactionListAfterClear)) {
            Reporter.log("\"Clear Search\" button functionality working properly. | ");
        }
    }

    @Override
    public void verifyHelpIconLink() {
        Assert.assertTrue(helpButtonAccountOverview.get(0).isDisplayed(), "helpIconLink is not present. | ");
        Reporter.log("\'help Icon Link\' is present. | ");
    }

    @Override
    public void validateDisclaimerText() {
        // TODO : enter code once functionality is present
    }

    @Override
    public void selectFileFormatToDownload() {
        Assert.assertTrue(super.radioCSV.isDisplayed(), "Option to download file in csv format not displayed. ");
        Reporter.log("CSV format is selected for downloading. | ");
    }

    @Override
    protected void verifyDownloadChoiceWindow() {
        if (driver.getWindowHandles().size() > 1) {
            Reporter.log("Download choice window shown. | ");
        }
    }

    /**
     * 
     */
    @Override
    public void verifyTransactionNotListedButton() {
        Assert.assertTrue(super.transactionNotListedButton.isDisplayed(), "TransactionNotListed button is not present. | ");
        super.transactionNotListedButton.click();
        Reporter.log("\"TransactionNotListed\" button clicked. | ");
        Assert.assertTrue(super.reportingAProblemDialogueCloseIcon.isDisplayed(),
            "\'Reporting A Problem\' PopUp is not present. | ");
        Reporter.log("\'Reporting A Problem\' PopUp is present. | ");
        super.reportingAProblemDialogueCloseIcon.click();
        Reporter.log("\'Reporting A Problem\' PopUp is closed. | ");
    }

    @Override
    public List<WebElement> getNoTransactionErrorMessageElementList() {
        return errorMessageList;
    }

    /**
     * Returns first line of description from each transaction in transactions
     * list
     */
    @Override
    public List<String> transactionsList() {
        List<String> transactionDataList = new ArrayList<>();
        for (WebElement eachTransaction : descriptionColumnAll) {
            transactionDataList.add(eachTransaction.getText());
        }
        return transactionDataList;
    }

}
