package com.hsbc.digital.testauto.pageobject.ca;

import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.pageobject.MoveMoneyCapturePageModel;

public class MoveMoneyCapturePage extends MoveMoneyCapturePageModel {


    @FindBy(xpath = "//div[contains(@id, 'myPayee')]//input[contains(@id, 'myPayee') and contains(@class, 'dijitArrowButtonInner')]")
    private WebElement myPayeeDropIcon;

    @FindBy(css = "div[id$='_myPayee_popup']")
    private WebElement myPayeeList;

    @FindBy(xpath = ".//div[contains(@id,'CaptureDefault')]//div[contains(@class,'submitButtonsPanel')]//*[@data-dojo-attach-point='_cancelButton']")
    private WebElement cancelButton;

    @FindBy(xpath = "//div[contains(@id,'SelectPayee') and contains(@id,'_myPayee_popup') and @role='listbox']//div[contains(@class,'row')]")
    private List<WebElement> myPayeeListAll;

    @FindBy(xpath = ".//input [contains(@value,'Confirm') and contains(@data-dojo-attach-point,'_confirmTxn') ]")
    private WebElement verfiyConfirmButton;

    @FindBy(xpath = ".//div[contains(@class,'verificationPage ')]//input[contains(@value,'Cancel')]")
    private WebElement verfiyConcelButton;

    @FindBy(xpath = "//div[contains(@class,'submitButtonsPanel')]//input[contains(@value,'Continue')]")
    private WebElement continueButton;

    @FindBy(xpath = ".//span[contains(text(),'Message to payee contains invalid characters. The following are not permitted: < > % { } [ ] & # \\\')]")
    private List<WebElement> errormsgToPayee1;

    @FindBy(xpath = ".//span[contains(text(),'Message to payee contains invalid characters. The following are not permitted: < > % { } [ ] & # \\\')]")
    private WebElement errormsgToPayee;

    @FindBy(xpath = ".//span[contains(@class,'InteracLogo verifyInteracLogo')]")
    private WebElement verfiylogo;

    public MoveMoneyCapturePage(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    @Override
    public void processIsValidAccInFromDropDown(final AccountDetails accountDetail, final String currencyCode) {
        clickMyPayeeTab();
        isValidAccInFromDropDown(myPayeeDropIcon, myPayeeListAll, accountDetail.getAccountName(), null, null);
    }

    @Override
    public void verfiyConfirmButton() {
        wait.until(ExpectedConditions.elementToBeClickable(verfiyConfirmButton));
        verfiyConfirmButton.isDisplayed();
        Reporter.log("Confirmation button is Displayed.");
    }


    @Override
    public void verfiyCancelButton() {
        wait.until(ExpectedConditions.elementToBeClickable(verfiyConcelButton));
        verfiyConcelButton.isDisplayed();
        Reporter.log("Cancel button is Displayed.");
    }

    @Override
    public void clickContinueButton() {
        wait.until(ExpectedConditions.elementToBeClickable(continueButton));
        continueButton.click();
        Reporter.log("Continue button is clicked.");
    }


    protected void isValidAccInFromDropDown(final WebElement myPayeeDropIcon, final List<WebElement> payeeList,
        final String accName, final String accNumber, final String currencyCode) {
        try {
            List<WebElement> payees;
            myPayeeDropIcon.click();
            payees = payeeList;
            for (WebElement elem : payees) {
                jsx.executeScript("arguments[0].scrollIntoView(true);", elem);
                if (elem.getText().contains(accName)) {
                    elem.click();
                    break;
                }
            }

        } catch (Exception e) {
            Assert.fail("Exceoption :", e);
            MoveMoneyCapturePageModel.logger.error("Exception thrown at:", e);
        }
    }

    @Override
    public String enterPayeeMessageTextSpecialchar() {

        String payeeReference = RandomUtil.generateSpecialCharacterText(MoveMoneyCapturePageModel.DEFAULT_REFERENCE_TEXT_LENGTH);
        msgToPayee.click();
        msgToPayee.clear();
        msgToPayee.sendKeys(payeeReference);
        msgToPayee.sendKeys(Keys.RETURN);
        Reporter.log("Your Message to payee entered is :" + payeeReference);
        return payeeReference;
    }

    @Override
    public void VerfiyErrormsg() {
        if (errormsgToPayee.isDisplayed()) {
            Reporter.log("Message to payee contains invalid characters.");
        } else {
            Reporter.log("Message to payee contains valid characters.");
        }
    }

    @Override
    public void clickCancelButton() {
        wait.until(ExpectedConditions.elementToBeClickable(cancelButton));
        cancelButton.click();
        Reporter.log("Cancel Button is clicked.");
    }

}
