/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

/**
 * <p>
 * <b> This model class will hold locators and functionality for User Interface
 * Requirement Dashboard </b> <br>
 * </p>
 * 
 * @author Nirmal
 * @version 1.0.0
 */
public abstract class UserInterfaceRequirementDashboardModel {

    protected final WebDriver driver;
    private final WebDriverWait wait;
    private final JavascriptExecutor jsx;

    @FindBy(xpath = "//*[contains(text(),'Welcome back')]")
    private WebElement welcomeMessageLabel;

    /*
     * HSBC LOGO
     */
    @FindBy(xpath = "//img[@alt='HSBC Retail']")
    private WebElement hsbcLogoForMass;

    @FindBy(xpath = "//*[contains(@alt,'HSBC Advance')]")
    private WebElement hsbcLogoForAdvance;

    @FindBy(xpath = "//*[@alt='HSBC Premier']")
    private WebElement hsbcLogoForPremier;

    /*
     * Masthead
     */
    @FindBy(xpath = "//*[contains(@id,'LanguageToggle')]")
    private WebElement languageToggleButton;

    @FindBy(xpath = "//*[contains(@id,'LanguageToggle')]//span[contains(@class,'dijitArrowButtonInner')]")
    private WebElement languageToggleDropdownIcon;

    @FindBy(xpath = "//table[contains(@class,'mastheadLanguageMenu')]//tr")
    private WebElement languageToggleDropdownItems;

    @FindBy(xpath = "//*[contains(@id,'CountryDropdown')]")
    private WebElement countryDetailsButtonMasthead;

    @FindBy(xpath = "//*[contains(@class,'msgCountBtn')]")
    private WebElement secureMessageButtonMasthead;

    @FindBy(xpath = "//*[contains(@class,'msgCountBtn')]//span[contains(@class,'dijitArrowButtonInner')]")
    private WebElement secureMessageDropdownIconMasthead;

    @FindBy(xpath = "//table[contains(@class,'messagesNavDropDown')]//tr")
    private WebElement secureMessageDropdownItemsMasthead;

    @FindBy(xpath = "//*[contains(@class,'accountDropdown')]")
    private WebElement profileMenuButtonMasthead;

    @FindBy(xpath = "//*[contains(@class,'accountDropdown')]//span[contains(@class,'dijitArrowButtonInner')]")
    private WebElement profileMenuDropdownIconMasthead;

    @FindBy(xpath = "//table[contains(@class,'mastHeadUserMenu')]//tr")
    private WebElement profileMenuDropdownItemsMasthead;

    @FindBy(xpath = "//*[contains(@class,'logOff')]")
    private WebElement logOffButtonMasthead;

    /*
     * Widgets
     */
    @FindBy(xpath = "//*[contains(@class,'dijitTitlePane')]")
    private WebElement accountSummaryWidget;

    @FindBy(xpath = "//*[contains(@class,'accountSummary')]")
    private WebElement accountOverviewWidget;

    @FindBy(xpath = "//*[contains(@class,'quickMoveMoney')]")
    protected List<WebElement> quickTransferWidget;

    @FindBy(xpath = "//*[contains(@class,'fxCalculator')]")
    private WebElement exchangeRateCalculatorWidget;

    /*
     * Account Overview Buttons
     */
    @FindBy(xpath = "//*[@class='print fr']")
    private WebElement printButtonAccountOverview;

    @FindBy(xpath = "//*[contains(@class,'moveMoney')]")
    private WebElement moveMoneyButtonAccountOverview;

    @FindBy(xpath = "//*[contains(@class,'iconButton manage')]")
    private WebElement manageButtonAccountOverview;

    @FindBy(xpath = "//*[contains(@class,'search')]")
    private WebElement searchButtonAccountOverview;

    @FindBy(xpath = "//span[contains(@class,'details')]")
    private WebElement detailsButtonAccountOverview;

    /*
     * -------- FOOTER LINKS --------
     *  Above Footer Links
     */
    @FindBy(xpath = "//div[contains(@class,'footerTopLine')]//li")
    private List<WebElement> aboveFooterLinks;

    /*
     * Footer Links - Middle layer
     */
    @FindBy(xpath = "//ul[preceding-sibling::h2[text()='Popular links']]/li")
    private List<WebElement> popularLinksFooter;

    @FindBy(xpath = "//ul[preceding-sibling::h2[text()='Open account now']]/li")
    private List<WebElement> openAccountNowLinksFooter;

    @FindBy(xpath = "//ul[preceding-sibling::h2[text()='Insights & advice']]/li")
    private List<WebElement> insightsAndAdviceLinksFooter;

    @FindBy(xpath = "//ul[preceding-sibling::h2[text()='My profile and account maintenance']]/li")
    private List<WebElement> myProfileAndAccountMaintenanceLinksFooter;

    @FindBy(xpath = "//ul[preceding-sibling::h2[text()='Help & support']]/li")
    private List<WebElement> helpAndSupportLinksFooter;
    /*
     * Below Footer Links
     */
    @FindBy(xpath = "//div[@class='footer clearfix']/ul[@class='baseline']/li")
    private List<WebElement> belowFooterLinks;

    protected static final String MASS = "mass";
    protected static final String ADVANCE = "advance";
    protected static final String PREMIER = "premier";
    private static final String SCROLL_TO_VIEW = "arguments[0].scrollIntoView(true);";

    /*
     * My Banking FlyerMenu - Column wise Links
     */
    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='My banking']]/descendant::li[preceding-sibling::li//h3/span[text()='My Accounts']]")
    private List<WebElement> firstColumnLinksMyBankingHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='My banking']]/descendant::ul[preceding-sibling::h3//span[text()='Move money']]/li")
    protected List<WebElement> secondColumnLinksMyBankingHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='My banking']]/descendant::ul[preceding-sibling::h3//span[text()='Cheques']]/li")
    private List<WebElement> thirdColumnLinksMyBankingHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='My banking']]/descendant::ul[preceding-sibling::h3//span[text()='Account services']]/li")
    private List<WebElement> fourthColumnLinksMyBankingHeader;

    /*
     * Products & services FlyerMenu - Column wise Links
     */
    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Products & services']]/descendant::ul[preceding-sibling::h3/span[text()='Account Opening']]/li")
    private List<WebElement> firstColumnLinksProductAndServicesHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Products & services']]/descendant::ul[preceding-sibling::h3/span[text()='Banking']]/li")
    private List<WebElement> secondColumnLinksProductAndServicesHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Products & services']]/descendant::ul[preceding-sibling::h3/span[text()='Borrowing']]/li")
    private List<WebElement> thirdColumnLinksProductAndServicesHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Products & services']]/descendant::ul[preceding-sibling::h3/span[text()='Insurance']]/li")
    private List<WebElement> fourthColumnLinksProductAndServicesHeader;

    /*
     * Investments & financial planning FlyerMenu - Column wise Links
     */
    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Investments & financial planning']]/descendant::ul[preceding-sibling::h3/span[text()='Advice and insights']]/li")
    private List<WebElement> firstColumnLinksInvestmentsAndFinancialPlanningHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Investments & financial planning']]/descendant::ul[preceding-sibling::h3/span[text()='Investment solutions']]/li")
    private List<WebElement> secondColumnLinksInvestmentsAndFinancialPlanningHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Investments & financial planning']]/descendant::ul[preceding-sibling::h3/span[text()='Retiring and Education']]/li")
    private List<WebElement> thirdColumnLinksInvestmentsAndFinancialPlanningHeader;

    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Investments & financial planning']]/descendant::ul[preceding-sibling::h3/span[text()='HSBC Premier']]/li")
    private List<WebElement> fourthColumnLinksInvestmentsAndFinancialPlanningHeader;

    /*
     *  Contact HSBC FlyerMenu - Column wise Links
     */
    @FindBy(xpath = "//li[child::a[contains(@class,'navigation-link')]/span[text()='Contact HSBC']]/descendant::li")
    private List<WebElement> linksContactHSBCHeader;

    /*
     * My banking Links list
     */
    private static final List<String> FIRST_COLUMN_LINKS_TEXT_MYBANKING = Arrays
        .asList("My investment accounts", "Launch HSBC InvestDirect", "Logon to HSBC Private Investment Management",
            "Report a lost or stolen card", "Report a lost or stolen card", "My profile", "Update Personal details",
            "Statement/notification options", "Alert settings");
    private static final List<String> SECOND_COLUMN_LINKS_TEXT_MYBANKING = Arrays.asList("Pay or transfer",
        "Future payments or transfers", "My payees", "Pending INTERAC e-Transfer", "Bill payment history", "Global view",
        "Add or remove a country", "Security", "Switch my Security Device", "Change personal security details",
        "Change my password", "Help with my Security Device", "Security centre");
    private static final List<String> SECOND_COLUMN_LINKS_TEXT_MYBANKING_MASS = Arrays.asList("Pay or transfer",
        "Future payments or transfers", "My payees", "Pending INTERAC e-Transfer", "Bill payment history", "Security",
        "Switch my Security Device", "Change personal security details", "Change my password", "Help with my Security Device",
        "Security centre");
    private static final List<String> THIRD_COLUMN_LINKS_TEXT_MYBANKING = Arrays.asList("Order cheques", "Stop a cheque", "Travel",
        "Notify us of travel");
    private static final List<String> FOURTH_COLUMN_LINKS_TEXT_MYBANKING = Arrays.asList("Rename accounts",
        "View foreign exchange rates", "Documents", "View and print statements", "View terms and conditions");

    /*
     * Product & services Links list
     */
    private static final List<String> FIRST_COLUMN_LINKS_TEXT_PRODUCTS_AND_SERVICES = Arrays.asList("Everyday Banking",
        "GICs and Term Deposits", "Tax-Free Savings Accounts (TFSA)", "Advice And Tools", "Saving for your goals",
        "Get a travel insurance quote", "Travel insurance FAQs", "Chequing account interest rates",
        "Savings account interest rates", "Foreign currency interest rates", "Foreign currency converter and exchange rates",
        "Life stage calculators", "Personal service charges statement of disclosure",
        "Powers of attorney and joint deposit accounts information");
    private static final List<String> SECOND_COLUMN_LINKS_TEXT_PRODUCTS_AND_SERVICES = Arrays.asList("Products overview",
        "Knowledge Centre", "Mortgage calculators", "Mortgage FAQs", "RRSP calculators", "Mortgage rates");
    private static final List<String> THIRD_COLUMN_LINKS_TEXT_PRODUCTS_AND_SERVICES = Arrays.asList("Borrowing overview",
        "Mortgages", "Loans", "Credit Cards", "Ways to bank", "Online Banking", "ATM", "Mobile banking", "Telephone Banking",
        "Branch", "INTERAC e-Transfer");
    private static final List<String> FOURTH_COLUMN_LINKS_TEXT_PRODUCTS_AND_SERVICES = Arrays.asList("HSBC Travel Insurance",
        "HSBC Premier", "HSBC Premier overview", "HSBC Advance", "HSBC Advance overview");

    /*
     * Investment & financial planning Links list
     */
    private static final List<String> FIRST_COLUMN_LINKS_TEXT_INVESTMENT_AND_FINANCIAL_PLANNING = Arrays.asList(
        "Investment insights centre", "Stock Market GIC Market Tracker", "HSBC Mutual Fund Information & resources",
        "Self-directed online investment tools & resources", "Self-directed online investing FAQs", "Wealth Planning");
    private static final List<String> SECOND_COLUMN_LINKS_TEXT_INVESTMENT_AND_FINANCIAL_PLANNING = Arrays.asList("Term Deposits",
        "Guranteed Investment Certificates (GIC)", "Mutual Funds", "Managed Solutions", "Registered Products",
        "Tax-Free Savings Accounts (TFSA)", "Self-directed online investing", "Private Investment Management");
    private static final List<String> THIRD_COLUMN_LINKS_TEXT_INVESTMENT_AND_FINANCIAL_PLANNING = Arrays.asList(
        "Plan for a comfortable retirement", "Receive an income in retirement", "Saving for education", "Grow your wealth",
        "Plan your children's future", "Plan your retirement", "Live your retirement");
    private static final List<String> FOURTH_COLUMN_LINKS_TEXT_INVESTMENT_AND_FINANCIAL_PLANNING = Arrays.asList(
        "HSBC Premier overview", "HSBC Advance", "HSBC Advance overview");

    /*
     * Contact HSBC planning Links list
     */
    private static final List<String> LINKS_TEXT_CONTACT_HSBC = Arrays.asList("Contact and support", "Send a message",
        "Find a branch or ATM", "Have a specialist contact me", "Book an appointment", "HSBC on social media");
    /*
     * Footer Links text
     */
    /* Above footer */
    private static final List<String> ABOVE_FOOTER_LINKS_TEXT = Arrays.asList("Contact HSBC", "Find a branch or ATM",
        "Ways to bank");

    /* Middle layer footer */
    private static final List<String> POPULAR_LINKS_FOOTER_TEXT = Arrays.asList("Learn about foreign currency accounts",
        "Learn about e-Statements", "Enrol for e-Statements", "e-Switch to HSBC Canada", "Payroll direct deposit",
        "View cheque hold policy", "Learn about mobile banking", "View HSBC account service charges", "Grow your wealth");
    private static final List<String> OPEN_ACCT_NOW_LINKS_FOOTER_TEXT = Arrays.asList("Open foreign currency savings account",
        "Open a Term Deposit / GIC", "Open a TFSA Savings account", "Open a TFSA Term Deposit account", "Apply for a loan",
        "Apply for a mortgage");
    private static final List<String> INSIGHTS_AND_ADVICE_LINKS_LINKS_FOOTER_TEXT = Arrays.asList("GSP demo", "GSP FAQs",
        "Mobile demo", "Mobile FAQs", "Global View / Global Transfers demo", "Calculate currency exchange rates",
        "Plan for retirement", "Calculate how much you can borrow");
    private static final List<String> MY_PROFILE_AND_ACCT_MAINTENANCE_LINKS_FOOTER_TEXT = Arrays.asList("Update Personal Details",
        "Statement/notification options", "Alert settings", "Switch my Security Device", "Change personal security details",
        "Change my password", "Help with my security device", "Security centre");
    private static final List<String> HELP_AND_SUPPORT_LINKS_FOOTER_TEXT = Arrays.asList("Contact and support", "Send a message",
        "Find a branch or ATM", "Have a specialist contact me", "Book an appointment", "HSBC on social media");

    /* below footer */
    private static final List<String> BELOW_FOOTER_LINKS_TEXT = Arrays.asList("About HSBC", "Careers", "Privacy", "Cookie policy",
        "Security", "Legal", "Hyperlink Policy", "Accessibility", "�Copyright HSBC Bank Canada 2016 . ALL RIGHTS RESERVED");

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger
        .getLogger(UserInterfaceRequirementDashboardModel.class);

    /**
     * Constructor to instantiate locators with driver. Will be invoked from
     * Children only.
     * 
     * @param driver
     */
    public UserInterfaceRequirementDashboardModel(final WebDriver driver) {
        this.driver = driver;
        wait = new WebDriverWait(driver, 30);
        PageFactory.initElements(driver, this);
        jsx = (JavascriptExecutor) driver;
    }

    /*
     * Widgets, Welcome message and Masthead
     */

    /**
     * This is to verify the Account Summary widget on the dashboard
     */
    public void verifyAccountSummaryWidget() {
        assertAndReportElementIsDisplayed(accountSummaryWidget, "Account Summary Widget is displayed",
            "Account Summary Widget is not displayed");
    }

    /**
     * This is to verify the Account Overview Widget on the dashboard and its
     * button
     */
    public void verifyAccountOverviewWidget() {
        assertAndReportElementIsDisplayed(accountOverviewWidget, "Account Overview Widget is displayed",
            "Account Overview Widget is not displayed");
    }

    /**
     * This is to verify the Quick Transfer Widget on the dashboard
     */
    public void verifyQuickTransferWidget() {
        assertAndReportElementIsDisplayed(quickTransferWidget.get(0), "Quick Transfer Widget is displayed",
            "Quick Transfer Widget is not displayed");
    }

    /**
     * This is to verify the Exchange Rate Calculator Widget on the dashboard
     */
    public void verifyExchangeRateCalculatorWidget() {
        assertAndReportElementIsDisplayed(exchangeRateCalculatorWidget, "Exchange Rate Calculator Widget is displayed",
            "Exchange Rate Calculator Widget is not displayed");
    }

    /**
     * This is to verify the Welcome Message on the dashboard
     */
    public void verifyWelcomeMessage() {
        assertAndReportElementIsDisplayed(welcomeMessageLabel, "Welcome Message displayed is:" + welcomeMessageLabel.getText(),
            "Welcome Message is not displayed");
    }

    /**
     * This is to verify the Masthead Buttons on the dashboard
     */
    public void verifyMastHead() {
        languageToggle();
        assertAndReportElementIsDisplayed(countryDetailsButtonMasthead, "Country Details button on Masthead is displayed",
            "Country Details button on Masthead is not displayed");
        secureMessageMasthead();
        profileMenuMasthead();
        assertAndReportElementIsDisplayed(logOffButtonMasthead, "Log off button on Masthead is displayed",
            "Log off button on Masthead is not displayed");
    }

    /**
     * This is to verify the Country Toggle in the Masthead on the dashboard
     */
    public void languageToggle() {
        assertAndReportElementIsDisplayed(languageToggleButton, "Country/language toggle button on Masthead is displayed",
            "Country/language toggle button on Masthead is not displayed");
        languageToggleDropdownIcon.click();
        assertAndReportElementIsDisplayed(languageToggleDropdownItems,
            "Country/language Dropdown Contents on Masthead is displayed",
            "Country/language Dropdown Contents on Masthead is not displayed");
    }

    /**
     * This is to verify the Secure Messaging in the Masthead on the dashboard
     */
    public void secureMessageMasthead() {
        assertAndReportElementIsDisplayed(secureMessageButtonMasthead, "Secure Messaging button on Masthead is displayed",
            "Secure Messaging button on Masthead is not displayed");
        secureMessageDropdownIconMasthead.click();
        assertAndReportElementIsDisplayed(secureMessageDropdownItemsMasthead,
            "Secure Messaging Dropdown Contents on Masthead is displayed",
            "Secure Messaging Dropdown Contents on Masthead is not displayed");
    }

    /**
     * This is to verify the Profile Menu in the Masthead on the dashboard
     */
    public void profileMenuMasthead() {
        assertAndReportElementIsDisplayed(profileMenuButtonMasthead, "Profile Name button on Masthead is displayed",
            "Profile Name button on Masthead is not displayed");
        profileMenuDropdownIconMasthead.click();
        assertAndReportElementIsDisplayed(profileMenuDropdownItemsMasthead,
            "Profile Name Dropdown Contents on Masthead is displayed",
            "Profile Name Dropdown Contents on Masthead is not displayed");
    }

    /* HSBC Logo   */
    /**
     * This is to verify the HSBC Logo for MASS on the dashboard
     */
    public void verifyHSBCLogoForMass() {
        assertAndReportElementIsDisplayed(hsbcLogoForMass, "HSBC Logo for Mass is displayed.",
            "HSBC Logo for Mass is not displayed");
    }

    /**
     * This is to verify the HSBC Logo for ADVANCE on the dashboard
     */
    public void verifyHSBCLogoForAdvance() {
        assertAndReportElementIsDisplayed(hsbcLogoForAdvance, "HSBC Logo for Advance is displayed.",
            "HSBC Logo for Advance is not displayed");
    }

    /**
     * This is to verify the HSBC Logo for PREMIER on the dashboard
     */
    public void verifyHSBCLogoForPremier() {
        assertAndReportElementIsDisplayed(hsbcLogoForPremier, "HSBC Logo for Premier is displayed.",
            "HSBC Logo for Premier is not displayed");
    }

    /**
     * This is to verify the All the Header links for the Premier on the
     * dashboard
     */
    public void verifyAllHeaderLinksForPremier(FlyerMenuNavigationModel navigationModel) {
        verifyMyBankingLinksHeader(navigationModel, PREMIER);
        verifyProductAndServicesLinksHeader(navigationModel);
        verifyInvestmentsAndFinancialLinksHeader(navigationModel);
        verifyContactHSBCLinksHeader(navigationModel);
    }

    /**
     * This is to verify the All the Header links for the Mass on the dashboard
     */
    public void verifyAllHeaderLinksForMass(FlyerMenuNavigationModel navigationModel) {
        verifyMyBankingLinksHeader(navigationModel, MASS);
        verifyProductAndServicesLinksHeader(navigationModel);
        verifyInvestmentsAndFinancialLinksHeader(navigationModel);
        verifyContactHSBCLinksHeader(navigationModel);
    }

    /**
     * This is to verify the All the Header links for the Advance on the
     * dashboard
     */
    public void verifyAllHeaderLinksForAdvance(FlyerMenuNavigationModel navigationModel) {
        verifyMyBankingLinksHeader(navigationModel, ADVANCE);
        verifyProductAndServicesLinksHeader(navigationModel);
        verifyInvestmentsAndFinancialLinksHeader(navigationModel);
        verifyContactHSBCLinksHeader(navigationModel);
    }

    private List<String> getSecondColumnLinksTextOfMyBankingHeaderList(String customerSegment) {
        List<String> secondColumnLinksText;
        if (MASS.equals(customerSegment)) {
            secondColumnLinksText = SECOND_COLUMN_LINKS_TEXT_MYBANKING_MASS;
        } else {
            secondColumnLinksText = SECOND_COLUMN_LINKS_TEXT_MYBANKING;
        }
        return secondColumnLinksText;
    }

    /**
     * This is to verify All My Banking Links in Header for Premier on the
     * dashboard
     */
    private void verifyMyBankingLinksHeader(FlyerMenuNavigationModel navigationModel, String customerSegment) {
        navigationModel.mouseOverOnMyBanking();
        validateAndCompareElement(firstColumnLinksMyBankingHeader, FIRST_COLUMN_LINKS_TEXT_MYBANKING,
            "My Banking Header first column");
        validateAndCompareElement(secondColumnLinksMyBankingHeader, getSecondColumnLinksTextOfMyBankingHeaderList(customerSegment),
            "My Banking Header second column");
        validateAndCompareElement(thirdColumnLinksMyBankingHeader, THIRD_COLUMN_LINKS_TEXT_MYBANKING,
            "My Banking Header third column");
        validateAndCompareElement(fourthColumnLinksMyBankingHeader, FOURTH_COLUMN_LINKS_TEXT_MYBANKING,
            "My Banking Header fourth column");
    }

    /**
     * This is to verify All Product And Services Links in Header for Premier
     * on the dashboard
     */
    private void verifyProductAndServicesLinksHeader(FlyerMenuNavigationModel navigationModel) {
        navigationModel.mouseOverOnProductAndServices();
        validateAndCompareElement(firstColumnLinksProductAndServicesHeader, FIRST_COLUMN_LINKS_TEXT_PRODUCTS_AND_SERVICES,
            "Product And Services Header first column");
        validateAndCompareElement(secondColumnLinksProductAndServicesHeader, SECOND_COLUMN_LINKS_TEXT_PRODUCTS_AND_SERVICES,
            "Product And Services Header second column");
        validateAndCompareElement(thirdColumnLinksProductAndServicesHeader, THIRD_COLUMN_LINKS_TEXT_PRODUCTS_AND_SERVICES,
            "Product And Services Header third column");
        validateAndCompareElement(fourthColumnLinksProductAndServicesHeader, FOURTH_COLUMN_LINKS_TEXT_PRODUCTS_AND_SERVICES,
            "Product And Services Header fourth column");
    }

    /**
     * This is to verify All Investment And Financial Links in Header for
     * Premier on the dashboard
     */
    private void verifyInvestmentsAndFinancialLinksHeader(FlyerMenuNavigationModel navigationModel) {
        navigationModel.mouseOverOnInvestmentAndFinancialPlanning();
        validateAndCompareElement(firstColumnLinksInvestmentsAndFinancialPlanningHeader,
            FIRST_COLUMN_LINKS_TEXT_INVESTMENT_AND_FINANCIAL_PLANNING, "Investment And Financial Header first column");
        validateAndCompareElement(secondColumnLinksInvestmentsAndFinancialPlanningHeader,
            SECOND_COLUMN_LINKS_TEXT_INVESTMENT_AND_FINANCIAL_PLANNING, "Investment And Financial Header second column");
        validateAndCompareElement(thirdColumnLinksInvestmentsAndFinancialPlanningHeader,
            THIRD_COLUMN_LINKS_TEXT_INVESTMENT_AND_FINANCIAL_PLANNING, "Investment And Financial Header third column");
        validateAndCompareElement(fourthColumnLinksInvestmentsAndFinancialPlanningHeader,
            FOURTH_COLUMN_LINKS_TEXT_INVESTMENT_AND_FINANCIAL_PLANNING, "Investment And Financial Header fourth column");
    }

    /**
     * This is to verify All Contact HSBC Links in Header for Premier on the
     * dashboard
     */
    private void verifyContactHSBCLinksHeader(FlyerMenuNavigationModel navigationModel) {
        navigationModel.mouseOverOnContactHSBC();
        validateAndCompareElement(linksContactHSBCHeader, LINKS_TEXT_CONTACT_HSBC, "Contact HSBC Header");
    }

    /*
     * Footer Methods
     */
    /**
     * This is to verify the First layer in the Footer on the dashboard
     */
    public void aboveFooterLink() {
        validateAndCompareElement(aboveFooterLinksList(), aboveFooterLinkText(), "Above footer links");
    }

    public List<WebElement> aboveFooterLinksList() {
        return aboveFooterLinks;
    }

    public List<String> aboveFooterLinkText() {
        return ABOVE_FOOTER_LINKS_TEXT;
    }

    /**
     * This is to verify the Middle layer in the Footer on the dashboard
     */
    public void belowFooterLink() {
        validateAndCompareElement(belowFooterLinksList(), belowFooterLinkText(), "Below footer links");
    }

    public List<WebElement> belowFooterLinksList() {
        return belowFooterLinks;
    }

    public List<String> belowFooterLinkText() {
        return BELOW_FOOTER_LINKS_TEXT;
    }

    /**
     * 
     * <p>
     * This is to scroll the WebElement into view and check whether it is
     * displayed on the application or not and report to the log
     * </p>
     * 
     * @param element
     *            - to check whether WebElement is displayed or not
     * @param passMessage
     *            - pass message
     * @param errorMessage
     *            - error message
     */
    public void validateAndCompareElement(List<WebElement> presentElementList, List<String> savedTextList, String placeHolder) {
        int count = 0;
        Reporter.log(placeHolder + " Links: ");
        for (int i = 0; i < presentElementList.size(); i++) {
            jsx.executeScript(SCROLL_TO_VIEW, presentElementList.get(i));
            if (presentElementList.get(i).getText().isEmpty()) {
                continue;
            } else if (presentElementList.get(i).getText().equals(savedTextList.get(count))) {
                Reporter.log(presentElementList.get(i).getText() + " | ");
                count++;
            } else {
                UserInterfaceRequirementDashboardModel.logger.error("Expected: " + savedTextList.get(count) + ", but Actual: "
                    + presentElementList.get(i).getText() + " link in " + placeHolder);
                Assert.fail("Expected: " + savedTextList.get(count) + ", but Actual: " + presentElementList.get(i).getText()
                    + " link in " + placeHolder);
            }
        }
    }

    /**
     * This is to verify the Middle layer in the Footer on the dashboard
     */
    public void footerLink() {
        validateAndCompareElement(popularLinksFooter, POPULAR_LINKS_FOOTER_TEXT, "Popular links footer");
        validateAndCompareElement(openAccountNowLinksFooter, OPEN_ACCT_NOW_LINKS_FOOTER_TEXT, "Open Account Now");
        validateAndCompareElement(insightsAndAdviceLinksFooter, INSIGHTS_AND_ADVICE_LINKS_LINKS_FOOTER_TEXT, "Insight and Advice");
        validateAndCompareElement(myProfileAndAccountMaintenanceLinksFooter, MY_PROFILE_AND_ACCT_MAINTENANCE_LINKS_FOOTER_TEXT,
            "My profile and account maintenance");
        validateAndCompareElement(helpAndSupportLinksFooter, HELP_AND_SUPPORT_LINKS_FOOTER_TEXT, "Help and support");
    }

    /**
     * 
     * <p>
     * This is to scroll the WebElement into view and check whether it is
     * displayed on the application or not and report to the log
     * </p>
     * 
     * @param element
     *            - to check whether WebElement is displayed or not
     * @param passMessage
     *            - pass message
     * @param errorMessage
     *            - error message
     */
    public void assertAndReportElementIsDisplayed(final WebElement element, final String passMessage, final String errorMessage) {
        wait.until(ExpectedConditions.visibilityOf(element));
        jsx.executeScript(SCROLL_TO_VIEW, element);
        Assert.assertTrue(element.isDisplayed(), errorMessage);
        Reporter.log(passMessage);
    }
}
