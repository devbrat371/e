package com.hsbc.digital.testauto.models;

public enum TransactionFrequency {

    UNTILFURNOTIC("Until Further Notice"), DATE("Date"), NOOFTRANSACTION("Number of transfers");

    private final String value;

    private TransactionFrequency(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
