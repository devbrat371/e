/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.models;


/**
 * <p>
 * <b> Class used for transfering data for Stop Cheque story. </b>
 * </p>
 */
public class StopChequeDetails {

    private AccountDetails issueChequeAccount;
    private String payeeName;
    private String chequeNumber;
    private String issueDate;
    private String amount;
    private String reasonToStopCheque;

    private String chequeEndNumber;

    /**
     * @return the chequeEndNumber
     */
    public String getChequeEndNumber() {
        return this.chequeEndNumber;
    }

    /**
     * @param chequeEndNumber
     *            the chequeEndNumber to set
     */
    public AccountDetails getIssueChequeAccount() {
        return issueChequeAccount;
    }

    public void setIssueChequeAccount(AccountDetails issueChequeAccount) {
        this.issueChequeAccount = issueChequeAccount;
    }

    public void setChequeEndNumber(final String chequeEndNumber) {
        this.chequeEndNumber = chequeEndNumber;
    }

    public void setChequeNumber(final String chequeNumber) {
        this.chequeNumber = chequeNumber;
    }

    public String getChequeNumber() {
        return this.chequeNumber;
    }


    public String getPayeeName() {
        return this.payeeName;
    }

    public void setPayeeName(final String payeeName) {
        this.payeeName = payeeName;
    }

    public String getIssueDate() {
        return this.issueDate;
    }

    public void setIssueDate(final String dateCapture) {
        this.issueDate = dateCapture;
    }

    public String getAmount() {
        return this.amount;
    }

    public void setAmount(final String amount) {
        this.amount = amount;
    }

    public String getReasonToStopCheque() {
        return reasonToStopCheque;
    }

    public void setReasonToStopCheque(String reasonToStopCheque) {
        this.reasonToStopCheque = reasonToStopCheque;
    }

    public void setStopChequeDetails(final StopChequeDetails stopCheque) {
        this.payeeName = stopCheque.getPayeeName();
        this.issueDate = stopCheque.getIssueDate();
        this.chequeNumber = stopCheque.getChequeNumber();
        this.amount = stopCheque.getAmount();
    }

    public void setStopChequeRange(final StopChequeDetails stopCheque) {
        this.chequeNumber = stopCheque.getChequeNumber();
        this.chequeEndNumber = stopCheque.getChequeEndNumber();
    }
}
