package com.hsbc.digital.testauto.pageobject.mx;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.hsbc.digital.testauto.pageobject.CommunicationPreferencesModel;

public class CommunicationPreferences extends CommunicationPreferencesModel {

	@FindBy(xpath = ".//*[contains(@id,'Address')]")
	protected WebElement address;

	@FindBy(xpath = ".//*[contains(@id,'phoneField')]")
	protected WebElement phone;

	@FindBy(xpath = "//div[@class='row commPreferencesTable commPreferencesStmtTable fourColumn']//div[@class='colOne']")
	private List<WebElement> statementType;

	public CommunicationPreferences(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

	public void navigateToCP(){
    	userLabel.click();
    	commPreferencesLink.click();
    }

	public void verifyDetails(){

		CommunicationPreferencesModel.logger.info(email.getText());
		CommunicationPreferencesModel.logger.info(phone.getText());
    	CommunicationPreferencesModel.logger.info(address.getText());


    }

	public void verifyLevel(){

    	for(WebElement type : statementType){
    		CommunicationPreferencesModel.logger.info("Level: "+type.getText());
    	}
    }

	 public void changeDefaultStatementType(){
		 radioUnChecked.click();
	    }

}
