package com.hsbc.digital.testauto.pageobject.us;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.hsbc.digital.testauto.pageobject.CommunicationPreferencesModel;

public class CommunicationPreferences extends CommunicationPreferencesModel {



	@FindBy(xpath = "//div[@class='row commPreferencesTable commPreferencesStmtTable fourColumn']//span[@class='accountNumber']")
	private WebElement accNum;



	public CommunicationPreferences(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

	public void navigateToCP(){



			userLabel.click();

	    	commPreferencesLink.click();

	}

	public void verifyDetails(){


    	CommunicationPreferencesModel.logger.info("Email: "+email.getText());

    }

	public void verifyLevel(){

		if(accNum.isDisplayed()){
			CommunicationPreferencesModel.logger.info("Account Level");
			CommunicationPreferencesModel.logger.info("Account: "+accNum.getText());
		}else{
			CommunicationPreferencesModel.logger.info("Profile Level");
		}


    }

	public void changeDefaultStatementType(){
    	radioUnChecked.click();
    }

}
