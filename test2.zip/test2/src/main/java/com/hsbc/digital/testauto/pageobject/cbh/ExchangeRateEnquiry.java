/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.cbh;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.pageobject.ExchangeRateEnquiryModel;

/**
 * <p><b>
 * TODO : Insert description of the class's responsibility/role.
 * </b></p>
 */
public class ExchangeRateEnquiry extends ExchangeRateEnquiryModel {

    private static final String[] EXPECTED_CURRENCY_LIST = {"AUD", "CAD", "CHF", "DKK", "EUR", "GBP", "HKD", "JPY", "LKR", "NOK",
        "NZD", "SEK", "SGD", "THB", "USD"};

    private static final String DEFAULT_CURRENCY = "USD";

    public ExchangeRateEnquiry(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    @Override
    public List<String> getExpectedCurrencyList() {
        return Arrays.asList(ExchangeRateEnquiry.EXPECTED_CURRENCY_LIST);
    }

    @Override
    public String getDefaultCurrency() {
        return ExchangeRateEnquiry.DEFAULT_CURRENCY;
    }


    /**
     * Method to verify the rate applied while conversion.
     * 
     * @param amount
     * 
     */
    public void isRateApplied() {
        isElementDisplayed(transferOrPaymentRateResult);
        verifyRateApplied(fromAmountValue, toAmountValue);
        enterAmount(toAmount);
        Reporter.log("To Amount Entered");
        verifyRateApplied(fromAmountValue, toAmountValue);
    }


    private void verifyRateApplied(final WebElement fromAmountValue, final WebElement toAmountValue) {
        String formatedAmountFrom = fromAmountValue.getAttribute("value").toString();
        String formatedAmountTo = toAmountValue.getAttribute("value").toString();
        String rateResultText = transferOrPaymentRateResult.getText();
        Assert.assertTrue(rateResultText.contains(formatedAmountFrom) && rateResultText.contains(formatedAmountTo)
            && rateResultText.contains(fromCurrency.getText()) && rateResultText.contains(toCurrency.getText()),
            "Exchange Rate is not applied");
        Reporter.log("Exchange Rate is applied");
    }

}
