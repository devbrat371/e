/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.mx;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.pageobject.OrderChequeBookCapturePageModel;

/**
 * <p>
 * <b> This class will hold locators and specific implementation for Order
 * Cheque Book for Mexico entity. </b>
 * </p>
 */
public class OrderChequeBookCapturePage extends OrderChequeBookCapturePageModel {

    /********************** Locators on Capture Page ******************************/
    // Locator for account drop down button
    @FindBy(xpath = "//div[contains(@id,'SelectAccount')]//td[contains(@class,'DownArrowButton')]//input")
    private WebElement accountDropDownButton;

    // Locator for number Of Cheques drop down button
    @FindBy(xpath = "//div[contains(@class,'SelectNumberCheq') and not(@style='display: none;')]//td[contains(@class,'DownArrowButton')]//input")
    private WebElement numberOfChequesDropDownButton;

    // Locator for List of number Of pages in Cheque book
    @FindBy(xpath = "//div[contains(@id,'dropdown') and not(contains(@style,'display'))]//td[contains(@id,'text')]")
    private List<WebElement> numberOfPagesList;

    // Locator for selected account
    @FindBy(xpath = "//div[contains(@id,'SelectAccount')]//table[contains(@id,'Select')]//div[contains(@class,'InputField')]")
    private WebElement selectedAccount;

    // Locator for selected number of chequebook
    @FindBy(xpath = "//div[contains(@class,'SelectNumberCheq') and not(@style='display: none;')]//table[contains(@id,'Select')]//div[contains(@class,'InputField')]/span")
    private WebElement selectedNumberOfPages;

    // Locator for Cancel message on Cancel dialog box
    @FindBy(xpath = "//div[@data-dojo-attach-point='_editOrderCancelDialog']//div[@class='formWrapper']")
    private WebElement capturePageCancelMessage2;

    // Locator for delivery address
    @FindBy(xpath = "//div[not(contains(@class,'noDisplay'))]/div[@data-dojo-attach-point='homebranch']")
    private WebElement deliveryAddress;

    // Locator for Dashboard Page Heading Title
    @FindBy(xpath = "//div[@class='managePanelOpen']//a[text()='Request chequebook']")
    private List<WebElement> orderChequesLink;


    private static final String EXPECTED_CAPTUREPAGE_TITLE = "Order chequebook";

    private static final int EXPECTED_MAX_NUMBER_OF_PAGES = 200;

    private static final String ACCOUNT_TYPE_CODE = "PMNA";

    public OrderChequeBookCapturePage(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    /**
     * Method to verify capture page is displayed.
     * 
     */
    @Override
    public void isOrderChequeCapturePageDisplayed() {
        Assert.assertTrue(
            orderChequeBookCapturePage.isDisplayed()
                && orderChequeBookCapturePage.getText().equalsIgnoreCase(EXPECTED_CAPTUREPAGE_TITLE),
            "Order Cheque Book Capture Page is not displayed or displayed title does not match with expected title. ");
        Reporter.log("Order Cheque Book Capture Page is displayed and displayed title matches with expected title. ");
    }

    @Override
    public void selectNumberOfPages() {
        clickNumberOfPagesDropDown();
        verifyMaximumNumberOfPages();
        selectValues(numberOfPagesList);
        Reporter.log("Number Of Pages in cheque book selected. ");
    }

    public void clickNumberOfPagesDropDown() {
        numberOfChequesDropDownButton.click();
        Reporter.log("Number Of Pages Drop Down button clicked. ");
    }

    /**
     * Method to verify maximum number of cheque book pages that user can order
     * in a cheque book.
     * 
     */
    public void verifyMaximumNumberOfPages() {
        Assert.assertTrue(
            Integer.parseInt(numberOfPagesList.get(numberOfPagesList.size() - 1).getText()) == EXPECTED_MAX_NUMBER_OF_PAGES,
            "Maximum number of pages in list is not as expected. ");
        Reporter.log("Maximum number of pages in list is as expected. ");
    }

    /**
     * Method to set Account details selected
     * 
     * @return accountDetails
     * 
     */
    @Override
    public AccountDetails setAccountDetails() {
        AccountDetails accountDetails = new AccountDetails();
        String[] details = selectedAccount.getText().split("\\r?\\n");
        accountDetails.setAccountName(details[0]);
        accountDetails.setAccountNumber(details[1]);
        accountDetails.setNumberOfPages(selectedNumberOfPages.getText());
        return accountDetails;
    }

    /**
     * Method to verify if delivery address is displayed on capture page.
     * 
     */
    @Override
    public void isDeliveryAddressDisplayed() {
        Assert.assertTrue(deliveryAddress.isDisplayed(), "Delivery Address is not displayed. ");
        Reporter.log("Delivery Address is displayed. ");
    }

    /**
     * Method to click on order cheque book link on manage tab.
     * 
     */
    @Override
    public void clickOrderChequeBookLink() {
        orderChequesLink.get(0).click();
        Reporter.log("Order chequebook link clicked. ");
    }

    @Override
    public boolean isOrderChequeBookLinkDisplayed() {
        if (!orderChequesLink.isEmpty()) {
            Reporter.log("Order Cheque Book link in manage tab is displayed. ");
            return true;
        } else {
            return false;
        }
    }

    /**
     * Method to verify invalid accounts for ordering a cheque book.
     * 
     */
    @Override
    public void verifyInvalidAccounts() {
        for (WebElement account : accountsLists) {
            if (account.getAttribute("unique-account-number").contains(ACCOUNT_TYPE_CODE)) {
                account.click();
                if (manageButtonList.isEmpty()) {
                    Reporter.log("Manage button not displayed for the account. ");
                } else {
                    clickManageButton();

                }
            }
        }
    }

    /**
     * Method to click on account selection drop down button on capture page.
     * 
     */
    @Override
    public void clickAccountDropDownButton() {
        accountDropDownButton.click();
        Reporter.log("Accounts selection drop down button clicked. ");
    }
}
