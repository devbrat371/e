package com.hsbc.digital.testauto.models;

import org.apache.commons.lang3.StringUtils;

/**
 * This class holds the values for Bank details and Payee details while adding
 * New payee
 * 
 * @author Shweta Jain
 * 
 */
public class AddBeneficiaryDetails {

    private BankDetails bankDetails;
    private String payeeName;
    private String accountType;
    private String payeeAddress1;
    private String payeeAddress2;
    private String payeeAddress3;
    private Integer payeeCount;


    public void setPayeeAddressFields(final String address) {
        if (StringUtils.isNotEmpty(address)) {
            this.setPayeeAddress1(address.split("::")[0]);
            this.setPayeeAddress2(address.split("::")[1]);
            this.setPayeeAddress3(address.split("::")[2]);
        }
    }

    public String getPayeeName() {
        return this.payeeName;
    }

    public void setPayeeName(final String payeeName) {
        this.payeeName = payeeName;
    }


    public Integer getPayeeCount() {
        return this.payeeCount;
    }


    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(final String accountType) {
        this.accountType = accountType;
    }


    public void setPayeeCount(final Integer payeeCount) {
        this.payeeCount = payeeCount;
    }


    public String getPayeeAddress1() {
        return payeeAddress1;
    }

    public void setPayeeAddress1(final String payeeAddress1) {
        this.payeeAddress1 = payeeAddress1;
    }

    public String getPayeeAddress2() {
        return payeeAddress2;
    }

    public void setPayeeAddress2(final String payeeAddress2) {
        this.payeeAddress2 = payeeAddress2;
    }

    public String getPayeeAddress3() {
        return payeeAddress3;
    }

    public void setPayeeAddress3(final String payeeAddress3) {
        this.payeeAddress3 = payeeAddress3;
    }

    public BankDetails getBankDetails() {
        return bankDetails;
    }

    public void setBankDetails(final BankDetails bankDetails) {
        this.bankDetails = bankDetails;
    }

}
