/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.DateUtil;
import com.hsbc.digital.testauto.library.FileUtil;
import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.library.TokenGenerator;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.models.Transaction;
import com.hsbc.digital.testauto.models.TransactionFlow;
import com.hsbc.digital.testauto.ui.library.UICommonUtil;

/**
 * <p>
 * <b> Abstract Class is used to define all the common function required for
 * Capture page of Move Money stories With Primary story being Story 39 </b>
 * 
 * @version 1.0.0
 * @author Neeraj Kumar & Pramesh
 * 
 *         </p>
 */

public abstract class MoveMoneyCapturePageModel {
    protected final WebDriverWait wait;
    protected final WebDriver driver;
    protected final JavascriptExecutor jsx;
    private final TokenGenerator generator;
    protected final UICommonUtil uiCommonUtil;

    protected static final String ENTITY_US = "us";
    protected static final String ENTITY_BANK_COUNTRY = "Canada";
    protected static final int DEFAULT_REFERENCE_TEXT_LENGTH = 6;
    private static final int DEFAULT_DAYS_TO_ADD_TRANSACTION_END_DATE = 80;
    private static final int DEFAULT_DAYS_TO_ADD_FOR_VALID_LATER_RECURRING_DATE = 2;
    private static final int DEFAULT_DAYS_TO_ADD_TO_AVOID_SATURDAY = 2;
    private static final int DEFAULT_DAYS_TO_ADD_TO_AVOID_SUNDAY = 1;
    private static final int DEFAULT_DECIMAL_PLACES = 2;
    private static final int AMOUNT_START_RANGE = 1;
    private static final int AMOUNT_END_RANGE = 100;
    protected static final int DEFAULT_LIST_STARTING_INDEX = 0;
    private static final String HUB_DATE = "hubDate";
    private static final String HUB_DATE_FORMAT = "hubFormat";
    private static final String SCROLL_TO_VIEW = "arguments[0].scrollIntoView(true);";
    private static final String GET_HIDDEN_TEXT = "return arguments[0].innerHTML";
    private static final String BLANK_FIELD_VALUE = "";
    protected static final String ELEMENT_VALUE_ATTRIBUTE = "value";
    private static final String ACCOUNT_TYPE = "Other Local Bank";
    protected static final int DEFAULT_ACCOUNT_NUMBER_LENGTH = 12;
    private static final int MIN_RANGE_NUMBER_OF_PAYMENT = 1;
    private static final int MAX_RANGE_NUMBER_OF_PAYMENT = 5;


    // *****************************DashBoard Page*******************

    @FindBy(xpath = "//div[@id='accountsummary']/div")
    private WebElement accountSummaryPanel;

    // *****************************Entity Country******

    @FindBy(xpath = "//div[contains(@id, '_header')]//div[contains(@id, 'CountryDropdown')]//span[contains(@id, 'DropDownButton')]")
    private WebElement entityCountry;

    // ******************************New Transaction Page***********

    @FindBy(xpath = "//div[contains(@id, '_TxnHandler')]")
    private WebElement capturePage;

    @FindBy(xpath = "//div[contains(@id, '_TxnHandler')]//*[contains(@data-dojo-attach-point, '_transactionTitle')]")
    private WebElement capturePageTitle;

    // ******************************From Account*******************

    @FindBy(xpath = "//span[contains(@class, 'optionItem')]//span[@class='row']")
    private WebElement selectedAccountNumber;

    @FindBy(xpath = "//span[contains(@class, 'optionItem')]//span[@class='title']")
    private WebElement selectedAccountName;

    @FindBy(xpath = "//div[contains(@id,'_fromAccount')]//table[contains(@id,'group_gpib_mvmny_bijit_Select')]//span[contains(@class,'accountDetailsactSlOption')]")
    private WebElement fromAccountNumber;

    @FindBy(xpath = "//div[contains(@id,'_fromAccount')]//table[contains(@id,'group_gpib_mvmny_bijit_Select')]//span[contains(@class,'title') and not(contains(@class,'noDisplay'))]")
    private WebElement fromAccountName;

    @FindBy(xpath = "//div[contains(@id, 'fromAccount')]//input[contains(@id, 'SelectDropDown')]")
    private WebElement fromDropIcon;

    // *******************************To Account*********************

    @FindBy(xpath = "//div[contains(@id, 'toAccount')]//input[contains(@id, 'SelectDropDown')]")
    private WebElement toDropIcon;

    @FindBy(xpath = "//div[contains(@id,'_toAccount')]//table[contains(@id,'group_gpib_mvmny_bijit_Select')]//span[contains(@class,'accountDetailsactSlOption')]")
    private WebElement toAccountNumber;

    @FindBy(xpath = "//div[contains(@id,'_toAccount')]//table[contains(@id,'group_gpib_mvmny_bijit_Select')]//span[contains(@class,'title')and not(contains(@class,'noDisplay'))]")
    private WebElement toAccountName;

    // ********************************Account Elements***************

    private final By accountNation = By.cssSelector("span[class*='nation']");

    private final By accountDetails1 = By.cssSelector("span[class*='optionItem']");

    private final By accountDetails2 = By.cssSelector("span[role*='option']");

    private final By accountName1 = By.xpath(".//span[contains(@class,'title') and not(contains(@class,'noDisplay'))]");

    private final By accountName2 = By.cssSelector("span[class*='row accountDetails']");

    private final By accountNumber = By.cssSelector("span[class*='accountDetails accountDetailsactSlOption']");

    private final By currency = By.cssSelector("span[class*='currencyTypeStyle2 currencyactSlOption']");

    private final By locatorAccountBalance = By.cssSelector("span[class*='balance']");

    @FindBy(xpath = "//div[contains(@class,'dijitMenuActive')]")
    protected WebElement listDropdown;

    // ********************************Move Money Tabs******************

    @FindBy(xpath = "//span[contains(@role, 'tab') and (starts-with(text(), 'My payees') or starts-with(text(), 'My Payees'))]")
    protected List<WebElement> myPayeesTabs;

    @FindBy(xpath = "//span[contains(@role, 'tab') and (starts-with(text(), 'My payees') or starts-with(text(), 'My Payees'))]")
    protected WebElement myPayeesTab;

    @FindBy(xpath = "//span[contains(@role, 'tab') and (starts-with(text(), 'My accounts') or starts-with(text(), 'My Accounts'))]")
    private WebElement myAccountsTab;

    @FindBy(xpath = "//span[contains(@role, 'tab') and (starts-with(text(), 'New payee') or starts-with(text(), 'New Payee'))]")
    private WebElement newPayeeTab;

    @FindBy(xpath = "//span[contains(@role, 'tab') and (starts-with(text(), 'New payee') or starts-with(text(), 'New Payee'))]")
    private List<WebElement> newPayeeTabs;

    // ********************************My Payee Section******************

    @FindBy(xpath = "//div[contains(@id, 'SelectPayee')]//label[contains(@for, 'myPayee')]")
    private WebElement myPayeesLabel;

    @FindBy(xpath = "//div[contains(@id, 'myPayee')]//input[contains(@id, 'myPayee') and contains(@class, 'dijitArrowButtonInner')]")
    protected WebElement myPayeeDropIcon;


    @FindBy(xpath = "//div[contains(@id,'SelectPayee') and contains(@id,'_myPayee_popup') and @role='listbox']//div[contains(@class,'row')]")
    private List<WebElement> myPayeeListAll;

    @FindBy(css = "div[id$='_myPayee_popup']")
    protected WebElement myPayeeList;

    @FindBy(css = "input[id$='myPayee'][role*='textbox']")
    protected WebElement myPayeeText;

    protected final By locatorPayeeAccountNumber = By
        .xpath("//div[contains(@id, 'Capture')]//div[contains(@class, 'payeeAccNumPad')]");

    protected final By locatorSelectedPayeeAccountNumber = By
        .xpath("//div[contains(@id, 'myPayee')]//span[contains(@class, 'accountDetails')]");

    private final By locatorMyPayeeName = By.cssSelector("span[class*='title']");

    // ********************************New Payee Section******************

    @FindBy(xpath = "//div[contains(@id, 'payeeType')]//label[contains(@data-dojo-attach-point, '_payeeTypePersonLabel')]")
    private WebElement personPayeeTab;

    @FindBy(xpath = "//div[contains(@id, 'payeeType')]//label[contains(@data-dojo-attach-point, '_payeeTypeCompanyLabel')]")
    private WebElement companyPayeeTab;

    @FindBy(xpath = "//span[contains(text(),'Payee') and contains(text(),'bank details')]")
    private WebElement linkPayeesBankDetails;

    @FindBy(xpath = "//input[contains(@id, 'bankCountry') and contains(@class, 'dijitArrowButtonInner')]")
    private WebElement bankCountryDropIcon;

    @FindBy(xpath = "//input[contains(@id, 'bankCountry') and contains(@data-dojo-attach-point, 'textbox,focusNode')]")
    private WebElement bankCountryText;

    @FindBy(xpath = "//table[contains(@id, 'Select') and contains(@aria-labelledby, 'newDomesticPayeeAccountType')]//input[contains(@class, 'dijitArrowButtonInner')]")
    private WebElement accountTypeDropIcon;

    @FindBy(xpath = "//table[contains(@id, 'Select') and contains(@aria-labelledby, 'newDomesticPayeeAccountType')]//span[contains(@role, 'option')]")
    private WebElement valueAccountType;

    @FindBy(xpath = "//input[contains(@id, '_accountCCY') and contains(@class, 'dijitArrowButtonInner')]")
    private WebElement accountCurrencyDropIcon;

    @FindBy(xpath = "//input[contains(@id, '_accountCCY') and contains(@data-dojo-attach-point, 'textbox,focusNode')]")
    private WebElement accountCurrencyText;

    @FindBy(xpath = "//input[contains(@id,'_acctNum') and contains(@data-dojo-attach-point, 'textbox,focusNode')]")
    protected WebElement accountNumberText;

    @FindBy(css = "input[id$='_accountReferenceNumber'][data-dojo-attach-point='textbox,focusNode']")
    protected WebElement companyReferenceText;

    @FindBy(xpath = "//input[contains(@id,'_acctNum') and contains(@data-dojo-attach-point, 'textbox,focusNode')]")
    private List<WebElement> accountNumberTexts;

    @FindBy(css = "input[id*='_bankName'][class*='dijitArrowButtonInner'],input[id*='_phBankSearchRoutingAgent'][class*='dijitArrowButtonInner']")
    private WebElement bankAndBranchNameDropIcon;

    @FindBy(xpath = "//input[contains(@id, '_phBankSearchCity') and contains(@class, 'dijitArrowButtonInner')]")
    private WebElement bankCityDropIcon;

    @FindBy(xpath = "//input[contains(@id, '_payeeName') and contains(@data-dojo-attach-point, 'textbox,focusNode')]")
    protected WebElement newPayeeNameText;

    @FindBy(xpath = "//input[contains(@id, '_payeeAddress1') and contains(@data-dojo-attach-point, 'textbox,focusNode')]")
    private WebElement address1Text;

    @FindBy(xpath = "//input[contains(@id, '_payeeAddress2') and contains(@data-dojo-attach-point, 'textbox,focusNode')]")
    private WebElement address2Text;

    @FindBy(xpath = "//input[contains(@id, '_payeeAddress3') and contains(@data-dojo-attach-point, 'textbox,focusNode')]")
    private WebElement address3Text;

    @FindBy(xpath = "//input[contains(@id, '_savePayee') and contains(@class, 'dijitCheckBoxInput')]")
    private WebElement saveToMyPayeesCheckBox;

    @FindBy(xpath = "//div[contains(@id, 'TitlePane')]//span[contains(@id, 'label') and (contains(text(), 'Next to personal details') or contains(text(), 'Add personal details'))] ")
    protected List<WebElement> nextToPersonalDetailsButtons;

    @FindBy(xpath = "//div[contains(@id, 'TitlePane')]//span[contains(@id, '_label') and contains(text(), 'Continue with payment')]")
    private WebElement continueWithPaymentButton;

    @FindBy(xpath = "//input[contains(@id, 'companyName') and contains(@class, 'dijitArrowButtonInner')]")
    protected WebElement companyListDropIcon;

    @FindBy(xpath = "//div[contains(@class,'dijitComboBoxMenu')  and contains(@role, 'listbox')]")
    protected WebElement listMenuItems;

    // ***********************Transfer My Payee Transfer Amount Section*******

    @FindBy(css = "input.dijitReset.dijitInputField.dijitArrowButtonInner[id$='transferCurrency']")
    private WebElement transferCurrencyDropIcon;


    private static final By LocatorM2MInternationalAmountfield = By
        .xpath(".//input[contains(@id,'group_gpib_mvmny_bijit_us_CaptureM2MInternationalTransfer_')and contains(@id,'_Amount_CurrencyTextBox')]");
    private static final By locatorM2MAmountField = By
        .xpath("//div[@data-dojo-attach-point='_amountFieldOuterDiv']//div[contains(@id,'_CurrencyTextBox')]//input[contains(@id,'_Amount')] | //input[contains(@id, 'CurrencyTextBox')]");
    private static final By locatorM2NMHSBCAmountField = By
        .cssSelector("input[id$='_amountLbl'][data-dojo-attach-point='textbox,focusNode'], input[id$='_amountFieldCapture'][data-dojo-attach-point='textbox,focusNode'], input[id*='currencyField'][id$='CurrencyTextBox'][data-dojo-attach-point='textbox,focusNode']");
    private static final By locatorNonHSBCAmountField = By
        .cssSelector("input[id$='_ariaPyeChargesLabelNew'][data-dojo-attach-point='textbox,focusNode'], input[id*='currencyField'][id$='CurrencyTextBox'][data-dojo-attach-point='textbox,focusNode']");
    private static final By locatorInternationalAmountField = By
        .cssSelector("input[id$='_ariaPyeChargesLabelNew'][data-dojo-attach-point='textbox,focusNode']");
    private static final By locatorM2CompanyAmountField = By
        .cssSelector("input[id*='amount'][id$='CurrencyTextBox'][data-dojo-attach-point='textbox,focusNode'], input[id*='currencyField'][id$='CurrencyTextBox'][data-dojo-attach-point='textbox,focusNode']");

    protected static final Map<TransactionFlow, By> transferAmountElements = new HashMap<>();

    @FindBy(xpath = "//div[contains(@id, 'Capture')]//a[contains(@data-dojo-attach-point, '_paymentLimitLink')] ")
    private WebElement paymentLimitLink;

    protected final By amountLabel = By
        .cssSelector("label.forSelect[for$='amountLbl'], label.forSelect[for$='ariaPyeChargesLabelNew'], div.forSelect.externalLabel.amtLabelm2mD,label.forSelect");

    // *********************************Reference Text*************************

    private static final By locatorM2MYourReferenceField = By
        .cssSelector("input[id*='_Reference'][data-dojo-attach-point='textbox,focusNode'],input[id*='_ValidationTextBox'][data-dojo-attach-point='textbox,focusNode']");
    private static final By locatorM2NMHSBCYourReferenceField = By
        .cssSelector("input[id*='_referenceLabelCapture'][data-dojo-attach-point='textbox,focusNode'], input[id$='_referenceYour'][data-dojo-attach-point='textbox,focusNode'], input[id*='_ValidationTextBox'][data-dojo-attach-point='textbox,focusNode']");
    private static final By locatorNonHSBCYourReferenceField = By
        .cssSelector("input[id*='_yourReference'][data-dojo-attach-point='textbox,focusNode'], input[id$='_reference'][data-dojo-attach-point='textbox,focusNode'], input[id*='_ValidationTextBox'][data-dojo-attach-point='textbox,focusNode'],input[id*='_referenceYour'][data-dojo-attach-point='textbox,focusNode']");
    private static final By locatorInternationalYourReferenceField = By
        .cssSelector("input[id*='_yourReference'][data-dojo-attach-point='textbox,focusNode'], input[id$='_reference'][data-dojo-attach-point='textbox,focusNode']");
    private static final By locatorM2CYourReferenceField = By
        .cssSelector("input[id$='yourRef'][data-dojo-attach-point='textbox,focusNode'], input[id$='reference'][data-dojo-attach-point='textbox,focusNode'], input[id*='_ValidationTextBox'][data-dojo-attach-point='textbox,focusNode']");

    protected static final Map<TransactionFlow, By> yourReferenceElements = new HashMap<>();

    @FindBy(xpath = "//input[contains(@id, '_payeeReference') and contains(@data-dojo-attach-point, 'textbox,focusNode')]")
    private WebElement payeeReferenceText;


    @FindBy(xpath = "//input[contains(@id, '_ValidationTextBox') and contains(@data-dojo-attach-point, 'textbox,focusNode')]")
    protected WebElement msgToPayee;


    // ********************************Transfer Date Tab Section***************

    @FindBy(xpath = "//span[starts-with(text(), 'Now')]")
    private WebElement nowTab;

    @FindBy(xpath = "//span[contains(text(), 'Date')]/ancestor::span[contains(text(), 'Later')]")
    private WebElement laterTab;

    @FindBy(xpath = "//span[starts-with(text(), 'Standing order') or starts-with(text(), 'Recurring')]")
    private WebElement recurringTab;

    @FindBy(xpath = "//span[starts-with(text(), 'Standing order') or starts-with(text(), 'Recurring')]")
    private List<WebElement> recurringTabs;


    // **********************************Later Section*************************

    @FindBy(css = "label[for$='_paymentDate']")
    private WebElement paymentDateLabel;

    @FindBy(xpath = "//div[contains(@id, 'paymentDate')]//input[@class='dijitReset dijitInputField dijitArrowButtonInner']")
    private WebElement paymentDateIcon;

    // ***********************************Recurring Section********************

    @FindBy(xpath = ".//input[contains(@id,'group_gpib_mvmny_bijit_CustTransferProperty_')and contains(@id,'_email')and(@aria-invalid='true')]")
    protected WebElement emailAddress;

    @FindBy(xpath = "//*[contains(@id, 'dapFrequency')]//*[contains(text(), 'Frequency')]")
    private WebElement frequencyLabel;

    @FindBy(xpath = "//table[contains(@aria-labelledby, '_dapFrequency')]//input[@class='dijitReset dijitInputField dijitArrowButtonInner']")
    private WebElement frequencyDropIcon;

    @FindBy(xpath = "//div[contains(@id, '_fromDate')]//input[@class='dijitReset dijitInputField dijitArrowButtonInner']")
    private WebElement dateOfFirstTransferIcon;

    @FindBy(css = "label[for$='_fromDate']")
    private WebElement dateofFirstTransferLabel;

    @FindBy(xpath = "//table[contains(@aria-labelledby, 'furtherNoticeBoxField')]//input[@class='dijitReset dijitInputField dijitArrowButtonInner']")
    protected WebElement transactionEndDateDropIcon;

    @FindBy(xpath = "//div[contains(@id, '_finalPaymentDate')]//input[@class='dijitReset dijitInputField dijitArrowButtonInner']")
    private WebElement dateOfFinalPaymentIcon;

    @FindBy(css = "input[id$='_numberOfTransactions'][data-dojo-attach-point='textbox,focusNode']")
    protected WebElement numberOfPaymentsText;

    @FindBy(xpath = "//input[contains(@id, 'CurrencyTextBox') and contains(@aria-labelledby, 'ariaLastPaymentAmountLabel')]")
    private WebElement lastTransferAmountText;

    @FindBy(xpath = "//div[contains(@class,'dijitTabContainerTopChildWrapper dijitVisible')]//*[ text()='Language of notification']//following-sibling::div//table//td[2]/input")
    protected WebElement languageNotification;

    // ***********************************Footer Button Section***************

    @FindBy(xpath = "//div[contains(@class,'submitButtonsPanel')]//*[contains(text(), 'Continue') or @data-dojo-attach-point='_continueButton']")
    private WebElement continueButton;

    @FindBy(xpath = "//input[@value='Continue']")
    private WebElement continueAfterEditButton;

    @FindBy(xpath = "//div[contains(@class,'submitButtonsPanel')]//*[@data-dojo-attach-point='_cancelButton']")
    private WebElement cancelButton;

    @FindBy(xpath = "//input[contains(@name, 'tdsOtpValue') and contains(@data-dojo-attach-point, 'textbox,focusNode')]")
    private WebElement transactionSecurityCodeText;

    @FindBy(xpath = "//div[@class='acceptTermsRow']//input[contains(@id,'TermsAndConditions')]")
    protected WebElement termAndConditionCheckBox;

    // ***********************************Cancel Dialog************************

    @FindBy(xpath = "//div[contains(@id,'ConfirmDialog')]//button[@data-dojo-attach-point='_btnCancel']")
    private WebElement cancelPopUpDialogButton;

    @FindBy(xpath = "//div[contains(@id,'ConfirmDialog')]//button[@data-dojo-attach-point='_btnOk']")
    private WebElement continuePopUpDialogButton;

    protected final By cancelDialog = By.xpath("//div[contains(@id,'ConfirmDialog')]");

    // *************************************Calendar Elements******************

    @FindBy(xpath = "//table[contains(@class,'dijitCalendar')]")
    private WebElement tableActiveCalendar;

    protected final By locatorTermAndConditionCheckBox = By
        .xpath("//div[@class='acceptTermsRow']//input[contains(@id,'TermsAndConditions')]");


    // ***************************************DropDown Elements****************

    protected final By menuText = By.cssSelector("[id$='_text']");

    protected final By menuPopup = By.cssSelector("div.dijitReset.dijitMenuItem[id*='_popup']");

    private final By companyPayeeLocator = By.xpath("//*[@class='dijitReset dijitMenuItem']/div[contains(@class,'company')]");

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(MoveMoneyCapturePageModel.class);

    static {
        transferAmountElements.put(TransactionFlow.M2MINTERNATIONAL_TRANSFER, LocatorM2MInternationalAmountfield);
        transferAmountElements.put(TransactionFlow.M2M_TRANSFER, locatorM2MAmountField);
        transferAmountElements.put(TransactionFlow.M2NMHSBC_TRANSFER, locatorM2NMHSBCAmountField);
        transferAmountElements.put(TransactionFlow.M2NMNONHSBC_TRANSFER, locatorNonHSBCAmountField);
        transferAmountElements.put(TransactionFlow.M2NMINTERNATIONAL_TRANSFER, locatorInternationalAmountField);
        transferAmountElements.put(TransactionFlow.M2COMPANY_TRANSFER, locatorM2CompanyAmountField);
        yourReferenceElements.put(TransactionFlow.M2M_TRANSFER, locatorM2MYourReferenceField);
        yourReferenceElements.put(TransactionFlow.M2NMHSBC_TRANSFER, locatorM2NMHSBCYourReferenceField);
        yourReferenceElements.put(TransactionFlow.M2NMNONHSBC_TRANSFER, locatorNonHSBCYourReferenceField);
        yourReferenceElements.put(TransactionFlow.M2NMINTERNATIONAL_TRANSFER, locatorInternationalYourReferenceField);
        yourReferenceElements.put(TransactionFlow.M2COMPANY_TRANSFER, locatorM2CYourReferenceField);
    }

    public MoveMoneyCapturePageModel(final WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, 30000);
        jsx = (JavascriptExecutor) driver;
        generator = new TokenGenerator();
        uiCommonUtil = new UICommonUtil(driver);
    }


    // *********************************Common Function************************
    /**
     * Method to get the ENTITY COUNTRY NAME as displayed in Account Selection
     * DropDown
     * 
     */
    protected String getEntityBankCountry() {
        return MoveMoneyCapturePageModel.ENTITY_BANK_COUNTRY;
    }


    /**
     * Method to return valid later or recurring date, avoiding Saturday/Sunday
     * 
     * @throws ParseException
     */
    private Date laterRecurringDate(final Map<String, String> envProperties) throws ParseException {
        Date parseDate = validDate(envProperties);
        Calendar cal = Calendar.getInstance();
        cal.setTime(parseDate);
        cal.add(Calendar.DAY_OF_YEAR, MoveMoneyCapturePageModel.DEFAULT_DAYS_TO_ADD_FOR_VALID_LATER_RECURRING_DATE);
        int dayofWeek = cal.get(Calendar.DAY_OF_WEEK);
        if (dayofWeek == Calendar.SATURDAY) {
            cal.add(Calendar.DAY_OF_YEAR, MoveMoneyCapturePageModel.DEFAULT_DAYS_TO_ADD_TO_AVOID_SATURDAY);
            parseDate = cal.getTime();
        } else if (dayofWeek == Calendar.SUNDAY) {
            cal.add(Calendar.DAY_OF_YEAR, MoveMoneyCapturePageModel.DEFAULT_DAYS_TO_ADD_TO_AVOID_SUNDAY);
            parseDate = cal.getTime();
        } else {
            parseDate = cal.getTime();
        }
        return parseDate;
    }

    /**
     * Method to return hub date and if its not specified, return system date
     * 
     * @throws ParseException
     */
    private static Date validDate(Map<String, String> envProperties) throws ParseException {
        if (!envProperties.get(HUB_DATE).trim().isEmpty()) {
            return DateUtil.getStringToDate(envProperties.get(HUB_DATE_FORMAT), envProperties.get(HUB_DATE));
        } else {
            return new Date();
        }
    }


    /**
     * Method to Select Value from Dropdown
     */
    protected void selectValue(final WebElement arrowDrop, final WebElement menuDrop, final String valueToSelect) {
        arrowDrop.click();
        wait.until(ExpectedConditions.visibilityOf(menuDrop));
        List<WebElement> valueElements = menuDrop.findElements(menuText).isEmpty() ? menuDrop.findElements(menuPopup) : menuDrop
            .findElements(menuText);
        for (WebElement valueElement : valueElements) {
            jsx.executeScript(SCROLL_TO_VIEW, valueElement);
            if (valueElement.getText().contains(valueToSelect)) {
                wait.until(ExpectedConditions.elementToBeClickable(valueElement));
                valueElement.click();
                Reporter.log(valueToSelect + " is selected in dropdown.");
                break;
            }
        }
    }


    /**
     * Method to Select Payee from Dropdown
     */
    protected void selectPayee(final WebElement myPayeeDropIcon, final WebElement payeeList, final String accName,
        final String accNumber) {
        boolean flag = false;
        int index = 0;
        myPayeeDropIcon.click();
        wait.until(ExpectedConditions.visibilityOf(payeeList));
        do {
            List<WebElement> payeesRows = payeeList.findElements(menuPopup);
            flag = payeeValue(payeeList, payeesRows, index, accName, accNumber);
            index++;
        } while (!flag);

    }

    private boolean payeeValue(WebElement payeeList, List<WebElement> payeeRows, int index, final String accName,
        final String accNumber) {
        boolean flag = false;

        jsx.executeScript(SCROLL_TO_VIEW, payeeRows.get(index));
        if (accName.contains(payeeRows.get(index).findElement(locatorMyPayeeName).getText())) {
            payeeRows.get(index).click();
            uiCommonUtil.activeElement(amountLabel).click();
            String payeeAccountNumber = driver.findElements(locatorPayeeAccountNumber).isEmpty() ? driver.findElement(
                locatorSelectedPayeeAccountNumber).getText() : driver.findElement(locatorPayeeAccountNumber).getText();
            if (payeeAccountNumber.equals(accNumber)) {
                flag = true;
            } else {
                myPayeeDropIcon.click();
                wait.until(ExpectedConditions.visibilityOf(payeeList));
            }
        }
        return flag;
    }

    /**
     * Select Random Value from DropDown
     * 
     * @param dropDownIcon
     *            DropDown Icon
     * @param dropDownItems
     *            Drop Down Menu Item
     */
    protected String selectRandamValue(final WebElement dropDownIcon, final WebElement dropDownItems) {
        dropDownIcon.click();
        wait.until(ExpectedConditions.visibilityOf(dropDownItems));
        List<WebElement> valueElements = dropDownItems.findElements(menuText).isEmpty() ? dropDownItems.findElements(menuPopup)
            : dropDownItems.findElements(menuText);
        int selectedElementNumber = RandomUtil.generateIntNumber(1, valueElements.size());
        jsx.executeScript(SCROLL_TO_VIEW, valueElements.get(selectedElementNumber));
        String selectedValue = valueElements.get(selectedElementNumber).getText();
        wait.until(ExpectedConditions.elementToBeClickable(valueElements.get(selectedElementNumber)));
        valueElements.get(selectedElementNumber).click();
        Reporter.log("Item Selected:" + valueElements.get(selectedElementNumber).getText());
        return selectedValue;
    }

    /**
     * Return Random Value from DropDown other than what is specified
     * 
     * @param dropDownIcon
     *            DropDown Icon
     * @param dropDownItems
     *            Drop Down Menu Item
     */
    protected String otherRandamValue(final WebElement dropDownIcon, final WebElement dropDownItems, String valueToAvoid) {
        List<String> valuesDropDown = new ArrayList<>();
        dropDownIcon.click();
        wait.until(ExpectedConditions.visibilityOf(dropDownItems));
        List<WebElement> valueElements = dropDownItems.findElements(menuText).isEmpty() ? dropDownItems.findElements(menuPopup)
            : dropDownItems.findElements(menuText);
        for (WebElement valueElement : valueElements) {
            jsx.executeScript(MoveMoneyCapturePageModel.SCROLL_TO_VIEW, valueElement);
            String currentValue = valueElement.getText();
            if (!currentValue.contains(valueToAvoid)) {
                valuesDropDown.add(currentValue);
            }
        }
        dropDownIcon.click();
        int index = RandomUtil.generateIntNumber(DEFAULT_LIST_STARTING_INDEX, valuesDropDown.size());
        return valuesDropDown.get(index);
    }


    protected boolean isValidAccount(final boolean domesticAccount, final String entity, final String accountlocation) {
        return (domesticAccount && accountlocation.equalsIgnoreCase(entity))
            || (!domesticAccount && !accountlocation.equalsIgnoreCase(entity));
    }

    private boolean isValidCurrency(final boolean domesticCurrency, final String accountCurrency, final String entityCurrency) {
        return (domesticCurrency && accountCurrency.equalsIgnoreCase(entityCurrency))
            || (!domesticCurrency && !accountCurrency.equalsIgnoreCase(entityCurrency));
    }

    /**
     * Method to Return Account Number of All Account in a DropDown
     */
    private List<AccountDetails> validAccountDetails(final String entityCurrency, final WebElement accountDropIcon,
        final WebElement menuDrop, final boolean domesticAccount, final boolean domesticCurrency) {
        List<AccountDetails> storeAccountValue = new ArrayList<>();
        String entity = getEntityBankCountry();
        accountDropIcon.click();
        wait.until(ExpectedConditions.visibilityOf(menuDrop));
        List<WebElement> accountRows = menuDrop.findElements(menuText);
        for (WebElement accountRow : accountRows) {
            jsx.executeScript(MoveMoneyCapturePageModel.SCROLL_TO_VIEW, accountRow);
            String currentAccountLocation = (String) jsx.executeScript(MoveMoneyCapturePageModel.GET_HIDDEN_TEXT,
                accountRow.findElement(accountNation));
            WebElement accName = accountRow.findElements(accountName1).isEmpty() ? accountRow.findElement(accountName2)
                : accountRow.findElement(accountName1);
            String currentAccountName = (String) jsx.executeScript(MoveMoneyCapturePageModel.GET_HIDDEN_TEXT, accName);
            WebElement optItem = accountRow.findElements(accountDetails1).isEmpty() ? accountRow.findElement(accountDetails2)
                : accountRow.findElement(accountDetails1);
            if (!optItem.findElements(accountNumber).isEmpty()) {
                WebElement accNumber = optItem.findElement(accountNumber);
                String currentAccountNumber = accNumber.getText();
                String currentAccountCurrency = (String) jsx.executeScript(MoveMoneyCapturePageModel.GET_HIDDEN_TEXT,
                    optItem.findElement(currency));
                String currentAccountBalance = (String) jsx.executeScript(MoveMoneyCapturePageModel.GET_HIDDEN_TEXT,
                    optItem.findElement(locatorAccountBalance));
                Double balance = Double.parseDouble(currentAccountBalance.replace(",", ""));
                if (isValidAccount(domesticAccount, entity, currentAccountLocation)
                    && isValidCurrency(domesticCurrency, currentAccountCurrency, entityCurrency) && balance > 0) {
                    AccountDetails accountInformations = new AccountDetails();
                    accountInformations.setAccountName(currentAccountName);
                    accountInformations.setAccountNumber(currentAccountNumber);
                    accountInformations.setAccountBalance(currentAccountBalance);
                    accountInformations.setDoubleAccountBalance(balance);
                    accountInformations.setCurrency(currentAccountCurrency);
                    storeAccountValue.add(accountInformations);
                }
            }
        }
        jsx.executeScript(SCROLL_TO_VIEW, accountDropIcon);
        accountDropIcon.click();
        return storeAccountValue;
    }

    /**
     * 
     * <p>
     * <b> This method is used to select account based on entity and flag
     * domesticAccount and flag domesticCurrency. If flag is false, it'll
     * select International account in from dropdown </b>
     * </p>
     * 
     * @return driver
     */
    private AccountDetails selectAccount(final String entityCurrency, final WebElement accountDropIcon,
        final boolean domesticAccount, final boolean domesticCurrency) {
        int index;
        List<AccountDetails> accountValue = validAccountDetails(entityCurrency, accountDropIcon, listDropdown, domesticAccount,
            domesticCurrency);
        Assert.assertTrue(!accountValue.isEmpty(), "No valid account found.");
        do {
            index = RandomUtil.generateIntNumber(DEFAULT_LIST_STARTING_INDEX, accountValue.size());
            selectAccountByAccountDetail(accountDropIcon, accountValue.get(index));
        } while (myPayeesTabs.isEmpty());
        return accountValue.get(index);
    }

    private void selectAccountByAccountDetail(final WebElement accountDropIcon, final AccountDetails accountDetail) {
        accountDropIcon.click();
        wait.until(ExpectedConditions.visibilityOf(listDropdown));
        List<WebElement> accDrop = listDropdown.findElements(menuText);
        clickValidAccountElement(accDrop, accountDetail);
    }

    protected void clickValidAccountElement(final List<WebElement> accountRows, final AccountDetails accountDetail) {
        for (WebElement accountRow : accountRows) {
            jsx.executeScript(SCROLL_TO_VIEW, accountRow);
            WebElement accName = accountRow.findElements(accountName1).isEmpty() ? accountRow.findElement(accountName2)
                : accountRow.findElement(accountName1);
            String currentAccountName = (String) jsx.executeScript(GET_HIDDEN_TEXT, accName);
            WebElement optItem = accountRow.findElements(accountDetails1).isEmpty() ? accountRow.findElement(accountDetails2)
                : accountRow.findElement(accountDetails1);
            WebElement accNumber = optItem.findElement(accountNumber);
            String currentAccountNumber = accNumber.getText();
            if (currentAccountNumber.equalsIgnoreCase(accountDetail.getAccountNumber())
                && currentAccountName.equalsIgnoreCase(accountDetail.getAccountName())) {
                accountRow.click();
                Reporter.log("\nAccount with Name : " + accountDetail.getAccountName() + " and Number :"
                    + accountDetail.getAccountNumber() + " is selected.");
                break;
            }
        }
    }

    protected void clickMyPayeeTab() {
        myPayeesTab.click();
        wait.until(ExpectedConditions.visibilityOf(myPayeesLabel));
        Reporter.log("My Payees tab is clicked.");
    }

    private void clickNewPayeeTab() {
        newPayeeTab.click();
        wait.until(ExpectedConditions.visibilityOf(personPayeeTab));
        Reporter.log("My Payees tab is clicked.");
    }

    private void clickLinkPayeeBankDetails() {
        linkPayeesBankDetails.click();
        Reporter.log("Payee Bank Details link is clicked.");
    }

    private void clickPersonTab() {
        personPayeeTab.click();
        if (!accountNumberTexts.isEmpty() && accountNumberText.isDisplayed()) {
            wait.until(ExpectedConditions.visibilityOf(accountNumberText));
        } else {
            clickLinkPayeeBankDetails();
            wait.until(ExpectedConditions.visibilityOf(accountNumberText));
        }
    }

    private void clickCompanyTab() {
        companyPayeeTab.click();
    }

    protected AccountDetails enterNewPayeeDetails(String payeeName, String payeeAccountNumber) {
        AccountDetails accountDetails = new AccountDetails();
        nextToPersonalDetailsButtons.get(DEFAULT_LIST_STARTING_INDEX).click();
        accountNumberText.clear();
        accountNumberText.sendKeys(payeeAccountNumber);
        newPayeeNameText.clear();
        newPayeeNameText.sendKeys(payeeName);
        newPayeeNameText.sendKeys(Keys.RETURN);
        accountDetails.setAccountName(payeeName);
        accountDetails.setAccountNumber(payeeAccountNumber);
        return accountDetails;
    }

    protected void clickTabsToOpenNewPersonPayeeDetails() {
        clickNewPayeeTab();
        clickPersonTab();
    }

    protected void clickTabsToOpenNewCompanyPayeeDetails() {
        clickNewPayeeTab();
        clickCompanyTab();
    }

    public AccountDetails enterNewHSBCDomesticLCYPayeeDetails(final String profile, final Map<String, String> envProperties) {
        Map<String, String> profileProperties = FileUtil.getTestDataProperties(envProperties.get("countryCode"), profile);
        String payeeName = RandomUtil.generateAlphabatic(DEFAULT_REFERENCE_TEXT_LENGTH);
        String payeeAccountNumber = profileProperties.get("domesticLCYAccountNumber1");
        clickTabsToOpenNewPersonPayeeDetails();
        return enterNewPayeeDetails(payeeName, payeeAccountNumber);
    }

    public AccountDetails enterNewHSBCDomesticFCYPayeeDetails(final String profile, final Map<String, String> envProperties) {
        Map<String, String> profileProperties = FileUtil.getTestDataProperties(envProperties.get("countryCode"), profile);
        String payeeName = RandomUtil.generateAlphabatic(DEFAULT_REFERENCE_TEXT_LENGTH);
        String payeeAccountNumber = profileProperties.get("domesticFCYAccountNumber1");
        clickTabsToOpenNewPersonPayeeDetails();
        selectValue(accountCurrencyDropIcon, listMenuItems, profileProperties.get("fcyCurrencyCode1"));
        return enterNewPayeeDetails(payeeName, payeeAccountNumber);
    }

    public AccountDetails enterNewNonHSBCDomesticPayeeDetails() {
        String payeeName = RandomUtil.generateAlphabatic(DEFAULT_REFERENCE_TEXT_LENGTH);
        String payeeAccountNumber = RandomUtil.generateIntNumber(DEFAULT_ACCOUNT_NUMBER_LENGTH);
        clickTabsToOpenNewPersonPayeeDetails();
        wait.until(ExpectedConditions.elementToBeClickable(accountTypeDropIcon));
        selectValue(accountTypeDropIcon, listDropdown, ACCOUNT_TYPE);
        wait.until(ExpectedConditions.elementToBeClickable(bankAndBranchNameDropIcon));
        selectRandamValue(bankAndBranchNameDropIcon, listMenuItems);
        return enterNewPayeeDetails(payeeName, payeeAccountNumber);
    }

    public AccountDetails enterNewInternationalPayeeDetails(final Map<String, String> envProperties) {
        String payeeName = RandomUtil.generateAlphabatic(DEFAULT_REFERENCE_TEXT_LENGTH);
        String payeeAccountNumber = RandomUtil.generateIntNumber(DEFAULT_ACCOUNT_NUMBER_LENGTH);
        clickTabsToOpenNewPersonPayeeDetails();
        wait.until(ExpectedConditions.elementToBeClickable(bankCountryDropIcon));
        String internationalCountry = otherRandamValue(bankCountryDropIcon, listMenuItems, envProperties.get("countryName"));
        selectValue(bankCountryDropIcon, listDropdown, internationalCountry);
        wait.until(ExpectedConditions.elementToBeClickable(bankCityDropIcon));
        selectRandamValue(bankCityDropIcon, listDropdown);
        wait.until(ExpectedConditions.elementToBeClickable(bankAndBranchNameDropIcon));
        selectRandamValue(bankAndBranchNameDropIcon, listMenuItems);
        return enterNewPayeeDetails(payeeName, payeeAccountNumber);
    }

    public AccountDetails enterNewCompanyPayeeDetails() {
        AccountDetails accountDetails = new AccountDetails();
        clickTabsToOpenNewCompanyPayeeDetails();
        accountDetails.setAccountName(selectRandamValue(companyListDropIcon, listMenuItems));
        String companyReference = RandomUtil.generateIntNumber(DEFAULT_ACCOUNT_NUMBER_LENGTH);
        companyReferenceText.clear();
        companyReferenceText.sendKeys(companyReference);
        companyReferenceText.sendKeys(Keys.RETURN);
        accountDetails.setAccountNumber(companyReference);
        return accountDetails;
    }

    public String enterTransferAmount(Transaction transactionDetail) {
        String amount;
        if (transactionDetail.getFromAccount().getDoubleAccountBalance() < AMOUNT_END_RANGE) {
            int endRange = transactionDetail.getFromAccount().getDoubleAccountBalance().intValue();
            amount = RandomUtil.generateDoubleNumber(AMOUNT_START_RANGE, endRange, DEFAULT_DECIMAL_PLACES);
        } else {
            amount = RandomUtil.generateDoubleNumber(AMOUNT_START_RANGE, AMOUNT_END_RANGE, DEFAULT_DECIMAL_PLACES);
        }
        WebElement fieldAmount = driver.findElement(transferAmountElements.get(transactionDetail.getTransactionFlow()));
        fieldAmount.click();
        fieldAmount.clear();
        fieldAmount.sendKeys(amount);
        fieldAmount.sendKeys(Keys.RETURN);
        Reporter.log("Transfer Amount entered is :" + amount);
        return amount;
    }

    public String enterYourReferenceText(Transaction transactionDetail) {
        String yourReference = RandomUtil.generateAlphaNumericText(DEFAULT_REFERENCE_TEXT_LENGTH);
        WebElement fieldYourReference = driver.findElement(yourReferenceElements.get(transactionDetail.getTransactionFlow()));
        fieldYourReference.click();
        fieldYourReference.clear();
        fieldYourReference.sendKeys(yourReference);
        fieldYourReference.sendKeys(Keys.RETURN);
        Reporter.log("Your Reference entered is :" + yourReference);
        return yourReference;

    }

    public String enterPayeeReferenceText() {
        String payeeReference = RandomUtil.generateAlphaNumericText(DEFAULT_REFERENCE_TEXT_LENGTH);
        payeeReferenceText.click();
        payeeReferenceText.clear();
        payeeReferenceText.sendKeys(payeeReference);
        payeeReferenceText.sendKeys(Keys.RETURN);
        Reporter.log("Your Reference entered is :" + payeeReference);
        return payeeReference;

    }

    public String enterPayeeMessageText(final Transaction transactionDetail) {
        String payeeReference = RandomUtil.generateAlphaNumericText(MoveMoneyCapturePageModel.DEFAULT_REFERENCE_TEXT_LENGTH);
        msgToPayee.click();
        msgToPayee.clear();
        msgToPayee.sendKeys(payeeReference);
        msgToPayee.sendKeys(Keys.RETURN);
        Reporter.log("Your Reference entered is :" + payeeReference);
        return payeeReference;

    }

    public String enterAddress() {
        String address = RandomUtil.generateAlphaNumericText(DEFAULT_REFERENCE_TEXT_LENGTH);
        address1Text.click();
        address1Text.clear();
        address1Text.sendKeys(address);
        address1Text.sendKeys(Keys.RETURN);
        return address;
    }

    public void selectTransferCurrency(String transferCurrency) {
        selectValue(transferCurrencyDropIcon, listDropdown, transferCurrency);
        Reporter.log("Transfer Currency value selected is :" + transferCurrency);
    }

    public void clickNowTab() {
        nowTab.click();
        Reporter.log("Later tab is clicked.");
    }

    public void clickLaterTab() {
        laterTab.click();
        Reporter.log("Later tab is clicked.");
    }

    public Date enterLaterDate(Map<String, String> envProperties) throws ParseException {
        return uiCommonUtil.selectDate(paymentDateIcon, tableActiveCalendar, laterRecurringDate(envProperties));
    }

    public void clickRecurringTab() {
        recurringTab.click();
        wait.until(ExpectedConditions.visibilityOf(frequencyLabel));
        Reporter.log("Recurring tab is clicked.");
    }

    public String selectFrequency() {
        String frequencyValue = selectRandamValue(frequencyDropIcon, listDropdown);
        Reporter.log("Frequency value selected is :" + frequencyValue);
        return frequencyValue;
    }

    public Date enterDateOfFirstTransfer(Map<String, String> envProperties) throws ParseException {
        Date firstTransactionDate = laterRecurringDate(envProperties);
        return uiCommonUtil.selectDate(dateOfFirstTransferIcon, tableActiveCalendar, firstTransactionDate);
    }

    public Date enterDateOfFinalPayment(Map<String, String> envProperties) throws ParseException {
        wait.until(ExpectedConditions.visibilityOf(paymentDateLabel));
        Date finalTransactionDate = DateUtil.addDays(validDate(envProperties), DEFAULT_DAYS_TO_ADD_TRANSACTION_END_DATE);
        return uiCommonUtil.selectDate(dateOfFinalPaymentIcon, tableActiveCalendar, finalTransactionDate);
    }


    public String enterNumberOfPayment(Transaction transactionDetails) {
        selectNumberOfTransfer(transactionDetails);
        String valueNop = String.valueOf(RandomUtil.generateIntNumber(MIN_RANGE_NUMBER_OF_PAYMENT, MAX_RANGE_NUMBER_OF_PAYMENT));
        numberOfPaymentsText.click();
        numberOfPaymentsText.clear();
        numberOfPaymentsText.sendKeys(valueNop);
        numberOfPaymentsText.sendKeys(Keys.RETURN);
        Reporter.log("Number of Payement entered is :" + valueNop);
        return valueNop;
    }

    public String enterLastTransferAmount(String lastAmount) {
        lastTransferAmountText.clear();
        lastTransferAmountText.sendKeys(lastAmount);
        Reporter.log("Last Transfer Amount entered is :" + lastAmount);
        return lastAmount;
    }

    protected void selectTransactionEndDate(Transaction transactionDetails) {
        Reporter.log("This method is not applicable in ca entity.");
    }

    private void selectNumberOfTransfer(Transaction transactionDetails) {
        selectTransactionEndDate(transactionDetails);
    }

    public void clickContinueButton() {
        wait.until(ExpectedConditions.elementToBeClickable(continueButton));
        continueButton.click();
        Reporter.log("Continue button is clicked.");
    }

    /**
     * Method to Enter TDS and Continue Transaction
     */
    public void clickContinueWithTDS(String profile, final Map<String, String> envProperties, Transaction transactionDetail) {
        Map<String, String> profileProperties = FileUtil.getTestDataProperties(envProperties.get("countryCode"), profile);
        String payeeAccountNumber = transactionDetail.getToAccount().getAccountNumber();
        int length = Integer.parseInt(envProperties.get("accountNoLengthTDS"));
        String refAccNumber = payeeAccountNumber.substring(Math.max(payeeAccountNumber.length() - length, 0));
        try {
            String tds = generator.getTransactionTDS(profileProperties.get("userName"), profileProperties.get("otpKey"),
                refAccNumber);
            transactionSecurityCodeText.clear();
            transactionSecurityCodeText.sendKeys(tds);
            clickContinueButton();
        } catch (Exception e) {
            MoveMoneyCapturePageModel.logger.error(e);
            Assert.fail("TDS generation failed" + e.getMessage(), e);
        }
    }

    public void clickCancelButton() {
        wait.until(ExpectedConditions.elementToBeClickable(cancelButton));
        cancelButton.click();
        Reporter.log("Cancel Button is clicked.");
    }

    public void clickCancelPopUpCancelButton() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(cancelDialog));
        cancelPopUpDialogButton.click();
        Reporter.log("Cancel Button on Cancel Dialog is clicked.");
    }

    public void clickContinuePopupContinueButton() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(cancelDialog));
        continuePopUpDialogButton.click();
        Reporter.log("Don't Cancel Button on Cancel Dialog is clicked.");
    }

    private boolean isFromAccountDisplay() {
        return fromAccountName.isDisplayed() && fromAccountNumber.isDisplayed();
    }

    private boolean isToAccountDisplay() {
        return toAccountName.isDisplayed() && toAccountNumber.isDisplayed();
    }

    private boolean isAmountFieldDisplay(Transaction transactionDetail) {
        WebElement fieldAmount = driver.findElement(transferAmountElements.get(transactionDetail.getTransactionFlow()));
        return fieldAmount.getAttribute(ELEMENT_VALUE_ATTRIBUTE).equals(BLANK_FIELD_VALUE);
    }

    private boolean isReferenceDisplay(Transaction transactionDetail) {
        WebElement fieldYourReference = driver.findElement(transferAmountElements.get(transactionDetail.getTransactionFlow()));
        return fieldYourReference.getAttribute(ELEMENT_VALUE_ATTRIBUTE).equals(BLANK_FIELD_VALUE);
    }

    public void verifyDetailsAfterCancelOnVerifyPage(Transaction transactionDetail) {
        Assert.assertTrue(isFromAccountDisplay(), "From Account information is not displayed.");
        Assert.assertTrue(isToAccountDisplay(), "To Account information is not displayed.");
        Assert.assertTrue(isAmountFieldDisplay(transactionDetail), "Amount Field is not displayed.");
        Assert.assertTrue(isReferenceDisplay(transactionDetail), "Reference Field is not displayed.");
    }

    private void isFromAccountNameDisplayed(AccountDetails accountDetail) {
        Assert.assertTrue(fromAccountName.getText().equalsIgnoreCase(accountDetail.getAccountName()),
            "From Account Name does not match expected value.");
        Reporter.log("From Account Name matches : " + accountDetail.getAccountName());
    }

    private void isFromAccountNumberDisplayed(AccountDetails accountDetail) {
        Assert.assertTrue(fromAccountNumber.getText().equalsIgnoreCase(accountDetail.getAccountNumber()),
            "From Account Number does not match expected value.");
        Reporter.log("From Account Number matches : " + accountDetail.getAccountNumber());
    }

    private void isToAccountNameDisplayed(AccountDetails accountDetail) {
        Assert.assertTrue(toAccountName.getText().equalsIgnoreCase(accountDetail.getAccountName()),
            "To Account Name does not match expected value.");
        Reporter.log("To Account Name matches : " + accountDetail.getAccountName());
    }

    private void isToAccountNumberDisplayed(AccountDetails accountDetail) {
        Assert.assertTrue(toAccountNumber.getText().equalsIgnoreCase(accountDetail.getAccountNumber()),
            "To Account Number does not match expected value.");
        Reporter.log("To Account Number matches : " + accountDetail.getAccountNumber());
    }

    private void isPayeeNameDisplayed(AccountDetails accountDetail) {
        Assert.assertTrue(accountDetail.getAccountName().contains(myPayeeText.getAttribute(ELEMENT_VALUE_ATTRIBUTE)),
            "Payee Name does not match expected value.");
        Reporter.log("Payee Name matches : " + accountDetail.getAccountName());
    }

    private void isInlinePayeeNameDisplayed(AccountDetails accountDetail) {
        Assert.assertTrue(newPayeeNameText.getAttribute(ELEMENT_VALUE_ATTRIBUTE).equalsIgnoreCase(accountDetail.getAccountName()),
            "Payee Name does not match expected value.");
        Reporter.log("Payee Name matches : " + accountDetail.getAccountName());
    }

    private void isPayeeNumberDisplayed(AccountDetails accountDetail) {
        WebElement payeeAccountNumber = driver.findElements(locatorPayeeAccountNumber).isEmpty() ? driver
            .findElement(locatorSelectedPayeeAccountNumber) : driver.findElement(locatorPayeeAccountNumber);
        Assert.assertTrue(payeeAccountNumber.getText().trim().equalsIgnoreCase(accountDetail.getAccountNumber().trim()),
            "Payee Account Number does not match expected value.");
        Reporter.log("Payee Number matches : " + accountDetail.getAccountName());
    }

    protected void isInlinePayeeNumberDisplayed(AccountDetails accountDetail) {
        Assert.assertTrue(accountNumberText.getAttribute(ELEMENT_VALUE_ATTRIBUTE)
            .equalsIgnoreCase(accountDetail.getAccountNumber()), "Payee Account Number does not match expected value.");
        Reporter.log("Payee Number matches : " + accountDetail.getAccountName());
    }

    private void isTransferAmountDisplayed(Transaction transactionDetail) {
        WebElement amountField = driver.findElement(transferAmountElements.get(transactionDetail.getTransactionFlow()));
        Assert.assertTrue(amountField.getAttribute(ELEMENT_VALUE_ATTRIBUTE).equalsIgnoreCase(transactionDetail.getAmount()),
            "Transfer Amount does not match expected value.");
        Reporter.log("Transfer Amount matches : " + transactionDetail.getAmount());
    }

    public void isPaymentLimitLinkDisplayed() {
        Assert.assertTrue(paymentLimitLink.isDisplayed(), "Payment Limit Link is not displayed.");
        Reporter.log("Payment Limit Link is displayed.");
    }

    private void isYourReferenceDisplayed(Transaction transactionDetail) {
        WebElement fieldYourReference = driver.findElement(yourReferenceElements.get(transactionDetail.getTransactionFlow()));
        Assert.assertTrue(
            fieldYourReference.getAttribute(ELEMENT_VALUE_ATTRIBUTE).equalsIgnoreCase(transactionDetail.getYourReference()),
            "From Account Name does not match expected value.");
        Reporter.log("Your reference matches : " + transactionDetail.getYourReference());
    }

    public void verifyPageTitle() {
        wait.until(ExpectedConditions.visibilityOf(capturePageTitle));
        Assert.assertTrue(capturePageTitle.isDisplayed(), "Capture Page is not displayed.");
        Reporter.log("Capture Page is displayed.");
    }

    /**
     * Method to verify details on Capture page after negating cancel with
     * first parameter as from account details and second parameter as to
     * account details
     */

    protected void verifyDetailsAfterNegatingCancel(Transaction transactionDetail) {
        isFromAccountNameDisplayed(transactionDetail.getFromAccount());
        isFromAccountNumberDisplayed(transactionDetail.getFromAccount());
        isTransferAmountDisplayed(transactionDetail);
        isYourReferenceDisplayed(transactionDetail);

    }

    public void verifyDetailsAfterNegatingCancelOnCapturePage(Transaction transactionDetail) {
        wait.until(ExpectedConditions.invisibilityOfElementLocated(cancelDialog));
        verifyDetailsAfterNegatingCancel(transactionDetail);
        isPayeeNameDisplayed(transactionDetail.getToAccount());
        isPayeeNumberDisplayed(transactionDetail.getToAccount());
        Reporter.log("Details verified after negating cancel.");
    }

    public void verifyInlineDetailsAfterNegatingCancelOnCapturePage(Transaction transactionDetail) {
        wait.until(ExpectedConditions.invisibilityOfElementLocated(cancelDialog));
        verifyDetailsAfterNegatingCancel(transactionDetail);
        isInlinePayeeNameDisplayed(transactionDetail.getToAccount());
        isInlinePayeeNumberDisplayed(transactionDetail.getToAccount());
        Reporter.log("Details verified after negating cancel.");
    }

    /**
     * Method to verify details on Capture page after Continue the Cancel Flow
     * with
     * 
     */
    public void verifyDetailsAfterContinueCancelOnCapturePage(Transaction transactionDetail) {
        wait.until(ExpectedConditions.invisibilityOfElementLocated(cancelDialog));
        isFromAccountNameDisplayed(transactionDetail.getFromAccount());
        isFromAccountNumberDisplayed(transactionDetail.getFromAccount());
        isToAccountNameDisplayed(transactionDetail.getToAccount());
        isToAccountNumberDisplayed(transactionDetail.getToAccount());
        isTransferAmountDisplayed(transactionDetail);
        isYourReferenceDisplayed(transactionDetail);
        Reporter.log("Details verified after negating cancel.");
    }

    /**
     * Method to verify details on Capture page after Click Edit on Verify Page
     * first parameter as from account details and second parameter as to
     * account details
     */
    public void verifyCaptureDetailsAfterEditOnVerifyPageforM2M(Transaction transactionDetails) {
        wait.until(ExpectedConditions.invisibilityOfElementLocated(cancelDialog));
        isFromAccountNameDisplayed(transactionDetails.getFromAccount());
        isFromAccountNumberDisplayed(transactionDetails.getFromAccount());
        isToAccountNameDisplayed(transactionDetails.getToAccount());
        isToAccountNumberDisplayed(transactionDetails.getToAccount());
        isTransferAmountDisplayed(transactionDetails);
        isYourReferenceDisplayed(transactionDetails);
        Reporter.log("Details verified after Edit on Verify Page.");
    }

    public AccountDetails setDefaultFromAccountDetails() {
        AccountDetails accountDetail = null;
        return accountDetail;
    }

    public void selectFromAccountByAccountDetail(AccountDetails accountDetail) {
        wait.until(ExpectedConditions.visibilityOf(capturePageTitle));
        selectAccountByAccountDetail(fromDropIcon, accountDetail);
    }

    public void selectToAccountByAccountDetail(AccountDetails accountDetail) {
        wait.until(ExpectedConditions.visibilityOf(capturePageTitle));
        selectAccountByAccountDetail(toDropIcon, accountDetail);
    }

    public AccountDetails selectDomesticFromFCYAccount(final String entityCurrency) {
        wait.until(ExpectedConditions.visibilityOf(capturePageTitle));
        return selectAccount(entityCurrency, fromDropIcon, true, false);
    }

    public AccountDetails selectDomesticFromLCYAccount(final String entityCurrency) {
        wait.until(ExpectedConditions.visibilityOf(capturePageTitle));
        return selectAccount(entityCurrency, fromDropIcon, true, true);
    }

    public AccountDetails selectDomesticToLCYAccount(final String entityCurrency) {
        wait.until(ExpectedConditions.visibilityOf(capturePageTitle));
        return selectAccount(entityCurrency, toDropIcon, true, true);
    }

    public AccountDetails selectDomesticToFCYAccount(final String entityCurrency) {
        wait.until(ExpectedConditions.visibilityOf(capturePageTitle));
        return selectAccount(entityCurrency, toDropIcon, true, false);
    }

    public AccountDetails selectInternationalToLCYAccount(final String entityCurrency) {
        return selectAccount(entityCurrency, toDropIcon, false, true);
    }

    public AccountDetails selectInternationalToFCYAccount(final String entityCurrency) {
        return selectAccount(entityCurrency, toDropIcon, false, false);
    }

    public AccountDetails selectInternationalFromLCYAccount(final String entityCurrency) {
        return selectAccount(entityCurrency, fromDropIcon, false, true);
    }

    public AccountDetails selectInternationalFromFCYAccount(final String entityCurrency) {
        return selectAccount(entityCurrency, fromDropIcon, false, false);
    }

    public void processPayeeSelection(AccountDetails accountDetail) {
        clickMyPayeeTab();
        selectPayee(myPayeeDropIcon, myPayeeList, accountDetail.getAccountName(), accountDetail.getAccountNumber());
    }

    public void enterLCY2LCYDuplicateTransaction(Transaction transactionDetail, boolean isPayee) {
        wait.until(ExpectedConditions.visibilityOf(capturePageTitle));
        selectAccountByAccountDetail(fromDropIcon, transactionDetail.getFromAccount());
        if (isPayee) {
            processPayeeSelection(transactionDetail.getToAccount());
        } else {
            selectAccountByAccountDetail(toDropIcon, transactionDetail.getToAccount());
        }
        enterTransferAmount(transactionDetail);
        enterYourReferenceText(transactionDetail);
        clickContinueButton();
    }

    /**
     * Select Reason For Transaction
     */
    public String selectReasonForTransaction(Transaction transaction) {
        return StringUtils.EMPTY;
    }

    /**
     * Click the Terms And Conditions Check box
     */
    public void clickTermsAndConditionsCheckBox() {

    }

    public void checkDashBoardContent() {
        Assert.assertTrue(accountSummaryPanel.isDisplayed(), "Account Summary Panel is not displayed.");
    }

    /**
     * This method verifies if payee name passed is selected in To account for
     * payment
     * 
     * @param name
     *            : payee name selected on manage beneficiary page for payment
     */
    public void verifyPayeeOnMMpage(AccountDetails accountDetail) {
        wait.until(ExpectedConditions.visibilityOf(capturePageTitle));
        jsx.executeScript(MoveMoneyCapturePageModel.SCROLL_TO_VIEW, myPayeesLabel);
        isPayeeNameDisplayed(accountDetail);
        isPayeeNumberDisplayed(accountDetail);
        Reporter.log("Selected payee  :" + accountDetail.getAccountName() + " is displayed in TO account field as payee selected.");
    }

    public void verifyCompanyPayeeList() {
        clickMyPayeeTab();
        selectCompanyPayee(myPayeeDropIcon, myPayeeList);
    }

    public void selectCompanyPayee(WebElement myPayeeDropIcon, WebElement companyPayeeList) {
        myPayeeDropIcon.click();
        this.wait.until(ExpectedConditions.visibilityOf(this.myPayeeList));
        List<WebElement> payeesRows = this.myPayeeList.findElements(this.companyPayeeLocator);
        Assert.assertTrue(payeesRows.size() == MoveMoneyCapturePageModel.DEFAULT_LIST_STARTING_INDEX,
            "Company Payeee is displayed for FCY CCY account");
    }

    public String selectFeesPaidBy() {
        return StringUtils.EMPTY;
    }

    /**
     * method to check if the selected acc is correct @author 43900757
     */

    public void processIsValidAccInFromDropDown(final AccountDetails accountDetail, final String currencyCode) {
        clickMyPayeeTab();
        isValidAccInFromDropDown(myPayeeDropIcon, myPayeeList, accountDetail.getAccountName(), accountDetail.getAccountNumber(),
            currencyCode);
    }

    protected void isValidAccInFromDropDown(final WebElement myPayeeDropIcon, final WebElement payeeList, final String accName,
        final String accNumber, final String currencyCode) {
        /**
         * see the implementation of this method in the entity specific POM
         */
    }

    public void verfiyConfirmButton() {}

    public void verfiyCancelButton() {}

    public String enterPayeeMessageTextSpecialchar() {

        String payeeReference = RandomUtil.generateSpecialCharacterText(MoveMoneyCapturePageModel.DEFAULT_REFERENCE_TEXT_LENGTH);
        msgToPayee.click();
        msgToPayee.clear();
        msgToPayee.sendKeys(payeeReference);
        msgToPayee.sendKeys(Keys.RETURN);
        Reporter.log("Your Message to payee entered is :" + payeeReference);
        return payeeReference;
    }

    public void VerfiyErrormsg() {}


    /**
     * <p>
     * <b> TODO : Insert description of the method's responsibility/role. </b>
     * </p>
     * 
     * @return
     */
    public String selectTransactionEnddate() {
        // TODO Auto-generated method stub
        return null;
    }


    /**
     * <p>
     * <b> TODO : Insert description of the method's responsibility/role. </b>
     * </p>
     * 
     * @return
     */
    public String selectLanguajeEnglish() {
        // TODO Auto-generated method stub
        return null;
    }


    /**
     * <p>
     * <b> TODO : Insert description of the method's responsibility/role. </b>
     * </p>
     * 
     * @return
     */
    public String verifyNumberOfPayements() {
        // TODO Auto-generated method stub
        return null;
    }


    /**
     * <p>
     * <b> TODO : Insert description of the method's responsibility/role. </b>
     * </p>
     * 
     */
    public void inputEmailaddress() {
        // TODO Auto-generated method stub

    }


    /**
     * <p>
     * <b> TODO : Insert description of the method's responsibility/role. </b>
     * </p>
     * 
     * @return
     */
    public String selectTransactionEnddateUntilFurtherNotice() {
        // TODO Auto-generated method stub
        return null;
    }


}
