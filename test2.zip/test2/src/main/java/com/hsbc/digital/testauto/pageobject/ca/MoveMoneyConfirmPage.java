package com.hsbc.digital.testauto.pageobject.ca;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.pageobject.MoveMoneyConfirmPageModel;
import com.hsbc.digital.testauto.ui.library.UICommonUtil;

public class MoveMoneyConfirmPage extends MoveMoneyConfirmPageModel {

	 //Label Values for M2M fields  
		/*    protected static final String LABEL_FROM = "Account";
		    protected static final String LABEL_TO = "Move money to";*/
		
	// Query Raised to Confirm Label Values for other MM Functions
		
		 protected static final String LABEL_FROM = "From";
		 protected static final String LABEL_TO = "To";
	
    public MoveMoneyConfirmPage(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }
    
   
    
    @Override
    protected void isFromAccountNameDisplayed(final AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_FROM, accountDetail.getAccountName(), UICommonUtil.confirmPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given From Account Name not found.");
        Reporter.log("From Account Name displayed is :" + accountDetail.getAccountName());
    }

    @Override
    protected void isFromAccountNumberDisplayed(final AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_FROM, accountDetail.getAccountNumber(),
            UICommonUtil.confirmPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
            "Given From Account Number not found.");
        Reporter.log("From Account Number displayed is :" + accountDetail.getAccountNumber());
    }

    @Override
    protected void isToAccountNameDisplayed(final AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_TO, accountDetail.getAccountName(), UICommonUtil.confirmPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given To Account Name not found.");
        Reporter.log("To Account Name displayed is :" + accountDetail.getAccountName());
    }

    @Override
    protected void isToAccountNumberDisplayed(final AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_TO, accountDetail.getAccountNumber(), UICommonUtil.confirmPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given To Account Number not found.");
        Reporter.log("To Account Number displayed is :" + accountDetail.getAccountNumber());
    }


}
