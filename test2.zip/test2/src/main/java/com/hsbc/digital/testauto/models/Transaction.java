package com.hsbc.digital.testauto.models;

import java.util.Date;
import java.util.List;

public class Transaction {

    private AccountDetails fromAccount;
    private AccountDetails toAccount;
    private String amount;
    private String yourReference;
    private String selectedYear;
    private Date laterDate;
    private Date firstDateOfTransaction;
    private Date finalDateOfTransaction;
    private String reasonForTransaction;
    private String frequencyValue;
    private String numberOfPayment;
    private String referenceNumber;
    private TransactionFrequency transactionFrequency;
    private TransactionFlow transactionFlow;
    private String payeeReference;
    private String address1;
    private String feesPaidBy;

    public String getFeesPaidBy() {
        return feesPaidBy;
    }

    public void setFeesPaidBy(String feesPaidBy) {
        this.feesPaidBy = feesPaidBy;
    }

    private List<String> transactionsList;

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getPayeeReference() {
        return payeeReference;
    }

    public void setPayeeReference(String payeeReference) {
        this.payeeReference = payeeReference;
    }

    public TransactionFlow getTransactionFlow() {
        return transactionFlow;
    }

    public void setTransactionFlow(TransactionFlow transactionFlow) {
        this.transactionFlow = transactionFlow;
    }

    public TransactionFrequency getTransactionFrequency() {
        return transactionFrequency;
    }

    public void setTransactionFrequency(TransactionFrequency transactionFrequency) {
        this.transactionFrequency = transactionFrequency;
    }

    public String getYourReference() {
        return yourReference;
    }

    public void setYourReference(final String yourReference) {
        this.yourReference = yourReference;
    }

    public String getSelectedYear() {
        return selectedYear;
    }

    public void setSelectedYear(final String selectedYear) {
        this.selectedYear = selectedYear;
    }

    public Date getLaterDate() {
        return laterDate;
    }

    public void setLaterDate(final Date laterDate) {
        this.laterDate = laterDate;
    }

    public Date getFirstDateOfTransaction() {
        return firstDateOfTransaction;
    }

    public void setFirstDateOfTransaction(final Date firstDateOfTransaction) {
        this.firstDateOfTransaction = firstDateOfTransaction;
    }

    public Date getFinalDateOfTransaction() {
        return finalDateOfTransaction;
    }

    public void setFinalDateOfTransaction(final Date finalDateOfTransaction) {
        this.finalDateOfTransaction = finalDateOfTransaction;
    }

    public String getReasonForTransaction() {
        return reasonForTransaction;
    }

    public void setReasonForTransaction(final String reasonForTransaction) {
        this.reasonForTransaction = reasonForTransaction;
    }

    public String getFrequencyValue() {
        return frequencyValue;
    }

    public void setFrequencyValue(final String frequencyValue) {
        this.frequencyValue = frequencyValue;
    }

    public String getNumberOfPayment() {
        return numberOfPayment;
    }

    public void setNumberOfPayment(final String numberOfPayment) {
        this.numberOfPayment = numberOfPayment;
    }

    public String getReferenceNumber() {
        return referenceNumber;
    }

    public void setReferenceNumber(final String referenceNumber) {
        this.referenceNumber = referenceNumber;
    }

    public AccountDetails getFromAccount() {
        return fromAccount;
    }

    public void setFromAccount(final AccountDetails fromAccount) {
        this.fromAccount = fromAccount;
    }

    public AccountDetails getToAccount() {
        return toAccount;
    }

    public void setToAccount(final AccountDetails toAccount) {
        this.toAccount = toAccount;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(final String amount) {
        this.amount = amount;
    }

    // POJO for Conytact RM

    private String enquiryAbout;
    private String contactYou;
    private String message;

    public String getEnquiryAbout() {
        return enquiryAbout;
    }

    public void setgetEnquiryAbout(final String enquiryAbout) {
        this.enquiryAbout = enquiryAbout;
    }

    public String getContactYou() {
        return contactYou;
    }

    public void setContactYou(final String contactYou) {
        this.contactYou = contactYou;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(final String message) {
        this.message = message;
    }

    public List<String> getTransactionsList() {
        return transactionsList;
    }

    public void setTransactionsList(List<String> transactionsList) {
        this.transactionsList = transactionsList;
    }
}
