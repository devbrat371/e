package com.hsbc.digital.testauto.pageobject.us;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hsbc.digital.testauto.pageobject.StopChequeConfirmPageModel;
import com.hsbc.digital.testauto.ui.library.UICommonUtil;

public class StopChequeConfirmPage extends StopChequeConfirmPageModel {

    private static final String LABEL_CHEQUE_RANGE = "Check range";

    @Override
    protected String getLabelChequeRange() {
        return LABEL_CHEQUE_RANGE;
    }

    @FindBy(xpath = "//div[contains(@class, 'submitButtonsPanel')]//*[contains(@data-dojo-attach-point, 'dapAgainBtn')]")
    private WebElement stopAnotherChequeButton;

    @Override
    protected WebElement getStopAnotherChequeButton() {
        return stopAnotherChequeButton;
    }

    public StopChequeConfirmPage(final WebDriver driver) {
        super(driver);
        uiCommonUtil = new UICommonUtil(driver);
    }

}
