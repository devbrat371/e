/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.library;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

/**
 * <p>
 * <b> This class is used for reading files and returns its data in different
 * format.<br>
 * It includes reading of files like properties,excel etc. </b>
 * </p>
 * 
 * @version 1.0.0
 * @author Shrikant Joshi
 */
public class FileUtil {

    /** Property file path for Environment configuration declared. */
    public static final String PROPERTY_FILE_PATH = "src/main/resources/projectenvconfig/";

    public static final String PROFILE_FILE_PATH = "src/main/resources/projecttestdata/";
    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(FileUtil.class);

    private FileUtil() {

    }

    /**
     * Method for reading config file for environment based on given Entity.
     * 
     * @param entity
     * @return Key/Value pairs from property file.
     */
    public static Map<String, String> getConfigProperties(final String entity) {
        return readProperties(FileUtil.PROPERTY_FILE_PATH + entity + ".properties");
    }

    /**
     * Generic method to read any property file from any location within
     * project for given path.
     * 
     * @param path
     *            :Path of Property File.
     * @return Key/Value pairs from property file.
     */
    public static Map<String, String> readProperties(final String path) {
        Properties prop = new Properties();
        Map<String, String> propMap = new HashMap<>();
        InputStream input = null;
        try {
            input = new FileInputStream(path);
            prop.load(input);

        } catch (IOException e) {
            FileUtil.logger.error("Exception at readProperties:", e);
        }
        for (Entry<Object, Object> entries : prop.entrySet()) {
            propMap.put((String) entries.getKey(), (String) entries.getValue());
        }
        return propMap;
    }

    /**
     * Method to get Test Data for Profile from property file based on profile
     * and location of file.
     * 
     * @return Key/Value pairs from property file based on given profile.
     */
    public static Map<String, String> getTestDataProperties(final String entity, final String profile) {
        return readProperties(FileUtil.PROFILE_FILE_PATH + entity + File.separator + profile + ".properties");
    }

}
