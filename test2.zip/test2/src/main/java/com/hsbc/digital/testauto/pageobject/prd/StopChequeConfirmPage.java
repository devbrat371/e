package com.hsbc.digital.testauto.pageobject.prd;

import org.openqa.selenium.WebDriver;

import com.hsbc.digital.testauto.pageobject.StopChequeConfirmPageModel;
import com.hsbc.digital.testauto.ui.library.UICommonUtil;

/**
 * <p>
 * <b> Stop Cheque Confirm page object model to hold generic function and
 * locators for prd entity of story stop cheque</b>
 * </p>
 * 
 * @version 1.0.0
 * @author Neeraj Kumar
 */

public class StopChequeConfirmPage extends StopChequeConfirmPageModel {

    public StopChequeConfirmPage(final WebDriver driver) {
        super(driver);
        uiCommonUtil = new UICommonUtil(driver);
    }
}
