/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.mx;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.pageobject.OrderChequeBookConfirmPageModel;

/**
 * <p>
 * <b> This class will hold locators and specific implementation for Order
 * Cheque Book for Mexico entity. </b>
 * </p>
 */
public class OrderChequeBookConfirmPage extends OrderChequeBookConfirmPageModel {

    /********************** Locators on Confirmation Page ******************************/

    // Locator for number Of Cheques on Confirmation Page
    @FindBy(xpath = "//dd[@data-dojo-attach-point='_confirmNumberOfPagesInChequeBook']")
    private WebElement numberOfChequesConfirmPage;

    // Locator for delivery address
    @FindBy(xpath = "//dd[@data-dojo-attach-point='_confirmDeliveryAddress']")
    private WebElement deliveryAddressConfirmPage;

    // Locator for Disclaimer on Verify Page
    @FindBy(xpath = "//div[contains(@data-dojo-attach-point,'confirmation')]//div[contains(@class,'sectionedFooter')]/p")
    private WebElement disclaimerMessageConfirmPage;

    public OrderChequeBookConfirmPage(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    /**
     * Method to verify if delivery address is displayed on confirmation page.
     * 
     */
    @Override
    public void isDeliveryAddressOnConfirmPageDisplayed() {
        Assert.assertTrue(deliveryAddressConfirmPage.isDisplayed(), "Delivery Address is not displayed. ");
        Reporter.log("Delivery Address is displayed. ");
    }

    /**
     * Method to verify if Disclaimer Message is displayed on Confirm page.
     * 
     */
    @Override
    public void isDisclaimerMessageOnConfirmPageDisplayed() {
        Assert.assertTrue(disclaimerMessageConfirmPage.isDisplayed(), "Disclaimer Message On Confirm Page is not displayed. ");
        Reporter.log("Disclaimer Message On Confirm Page is displayed. ");
    }
}
