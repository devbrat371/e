/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

/**
 * <p>
 * <b> This model class will hold locators and functionality for Request
 * Replacement Pin Confirm page that can be used around all entities. </b>
 * </p>
 * 
 * @version 1.0.0
 * @author SatyaPrakash S Vyas
 */
public class IssueReplacementPinConfirmModel {

    private final WebDriverWait wait;

    @FindBy(xpath = "//div[@class='alertPanel confirmation']/p")
    private WebElement successMessage;

    @FindBy(xpath = "//div[@class='alertPanel confirmation error']/p")
    private WebElement errorMessage;

    @FindBy(xpath = "//div[@class='RequestpinDeliverTo']/p")
    private WebElement requestPinDeliveredToText;

    @FindBy(xpath = "//input[@value='My accounts']")
    private WebElement myAccountsButton;

    @FindBy(xpath = "//span[text()='My accounts']")
    private WebElement dashboardPage;

    private static final String PENDING_COMPLETION_ERROR_MESSAGE = "Error Message on confirmation Page is shown. Error message is:- Sorry, your instruction cannot be processed as we have received similar instructions pending completion. Please contact us for assistance.Our Ref.:{P48}";

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(IssueReplacementPinConfirmModel.class);

    public IssueReplacementPinConfirmModel(final WebDriver driver) {
        PageFactory.initElements(driver, this);
        this.wait = new WebDriverWait(driver, 30000);
    }

    public void validateSuccessMessage() {
        try {
            successMessage.isDisplayed();
            Reporter.log("Success Message on confirmation Page is shown. Success message is :- " + successMessage.getText());
            Reporter.log("Request pin delivered to: " + requestPinDeliveredToText.getText());
        } catch (Exception e) {
            if (IssueReplacementPinConfirmModel.PENDING_COMPLETION_ERROR_MESSAGE.equalsIgnoreCase(errorMessage.getText())) {
                Reporter.log("Already submitted request. Message is:- " + errorMessage.getText());
            } else {
                IssueReplacementPinConfirmModel.logger.error("Error Message on confirmation Page is shown. Error message is:- "
                    + errorMessage.getText(), e);
                Assert.fail("Error on sending request pin");
            }
        }
    }

    public void clickMyAccountsButton() {
        wait.until(ExpectedConditions.elementToBeClickable(myAccountsButton));
        myAccountsButton.click();
        dashboardPage.isDisplayed();
        Reporter.log("My Accounts button from Confirmation page is clicked and Dashboard page shown.");
    }
}
