/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.ca;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

import com.hsbc.digital.testauto.pageobject.OpenAccountOptionsModel;

/**
 * <p>
 * <b> This class will hold locators and specific implementation for Canada
 * entity. </b>
 * </p>
 */
public class OpenAccountOptions extends OpenAccountOptionsModel {

    final WebDriver driver;
    final WebDriverWait wait;

    @FindBy(xpath = "//div[contains(@class,'currency-text')]")
    private WebElement newAccountCurrency;

    @FindBy(xpath = "//div[@data-dojo-attach-point='_disclaimerForTFSA' and not (contains(@class,'dijitHidden'))]//input[contains(@id,'disclaimerchkboxforTFSA')]")
    private List<WebElement> disclaimerCheckboxforTFSA;

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(OpenAccountOptions.class);

    public OpenAccountOptions(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
        this.driver = driver;
        this.wait = new WebDriverWait(driver, 30);
    }

    @Override
    public String selectNewAccountCurrency() {
        Reporter.log("Currency Stored is: " + newAccountCurrency.getText() + ".");
        return newAccountCurrency.getText();
    }

    /**
     * Clicks disclaimer checkbox if displayed
     */
    public void clickTnCCheckbox() {
        if (!disclaimerCheckboxforTFSA.isEmpty()) {
            disclaimerCheckboxforTFSA.get(0).click();
            Reporter.log("disclaimerCheckboxforTFSA clicked.");
        }

    }
}
