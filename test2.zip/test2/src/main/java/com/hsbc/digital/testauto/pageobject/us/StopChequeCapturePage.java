/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.us;

import java.text.ParseException;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.hsbc.digital.testauto.models.StopChequeDetails;
import com.hsbc.digital.testauto.pageobject.StopChequeCapturePageModel;

/**
 * <p>
 * <b> Stop Cheque page object model to hold generic function and locators for
 * us entity. </b>
 * </p>
 */
public class StopChequeCapturePage extends StopChequeCapturePageModel {

    @FindBy(xpath = "//div[text()='Cheque range']//following-sibling::div")
    private WebElement chequeRangeReview;

    @FindBy(xpath = "//div[text()='Reason to stop cheque']//following-sibling::div")
    private WebElement stopChequeReasonReview;

    @FindBy(xpath = "//span[@class='verifyAccountNumber']")
    private WebElement accountNumberReview;


    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(StopChequeCapturePage.class);

    public StopChequeCapturePage(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    @Override
    protected String enterIssueDate(final StopChequeDetails stopCheque) throws ParseException {
        return StringUtils.EMPTY;
    }

    @Override
    public void validateFieldErrorsCapturePage() {
        isErrorOnBlankChequeNumberFieldDisplayed();
    }

    @Override
    public String selectReasonToStopCheque() {
        return StringUtils.EMPTY;
    }

}
