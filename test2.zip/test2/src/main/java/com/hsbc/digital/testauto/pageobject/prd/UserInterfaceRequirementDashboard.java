/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.prd;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.hsbc.digital.testauto.pageobject.UserInterfaceRequirementDashboardModel;

/**
 * <p>
 * <b> This class will hold locators and specific implementation for User
 * Interface Requirement Dashboard for PRD (China) entity. </b>
 * </p>
 */
public class UserInterfaceRequirementDashboard extends UserInterfaceRequirementDashboardModel {

    /*
     * HSBC LOGO
     */
    @FindBy(xpath = "//*[@class='logo hsbcRetail']")
    private WebElement hsbcLogoForMass;

    @FindBy(xpath = "//*[@class='logo hsbcAdvance']")
    private WebElement hsbcLogoForAdvance;

    @FindBy(xpath = "//*[@class='logo hsbcPremier']")
    private WebElement hsbcLogoForPremier;

    /*
     * -------- FOOTER LINKS --------
     *  Above Footer Links
     */
    @FindBy(xpath = "//li[contains(@class,'search')]")
    private WebElement findBranchOrATMLinkFooter;

    /*
     * Below Footer Links
     */
    @FindBy(xpath = "//*[contains(@data-url,'privacy-and-security')]")
    private WebElement privacyAndSecurityLinkFooter;

    @FindBy(xpath = "//*[contains(@data-url,'terms-of-use')]")
    private WebElement termsOfUseLinkFooter;

    @FindBy(xpath = "//*[contains(@data-url,'about')]")
    private WebElement aboutHSBCLinkFooter;

    /*
     *  My Profile Footer Links
     */
    @FindBy(xpath = "//*[@data-pageid='contactinformation']")
    private WebElement updatePersonalInformationLinkMyProfileFooter;

    @FindBy(xpath = "//*[@data-pageid='changebanklimits']")
    private WebElement manageInternetBankingLimitsLinkMyProfileFooter;

    @FindBy(xpath = "//*[@data-pageid='statements']")
    private WebElement statementsOrAdvicesLinkMyProfileFooter;

    @FindBy(xpath = "//*[contains(@data-url,'RequestAccountEStatement')]")
    private WebElement requestEStatementLinkMyProfileFooter;

    @FindBy(xpath = "//*[@data-pageid='orderToken']")
    private WebElement manageSecureKeyLinkMyProfileFooter;

    @FindBy(xpath = "//*[@data-pageid='secInfo']")
    private WebElement changeSecuritySettingsLinkMyProfileFooter;

    /*
     * Investment Footer Links
     */
    @FindBy(xpath = "//*[contains(@data-url,'MyRiskProfiler')]")
    private WebElement myRiskProfilerLinkInvestmentFooter;

    @FindBy(xpath = "//*[contains(@data-url,'DualCurrencyInvestment')]")
    private WebElement dualCurrencyInvestmentLinkInvestmentFooter;

    @FindBy(xpath = "//*[contains(@data-url,'OnlineQDIITradingPlatform')]")
    private WebElement onlineQDIITradingLinkInvestmentFooter;

    @FindBy(xpath = "//*[contains(@data-url,'OnlineStructuredProductGTradingPlatform')]")
    private WebElement onlineStructuredTradingLinkInvestmentFooter;

    /*
     * Contact HSBC Footer Links
     */
    @FindBy(xpath = "//a[contains(text(),'Contact us')]")
    private WebElement contactUsLinkContactHSBCFooter;


    public UserInterfaceRequirementDashboard(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    /*
     * Footer Methods
     */

    /**
     * This is to verify the First layer in the Footer on the dashboard
     */
    /*@Override
    public void verifyFindBranchOrATMLinkFooter() {
        assertAndReportElementIsDisplayed(findBranchOrATMLinkFooter, "Find Branch or ATM Link in Footer is displayed",
            "Find Branch or ATM Link in Footer is not displayed");
    }

    @Override
    public void verifyWaysToBankLinkFooter() {}
    */
    /**
     * This is to verify the Last layer in the Footer on the dashboard
     */
    @Override
    public void belowFooterLink() {
        // TODO : Sp
    }

    /**
     * This is to verify the Middle layer in the Footer on the dashboard
     */
    @Override
    public void footerLink() {
        myProfileLinksFooter();
        investmentLinksFooter();
        contactHSBCLinksFooter();
    }

    /**
     * This is to verify the Middle layer in the Footer for My Profile links on
     * the dashboard
     */
    private void myProfileLinksFooter() {
        assertAndReportElementIsDisplayed(updatePersonalInformationLinkMyProfileFooter,
            "Update Personal and Contact Information in My Profile Footer is displayed",
            "Update Personal and Contact Information in My Profile Footer is not displayed");
        assertAndReportElementIsDisplayed(manageInternetBankingLimitsLinkMyProfileFooter,
            "Manage Internet Banking Limits in My Profile Footer is displayed",
            "Manage Internet Banking Limits in My Profile Footer is not displayed");
        assertAndReportElementIsDisplayed(statementsOrAdvicesLinkMyProfileFooter,
            "Statements / Advices in My Profile Footer is displayed", "Statements / Advices in My Profile Footer is not displayed");
        assertAndReportElementIsDisplayed(requestEStatementLinkMyProfileFooter,
            "Request Account E-Statement and E-Advice in My Profile Footer is displayed",
            "Request Account E-Statement and E-Advice in My Profile Footer is not displayed");
        assertAndReportElementIsDisplayed(manageSecureKeyLinkMyProfileFooter,
            "Manage Secure Key in My Profile Footer is displayed", "Manage Secure Key in My Profile Footer is not displayed");
        assertAndReportElementIsDisplayed(changeSecuritySettingsLinkMyProfileFooter,
            "Change Security Settings in My Profile Footer is displayed",
            "Change Security Settings in My Profile Footer is not displayed");
    }

    /**
     * This is to verify the Middle layer in the Footer for Investment links on
     * the dashboard
     */
    private void investmentLinksFooter() {
        assertAndReportElementIsDisplayed(myRiskProfilerLinkInvestmentFooter, "My risk profiler in Investment Footer is displayed",
            "My risk profiler in Investment Footer is not displayed");
        assertAndReportElementIsDisplayed(dualCurrencyInvestmentLinkInvestmentFooter,
            "Dual Currency Investment in Investment Footer is displayed",
            "Dual Currency Investment in Investment Footer is not displayed");
        assertAndReportElementIsDisplayed(onlineQDIITradingLinkInvestmentFooter,
            "Online QDII Trading Platform in Investment Footer is displayed",
            "Online QDII Trading Platform in Investment Footer is not displayed");
        assertAndReportElementIsDisplayed(onlineStructuredTradingLinkInvestmentFooter,
            "Online Structured Product Trading Platform Link in Investment Footer is displayed",
            "Online Structured Product Trading Platform Link in Investment Footer is not displayed");
    }

    /**
     * This is to verify the Middle layer in the Footer for Contact HSBC links
     * on the dashboard
     */
    private void contactHSBCLinksFooter() {
        assertAndReportElementIsDisplayed(contactUsLinkContactHSBCFooter, "Contact Us Link in Contact HSBC Footer is displayed",
            "Contact Us Link in Contact HSBC Footer is not displayed");
    }

}
