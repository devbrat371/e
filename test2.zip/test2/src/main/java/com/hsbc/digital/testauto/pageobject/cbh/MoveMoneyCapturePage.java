package com.hsbc.digital.testauto.pageobject.cbh;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.models.Transaction;
import com.hsbc.digital.testauto.pageobject.MoveMoneyCapturePageModel;

public class MoveMoneyCapturePage extends MoveMoneyCapturePageModel {

    protected static final int DEFAULT_ACCOUNT_NUMBER_LENGTH = 10;
    protected static final String ENTITY_BANK_COUNTRY = "Sri Lanka";
    private static final Map<String, String> companyReferenceValue = new HashMap<>();

    @FindBy(xpath = "//div[contains(@id, 'TitlePane')]//span[contains(@id, 'label') and (contains(text(), 'Next to personal details') or contains(text(), 'Add personal details')) or contains(text(),'Payee bank details')]")
    protected List<WebElement> nextToPersonalDetailsButtons;

    @FindBy(xpath = "//div[contains(@id, 'TitlePane')]//span[contains(text(), 'Payee personal details')]")
    protected List<WebElement> payeePersonalDetails;

    @FindBy(xpath = "//li[contains(@data-dojo-attach-point,'_acctNumField')]//input[contains(@id,'_acctNum') and contains(@data-dojo-attach-point, 'textbox,focusNode')]")
    protected WebElement accountNumberText;

    @FindBy(xpath = "//div[contains(@id, 'fromAccount')]//table[contains(@id, 'SelectDropDown')]//span[contains(@class, 'optionItem')]//span[contains(@class, 'title')]")
    private WebElement fromAccountName;

    @FindBy(xpath = "//div[contains(@id, 'fromAccount')]//table[contains(@id, 'SelectDropDown')]//span[contains(@class, 'row')]//span[contains(@class, 'accountDetails')]")
    private WebElement fromAccountNumber;

    @FindBy(xpath = "//div[contains(@id, 'fromAccount')]//table[contains(@id, 'SelectDropDown')]//span[contains(@class, 'row')]//span[contains(@class, 'balance')]")
    private WebElement fromAccountBalance;

    @FindBy(xpath = "//span[text()='Later']")
    private WebElement laterTab;

    @FindBy(xpath = "//div[@data-dojo-attach-point='_pyeChargesNode']//input[contains(@class,'dijitArrowButtonInner')]")
    private WebElement feesPaidByIcon;

    @FindBy(xpath = "//div[@data-dojo-attach-point='_purposeOfTransactionAttr']//input[contains(@class,'dijitArrowButtonInner')]")
    private WebElement reasonForTransactionIcon;
    
    /**
     * Method to get the ENTITY COUNTRY NAME as displayed in Account Selection
     * DropDown
     * 
     */
    @Override
    protected String getEntityBankCountry() {
        return ENTITY_BANK_COUNTRY;
    }


    public MoveMoneyCapturePage(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    static {
        companyReferenceValue.put("SRI LANKA TELECOM ( ALL SERVICES )", "12");
        companyReferenceValue.put("MOBITEL (PVT) LTD", "10");
    }

    @Override
    public AccountDetails enterNewCompanyPayeeDetails() {
        AccountDetails accountDetails = new AccountDetails();
        clickTabsToOpenNewCompanyPayeeDetails();
        Object[] values = companyReferenceValue.keySet().toArray();
        Object key = values[new Random().nextInt(values.length)];
        selectValue(companyListDropIcon, listMenuItems, key.toString());
        accountDetails.setAccountName(key.toString());
        String companyReference = RandomUtil.generateIntNumber(Integer.parseInt(companyReferenceValue.get(key)));
        companyReferenceText.clear();
        companyReferenceText.sendKeys(companyReference);
        companyReferenceText.sendKeys(Keys.RETURN);
        accountDetails.setAccountNumber(companyReference);
        return accountDetails;
    }

    @Override
    protected AccountDetails enterNewPayeeDetails(String payeeName, String payeeAccountNumber) {
        AccountDetails accountDetails = new AccountDetails();
        accountNumberText.clear();
        accountNumberText.sendKeys(payeeAccountNumber);
        accountDetails.setAccountNumber(payeeAccountNumber);
        accountNumberText.sendKeys(Keys.RETURN);
        return accountDetails;
    }

    @Override
    public void verifyInlineDetailsAfterNegatingCancelOnCapturePage(Transaction transactionDetail) {
        wait.until(ExpectedConditions.invisibilityOfElementLocated(cancelDialog));
        verifyDetailsAfterNegatingCancel(transactionDetail);
        isInlinePayeeNumberDisplayed(transactionDetail.getToAccount());
        Reporter.log("Details verified after negating cancel.");
    }

    @Override
    protected void isInlinePayeeNumberDisplayed(AccountDetails accountDetail) {
        Assert.assertTrue(accountNumberText.getAttribute(ELEMENT_VALUE_ATTRIBUTE)
            .equalsIgnoreCase(accountDetail.getAccountNumber()), "Payee Account Number does not match expected value.");
        Reporter.log("Payee Number matches : " + accountDetail.getAccountName());
    }

    @Override
    public String enterPayeeReferenceText() {
        return StringUtils.EMPTY;

    }

    @Override
    public AccountDetails enterNewNonHSBCDomesticPayeeDetails() {
        AccountDetails accountDetails;
        String payeeName = RandomUtil.generateAlphabatic(DEFAULT_REFERENCE_TEXT_LENGTH);
        accountDetails = super.enterNewNonHSBCDomesticPayeeDetails();
        nextToPersonalDetailsButtons.get(DEFAULT_LIST_STARTING_INDEX).click();
        payeePersonalDetails.get(DEFAULT_LIST_STARTING_INDEX).click();
        newPayeeNameText.clear();
        newPayeeNameText.sendKeys(payeeName);
        newPayeeNameText.sendKeys(Keys.RETURN);
        accountDetails.setAccountName(payeeName);
        return accountDetails;
    }

    @Override
    public String enterAddress() {
        return StringUtils.EMPTY;
    }

    @Override
    public AccountDetails setDefaultFromAccountDetails() {
        AccountDetails accountDetail = new AccountDetails();
        accountDetail.setAccountName(fromAccountName.getText());
        accountDetail.setAccountNumber(fromAccountNumber.getText());
        Double balance = Double.parseDouble(fromAccountBalance.getText().replace(",", ""));
        accountDetail.setDoubleAccountBalance(balance);
        return accountDetail;
    }

    @Override
    public String selectFeesPaidBy() {
        wait.until(ExpectedConditions.visibilityOf(feesPaidByIcon));
        return otherRandamValue(feesPaidByIcon, listDropdown, "Select");
    }

    @Override
    public String selectReasonForTransaction(Transaction transaction) {
        wait.until(ExpectedConditions.visibilityOf(reasonForTransactionIcon));
        return otherRandamValue(reasonForTransactionIcon, listDropdown, "Select");
    }
}
