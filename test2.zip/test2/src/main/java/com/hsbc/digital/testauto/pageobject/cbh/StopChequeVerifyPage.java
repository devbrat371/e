package com.hsbc.digital.testauto.pageobject.cbh;

import java.text.ParseException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.hsbc.digital.testauto.models.StopChequeDetails;
import com.hsbc.digital.testauto.pageobject.StopChequeVerifyPageModel;
import com.hsbc.digital.testauto.ui.library.UICommonUtil;

/**
 * <p>
 * <b> Stop Cheque Verify page object model to hold generic function and
 * locators for cbh entity of story stop cheque</b>
 * </p>
 * 
 * @version 1.0.0
 * @author Neeraj Kumar
 */
public class StopChequeVerifyPage extends StopChequeVerifyPageModel {

    protected static final String LABEL_CHEQUE_RANGE = "Cheque number range";

    @Override
    protected String getLabelChequeRange() {
        return LABEL_CHEQUE_RANGE;
    }


    public StopChequeVerifyPage(final WebDriver driver) {
        super(driver);
        uiCommonUtil = new UICommonUtil(driver);
    }

    @Override
    public void validateReviewPageWithChequeNumber(final StopChequeDetails stopChequeDetails) throws ParseException {
        wait.until(ExpectedConditions.visibilityOf(verifyPageTitle));
        isPageTitleDisplayed(verifyPageTitle);
        isIssueChequeAccountNameDisplayed(stopChequeDetails);
        isIssueChequeAccountNumberDisplayed(stopChequeDetails);
        isChequeNumberDisplayed(stopChequeDetails);
        isAmountDisplayed(stopChequeDetails);
        isReasonToStopChequeDisplayed(stopChequeDetails);
    }

    @Override
    public void validateReviewPageWithChequeRange(final StopChequeDetails stopChequeDetails) throws ParseException {
        wait.until(ExpectedConditions.visibilityOf(verifyPageTitle));
        isPageTitleDisplayed(verifyPageTitle);
        isIssueChequeAccountNameDisplayed(stopChequeDetails);
        isIssueChequeAccountNumberDisplayed(stopChequeDetails);
        isChequeRangeDisplayed(stopChequeDetails);
        isReasonToStopChequeDisplayed(stopChequeDetails);
    }

}
