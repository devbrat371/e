/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.DateUtil;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.models.OpenAccountDetails;
import com.hsbc.digital.testauto.pageobject.ca.OpenAccountVerify;

/***
 * <p>
 * <b> This model class will hold locators and functionality for Open Account
 * Confirmation page. </b>
 * </p>
 * 
 * @author SatyaPrakash S Vyas
 * @version 1.0.0
 */
public abstract class OpenAccountConfirmationModel {

    protected final JavascriptExecutor jsx;

    /**
     * Error Message List
     */
    @FindBy(xpath = "//div[@class='alertPanel error']")
    protected List<WebElement> widgetErrors;

    @FindBy(xpath = "//*[@class='alertPanel confirmation']/p")
    protected WebElement confirmationAlert;

    @FindBy(xpath = "//*[contains(@data-dojo-attach-point,'referenceNoAtt')]")
    private WebElement referenceNumber;

    @FindBy(xpath = "//*[contains(@data-dojo-attach-point,'ProductName')]")
    private WebElement appliedProductName;

    @FindBy(xpath = "//*[@data-dojo-attach-point='tdaccnoAck']")
    private WebElement newAccountNumber;
    /**
     * Debit Account Name
     */
    @FindBy(xpath = "//*[@data-dojo-attach-point='_accountSelectedAtt']")
    private WebElement debitAccountName;

    /**
     * Debit Account Number
     */
    @FindBy(xpath = "//*[@data-dojo-attach-point='_accountSelectedAccNumberAtt']")
    protected WebElement debitAccountNumber;

    @FindBy(xpath = "//*[@data-dojo-attach-point='accountTermMonth']")
    private WebElement accountTerm;

    @FindBy(xpath = "//*[(@data-dojo-attach-point='newAccountCurrency') or (@data-dojo-attach-point='newaccountcurrency')]/following-sibling::strong")
    private WebElement accountCurrencyLabel;

    @FindBy(xpath = "//*[@data-dojo-attach-point='amountToDepositValue']")
    private WebElement amountToDeposit;

    @FindBy(xpath = "//*[@data-dojo-attach-point='MaturityDate']")
    private WebElement maturityDateLabel;

    @FindBy(xpath = "//*[contains(@data-dojo-attach-point,'effective')]")
    private WebElement effectiveDateLabel;

    @FindBy(xpath = "//*[contains(@data-dojo-attach-point,'nterestRate')]/..")
    protected WebElement interestRateLabel;

    @FindBy(xpath = "//*[@data-dojo-attach-point='InterestAmount']")
    protected WebElement interestAmountField;

    @FindBy(xpath = "//*[contains(@data-dojo-attach-point,'nterestPaid')]")
    private WebElement interestPaidLabel;

    /**
     * Credit Account Details
     */
    @FindBy(xpath = "//*[contains(@data-dojo-attach-point,'nterestCreditedTo')]")
    private WebElement creditAccountName;

    @FindBy(xpath = "//*[contains(@data-dojo-attach-point,'nterestAccountNumber')]")
    private WebElement creditAccountNumber;

    /**
     * Print button section
     */
    @FindBy(xpath = "//*[contains(@class,'btnTertiary') and contains(@data-dojo-attach-point,'printButton')]")
    private WebElement printButton;

    @FindBy(xpath = "//div[contains(@id,'hdx_dijits_PrintFriendlyFormatDialog_') and not (contains(@style,'display: none'))]")
    private WebElement printDialog;

    @FindBy(xpath = "//div[contains(@id,'hdx_dijits_PrintFriendlyFormatDialog_') and not (contains(@style,'display: none'))]//button[@data-dojo-attach-point='closeButton']")
    private WebElement printDialogCancelButton;

    @FindBy(xpath = "//div[contains(@class,'viewMyAc')]/input[contains(@value,'My accounts')]")
    private WebElement myAccountButton;

    @FindBy(xpath = "//*[@id='stackContainer']/div/div[1]/h2[text()='Confirmation']")
    private WebElement confirmPageTitle;

    @FindBy(xpath = "//dt[text()='New account number']/following-sibling::dd[@data-dojo-attach-point='tdaccnoAck']")
    private WebElement newTDAccountNumber;

    @FindBy(xpath = "//span[contains(@class,'itemName')]")
    private List<WebElement> accountsTypeAtDashboardPage;

    protected static final String MESSAGE_SUCCESS = "Application Successful";
    private static final String MESSAGE_APPROVED = "Application approved";
    private static final String MESSAGE_SUBMITTED = "Application submitted successfully";

    private static final String DATE_FORMAT_DDMMMYYYY = "dd MMM yyyy";
    protected static final String SCROLL_TO_VIEW = "arguments[0].scrollIntoView(true);";

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(OpenAccountConfirmationModel.class);

    public OpenAccountConfirmationModel(final WebDriver driver) {
        PageFactory.initElements(driver, this);
        jsx = (JavascriptExecutor) driver;
    }

    /**
     * verify success message on OpenAccounts confirmation page
     */
    protected void validateSuccessMessage() {
        if (!widgetErrors.isEmpty() && widgetErrors.get(0).isDisplayed()) {
            Assert.fail("Error message shown on confirmation page is: " + widgetErrors.get(0).getText());
        } else if (OpenAccountConfirmationModel.MESSAGE_APPROVED.equalsIgnoreCase(confirmationAlert.getText())
            || OpenAccountConfirmationModel.MESSAGE_SUCCESS.equalsIgnoreCase(confirmationAlert.getText())) {
            Reporter.log("Success Message shown on confirmation page. | ");
        } else if (OpenAccountConfirmationModel.MESSAGE_SUBMITTED.equalsIgnoreCase(confirmationAlert.getText())) {
            Reporter
                .log("Application submitted successfully message shown on confirmation page and application reference number displayed. | ");
        }
        Reporter.log("Application reference number is: " + referenceNumber.getText() + ".");
    }

    public void validateErrorMessageAppearance() {
        if (!widgetErrors.isEmpty() && widgetErrors.get(0).isDisplayed()) {
            Reporter.log("Error message shown on confirmation page is: " + widgetErrors.get(0).getText());
        } else {
            Assert.fail("No Error message shown after Max limit is crossed. | ");
        }
    }

    /**
     * This method checks Print functionality on verify page.
     */
    public void clickPrintButton() {
        printButton.click();
        printDialog.isDisplayed();
        printDialogCancelButton.click();
        Reporter.log("Print button is clicked on Confirmation page. | ");
    }

    /**
     * Click my account button on Open Accounts confirmation page
     */
    protected void clickMyAccountsButton() {
        getMyAccountButtonElement().click();
        Reporter.log("My Accounts button on confirmation page clicked. | ");
    }

    protected WebElement getMyAccountButtonElement() {
        return myAccountButton;
    }

    /**
     * Verifies details on confirmation page
     * 
     * @param openAccount
     * @param envProperties
     */

    public void verifyDetails(final OpenAccountDetails openAccount, final Map<String, String> envProperties) {
        if (!widgetErrors.isEmpty() && widgetErrors.get(0).isDisplayed()) {
            Reporter.log("Error message shown is: ");
            for (WebElement errorContainer : widgetErrors) {
                Reporter.log(errorContainer.getText());
            }
            Assert.fail();
        } else {
            String dateOfApplication = StringUtils.EMPTY;
            try {
                dateOfApplication = DateUtil.getDateToString(OpenAccountConfirmationModel.DATE_FORMAT_DDMMMYYYY,
                    DateUtil.getSystemDate());
            } catch (ParseException e) {
                Assert.fail("", e);
            }
            String productName = openAccount.getProductName();
            AccountDetails debitAccount = openAccount.getDebitAccount();
            String selectedInvestmentAccount = openAccount.getInvestmentAccount();
            String selectedTerm = openAccount.getTermDuration();
            String currency = openAccount.getCurrency();
            Double selectedAmount = openAccount.getAmount();
            String maturityInstruction = openAccount.getMaturityInstruction();
            String maturityDate = openAccount.getMaturityDate();
            String interestRate = openAccount.getInterestRate();
            String interestAmount = openAccount.getInterestAmount();
            String additionalOnlineRate = openAccount.getAdditionalOnlineRate();
            String interestPaidInterval = openAccount.getInterestPaidInterval();
            AccountDetails creditAccount = openAccount.getCreditAccount();
            String totalRate = openAccount.getTotalRate();
            Boolean isTermInMonths = openAccount.getIsTermInMonths();

            // TODO: validateDateOfApplication(dateOfApplication);
            validateProductName(productName);
            validateAccountCurrency(currency);
            validateDebitAccount(debitAccount);
            validateInvestmentAccount(selectedInvestmentAccount);
            validateSelectedTerm(selectedTerm, isTermInMonths);
            validateSelectedAmount(selectedAmount);
            validateMaturityInstruction(maturityInstruction);
            validateMaturityDate(maturityDate);
            validateEffectiveDate(envProperties);
            validateInterestRate(interestRate);
            validateInterestAmount(interestAmount);
            validateInterestPaid(interestPaidInterval);
            validateCreditAccount(creditAccount);
            validateAdditionalOnlineRate(additionalOnlineRate);
            validateTotalRate(totalRate);
        }
    }

    protected void validateDateOfApplication(final String dateOfApplication) {
        // Do nothing. Handled in entity POM
    }

    public void validateProductName(final String productName) {
        Assert.assertTrue(isValueCorrect(productName, getProductNameElement(), false), "Product Name is not correct, Expected:- "
            + productName + " & Actual is:- " + getProductNameElement().getText());
        Reporter.log("Product Name matched.");
    }

    public void validateDebitAccount(final AccountDetails debitAccount) {
        Assert.assertTrue(
            isAccountVerified(debitAccount, debitAccountName, debitAccountNumber),
            "Debit Account Details are Not Same ,Expected: " + debitAccount.getAccountName() + ","
                + debitAccount.getAccountNumber() + " & Actual is :-" + debitAccountName.getText() + ","
                + debitAccountNumber.getText());
        Reporter.log("Debit Account Details matched.");
    }

    protected void validateInvestmentAccount(final String selectedInvestmentAccount) {
        // Do nothing. Handled in entity POM
    }

    public void validateAccountCurrency(final String currency) {
        if (currency != null) {
            Assert.assertTrue(isValueCorrect(currency, getAccountCurrencyElement(), false),
                "Account currency is not same, Expected:- " + currency + " & Actual is:- " + getAccountCurrencyElement().getText());
            Reporter.log("Currency matched.");
        }
    }

    /**
     * Validates term duration
     * 
     * @param selectedTerm
     *            : String
     * @param isTermInMonths
     *            : boolean
     */
    public void validateSelectedTerm(final String selectedTerm, final Boolean isTermInMonths) {
        if (selectedTerm != null) {
            String term = selectedTerm;
            if (isTermInMonths && StringUtils.containsIgnoreCase(selectedTerm, "year")) {
                int noOfYears = Integer.parseInt(selectedTerm.split(" ")[0]);
                term = noOfYears * 12 + " Months";
            }
            Assert.assertTrue(isValueCorrect(term, accountTerm, false), "Account Term is not same, Expected:- " + term
                + " & Actual is:- " + accountTerm.getText());
            Reporter.log("Term deposit matched.");
        }
    }

    public void validateSelectedAmount(final Double selectedAmount) {
        if (selectedAmount != null) {
            Assert.assertTrue(isValueCorrect(selectedAmount, amountToDeposit), "Amount is not same, Expected:- " + selectedAmount
                + " & Actual is:- " + amountToDeposit.getText());
            Reporter.log("Amount matched.");
        }
    }

    protected void validateMaturityInstruction(final String maturityInstruction) {
        // Do nothing. Handled in entity POM
    }

    /**
     * Validates maturity date value
     * 
     * @param maturityDate
     *            : String
     */
    protected void validateMaturityDate(final String maturityDate) {
        if (maturityDate != null) {
            Assert.assertTrue(isValueCorrect(maturityDate, maturityDateLabel, false), "Maturity Date is not same, Expected:- "
                + maturityDate + " & Actual is:- " + maturityDateLabel.getText());
            Reporter.log("Maturity Date matched.");
        }
    }

    public void validateEffectiveDate(final Map<String, String> envProperties) {
        if (envProperties != null) {
            String effectiveDate = StringUtils.EMPTY;
            String hubDate = envProperties.get("hubDate");
            String hubFormat = envProperties.get("hubFormat");
            try {
                effectiveDate = DateUtil.getDateToString(OpenAccountConfirmationModel.DATE_FORMAT_DDMMMYYYY,
                    DateUtil.getStringToDate(hubFormat, hubDate));
            } catch (ParseException e) {
                OpenAccountVerify.logger.error("Error in Hub date.", e);
            }
            Assert.assertTrue(isValueCorrect(effectiveDate, effectiveDateLabel, false),
                "Effective Date does not match, Expected:- " + effectiveDate + " & Actual is:- " + effectiveDateLabel.getText());
            Reporter.log("Effective Date  matched.");
        }
    }

    public void validateInterestRate(final String interestRate) {
        if (interestRate != null) {
            Assert.assertTrue(isValueCorrect(interestRate, getInterestRateElement(), false),
                "Interest rate is not same, Expected:- " + interestRate + " & Actual is:- " + getInterestRateElement().getText());
            Reporter.log("Interest rate matched.");
        }
    }

    public void validateInterestAmount(final String interestAmount) {
        if (interestAmount != null) {
            Assert.assertTrue(isValueCorrect(interestAmount, interestAmountField, false),
                "Interest Amount is not same, Expected:- " + interestAmount + " & Actual is:- " + interestAmountField.getText());
        }
    }

    protected void validateInterestPaid(final String interestPaidInterval) {
        if (interestPaidInterval != null) {
            Assert.assertTrue(
                isValueCorrect(interestPaidInterval, interestPaidLabel, true),
                "Interest Paid interval is not same, Expected:- " + interestPaidInterval + " & Actual is:- "
                    + interestPaidLabel.getText());
            Reporter.log("Interest Paid interval matched.");
        }
    }

    protected void validateCreditAccount(final AccountDetails creditAccount) {
        if (creditAccount != null) {
            Assert.assertTrue(
                isAccountVerified(creditAccount, creditAccountName, creditAccountNumber),
                "Debit Account Details are Not Same, Expected: " + creditAccount.getAccountName() + ","
                    + creditAccount.getAccountNumber() + " & Actual is :-" + creditAccountName.getText() + ","
                    + creditAccountNumber.getText());
            Reporter.log("Credit Account details matched.");
        }
    }

    protected void validateAdditionalOnlineRate(final String additionalOnlineRate) {
        // Do nothing. Handled in entity POM
    }

    protected void validateTotalRate(final String totalRate) {
        // Do nothing. Handled in entity POM
    }

    protected WebElement getProductNameElement() {
        return appliedProductName;
    }

    protected WebElement getAccountCurrencyElement() {
        return accountCurrencyLabel;
    }

    protected WebElement getInterestRateElement() {
        return interestRateLabel;
    }

    /**
     * This is Generic Method to Verify Account Details
     * 
     * @param accountDetails
     *            : Account Details
     * @param accountName
     *            : Confirmation Account Name
     * @param accountNumber
     *            : Confirmation Account Number
     * @return <b> true/false <b>
     */
    private boolean isAccountVerified(final AccountDetails accountDetails, final WebElement accountName,
        final WebElement accountNumber) {
        jsx.executeScript(OpenAccountConfirmationModel.SCROLL_TO_VIEW, accountName);
        return accountDetails.getAccountName().equalsIgnoreCase(accountName.getText())
            && accountDetails.getAccountNumber().equalsIgnoreCase(accountNumber.getText());
    }

    /**
     * This is Generic Method to Verify String values
     * 
     * @param savedValue
     *            : Saved value in String
     * @param presentValue
     *            :Value present on page
     * @param checkByContains
     *            : true/false
     * @return <b> true/false <b>
     */
    protected boolean isValueCorrect(final String savedValue, final WebElement presentValue, final boolean checkByContains) {
        boolean flag;
        jsx.executeScript(OpenAccountConfirmationModel.SCROLL_TO_VIEW, presentValue);
        if (checkByContains) {
            flag = StringUtils.contains(presentValue.getText(), savedValue);
        } else {
            flag = savedValue.equalsIgnoreCase(presentValue.getText());
        }
        return flag;
    }

    /**
     * This is Generic Method to Verify Double values
     * 
     * @param savedValue
     *            : Saved value in Double
     * @param presentValue
     *            :Value present on page as WebElement
     * @return <b> true/false <b>
     */
    protected boolean isValueCorrect(final Double savedValue, final WebElement presentValue) {
        jsx.executeScript(OpenAccountConfirmationModel.SCROLL_TO_VIEW, presentValue);
        return savedValue == Double.parseDouble(presentValue.getText());
    }

    /**
     * 
     */
    protected String getNewAccountNumber() {
        Reporter.log("New account number is: " + newAccountNumber.getText() + ".");
        return newAccountNumber.getText();
    }

    public void applyOpenAccountConfirmationPage(final OpenAccountDetails openAccount, final Map<String, String> envProperties) {
        validateSuccessMessage();
        verifyDetails(openAccount, envProperties);
        logDisplayedElements();
        openAccount.setNewAccountNumber(getNewAccountNumber());
        clickPrintButton();
        clickMyAccountsButton();
    }

    protected void logDisplayedElements() {
        // Do nothing. Handled in entity POM
    }

    public void openUSTermDepositConfirmationPage(final OpenAccountDetails openAccount) {
        validateSuccessMessage();
        validateMaturityDate(openAccount.getMaturityDate());
        openAccount.setNewAccountNumber(getNewAccountNumber());
        clickPrintButton();
        clickMyAccountsButton();
    }

    /**
     * <p>
     * <b> TODO : Insert description of the method's responsibility/role. </b>
     * </p>
     * 
     * @return
     */
    public OpenAccountDetails verifyConfirmationPage() {
        // TODO Auto-generated method stub
        return null;
    }

    /**
     * <p>
     * <b> TODO : Insert description of the method's responsibility/role. </b>
     * </p>
     * 
     */
    public void verifyPrintButtonFunctionality() {
        // TODO Auto-generated method stub

    }

    public OpenAccountDetails verifyConfirmationPageForTermDeposit() {
        return null;
    }
}
