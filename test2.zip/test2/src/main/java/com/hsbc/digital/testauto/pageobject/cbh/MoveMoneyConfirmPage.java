package com.hsbc.digital.testauto.pageobject.cbh;

import java.text.ParseException;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.DateUtil;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.models.Transaction;
import com.hsbc.digital.testauto.pageobject.MoveMoneyCapturePageModel;
import com.hsbc.digital.testauto.pageobject.MoveMoneyConfirmPageModel;
import com.hsbc.digital.testauto.ui.library.UICommonUtil;

public class MoveMoneyConfirmPage extends MoveMoneyConfirmPageModel {
    protected static final String LABEL_FROM = "Account";
    protected static final String LABEL_TO = "Account";
    protected static final String LABELM2C_TO = "To";
    private final String DATE_FORMAT = "EEEEE, dd MMMMM yyyy";
    private static final String LABELM2C_START_DATE = "Start Date";
    private static String LABEL_PAYEEACCOUNTNUMBER = StringUtils.EMPTY;
    private static String LABEL_PAYEENAME = StringUtils.EMPTY;
    protected static final String LABEL_PAYMENT_DATE = "Transaction date";

    public MoveMoneyConfirmPage(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    @Override
    protected void setAllLabel(Transaction transaction) {
        System.out.println(transaction.getTransactionFlow().getValue());
        switch (transaction.getTransactionFlow().getValue()) {
        case "M2NMHSBCTransfer":
            labels.put(LABEL_FROM, "Account");
            labels.put(LABEL_TO, "To");
            labels.put(LABEL_AMOUNT, "Amount");
            labels.put(LABEL_DEBIT_AMOUNT, "Debit amount");
            labels.put(LABEL_PAYMENT_DATE, "Payment date");
            labels.put(LABEL_YOUR_REFERENCE, "Your reference");
            labels.put(LABEL_START_DATE, "Date of first transaction");
            labels.put(LABEL_TRANSACTION_END_DATE, "Transaction end date");
            labels.put(LABEL_FREQUENCY, "Frequency");
            labels.put(LABEL_NUMBER_OF_PAYMENT, "Total number of transactions");
            labels.put(LABEL_REASON_FOR_TRANSACTION, "Reason for transaction");
            labels.put(PAYMENT_RECURRING_VALUE, "Recurring ");
            labels.put(LABEL_PAYEE_ADDRESS, "Payee address");
            break;
        case "M2MTransfer":
            labels.put(LABEL_FROM, "Account");
            labels.put(LABEL_TO, "Account");
            labels.put(LABEL_AMOUNT, "Amount");
            labels.put(LABEL_DEBIT_AMOUNT, "Debit amount");
            labels.put(LABEL_PAYMENT_DATE, "Payment date");
            labels.put(LABEL_YOUR_REFERENCE, "Your reference");
            labels.put(LABEL_START_DATE, "Date of first transaction");
            labels.put(LABEL_TRANSACTION_END_DATE, "Transaction end date");
            labels.put(LABEL_FREQUENCY, "Frequency");
            labels.put(LABEL_NUMBER_OF_PAYMENT, "Total number of transactions");
            labels.put(LABEL_REASON_FOR_TRANSACTION, "Reason for transaction");
            labels.put(PAYMENT_RECURRING_VALUE, "Recurring ");
            labels.put(LABEL_PAYEE_ADDRESS, "Payee address");
            break;
        case "M2NMNonHSBCTransfer":
            labels.put(LABEL_FROM, "Account");
            labels.put(LABEL_TO, "To");
            labels.put(LABEL_PAYEENAME, "Payee Name");
            labels.put(LABEL_PAYEEACCOUNTNUMBER, "Payee Account Number");
            labels.put(LABEL_AMOUNT, "Amount");
            labels.put(LABEL_DEBIT_AMOUNT, "Debit amount");
            labels.put(LABEL_PAYMENT_DATE, "Payment date");
            labels.put(LABEL_YOUR_REFERENCE, "Your reference");
            labels.put(LABEL_START_DATE, "Date of first transaction");
            labels.put(LABEL_TRANSACTION_END_DATE, "Transaction end date");
            labels.put(LABEL_FREQUENCY, "Frequency");
            labels.put(LABEL_NUMBER_OF_PAYMENT, "Total number of transactions");
            labels.put(LABEL_REASON_FOR_TRANSACTION, "Reason for transaction");
            labels.put(PAYMENT_RECURRING_VALUE, "Recurring ");
            labels.put(LABEL_PAYEE_ADDRESS, "Payee address");
            break;
        default:
            break;
        }

    }

    @Override
    protected void isFromAccountNameDisplayed(final AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_FROM, accountDetail.getAccountName(), UICommonUtil.confirmPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given From Account Name not found.");
        Reporter.log("From Account Name displayed is :" + accountDetail.getAccountName());
    }

    @Override
    protected void isFromAccountNumberDisplayed(final AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_FROM, accountDetail.getAccountNumber(),
            UICommonUtil.confirmPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
            "Given From Account Number not found.");
        Reporter.log("From Account Number displayed is :" + accountDetail.getAccountNumber());
    }

    @Override
    protected void isPayeeReferenceTextDisplayed(String payeeReference) {
        Reporter.log("Payee Reference is not Applicable for Srilanka");
    }

    @Override
    public void verifyNonHSBCFCY2LCYNowTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isDebitAmountDisplayed(transactionDetail.getAmount());
        isPayeeReferenceTextDisplayed(transactionDetail.getPayeeReference());
        Reporter.log("NonHSBCFCY2LCYNow Transaction Details verified on Confirm Page.");
    }

    protected void isPayeeAccountNameDisplayed(final AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(getLabel(LABEL_PAYEENAME), accountDetail.getAccountName(),
            UICommonUtil.verifyPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given To Account Name not found.");
        Reporter.log("To Account Name displayed is :" + accountDetail.getAccountName());
    }

    protected void isPayeeAccountNumberDisplayed(final AccountDetails accountDetail) {
        Assert
            .assertTrue(uiCommonUtil.textByParentAndSibling(getLabel(LABEL_PAYEEACCOUNTNUMBER), accountDetail.getAccountNumber(),
                UICommonUtil.verifyPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
                "Given To Account Number not found.");
        Reporter.log("To Account Number displayed is :" + accountDetail.getAccountNumber());
    }

    @Override
    protected void isToAccountNameDisplayed(final AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_TO, accountDetail.getAccountName(), UICommonUtil.confirmPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given To Account Name not found.");
        Reporter.log("To Account Name displayed is :" + accountDetail.getAccountName());
    }

    protected void isM2CToAccountNameDisplayed(final AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABELM2C_TO, accountDetail.getAccountName(),
            UICommonUtil.confirmPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given To Account Name not found.");
        Reporter.log("To Account Name displayed is :" + accountDetail.getAccountName());
    }

    @Override
    protected void isToAccountNumberDisplayed(final AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_TO, accountDetail.getAccountNumber(), UICommonUtil.confirmPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given To Account Number not found.");
        Reporter.log("To Account Number displayed is :" + accountDetail.getAccountNumber());
    }

    protected void isM2CToAccountNumberDisplayed(final AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABELM2C_TO, accountDetail.getAccountNumber(),
            UICommonUtil.confirmPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
            "Given To Account Number not found.");
        Reporter.log("To Account Number displayed is :" + accountDetail.getAccountNumber());
    }

    @Override
    protected void isPaymentDateAsLaterDateDisplayed(final Transaction transaction) {
        String paymentDate;
        try {
            paymentDate = DateUtil.getDateToString(DATE_FORMAT, transaction.getLaterDate());
            Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_PAYMENT_DATE, paymentDate, UICommonUtil.confirmPage,
                UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Payment Date not found.");
            Reporter.log("Payment Date displayed is :" + paymentDate);
        } catch (ParseException e) {
            MoveMoneyConfirmPageModel.logger.error(e);
            Assert.fail("Parsing to Payment Date Fail " + e.getMessage(), e);
        }
    }

    @Override
    public void verifyM2CLCY2LCYLaterTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateLaterFlow(transactionDetail);
        isAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYLater Transaction Details verified on Verify Page.");
    }

    @Override
    public void verifyM2CFCY2LCYLaterTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        this.verifyLCY2LCYLaterTransactionDetailsOnConfirmPage(transactionDetail);
    }

    @Override
    public void verifyLCY2LCYNowTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYNow Transaction Details verified on Confirm Page.");
    }

    @Override
    public void verifyLCY2LCYLaterTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateLaterFlow(transactionDetail);
        isAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYLater Transaction Details verified on Confirm Page.");
    }

    @Override
    public void verifyLCY2LCYRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("LCY2LCYRecurring Transaction Details verified on Confirm Page.");
    }

    @Override
    public void verifyInlineNonHSBCLCY2LCYNowTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        wait.until(ExpectedConditions.visibilityOf(confirmPageTitle));
        setAllLabel(transactionDetail);
        isFromAccountNameDisplayed(transactionDetail.getFromAccount());
        isFromAccountNumberDisplayed(transactionDetail.getFromAccount());
        if (StringUtils.isNotEmpty(transactionDetail.getToAccount().getAccountName())) {
            isPayeeAccountNameDisplayed(transactionDetail.getToAccount());
        }
        isPayeeAccountNumberDisplayed(transactionDetail.getToAccount());
        isPaymentDateDisplayed(DEFAULT_PAYMENT_DATE_VALUE);
        isYourReferenceTextDisplayed(transactionDetail.getYourReference());
        isAmountDisplayed(transactionDetail.getAmount());
        isPayeeReferenceTextDisplayed(transactionDetail.getPayeeReference());
        Reporter.log("InlineLCY2LCYNowNonHSBC Transaction Details verified on Verify Page.");
    }

    @Override
    public void verifyM2MLCY2FCYRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        wait.until(ExpectedConditions.visibilityOf(confirmPageTitle));
        isFromAccountNameDisplayed(transactionDetail.getFromAccount());
        isFromAccountNumberDisplayed(transactionDetail.getFromAccount());
        isToAccountNameDisplayed(transactionDetail.getToAccount());
        isToAccountNumberDisplayed(transactionDetail.getToAccount());
        isYourReferenceTextDisplayed(transactionDetail.getYourReference());
        isM2CStartDateDisplayed(transactionDetail);
        isAmountDisplayed(transactionDetail.getAmount());
    }

    protected void isM2CStartDateDisplayed(final Transaction transaction) {
        try {
            String startDate = DateUtil.getDateToString(DATE_FORMAT, transaction.getFirstDateOfTransaction());
            Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABELM2C_START_DATE, startDate, UICommonUtil.verifyPage,
                UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Start Date not found.");
            Reporter.log("Start Date displayed is :" + startDate);
        } catch (ParseException e) {
            MoveMoneyCapturePageModel.logger.error(e);
            Assert.fail("Parsing to Payment Date Fail " + e.getMessage(), e);
        }

    }

    @Override
    protected void isStartDateDisplayed(Transaction transaction) {
        try {
            String startDate = DateUtil.getDateToString(DATE_FORMAT, transaction.getFirstDateOfTransaction());
            Assert.assertTrue(uiCommonUtil.textByParentAndSibling(getLabel(LABEL_START_DATE), startDate, UICommonUtil.confirmPage,
                UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Start Date not found.");
            Reporter.log("Start Date displayed is :" + startDate);
        } catch (ParseException e) {
            MoveMoneyCapturePageModel.logger.error(e);
            Assert.fail("Parsing to Payment Date Fail " + e.getMessage(), e);
        }

    }


    @Override
    protected void isNumberOfPaymentDisplayed(String valueNOP) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(getLabel(LABEL_NUMBER_OF_PAYMENT), valueNOP, UICommonUtil.verifyPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Number Of Payment not found.");
        Reporter.log("Number Of Payment displayed is :" + valueNOP);
    }

    @Override
    public void verifyM2CLCY2LCYNowTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        wait.until(ExpectedConditions.visibilityOf(confirmPageTitle));
        isFromAccountNameDisplayed(transactionDetail.getFromAccount());
        isFromAccountNumberDisplayed(transactionDetail.getFromAccount());
        isM2CToAccountNameDisplayed(transactionDetail.getToAccount());
        isM2CToAccountNumberDisplayed(transactionDetail.getToAccount());
        isPaymentDateDisplayed(DEFAULT_PAYMENT_DATE_VALUE);
        isYourReferenceTextDisplayed(transactionDetail.getYourReference());
        isAmountDisplayed(transactionDetail.getAmount());

    }

    @Override
    protected void isPaymentDateDisplayed(String paymentDate) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_PAYMENT_DATE, "Now", UICommonUtil.confirmPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Payment Date not found.");
        Reporter.log("Payment Date displayed is :" + paymentDate);
    }

}
