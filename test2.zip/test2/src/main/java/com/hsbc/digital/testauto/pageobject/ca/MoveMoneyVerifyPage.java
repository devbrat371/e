package com.hsbc.digital.testauto.pageobject.ca;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.pageobject.MoveMoneyVerifyPageModel;
import com.hsbc.digital.testauto.ui.library.UICommonUtil;

public class MoveMoneyVerifyPage extends MoveMoneyVerifyPageModel {


    // Query Raised to Confirm Label Values for other MM Functions

    protected static final String LABEL_FROM = "From";
    protected static final String LABEL_TO = "To";

    public MoveMoneyVerifyPage(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//div[contains(@class, 'submitButtonsPanel')]//input[contains(@value,'Confirm')]")
    private WebElement confirmButton;

    @FindBy(xpath = ".//div[contains(@class,'itemButton')]//button[contains(@ data-dojo-attach-point,'_edit')]")
    private WebElement editDetailsButton;

    @FindBy(xpath = ".//span[contains(@class,'InteracLogo')]")
    private WebElement verfiylogocapturepage;

    @FindBy(xpath = "//div[contains(text(),'Payment fee is charged to the account you are transferring funds from, whether the INTERAC e-Transfer is cancelled, declined, expires or the recipient fails to answer security question correctly')]")
    private WebElement verfiyfeeBodyippage;

    @FindBy(xpath = "//div[contains(text(),'Payment fee is charged to the account you are transferring funds from, whether the INTERAC e-Transfer is cancelled, declined, expires or the recipient fails to answer security question correctly')]")
    private List<WebElement> verfiyfeeBody1ippage;

    @FindBy(xpath = ".//p[contains(@class,'M2MfieldSubtext') and contains(text(),'Transfers sent or received after 18:00 PT will reflect the next business date')]")
    private WebElement copytextippage;

    @FindBy(xpath = ".//p[contains(@class,'M2MfieldSubtext') and contains(text(),'Transfers sent or received after 18:00 PT will reflect the next business date')]")
    private List<WebElement> copytextippage1;

    @FindBy(xpath = "//div[contains(@id,'TxnHandler')]//span[contains(@class,'InteracTrademarkwp') or contains(text(),'Trademark of Interac Inc. Used under license.')]")
    private WebElement TradeMark;

    @FindBy(xpath = "//div[contains(@id,'VerifyInteracPayeeTransfer')]//span[contains(@class,'InteracTrademarkwp') or contains(text(),'Trademark of Interac Inc. Used under license.')]")
    private WebElement verifyTradeMark;


    @FindBy(xpath = ".//span[contains(@class,'InteracLogo')]")
    private WebElement verfiylogoconfirmation;

    @FindBy(xpath = ".//div[contains(@class,'verificationPage ')]//div[contains(text(),'Payment fee is charged to the account you are transferring funds from, whether the INTERAC e-Transfer is cancelled, declined, expires or the recipient fails to answer security question correctly')]")
    private WebElement verfiyfeeBodyverifypage;

    @FindBy(xpath = ".//div[contains(@class,'verificationPage ')]//div[contains(text(),'Payment fee is charged to the account you are transferring funds from, whether the INTERAC e-Transfer is cancelled, declined, expires or the recipient fails to answer security question correctly')]")
    private List<WebElement> verfiyfeeBody1verifypage;


    @FindBy(xpath = ".//div[contains(@class,'rightLblAlign')]//span[contains(text(),'Transfers sent or received after 18:00 PT will reflect the next business date')]")
    private WebElement copytextvppage;

    @FindBy(xpath = ".//div[contains(@class,'rightLblAlign')]//span[contains(text(),'Transfers sent or received after 18:00 PT will reflect the next business date')]")
    private List<WebElement> copytextvppage1;

    @FindBy(xpath = ".//div[contains(@class,'confirmTransferValue ')]//span[contains(text(),'Transfers sent or received after 18:00 PT will reflect the next business date')]")
    private WebElement copytextconfirpage;

    @FindBy(xpath = ".//div[contains(@class,'confirmTransferValue ')]//span[contains(text(),'Transfers sent or received after 18:00 PT will reflect the next business date')]")
    private List<WebElement> copytextconfirpage1;

    @FindBy(xpath = ".//span[contains(@class,'InteracLogo verifyInteracLogo')]")
    private WebElement verfiylogo;


    @FindBy(xpath = ".//div[contains(@class,'msgAvailableBalanceConfirm') and contains(text(),'CAD 1.25 is charged to the account you are transferring funds from, whether the INTERAC e-Transfer is cancelled, declined, expires, or the recipient fails to answer the security question correctly')]")
    private WebElement verfiyfeeBodyConfimpage;

    @FindBy(xpath = ".//div[contains(@class,'msgAvailableBalanceConfirm') and contains(text(),'CAD 1.25 is charged to the account you are transferring funds from, whether the INTERAC e-Transfer is cancelled, declined, expires, or the recipient fails to answer the security question correctly')]")
    private List<WebElement> verfiyfeeBody1Confimpage;


    @FindBy(xpath = ".//input[contains(@class,'btnTertiary') and contains(@value,'My accounts')]")
    private WebElement myAccountButton;


    @FindBy(xpath = ".//span[contains(text(),'My accounts') and contains(@class,'title')]")
    protected WebElement verifyMyAccountTitle;

    @Override
    protected void isFromAccountNameDisplayed(final AccountDetails accountDetail) {
        Assert
            .assertTrue(uiCommonUtil.textByParentAndSibling(MoveMoneyVerifyPage.LABEL_FROM, accountDetail.getAccountName(),
                UICommonUtil.verifyPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
                "Given From Account Name not found.");
        Reporter.log("From Account Name displayed is :" + accountDetail.getAccountName());
    }

    @Override
    protected void isFromAccountNumberDisplayed(final AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(MoveMoneyVerifyPage.LABEL_FROM, accountDetail.getAccountNumber(),
            UICommonUtil.verifyPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
            "Given From Account Number not found.");
        Reporter.log("From Account Number displayed is :" + accountDetail.getAccountNumber());
    }

    @Override
    protected void isToAccountNameDisplayed(final AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(MoveMoneyVerifyPage.LABEL_TO, accountDetail.getAccountName(),
            UICommonUtil.verifyPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given To Account Name not found.");
        Reporter.log("To Account Name displayed is :" + accountDetail.getAccountName());
    }

    @Override
    protected void isToAccountNumberDisplayed(final AccountDetails accountDetail) {
        Assert
            .assertTrue(uiCommonUtil.textByParentAndSibling(MoveMoneyVerifyPage.LABEL_TO, accountDetail.getAccountNumber(),
                UICommonUtil.verifyPage, UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue),
                "Given To Account Number not found.");
        Reporter.log("To Account Number displayed is :" + accountDetail.getAccountNumber());
    }

    @Override
    public void clickConfirmButton() {
        wait.until(ExpectedConditions.elementToBeClickable(confirmButton));
        confirmButton.click();
        Reporter.log("Confirm button is clicked.");
    }

    @Override
    public void clickEditDetailsButton() {
        wait.until(ExpectedConditions.elementToBeClickable(editDetailsButton));
        editDetailsButton.click();
        Reporter.log("Edit Details button is clicked.");
    }

    @Override
    public void verfiyInteractLogoCapturepage() {
        wait.until(ExpectedConditions.elementToBeClickable(verfiylogocapturepage));
        verfiylogocapturepage.isDisplayed();
        Reporter.log("Verify on the Capture /input page , interact e transfer logo is present below payee ");
    }


    @Override
    public void verfiyFeeBodyInputpage() {
        wait.until(ExpectedConditions.elementToBeClickable(verfiyfeeBodyippage));
        if (verfiyfeeBodyippage.isDisplayed() && verfiyfeeBody1ippage.size() > 0) {
            Reporter.log("Verify on the Capture /input page ,Verify the Fee field and body copy displayed below Fee field");
        } else {
            Reporter.log("Verify on the Capture /input page ,Verify the Fee field and body copy Not displayed below Fee field");

        }
    }

    @Override
    public void copytextInputpage() {
        wait.until(ExpectedConditions.elementToBeClickable(copytextippage));
        if (copytextippage.isDisplayed() && copytextippage1.size() > 0) {
            Reporter
                .log("Verify on the Capture /input page ,Transfers sent or received after 18:00 PT will reflect the next business date");
        } else {
            Reporter
                .log("Not Verify on the Capture /input page ,Transfers sent or received after 18:00 PT will reflect the next business date");

        }
    }

    @Override
    public void verfiyCapctureBrandingTradeMark() {

        wait.until(ExpectedConditions.elementToBeClickable(TradeMark));
        if (TradeMark.isDisplayed()) {
            Reporter.log("Verify on the Capture /input page , @Trademark of Interac Inc. Used under license. ");
        } else {
            Reporter.log("Verify on the Capture /input page ,not displayed @Trademark of Interac Inc. Used under license. ");
        }
    }

    @Override
    public void verfiypageBrandingTradeMark() {

        wait.until(ExpectedConditions.elementToBeClickable(verifyTradeMark));
        if (verifyTradeMark.isDisplayed()) {
            Reporter.log("Verify on the Verify page , @Trademark of Interac Inc. Used under license. ");
        } else {
            Reporter.log("Verify on the Verify page ,not displayed @Trademark of Interac Inc. Used under license. ");
        }
    }


    @Override
    public void verfiyInteractLogoConfirmation() {
        if (verfiylogoconfirmation.isDisplayed()) {
            Reporter.log("interact e transfer logo is present on the Confirmation page");
        } else {
            Reporter.log("interact e transfer logo is Notpresent on the Confirmation page");
        }
    }

    @Override
    public void verfiyFeeBodyVerifypage() {
        wait.until(ExpectedConditions.elementToBeClickable(verfiyfeeBodyverifypage));
        if (verfiyfeeBodyverifypage.isDisplayed() && verfiyfeeBody1verifypage.size() > 0) {
            Reporter.log("Verify on the Verify page ,Verify the Fee field and body copy displayed below Fee field");
        } else {
            Reporter.log("Verify on the Verify page ,Verify the Fee field and body copy Not displayed below Fee field");

        }
    }

    @Override
    public void copytextVerifypage() {
        wait.until(ExpectedConditions.elementToBeClickable(copytextvppage));
        if (copytextvppage.isDisplayed() && copytextvppage1.size() > 0) {
            Reporter
                .log("Verify on the Verify  page ,Transfers sent or received after 18:00 PT will reflect the next business date");
        } else {
            Reporter
                .log("Not Verify on the Verify page ,Transfers sent or received after 18:00 PT will reflect the next business date");

        }
    }

    @Override
    public void copytextConfimationypage() {
        wait.until(ExpectedConditions.elementToBeClickable(copytextconfirpage));
        if (copytextconfirpage.isDisplayed() && copytextconfirpage1.size() > 0) {
            Reporter
                .log("Verify on the Confirmation  page ,Transfers sent or received after 18:00 PT will reflect the next business date");
        } else {
            Reporter
                .log("Not Verify on the Confirmation page ,Transfers sent or received after 18:00 PT will reflect the next business date");

        }
    }

    @Override
    public void verfiyInteractLogoVerfiypage() {
        wait.until(ExpectedConditions.elementToBeClickable(verfiylogo));
        verfiylogo.isDisplayed();
        Reporter.log("Verify on the Verfiy /input page , interact e transfer logo is present below payee ");
    }

    @Override
    public void verfiyFeeBodyConfirmationpage() {
        wait.until(ExpectedConditions.elementToBeClickable(verfiyfeeBodyConfimpage));
        if (verfiyfeeBodyConfimpage.isDisplayed() && verfiyfeeBody1Confimpage.size() > 0) {
            Reporter.log("Verify on the Confirmation page ,Verify the Fee field and body copy displayed below Fee field");
        } else {
            Reporter.log("Verify on the Confirmation page ,Verify the Fee field and body copy Not displayed below Fee field");

        }
    }

    @Override
    public void clickMyAccountButton() {
        wait.until(ExpectedConditions.elementToBeClickable(myAccountButton));
        myAccountButton.click();
        Reporter.log("My Account  button is clicked.");
    }

    @Override
    public void verifyMyAccountpage() {
        wait.until(ExpectedConditions.visibilityOf(verifyMyAccountTitle));
        if (verifyMyAccountTitle.isDisplayed()) {
            Reporter.log("Account Summay page is displayed after click on the My Account button.");
        } else {
            Reporter.log("Account Summay page is Not displayed after click on the My Account button.");
        }
    }

}
