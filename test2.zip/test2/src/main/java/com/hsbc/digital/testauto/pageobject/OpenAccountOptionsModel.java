/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.DateUtil;
import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.models.OpenAccountDetails;

/***
 * <p>
 * <b> This model class will hold locators and functionality for Open Account
 * Options page. </b>
 * </p>
 * 
 * @author SatyaPrakash S Vyas
 * @version 1.0.0
 */
public abstract class OpenAccountOptionsModel {

    private final WebDriverWait wait;
    protected final JavascriptExecutor jsx;

    @FindBy(xpath = "//form[@name='_openTermAcctForm']")
    private WebElement openTDOptionsForm;

    @FindBy(xpath = "//h2[(@data-dojo-attach-point='stepTitle') and (text()='Options')]")
    private WebElement optionPageTitle;

    @FindBy(xpath = "//div[contains(@class,'optionsProductName')]")
    private WebElement productNameField;

    /**
     * From DropDown Icon
     */
    @FindBy(xpath = "//table[contains(@id,'SelectDropDown')]//input[contains(@class,'dijitArrowButtonInner')]")
    private List<WebElement> accountDropDownIcon;
    /**
     * DropDown Item List
     */

    @FindBy(xpath = "//div[contains(@id, 'SelectDropDown_') and contains(@style,'visibility: visible')]//tr[contains(@id,'dijit_MenuItem')]")
    private List<WebElement> debitAccountDropDownItems;

    @FindBy(xpath = "//div[contains(@class,'dijitMenuActive')]")
    protected WebElement listDropdown;

    protected final By menuText = By.cssSelector("[id$='_text']");


    /*************************** Account Details *****************************/

    protected final By accountDetails1 = By.cssSelector("span[class*='optionItem']");

    protected final By accountDetails2 = By.cssSelector("span[role*='option']");

    protected final By accountName1 = By.xpath("//span[contains(@class,'title') and not(contains(@class,'noDisplay'))]");

    protected final By accountName2 = By.cssSelector("span[class*='row accountDetails']");

    protected final By accountNum = By.cssSelector("span[class*='accountDetails accountDetailsactSlOption']");

    private final By currency = By.cssSelector("span[class*='currencyTypeStyle2 currencyactSlOption']");

    protected final By locatorAccountBalance = By.cssSelector("span[class*='balance']");

    /*************************************************************************/

    @FindBy(xpath = "//table[contains(@id,'SelectDropDown')]//span[@class='location']/following-sibling::span/span[1]")
    protected List<WebElement> debitAccountNameList;

    @FindBy(xpath = "//table[contains(@id,'SelectDropDown')]//span[contains(@class,'accountDetailsactSlOption')]")
    protected List<WebElement> accountNumberList;

    @FindBy(xpath = "//table[contains(@id,'SelectDropDown')]//span[@class='balance']")
    protected List<WebElement> debitAccountBalanceList;

    @FindBy(xpath = "//input[starts-with(@id,'group_gpib_actopening_common_bijits_ProductConfig') and contains(@id,'ammountToBePlaced')]")
    private WebElement amountField;

    @FindBy(xpath = "//div[@data-dojo-attach-point='_termInputDiv']//input[contains(@id,'numberTextBox')]")
    private WebElement termField;

    @FindBy(xpath = "//div[@data-dojo-attach-point='_termInputDiv']//input[contains(@id,'NumberTextBox')]/following-sibling::input")
    private WebElement termValueField;

    @FindBy(xpath = "//div[contains(@class,'currencyRate')]//span[contains(@data-dojo-attach-point,'_minDeposit')]")
    private List<WebElement> minAmountLabel;

    @FindBy(xpath = "//table[contains(@id,'_interestPaid')]//input[contains(@id,'_interestPaid')]")
    private List<WebElement> interestPaidDropDownIcon;

    @FindBy(xpath = "//div[contains(@class,'interestPaidPopup')]//tr[contains(@id,'dijit_MenuItem_')]")
    private List<WebElement> interestPaidDropDownItems;

    @FindBy(xpath = "//table[contains(@id,'_interestPaid')]//span[contains(@class,'dijitSelectLabel')]")
    private WebElement interestPaidOptionSelected;

    @FindBy(xpath = "//span[contains(@id,'interestPaid')]")
    private WebElement interestPaidLabel;

    @FindBy(xpath = "//table[contains(@id,'SelectDropDown')]//input[contains(@class, 'dijitArrowButtonInner')]")
    private List<WebElement> creditingDropDownIcon;

    @FindBy(xpath = "//div[contains(@id, 'SelectDropDown_') and contains(@style,'visibility: visible') and contains(@class,'transferDropdown')]/table/tbody")
    private List<WebElement> creditAccountDropDownTable;

    @FindBy(xpath = "//table[contains(@id,'SelectDropDown')]//span[contains(@class,'title')]")
    private List<WebElement> creditAccountName;

    @FindBy(xpath = "//button[@data-dojo-attach-point='_calculateBtnNode']")
    private WebElement calculateButton;

    @FindBy(xpath = "//button[contains(@class,'btnSecondary') and text()='Continue']")
    private WebElement continueButton;

    @FindBy(xpath = "//button[contains(@class,'btnTertiary') and text()='Cancel']")
    private WebElement cancelButton;

    @FindBy(xpath = "hdx_dijits_Dialog_")
    private List<WebElement> cancelDialogList;

    @FindBy(xpath = "//div[contains(@id,'hdx_dijits_Dialog_') and not (contains(@style,'display: none'))]//button[(@data-dojo-attach-point='_captureCancelYes')]")
    private WebElement cancelDialogYes;

    @FindBy(xpath = "//div[contains(@id,'hdx_dijits_Dialog_') and not (contains(@style,'display: none'))]//button[(@data-dojo-attach-point='_captureCancelNo')]")
    private WebElement cancelDialogNo;

    @FindBy(xpath = "//div[contains(@class,'currency-text')]")
    private WebElement newAccountCurrency;

    @FindBy(xpath = "//div[contains(@class,'addNewCurrencyAccountN')]//div[contains(@class,'dijitDownArrowButton')]")
    private WebElement currencyDropDownIcon;

    @FindBy(xpath = "//div[contains(@class,'dijitMenu dijitComboBoxMenu')]/div[contains(@class,'dijitReset dijitMenuItem')]")
    private List<WebElement> currencyDropDownItems;

    @FindBy(xpath = "//span[contains(@class,'CurrencyBox currencyType')]")
    private WebElement currencyCode;

    @FindBy(xpath = "//*[contains(@id,'arrowid_hdx_dijits_form_Select')]")
    protected WebElement termOptionsDropDown;

    @FindBy(xpath = "//div[contains(@class,'accountTermPopup')]//tr[contains(@id,'dijit_MenuItem_')]")
    protected List<WebElement> termDropDownItems;

    @FindBy(xpath = "//li[@data-dojo-attach-point='accountTerm']//span[contains(@class,'dijitSelectLabel')]")
    protected WebElement termOptionSelected;

    @FindBy(xpath = "//li[@data-dojo-attach-point='accountTerm']/span")
    private WebElement termDurationLabel;

    @FindBy(xpath = "//div[@class='ourRatesLink']//span[contains(@id,'label')]")
    protected WebElement ourRatesButton;

    @FindBy(xpath = "//div[@class='radioBtn']//input[contains(@id,'radioOne') and @name='accountholder']")
    private WebElement radioYes;

    @FindBy(xpath = "//*[@data-dojo-attach-point='_radioErrorMsg']/p")
    private WebElement radioErrorBox;

    @FindBy(xpath = "//div[@class='radioBtn']//input[contains(@id,'radioTwo') and @name='accountholder']")
    private WebElement radioNo;

    @FindBy(xpath = "//table[contains(@id,'reasonForOpeningAccountFirstSelect')]//input[contains(@id,'reasonForOpeningAccountFirstSelect')]")
    private WebElement reasonDropDownIcon;

    @FindBy(xpath = "//div[contains(@class,'reasonForOpeningAccountFirstSelectPopup')]//tr[contains(@id,'dijit_MenuItem_')]")
    private List<WebElement> reasonDropDownItems;

    @FindBy(xpath = "//table[contains(@id,'reasonForOpeningAccountFirstSelect')]//span[contains(@class,'dijitSelectLabel')]")
    private WebElement reasonOptionSelected;

    /**
     * Section for Our Rates Dialogue
     */

    @FindBy(xpath = "//div[contains(@id,'hdx_dijits_Dialog_') and not (contains(@style,'display: none'))]//div[@class='ratesPopUp']")
    protected WebElement ratesDialogue;

    @FindBy(xpath = "//div[contains(@id,'hdx_dijits_Dialog_') and not (contains(@style,'display: none'))]//button[@title='Close']")
    protected WebElement ratesDialogueClose;

    @FindBy(xpath = "//div[contains(@id,'hdx_dijits_Dialog_') and not (contains(@style,'display: none'))]//tr[@class='rateTableHeading']/following-sibling::tr")
    protected List<WebElement> ratesDialogueRateTableRows;

    /**
     * Section for US Dollar
     */
    @FindBy(xpath = "//li[contains(@class,'padinDebit')]//div[@data-dojo-attach-point='_singleAccnt']//span[@class='location']/following-sibling::span/span[not(contains(@class,'noDisplay'))]")
    protected WebElement debitAccountName;

    @FindBy(xpath = "//li[contains(@class,'padinDebit')]//div[@data-dojo-attach-point='_singleAccnt']//span[contains(@class,'accountDetailsactSlOption')]")
    protected WebElement debitAccountNumber;

    @FindBy(xpath = "//li[contains(@class,'padinDebit')]//div[@data-dojo-attach-point='_singleAccnt']//span[@class='balance']")
    protected WebElement debitAccountBalance;

    /**
     * Section for Interest fields
     */
    @FindBy(xpath = "//div[@data-dojo-attach-point='_maturityDate']")
    private WebElement maturityDate;

    @FindBy(xpath = "//span[@data-dojo-attach-point='_maturityDateError']")
    private List<WebElement> maturityDateError;

    @FindBy(xpath = "//div[@data-dojo-attach-point='_interestRate']")
    private WebElement interestRate;

    @FindBy(xpath = "//div[@data-dojo-attach-point='_additionalOnlineRate']")
    private WebElement additionalOnlineRate;

    @FindBy(xpath = "//div[@data-dojo-attach-point='_totalRate']")
    private WebElement totalRate;

    @FindBy(xpath = "//*[@id='productsContainer']/div/div[1]/h2")
    protected WebElement opennewTDTitleHeading;

    private final By locatorInterestLoader = By
        .xpath("//span[(@data-dojo-attach-point='_interestLoader') and (not (@style='display: none;'))]");

    private static final int DEFAULT_LIST_STARTING_INDEX = 0;

    protected static final String MAKE_ELEMENT_VISIBLE = "arguments[0].style.height='auto'; arguments[0].style.visibility='visible';";
    protected static final String SCROLL_INTO_VIEW = "arguments[0].scrollIntoView(true);";
    protected static final String GET_HIDDEN_TEXT = "return arguments[0].innerHTML";
    private static final String INTEREST_PAID_DURATION = "Upon Maturity";
    protected static final String LOG_MESSAGE_DEBIT_ACCT_SELECTED = "Debit Account selected is: ";
    public static final String FOREIGN_CURRENCY = "foreign currency";
    public static final String US_TD = "US term deposit";
    public static final String TFSA_TD = "TFSA eTerm deposit";
    public static final String GIC_SIMPLE_INTEREST = "Non Redeemable Simple Interest GIC Account";

    public static final String PAGARE_MONEDA_NACIONAL = "Pagare moneda nacional";
    public static final String INVERSION_EXPRESS = "Inversion express";
    public static final String CEDE_TASA_FIJA = "CEDE Tasa Fija";
    public static final String CEDE_TASA_VARIABLE_CETE = "CEDE Tasa Variable CETE";
    public static final String CEDE_TASA_VARIABLE_TIIE = "CEDE Tasa Variable TIIE";

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(OpenAccountOptionsModel.class);

    public OpenAccountOptionsModel(final WebDriver driver) {
        PageFactory.initElements(driver, this);
        jsx = (JavascriptExecutor) driver;
        this.wait = new WebDriverWait(driver, 30);
    }

    /**
     * Verifying title heading of the page
     */
    public void verifyTitle() {
        wait.until(ExpectedConditions.visibilityOf(optionPageTitle));
    }

    public String getProductName() {
        Reporter.log("Product name is: " + productNameField.getText() + ". | ");
        return productNameField.getText();
    }

    public String selectInvestmentAccount(boolean isNewInvestmentAcct) {
        OpenAccountOptionsModel.logger.info("Parameter not used in this entity where value is: " + isNewInvestmentAcct);
        return null;
    }

    /**
     * <p>
     * <b> Selects Debit account from drop down.
     * </p>
     * 
     * @param profileProperties
     *            : to get customer number
     * @param selectOnlySoleAccount
     *            : true/false
     * @return accountDetails : AccountDetails
     */
    protected AccountDetails selectDebitAccount(Map<String, String> profileProperties, Boolean selectOnlySoleAccount) {
        String customerNumber = profileProperties.get("customerNumber");
        AccountDetails accountDetails = null;
        if (!accountDropDownIcon.isEmpty() && accountDropDownIcon.get(0).isDisplayed()) {
            accountDetails = new AccountDetails();
            selectAccount(accountDropDownIcon.get(0), selectOnlySoleAccount, customerNumber, minAmount());
            accountDetails.setAccountName(debitAccountNameList.get(0).getText());
            accountDetails.setAccountNumber(accountNumberList.get(0).getText());
            accountDetails.setAccountBalance(debitAccountBalanceList.get(0).getText());
            Reporter.log(LOG_MESSAGE_DEBIT_ACCT_SELECTED + debitAccountNameList.get(0).getText() + " :: "
                + accountNumberList.get(0).getText() + ".");
        } else if (StringUtils.containsIgnoreCase(debitAccountNumber.getText(), customerNumber)) {
            accountDetails = new AccountDetails();
            accountDetails.setAccountName(debitAccountName.getText());
            accountDetails.setAccountNumber(debitAccountNumber.getText());
            accountDetails.setAccountBalance(debitAccountBalance.getText());
            Reporter.log(LOG_MESSAGE_DEBIT_ACCT_SELECTED + debitAccountName.getText() + " :: " + debitAccountNumber.getText()
                + ". | ");
        } else {
            Assert.fail("No sole account present in Debit account. | ");
        }
        return accountDetails;
    }

    /**
     * 
     * <p>
     * <b> This method is used to select account based flag soleAccount. If
     * flag is false, it'll select joint account in account dropdown </b>
     * </p>
     * 
     * @return selected random value from List
     */
    private AccountDetails selectAccount(final WebElement accountDropIcon, Boolean isSoleAccount, final String customerNumber,
        String minBalance) {
        int index = DEFAULT_LIST_STARTING_INDEX;
        List<AccountDetails> accountValue = validAccountDetails(accountDropIcon, listDropdown, isSoleAccount, customerNumber,
            minBalance);
        Assert.assertTrue(!accountValue.isEmpty(), "No valid account found.");
        if (accountValue.size() != 1) {
            index = RandomUtil.generateIntNumber(DEFAULT_LIST_STARTING_INDEX, accountValue.size());
        }
        selectAccountByAccountDetail(accountDropIcon, accountValue.get(index));
        return accountValue.get(index);
    }

    protected void selectAccountByAccountDetail(final WebElement accountDropIcon, AccountDetails accountDetail) {
        accountDropIcon.click();
        wait.until(ExpectedConditions.visibilityOf(listDropdown));
        List<WebElement> accDrop = listDropdown.findElements(menuText);
        clickValidAccountElement(accDrop, accountDetail);
    }

    private boolean isValidAccount(Boolean isSoleAccount, String customerNumber, String accountNumber) {
        return (isSoleAccount && accountNumber.contains(customerNumber))
            || (!isSoleAccount && !accountNumber.contains(customerNumber));
    }

    private List<AccountDetails> validAccountDetails(final WebElement accountDropIcon, final WebElement menuDrop,
        Boolean isSoleAccount, final String customerNumber, String minBalance) {
        List<AccountDetails> storeAccountValue = new ArrayList<>();
        accountDropIcon.click();
        wait.until(ExpectedConditions.visibilityOf(menuDrop));
        List<WebElement> accountRows = menuDrop.findElements(menuText);
        for (WebElement accountRow : accountRows) {
            jsx.executeScript(SCROLL_INTO_VIEW, accountRow);
            WebElement accName = accountRow.findElements(accountName1).isEmpty() ? accountRow.findElement(accountName2)
                : accountRow.findElement(accountName1);
            String accountName = (String) jsx.executeScript(GET_HIDDEN_TEXT, accName);
            WebElement optItem = accountRow.findElements(accountDetails1).isEmpty() ? accountRow.findElement(accountDetails2)
                : accountRow.findElement(accountDetails1);
            WebElement accNumber = optItem.findElement(accountNum);
            String strAccountNumber = accNumber.getText();
            String accountCurrency = (String) jsx.executeScript(GET_HIDDEN_TEXT, optItem.findElement(currency));
            String accountBalance = (String) jsx.executeScript(GET_HIDDEN_TEXT, optItem.findElement(locatorAccountBalance));
            Double balance = Double.parseDouble(accountBalance.replace(",", ""));
            if (isValidAccount(isSoleAccount, customerNumber, strAccountNumber) && balance >= Double.parseDouble(minBalance)) {
                AccountDetails accountInformations = new AccountDetails();
                accountInformations.setAccountName(accountName);
                accountInformations.setAccountNumber(strAccountNumber);
                accountInformations.setAccountBalance(accountBalance);
                accountInformations.setDoubleAccountBalance(balance);
                accountInformations.setCurrency(accountCurrency);
                storeAccountValue.add(accountInformations);
            }
        }
        jsx.executeScript(SCROLL_INTO_VIEW, accountDropIcon);
        accountDropIcon.click();
        return storeAccountValue;
    }

    private void clickValidAccountElement(List<WebElement> accountRows, AccountDetails accountDetail) {
        for (WebElement accountRow : accountRows) {
            jsx.executeScript(SCROLL_INTO_VIEW, accountRow);
            WebElement accName = accountRow.findElements(accountName1).isEmpty() ? accountRow.findElement(accountName2)
                : accountRow.findElement(accountName1);
            String accountName = (String) jsx.executeScript(GET_HIDDEN_TEXT, accName);
            WebElement optItem = accountRow.findElements(accountDetails1).isEmpty() ? accountRow.findElement(accountDetails2)
                : accountRow.findElement(accountDetails1);
            WebElement accNumber = optItem.findElement(accountNum);
            String strAccountNumber = accNumber.getText();
            if (strAccountNumber.equalsIgnoreCase(accountDetail.getAccountNumber())
                && accountName.equalsIgnoreCase(accountDetail.getAccountName())) {
                accountRow.click();
                break;
            }
        }
    }

    /**
     * Selects Random account
     * 
     * @param dropDownIcon
     * @param dropDownItems
     * @param customerNumber
     */
    public void selectAccount(final WebElement dropDownIcon, final List<WebElement> dropDownItems, final String customerNumber) {
        dropDownIcon.click();
        int selectedElementNumber = 0;
        while (true) {
            if (dropDownItems.size() != 1) {
                selectedElementNumber = RandomUtil.generateIntNumber(DEFAULT_LIST_STARTING_INDEX, dropDownItems.size() - 1);
            }
            WebElement debitAccountInList = dropDownItems.get(selectedElementNumber);
            jsx.executeScript(SCROLL_INTO_VIEW, debitAccountInList);
            debitAccountInList.click();
            String accountBalance = debitAccountBalanceList.get(0).getText();
            if (StringUtils.containsIgnoreCase(accountNumberList.get(0).getText(), customerNumber)
                && Double.parseDouble(minAmount()) <= Double.parseDouble(accountBalance.replace(",", ""))) {
                break;
            } else {
                dropDownIcon.click();
            }
        }
    }

    /**
     * To select New Account currency account
     */
    public String selectNewAccountCurrency() {
        wait.until(ExpectedConditions.elementToBeClickable(currencyDropDownIcon));
        currencyDropDownIcon.click();
        int selectedElementNumber = 0;
        if (currencyDropDownItems.size() != 1) {
            selectedElementNumber = RandomUtil.generateIntNumber(DEFAULT_LIST_STARTING_INDEX, currencyDropDownItems.size() - 1);
        }
        WebElement currencyInList = currencyDropDownItems.get(selectedElementNumber);
        jsx.executeScript(SCROLL_INTO_VIEW, currencyInList);
        String accountCurrency = currencyInList.getText();
        Reporter.log("Currency Selected is: " + currencyInList.getText() + ". | ");
        currencyInList.click();
        return accountCurrency;
    }

    public String selectNewAccountCurrencyForForeignCurrencySaving() {
        wait.until(ExpectedConditions.elementToBeClickable(currencyDropDownIcon));
        currencyDropDownIcon.click();
        int selectedElementNumber = 0;
        jsx.executeScript(MAKE_ELEMENT_VISIBLE, currencyDropDownItems.get(0));
        if (currencyDropDownItems.size() != 1) {
            selectedElementNumber = RandomUtil.generateIntNumber(DEFAULT_LIST_STARTING_INDEX, currencyDropDownItems.size() - 1);
        }
        WebElement currencyInList = currencyDropDownItems.get(selectedElementNumber);
        jsx.executeScript(SCROLL_INTO_VIEW, currencyInList);
        String accountCurrency = currencyInList.getText();
        Reporter.log("Currency Selected is: " + currencyInList.getText() + ".");
        currencyInList.click();
        return accountCurrency.replace(currencyCode.getText(), "");
    }

    /**
     * To select Account Term
     */
    public String selectAccountTerm(Map<String, String> envProperties) {
        String termSelected = StringUtils.EMPTY;
        if (envProperties == null) {
            termOptionsDropDown.click();
            int selectedElementNumber = 0;
            jsx.executeScript(MAKE_ELEMENT_VISIBLE, termDropDownItems.get(0));
            if (termDropDownItems.size() != 1) {
                selectedElementNumber = RandomUtil.generateIntNumber(DEFAULT_LIST_STARTING_INDEX, termDropDownItems.size() - 1);
            }
            WebElement termInList = termDropDownItems.get(selectedElementNumber);
            jsx.executeScript(SCROLL_INTO_VIEW, termInList);
            termInList.click();
            termSelected = termOptionSelected.getText();
            Reporter.log("Term Selected is: " + termSelected + ". | ");
        }
        return termSelected;
    }

    /**
     * To enter Account Term
     */
    public String enterAccountTerm(int termValue, Map<String, String> envProperties) {
        int termDuration = termValue;
        boolean isCorrectDateFound = true;
        int numberToGetWeekday = 0;
        while (isCorrectDateFound) {
            termField.clear();
            termField.sendKeys(String.valueOf(termDuration));
            Reporter.log("Term value entered is: " + termDuration + ".| ");
            Date calcMaturityDate = DateUtil.addDays(new Date(), termDuration);
            if (checkForHoliday(setTimeToZero(calcMaturityDate), envProperties)) {
                Reporter.log("***Maturity date is on Holiday. Added 1 to term.*** | ");
                termDuration = termDuration + 1;
            } else if ((numberToGetWeekday = checkForWeekends(setTimeToZero(calcMaturityDate))) > 0) {
                Reporter.log("***Maturity date is on Weekend. Added " + numberToGetWeekday + " to term.*** | ");
                termDuration = termDuration + numberToGetWeekday;
            } else if (checkForAbove365Days(termDuration)) {
                Reporter.log("***Term is above 365. Minus 364 from term.*** | ");
                termDuration = termDuration - 364;
            } else {
                isCorrectDateFound = false;
            }
        }
        Reporter.log(termDuration + " entered in Term field. | ");
        return termDuration + " days";
    }

    protected Date setTimeToZero(Date calcMaturityDate) {
        Calendar c = Calendar.getInstance();
        c.setTime(calcMaturityDate);
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTime();
    }

    /**
     * To store Account Term
     */
    public String storeAccountTerm() {
        Reporter.log("Account term is: " + termDurationLabel.getText());
        return termDurationLabel.getText();
    }

    /**
     * Check the Amount Field is Editable or Not
     */
    public void isAmountFieldEditable() {
        Assert.assertTrue(amountField.isEnabled(), "Amount field is not Editable or Enable.");
    }

    protected String minAmount() {
        String amount = "0.00";
        if (!minAmountLabel.isEmpty() && minAmountLabel.get(0).isDisplayed()) {
            amount = minAmountLabel.get(0).getText();
        }
        return amount;
    }

    /**
     * Match if minimum Amount is correct for product and return amount
     * 
     * @param product
     *            : String
     * @return amount : String
     */
    public String minAmount(String product) {
        OpenAccountOptionsModel.logger.info("Parameter not used in this entity where value is: " + product);
        return null;
    }

    public Double enterAmount(String product) {
        if (product == null) {
            amountField.clear();
            amountField.sendKeys(minAmount());
            Reporter.log(minAmount() + " entered in amount field.");
        } else {
            Assert.fail("product value should be null for the entity.");
        }
        return Double.parseDouble(minAmount());
    }

    /**
     * Get interest rate from our rate pop up
     * 
     * @param openAccount
     *            : OpenAccountDetails
     * @param isTermInMonths
     *            : true/false
     * @return strInterestRate : String
     */
    public String getInterestRate(OpenAccountDetails openAccount, boolean isTermInMonths) {
        Double amount = openAccount.getAmount();
        String termSelected = openAccount.getTermDuration();
        if (isTermInMonths && StringUtils.containsIgnoreCase(termSelected, "year")) {
            int noOfYears = Integer.parseInt(termSelected.split(" ")[0]);
            termSelected = noOfYears * 12 + " Months";
        }
        ourRatesButton.click();
        String strInterestRate = StringUtils.EMPTY;
        wait.until(ExpectedConditions.visibilityOf(ratesDialogue));
        for (int currentRow = 0; currentRow < ratesDialogueRateTableRows.size(); currentRow++) {
            List<WebElement> cols = ratesDialogueRateTableRows.get(currentRow).findElements(By.tagName("td"));
            jsx.executeScript(SCROLL_INTO_VIEW, cols.get(0));
            if (termSelected.equalsIgnoreCase(cols.get(0).getText())) {
                strInterestRate = returnInterestRate(amount, cols, currentRow);
                break;
            }
        }
        ratesDialogueClose.click();
        strInterestRate = strInterestRate + " %";
        Reporter.log("Interest rate will be " + strInterestRate + ".");
        return strInterestRate;
    }

    public String returnInterestRate(Double amount, List<WebElement> columns, int row) {
        String strInterestRate = StringUtils.EMPTY;
        List<WebElement> cols = columns;
        String amountRange = cols.get(1).getText();
        Double amountRangeMinValue = Double.parseDouble(((amountRange.split("-")[0]).trim()).replace(",", ""));
        Double amountRangeMaxValue = Double.parseDouble(((amountRange.split("-")[1]).trim()).replace(",", ""));
        if (amount >= amountRangeMinValue && amount <= amountRangeMaxValue) {
            strInterestRate = cols.get(2).getText();
        } else {
            int currentRow = row;
            while (currentRow < ratesDialogueRateTableRows.size()) {
                currentRow++;
                cols = ratesDialogueRateTableRows.get(currentRow).findElements(By.tagName("td"));
                amountRange = cols.get(0).getText();
                amountRangeMinValue = Double.parseDouble(((amountRange.split("-")[0]).trim()).replace(",", ""));
                amountRangeMaxValue = Double.parseDouble(((amountRange.split("-")[1]).trim()).replace(",", ""));
                strInterestRate = cols.get(1).getText();
                if (amount >= amountRangeMinValue && amount <= amountRangeMaxValue) {
                    strInterestRate = cols.get(1).getText();
                    break;
                }
            }
        }
        return strInterestRate;
    }

    public String selectInterestPaid(final String termSelected) {
        String interestPaidSelected = StringUtils.EMPTY;
        if (!("30 days".equalsIgnoreCase(termSelected) || "60 days".equalsIgnoreCase(termSelected)) && termSelected != null) {
            if (!interestPaidDropDownIcon.isEmpty() && interestPaidDropDownIcon.get(0).isDisplayed()) {
                wait.until(ExpectedConditions.elementToBeClickable(interestPaidDropDownIcon.get(0)));
                interestPaidDropDownIcon.get(0).click();
                int selectedElementNumber = 0;
                if (interestPaidDropDownItems.size() != 1) {
                    selectedElementNumber = RandomUtil.generateIntNumber(DEFAULT_LIST_STARTING_INDEX,
                        interestPaidDropDownItems.size() - 1);
                }
                WebElement selectedItem = interestPaidDropDownItems.get(selectedElementNumber);
                jsx.executeScript(SCROLL_INTO_VIEW, selectedItem);
                selectedItem.click();
                interestPaidSelected = interestPaidOptionSelected.getText();
                Reporter.log("Interest Paid: " + interestPaidSelected + ".");
            }
        } else {
            interestPaidSelected = interestPaidLabel.getText();
            Reporter.log("Interest will be paid Upon Maturity.");
        }
        return interestPaidSelected;
    }

    /**
     * <p>
     * <b> Selects Credit account from drop down.
     * </p>
     * 
     * @param openAccount
     *            : to get InterestPaidInterval
     * @param profileProperties
     *            : to get customer number
     * @param selectOnlySoleAccount
     *            : true/false
     * @return accountDetails : AccountDetails
     */
    public AccountDetails selectCreditAccount(OpenAccountDetails openAccount, Map<String, String> profileProperties,
        boolean selectOnlySoleAccount) {
        String customerNumber = profileProperties.get("customerNumber");
        String interestPaid = openAccount.getInterestPaidInterval();
        AccountDetails accountDetails = null;
        if (!(INTEREST_PAID_DURATION.equalsIgnoreCase(interestPaid)) && (interestPaid != null)) {
            String minBalance = "0.00";
            selectAccount(accountDropDownIcon.get(1), selectOnlySoleAccount, customerNumber, minBalance);
            accountDetails = new AccountDetails();
            accountDetails.setAccountName(creditAccountName.get(1).getText());
            accountDetails.setAccountNumber(accountNumberList.get(1).getText());
            Reporter.log("Credit Account selected is: " + creditAccountName.get(1).getText() + " :: "
                + accountNumberList.get(1).getText());
        }
        return accountDetails;
    }

    public void fillOptions(Map<String, String> profileProperties) {
        String accountBalance = debitAccountBalanceList.get(0).getText();
        Reporter.log(LOG_MESSAGE_DEBIT_ACCT_SELECTED + debitAccountNameList.get(0).getText() + " :: "
            + accountNumberList.get(0).getText() + ".");
        if (Double.parseDouble(minAmount()) > Double.parseDouble(accountBalance.replace(",", ""))) {
            selectDebitAccount(profileProperties, true);
        }
        isAmountFieldEditable();
        amountField.clear();
        amountField.sendKeys(minAmount());
        Reporter.log(minAmount() + " entered in amount field.");
        selectReasonForOpeningAccount();
    }

    /**
     * Clicks Continue button on ApplyOpenAccount Options Page
     */
    public void clickContinueButton() {
        wait.until(ExpectedConditions.elementToBeClickable(continueButton));
        continueButton.click();
        Reporter.log("Continue button clicked. | ");
    }

    /**
     * Clicks Cancel button on ApplyOpenAccount Options Page
     * 
     * @param true/false
     */
    public void clickCancelButton(final boolean isCancel) {
        wait.until(ExpectedConditions.elementToBeClickable(cancelButton));
        cancelButton.click();
        if (isCancel) {
            cancelDialogYes.click();
            wait.until(ExpectedConditions.visibilityOf(opennewTDTitleHeading));
            jsx.executeScript(SCROLL_INTO_VIEW, opennewTDTitleHeading);
            Reporter.log("Cancel button - Continue clicked and Product details page shown.");
        } else {
            cancelDialogNo.click();
            wait.until(ExpectedConditions.visibilityOf(openTDOptionsForm));
            Reporter.log("Options Page shown after clicking Cancel button - Cancel on Options page.");
        }
    }

    /**
     * Select radio button based on boolean value
     * 
     * @param IsYes
     */
    public void selectRadio(boolean isYes) {
        if (isYes) {
            radioYes.click();
            radioErrorBox.isDisplayed();
            Reporter.log("Radio Yes clicked and error message shown.");
        } else {
            wait.until(ExpectedConditions.visibilityOf(radioNo));
            radioNo.click();
            wait.until(ExpectedConditions.elementToBeSelected(radioNo));
            Reporter.log("Radio No Clicked.");
        }
    }

    public void selectReasonForOpeningAccount() {
        wait.until(ExpectedConditions.elementToBeClickable(reasonDropDownIcon));
        reasonDropDownIcon.click();
        int selectedElementNumber = 1;
        jsx.executeScript(MAKE_ELEMENT_VISIBLE, reasonDropDownItems.get(0));
        if (reasonDropDownItems.size() == 1) {
            Assert.fail("No proper reason present.");

        } else if (reasonDropDownItems.size() > 2) {
            selectedElementNumber = RandomUtil.generateIntNumber(1, reasonDropDownItems.size() - 1);
        }
        WebElement reason = reasonDropDownItems.get(selectedElementNumber);
        jsx.executeScript(SCROLL_INTO_VIEW, reason);
        wait.until(ExpectedConditions.visibilityOf(reason));
        reason.click();
        String reasonSelected = reasonOptionSelected.getText();
        Reporter.log("Reason for opening account is: " + reasonSelected + ".");
    }

    public void clickTnCCheckbox() {}

    /**
     * @param openAccount
     * @param profileProperties
     */
    public void applyOpenTDAccountFillOptions(OpenAccountDetails openAccount, Map<String, String> profileProperties) {
        verifyTitle();
        openAccount.setProductName(getProductName());
        openAccount.setDebitAccount(selectDebitAccount(profileProperties, true));
        openAccount.setCurrency(selectNewAccountCurrency());
        openAccount.setTermDuration(selectAccountTerm(null));
        openAccount.setAmount(enterAmount(null));
        openAccount.setInterestRate(getInterestRate(openAccount, true));
        if (US_TD.equals(openAccount.getTypeOfProduct())) {
            openAccount.setInterestPaidInterval(selectInterestPaid(null));
            selectReasonForOpeningAccount();
        } else {
            openAccount.setInterestPaidInterval(selectInterestPaid(openAccount.getTermDuration()));
            if (TFSA_TD.equals(openAccount.getTypeOfProduct())) {
                openAccount.setCreditAccount(selectCreditAccount(openAccount, profileProperties, false));
            } else {
                openAccount.setCreditAccount(selectCreditAccount(openAccount, profileProperties, true));
            }
            selectRadio(true);
            selectRadio(false);
            selectReasonForOpeningAccount();
            clickTnCCheckbox();
        }
        clickContinueButton();
    }

    /**
     * @param openAccount
     * @param profileProperties
     */
    public void applyOpenSavingsAccountFillOptions(OpenAccountDetails openAccount, Map<String, String> profileProperties,
        String currencyType) {
        verifyTitle();
        openAccount.setProductName(getProductName());
        openAccount.setDebitAccount(selectDebitAccount(profileProperties, true));
        if (FOREIGN_CURRENCY.equals(currencyType)) {
            openAccount.setCurrency(selectNewAccountCurrencyForForeignCurrencySaving());
        } else {
            openAccount.setCurrency(selectNewAccountCurrency());
        }
        selectRadio(true);
        selectRadio(false);
        selectReasonForOpeningAccount();
        clickContinueButton();
    }

    /**
     * @param openAccount
     * @param profileProperties
     */
    public void openGICProductFillOptions(OpenAccountDetails openAccount, Map<String, String> profileProperties) {
        verifyTitle();
        openAccount.setProductName(getProductName());
        openAccount.setDebitAccount(selectDebitAccount(profileProperties, true));
        openAccount.setTermDuration(selectAccountTerm(null));
        openAccount.setCurrency(selectNewAccountCurrency());
        openAccount.setAmount(enterAmount(null));
        openAccount.setInterestRate(getInterestRate(openAccount, true));
        openAccount.setInterestPaidInterval(selectInterestPaid(openAccount.getTermDuration()));
        if (GIC_SIMPLE_INTEREST.equals(openAccount.getTypeOfProduct())) {
            openAccount.setCreditAccount(selectCreditAccount(openAccount, profileProperties, true));
        }
        selectRadio(true);
        selectRadio(false);
        selectReasonForOpeningAccount();
        clickContinueButton();
    }

    /**
     * Returns maturity instruction
     */
    public String selectMaturityInstruction() {
        return null;
    }

    /**
     * Returns randomly generated term value
     */
    private int randomTermValue() {
        return RandomUtil.generateIntNumber(1, 721);
    }

    public void productsWithInputTermOptionsPage(OpenAccountDetails openAccount, Map<String, String> envProperties) {
        verifyTitle();
        openAccount.setProductName(getProductName());
        openAccount.setDebitAccount(selectDebitAccount(null, null));
        openAccount.setInvestmentAccount(selectInvestmentAccount(openAccount.getIsNewInvestmentAcct()));
        openAccount.setCurrency(selectNewAccountCurrency());
        openAccount.setAmount(enterAmount(openAccount.getProduct()));
        openAccount.setMaturityInstruction(selectMaturityInstruction());
        openAccount.setTermDuration(enterAccountTerm(randomTermValue(), envProperties));
        clickCalculateButton();
        openAccount.setMaturityDate(getmaturityDate());
        openAccount.setInterestRate(getInterestRate());
        openAccount.setAdditionalOnlineRate(getAdditionalOnlineRate());
        openAccount.setTotalRate(getTotalRate());
        clickContinueButton();
    }

    public void cEDETasaProductsOptionsPage(OpenAccountDetails openAccount, Map<String, String> envProperties) {
        verifyTitle();
        openAccount.setProductName(getProductName());
        openAccount.setDebitAccount(selectDebitAccount(null, null));
        openAccount.setInvestmentAccount(selectInvestmentAccount(openAccount.getIsNewInvestmentAcct()));
        openAccount.setCurrency(selectNewAccountCurrency());
        openAccount.setAmount(enterAmount(openAccount.getProduct()));
        openAccount.setMaturityInstruction(selectMaturityInstruction());
        openAccount.setTermDuration(selectAccountTerm(envProperties));
        clickCalculateButton();
        openAccount.setMaturityDate(getmaturityDate());
        openAccount.setInterestRate(getInterestRate());
        openAccount.setAdditionalOnlineRate(getAdditionalOnlineRate());
        openAccount.setTotalRate(getTotalRate());
        clickContinueButton();
    }

    private String getmaturityDate() {
        Reporter.log("Maturity date is: " + maturityDate.getText());
        return maturityDate.getText();
    }

    private String getInterestRate() {
        Reporter.log("Interest rate is: " + interestRate.getText() + ".| ");
        return interestRate.getText();
    }

    private String getAdditionalOnlineRate() {
        Reporter.log("Additional online rate is: " + additionalOnlineRate.getText() + ".| ");
        return additionalOnlineRate.getText();
    }

    private String getTotalRate() {
        Reporter.log("Total rate is: " + totalRate.getText() + ". | ");
        return totalRate.getText();
    }

    /**
     * Clicks calculate button on Options page and check maturity date on
     * <b>holiday or Weekends<b>
     * 
     * @param openAccount
     * @param isProductWithInputTerm
     */
    private void clickCalculateButton() {
        wait.until(ExpectedConditions.elementToBeClickable(calculateButton));
        calculateButton.click();
        wait.until(ExpectedConditions.invisibilityOfElementLocated(locatorInterestLoader));
        Reporter.log("Calculate button clicked. | ");
    }

    public void validateMaturityErrorForHoliday(OpenAccountDetails openAccount, Map<String, String> envProperties,
        Map<String, String> profileProperties) {
        verifyTitle();
        getProductName();
        selectDebitAccount(null, null);
        selectInvestmentAccount(false);
        selectNewAccountCurrency();
        enterAmount(openAccount.getProduct());
        selectMaturityInstruction();
        long diffDays = 0;
        for (Date eachDate : getHolidays(envProperties)) {
            if (eachDate.after(setTimeToZero(new Date()))) {
                long diff = eachDate.getTime() - setTimeToZero(new Date()).getTime();
                diffDays = diff / (24 * 60 * 60 * 1000);
                break;
            }
        }
        termField.clear();
        termField.sendKeys(String.valueOf(diffDays));
        Reporter.log("Term value entered is: " + diffDays);
        clickCalculateButton();
        if (!maturityDateError.isEmpty() && maturityDateError.get(0).isDisplayed()) {
            Reporter.log("Maturity date is on Holiday and Error mesage is shown. | ");
        } else {
            Assert.fail("Error message for maturity date on holiday is not displayed. | ");
        }
    }

    public void validateMaturityErrorForWeekend() {
        termField.clear();
        int termValue = 0;
        int i = 1;
        while (i <= 7) {
            Date calcMaturityDate = DateUtil.addDays(new Date(), i);
            if (checkForWeekends(calcMaturityDate) > 0) {
                termValue = i;
                termField.sendKeys(String.valueOf(termValue));
                clickCalculateButton();
                if (!maturityDateError.isEmpty() && maturityDateError.get(0).isDisplayed()) {
                    Reporter.log("Maturity date is on Weekend and Error mesage is shown. | ");
                } else {
                    Assert.fail("Error message for maturity date on weekend is not displayed. | ");
                }
            }
            i++;
        }
    }

    protected boolean checkForHoliday(Date calcMaturityDate, Map<String, String> envProperties) {
        boolean isMaturityDateOnHoliday = false;
        if (getHolidays(envProperties).contains(calcMaturityDate)) {
            isMaturityDateOnHoliday = true;
        }
        return isMaturityDateOnHoliday;
    }

    protected int checkForWeekends(Date calcMaturityDate) {
        int numberToGetWeekday = 0;
        Calendar c = Calendar.getInstance();
        c.setTime(calcMaturityDate);
        int dayOfWeek = c.get(Calendar.DAY_OF_WEEK);
        numberToGetWeekday = (dayOfWeek == Calendar.SUNDAY) ? 1 : numberToGetWeekday;
        numberToGetWeekday = (dayOfWeek == Calendar.SATURDAY) ? 2 : numberToGetWeekday;
        return numberToGetWeekday;
    }

    private boolean checkForAbove365Days(int termDuration) {
        return termDuration >= 365;
    }

    private List<Date> getHolidays(Map<String, String> envProperties) {
        String[] holidayListArray = envProperties.get("holidayList").split(",");
        List<Date> holidayList = new ArrayList<>();
        for (int count = 0; count < holidayListArray.length; count++) {
            Date dateHoliday = new Date();
            try {
                dateHoliday = DateUtil.getStringToDate(DateUtil.DATE_FORMAT_DDMMYYYY, holidayListArray[count]);
            } catch (ParseException e) {
                Assert.fail("Date Error: ", e);
            }
            holidayList.add(dateHoliday);
        }
        return holidayList;
    }

    public OpenAccountDetails captureDetailsForSavingOnOptionPage(final Map<String, String> profileProperties) {
        return null;
    }

    public OpenAccountDetails captureDetailsForTermDepositOnOptionPage(final Map<String, String> profileProperties) {
        return null;
    }

    public void setProductToPOJO(OpenAccountDetails openAccount, int productNumber) {
        switch (productNumber) {
        case 0:
        case 3:
        case 8:
            openAccount.setProduct(PAGARE_MONEDA_NACIONAL);
            break;
        case 1:
        case 4:
        case 9:
            openAccount.setProduct(INVERSION_EXPRESS);
            break;
        case 2:
        case 7:
            openAccount.setProduct(CEDE_TASA_FIJA);
            break;
        case 5:
            openAccount.setProduct(CEDE_TASA_VARIABLE_CETE);
            break;
        case 6:
            openAccount.setProduct(CEDE_TASA_VARIABLE_TIIE);
            break;
        }
    }
}
