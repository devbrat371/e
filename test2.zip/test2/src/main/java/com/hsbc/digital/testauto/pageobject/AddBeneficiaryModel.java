package com.hsbc.digital.testauto.pageobject;


import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.library.TokenGenerator;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.models.AddBeneficiaryDetails;
import com.hsbc.digital.testauto.models.BankDetails;


/**
 * <p>
 * <b> This model class will hold locators and functionality for My payees
 * page. </b>
 * </p>
 * 
 * @author Shweta Jain
 * @version 1.0.0
 */
public abstract class AddBeneficiaryModel {

    private final WebDriverWait wait;
    protected WebDriver driver;
    /**
     * Web elements for story 40- Add beneficiary---------Starts
     */
    @FindBy(xpath = ".//*[@id='dijit__WidgetBase_0']/a/span[1]")
    public WebElement linkMyBanking;

    @FindBy(xpath = ".//div[@id='PayeeForm']/h2[@class='managePayeesTitle']")
    protected WebElement myPayeesPageTitle;

    @FindBy(xpath = ".//button/span[@class='newPayee']")
    protected WebElement newPayeeTab;

    @FindBy(xpath = ".//*[@id='payeeType']/label[1]/span[1]")
    protected WebElement enterDetailsBtn;

    @FindBy(xpath = ".//table[@data-progressive='accountTypeSelect']//input[contains(@id,'arrowid_hdx_dijits_form_Select')]")
    private WebElement payeeTypeDropdownIcon;

    @FindBy(xpath = ".//div[starts-with(@id,'hdx_dijits_form_Select') and contains(@id,'menu')]//table[@class='dijitReset dijitMenuTable']")
    private WebElement payeeTypeList;

    @FindBy(xpath = ".//table[@class='dijitReset dijitMenuTable']//td[contains(@id,'dijit_MenuItem') and contains(text(),'HSBC Bank Account')]")
    private WebElement domHSBCPayeeItem;

    @FindBy(xpath = ".//table[@class='dijitReset dijitMenuTable']//td[contains(@id,'dijit_MenuItem') and contains(text(),'Other Local Bank')]")
    private WebElement otherLocalankPayeeItem;

    @FindBy(xpath = ".//*[@data-dojo-attach-point='_bankNameField']//input[contains(@id,'hdx_dijits_form_MegaComboBox') and @role='textbox']")
    protected WebElement localBankNameField;

    @FindBy(xpath = ".//*[@data-dojo-attach-point='_bankNameField']//input[contains(@id,'hdx_dijits_form_MegaComboBox') and @class='dijitReset dijitInputField dijitArrowButtonInner']")
    protected WebElement localBankNameListDropdownIcon;

    @FindBy(xpath = ".//div[starts-with(@id,'widget_hdx_dijits_form_MegaComboBox') and contains(@id,'dropdown')]")
    protected WebElement localBankNameList;

    @FindBy(xpath = ".//input[starts-with(@id,'arrowid_group_gpib_mvmny_bijit_AddPersonStandaloneNew') and contains(@id,'bankCountry')]")
    private WebElement countryListDropdownIcon;

    @FindBy(xpath = ".//div[starts-with(@id,'group_gpib_mvmny_bijit_AddPersonStandaloneNew') and contains(@id,'bankCountry_popup')]")
    private WebElement countryList;

    @FindBy(xpath = ".//input[starts-with(@id,'arrowid_group_gpib_mvmny_bijit_Addi18nPayee_') and contains(@id,'phBankSearchCity')]")
    private WebElement intBankCityListDropdownIcon;

    @FindBy(xpath = ".//div[starts-with(@id,'group_gpib_mvmny_bijit_Addi18nPayee') and contains(@id,'phBankSearchCity_popup')]")
    private WebElement internationalBankCityList;

    @FindBy(xpath = ".//input[starts-with(@id,'arrowid_group_gpib_mvmny_bijit_Addi18nPayee') and contains(@id,'phBankSearchRoutingAgent')]")
    private WebElement intlBankListDropdownIcon;

    @FindBy(xpath = ".//div[starts-with(@id,'widget_group_gpib_mvmny_bijit_Addi18nPayee') and contains(@id,'phBankSearchRoutingAgent_dropdown')]/div[@class='dijitMegaComboBoxPopup']")
    private WebElement internationalBankList;

    @FindBy(xpath = ".//input[starts-with(@id,'group_gpib_mvmny_bijit_Addi18nPayee') and contains(@id,'bankName')]")
    private WebElement bankName;

    @FindBy(xpath = ".//input[starts-with(@id,'group_gpib_mvmny_bijit_Addi18nPayee') and contains(@id,'bankCode')]")
    private WebElement bankClearingCode;

    @FindBy(xpath = ".//input[starts-with(@id,'group_gpib_mvmny_bijit_Addi18nPayee') and  contains(@id,'bankAddress1')]")
    private WebElement bankAdd1Field;

    @FindBy(xpath = ".//input[starts-with(@id,'group_gpib_mvmny_bijit_Addi18nPayee') and  contains(@id,'bankAddress2')]")
    private WebElement bankAdd2Field;

    @FindBy(xpath = ".//input[starts-with(@id,'group_gpib_mvmny_bijit_Addi18nPayee') and  contains(@id,'bankAddress3')]")
    private WebElement bankAdd3Field;

    // @FindBy(xpath = ".//input[contains(@id,'accountNumberInput')]")
    @FindBy(xpath = ".//input[starts-with(@id,'accountNumberInput_group_gpib_mvmny_bijit_AddOtrHSBCPayee')]")
    protected WebElement domAccountNumberField;

    @FindBy(xpath = ".//input[starts-with(@id,'group_gpib_mvmny_bijit_Addi18nPayee') and contains(@id,'_acctNum')]")
    private WebElement internationalAccountNumberField;

    @FindBy(xpath = ".//*[@data-dojo-attach-point='_bank_accountCCY']//input[@class='dijitReset dijitInputField dijitArrowButtonInner']")
    protected WebElement currencyListDropDownIcon;

    // @FindBy(xpath =
    // "//div[contains(@class,'dijitMenuItem') and @role='option']")
    @FindBy(xpath = ".//*[starts-with(@id,'widget_hdx_dijits_form_MegaComboBox_') and contains(@id,'_dropdown')]")
    protected WebElement currencyList;

    @FindBy(xpath = ".//input[starts-with(@id,'arrowid_companyName_group_gpib_mvmny_bijit_AddCompany')]")
    private WebElement companyPayeeListDropdownIcon;

    @FindBy(xpath = ".//div[starts-with(@id,'companyName_group_gpib_mvmny_bijit_AddCompany') and contains(@id,'popup')]")
    private WebElement companyPayeeList;

    @FindBy(xpath = ".//*[starts-with(@id,'dijit_form_Button')and text()='Add payee details']")
    private WebElement addPayeeDetailsBtn;

    protected WebElement getAddPayeeDetailsBtn() {
        return addPayeeDetailsBtn;
    }

    @FindBy(xpath = ".//input[contains(@id,'payeeNameInput_group_gpib_mvmny_bijit_AddPersonStandaloneNew')]")
    private WebElement payeeNameField;

    @FindBy(xpath = ".//input[contains(@id,'companyReference_group_gpib_mvmny_bijit_AddCompany')]")
    private WebElement companyReferenceField;

    @FindBy(xpath = ".//input[contains(@id,'tdsCode_group_gpib_cmn_bijit_reauthtds')]")
    protected WebElement tdsCodeField;

    @FindBy(xpath = ".//button[@class='btnTertiary' and contains(@data-dojo-attach-point,'cancelNewPayee')]")
    private WebElement cancelNewPayeeButton;


    @FindBy(xpath = ".//div[contains(@id,'group_gpib_cmn_bijit_ConfirmDialog')]//button[@class='btnSecondary' and @data-dojo-attach-point='_btnCancel']")
    private WebElement confirmCancelButton;

    @FindBy(xpath = ".//div[contains(@id,'group_gpib_cmn_bijit_ConfirmDialog')]//button[@class='btnTertiary' and @data-dojo-attach-point='_btnOk']")
    private WebElement dontCancelBtn;

    @FindBy(xpath = ".//button[contains(@class,'btnSecondary') and contains(@data-dojo-attach-point,'saveNewPayee')]")
    private WebElement saveDetailsBtn;

    @FindBy(xpath = ".//*[@id='sucessMsgAddEditDelete']")
    protected WebElement confirmPayeeMsg;

    @FindBy(xpath = ".//button[@data-dojo-attach-point='filterAllNode']/span")
    private WebElement payeesCount;

    /**
     * Locators for Bank country list, Bank city List, Account currency List
     */
    By countryLocator = By.xpath(".//div[contains(@id,'bankCountry_popup') and (@class='dijitReset dijitMenuItem')]");
    By otherCountryLocator = By
        .xpath(".//div[contains(@id,'bankCountry_popup') and (@class='dijitReset dijitMenuItem') and contains(text(),'Other')]");
    By cityLocator = By.xpath(".//div[contains(@id,'phBankSearchCity') and (@class='dijitReset dijitMenuItem')]");
    By otherCityLocator = By.xpath(".//div[text()='OTHER']");
    protected By otherLocalBankLocator = By
        .xpath(".//div[starts-with(@id,'hdx_dijits_form_MegaComboBox') and contains(@id,'popup') and @class='dijitReset dijitMenuItem']");
    By intBankLocator = By.xpath(".//div[contains(@id,'phBankSearchRoutingAgent_popup') and (@class='dijitReset dijitMenuItem')]");
    By otherBankLocator = By.xpath(".//div[text()='Other']");
    protected By currencyLocator = By
        .xpath(".//div[contains(@id,'hdx_dijits_form_MegaComboBox') and @class='dijitReset dijitMenuItem']");
    By companyListLocator = By.xpath("//div[@class='dijitReset dijitMenuItem']");

    private static final String COUNTRY_OTHER = "Other";
    private static final String CITY_OTHER = "OTHER";
    private static final String BANK_OTHER = "Other";
    private static final String SUCCESS_MSG = "successfully";
    private static final String BANK_CODE = "HKBAMEL";
    private static final String INT_PAYEE_TYPE = "INTERNATION_BANK_PAYEE";
    private static final String PAYEE_TYPE_COMPANY = "COMPANY PAYEE";
    private static final String BANK_COUNTRY = "Canada";
    private static final String LABEL_PAYEE_NAME = "Payee name";
    private static final String ENTITY_BANK_COUNTRY = "Canada";


    /**
     * Web elements for story 40- Add beneficiary---------Ends
     */

    /**
     * Web elements for story 41- Manage beneficiary---------Starts
     */
    protected final JavascriptExecutor jsx;

    protected static final int DEFAULT_LIST_STARTING_INDEX = 0;
    protected static final String GET_HIDDEN_TEXT = "return arguments[0].innerHTML";
    protected static final String SCROLL_TO_VIEW = "arguments[0].scrollIntoView(true);";
    protected static final String PERSON_PAYEE = "Person";
    protected static final String COMPANY_PAYEE = "Company";
    @FindBy(xpath = "//div[@id='PayeeForm']//h2[contains(@class, 'managePayeesTitle')]")
    protected WebElement payeePageTitle;

    @FindBy(xpath = ".//a[@data-uid='myPayees']")
    private WebElement linkMyPayees;

    @FindBy(xpath = ".//button[@class='btnQuaternary btnIcon selected' and @data-dojo-attach-point='filterAllNode']")
    private WebElement allPayeesTab;

    @FindBy(xpath = "//div[contains(@id, '_header')]//div[contains(@id, 'CountryDropdown')]//span[contains(@id, 'DropDownButton')]")
    protected WebElement entityCountry;

    @FindBy(xpath = ".//*[starts-with(@id,'gridx_Grid')]//following-sibling::td//strong")
    private List<WebElement> allPayeesNamesList;

    @FindBy(xpath = ".//div[@class='gridxBody gridxBodyRowHoverEffect'  and @data-dojo-attach-point='bodyNode']")
    private WebElement allPayeesTable;

    @FindBy(xpath = ".//td[@class=' payeeType']/img")
    private WebElement payeeTypeImage;

    /**
     * Number of Payees present on the page
     */
    @FindBy(id = "gridx_Grid_1")
    private WebElement payeeTable;

    @FindBy(xpath = ".//div[starts-with(@id,'group_gpib_mvmny_bijit_EditCompany')]")
    protected WebElement companyPayeeDetailsView;

    @FindBy(xpath = ".//dd[@data-dojo-attach-point='_compNameAttach']")
    private WebElement companyName;

    @FindBy(xpath = ".//dd[@data-dojo-attach-point='_accntRefNumAttch']")
    private WebElement companyRefNumber;

    @FindBy(xpath = ".//div[starts-with(@id,'hdx_bijits_payee_ManagePayees_Person') and @class='editContainer']")
    protected WebElement personPayeeDetailsView;

    @FindBy(xpath = ".//div[@class='editContainer' and @data-dojo-attach-point='_editContainer']")
    private WebElement editDetailsView;

    // Locators
    private final By payeeCountry = By.xpath(".//td[contains(@class,'payeeCountry')]/span");
    private final By payeeName = By.xpath(".//td[contains(@class,'payeeName')]/strong");
    private final By accNumber = By.xpath(".//td[contains(@class,'payeeName')]/span");
    private final By viewButton = By.xpath(".//td[contains(@class,'payeeButtons')]//button[contains(@class,'viewPayee')]");
    private final By addressFieldLabel = By.xpath(".//div[@data-dojo-attach-point='_payeeAddrLine1Node']/dt");
    private final By addressFieldValue = By.xpath(".//div[@data-dojo-attach-point='_payeeAddrLine1Node']/dd");
    private final By bankCodeField = By.xpath(".//div[@data-dojo-attach-point='_bankCodeNode']/dt");
    private final By bankCodeValue = By.xpath(".//div[@data-dojo-attach-point='_bankCodeNode']/dt");
    private final By accountNumberField = By.xpath(".//div[@data-dojo-attach-point='_accountNumberNode']/dt");
    private final By accountNumbervalue = By.xpath(".//div[@data-dojo-attach-point='_accountNumberNode']/dd");
    private final By accountCCYField = By.xpath(".//div[@data-dojo-attach-point='_bankAccountCcyNode']/dt");
    private final By accountCCYValue = By.xpath(".//div[@data-dojo-attach-point='_bankAccountCcyNode']/dd");
    private final By bankNameField = By.xpath(".//div[@data-dojo-attach-point='_bankNameNode']/dt");
    private final By bankNameValue = By.xpath(".//div[@data-dojo-attach-point='_bankNameNode']/dd");
    private final By bankAddField = By.xpath(".//div[@data-dojo-attach-point='_bankAddressNode']/dt");
    private final By bankAddvalue = By.xpath(".//div[@data-dojo-attach-point='_bankAddressNode']/dd");
    private final By closeButton = By.xpath(".//button[@data-dojo-attach-point='_editCancelNode']");
    private final By deleteButton = By.xpath(".//td[contains(@class,'payeeButtons')]//button[contains(@class,'deletePayee')]");
    private final By payButton = By.xpath(".//td[contains(@class,'payeeButtons')]//button[contains(@class,'payPayee')]");

    protected final By locatorAllPayeesRow = By.xpath("//div[contains(@class, 'gridxRow') and contains(@role, 'row')]");

    protected final By locatorPayeeType = By.xpath(".//td[contains(@class, 'payeeType')]//img");

    private final By locatorCompanyPayeeName = By.xpath(".//td[contains(@class, 'payeeName')]//strong");

    private final By locatorCompanyPayeeNumber = By.xpath(".//td[contains(@class, 'payeeName')]//span");

    protected final By locatorPayeeName = By.xpath(".//td[contains(@class, 'payeeName')]/strong");

    protected final By locatorPayeeCountry = By.xpath(".//td[contains(@class, 'payeeCountry')]");

    protected final By locatorViewPayee = By
        .xpath(".//td[contains(@class, 'payeeButtons')]//button[contains(@class, 'viewPayee')]");

    protected final By locatorManagePerson = By.xpath(".//div[contains(@id, 'ManagePayees_Person')]");

    protected final By locatorPayeeAccountNumber = By
        .xpath(".//div[contains(@data-dojo-attach-point, '_accountNumberNode')]//dd[contains(@data-dojo-attach-point, '_accountNumberAttch')]");

    protected final By locatorPayeeCurrency = By
        .xpath(".//div[contains(@data-dojo-attach-point, '_bankAccountCcyNode')]//dd[contains(@data-dojo-attach-point, '_accntCCYAttach')]");

    protected final By locatorPayeeBankCountry = By
        .xpath(".//div[contains(@data-dojo-attach-point, '_payeeBankCountryNode')]//span[contains(@data-dojo-attach-point, '_payeeBankCountry') and contains(@class, 'country')]");

    @FindBy(xpath = "//div[starts-with(@id,'hdx_dijits_Dialog')]//div[@class='dialogAlert deletePayeeDialog']")
    WebElement delPayeeDialog;

    @FindBy(xpath = "//div[contains(@id, 'Dialog') and contains(@class, 'dijitDialogFixed')]")
    private List<WebElement> deletePayeeWithFuturePaymentDialogs;

    @FindBy(xpath = "//div[contains(@class, 'deletePayeeDialog')]//div[contains(@class, 'submitButtonsPanel')]//*[contains(@data-dojo-attach-point, '_viewPaymentsBtn')]")
    private WebElement viewPaymentButtonDeletePayeeWithFuturePaymentDialog;

    @FindBy(xpath = "//div[contains(@class, 'deletePayeeDialog')]//div[contains(@class, 'submitButtonsPanel')]//*[contains(@data-dojo-attach-point, '_delCancelNode')]")
    private WebElement cancelButtonDeletePayeeWithFuturePaymentDialog;

    @FindBy(xpath = ".//div[starts-with(@id,'hdx_dijits_Dialog')]//p[@data-dojo-attach-point='_payeeNameNode']")
    private WebElement payeeNameOnDialog;

    protected WebElement getPayeeNameOnDialog() {
        return payeeNameOnDialog;
    }

    private final By cancelBtnOnDialog = By.xpath(".//button[@class='btnTertiary' and @data-dojo-attach-point='_delCancelNode']");
    private final By deletBtnOnDialog = By.xpath(".//button[@class='btnPrimary' and @data-dojo-attach-point='_delConfirmNode']");

    @FindBy(xpath = ".//div[@id='sucessMsgAddEditDelete']")
    private WebElement sucessMsg;

    @FindBy(xpath = ".//div[@id='sucessMsgAddEditDelete']//b")
    private WebElement deletedPayeeName;

    @FindBy(xpath = "//div[@class = 'alertPanel info withButton']//p")
    private WebElement alertMessageWhenNoPayee;

    @FindBy(xpath = "//button[@class = 'btnQuaternary btnIcon']//span[@class = 'person']")
    private List<WebElement> personTabsPayees;

    @FindBy(xpath = "//button[@class = 'btnQuaternary btnIcon']//span[@class = 'company']")
    private List<WebElement> companyTabsPayees;

    TokenGenerator tokenGenerator;

    /**
     * Web elements for story 41- Manage beneficiary---------Ends
     */

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(AddBeneficiaryModel.class);

    public AddBeneficiaryModel(final WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        jsx = (JavascriptExecutor) driver;
        wait = new WebDriverWait(driver, 30000);
        tokenGenerator = new TokenGenerator();
    }

    protected String getEntityBankCountry() {
        return ENTITY_BANK_COUNTRY;
    }

    /**
     * POM methods for story- 40- Add Beneficiary------------Starts
     */

    /**
     * This is generic method to open My payees page to initiate Add payee flow
     * 
     * @return int : All Payee count before add payee flow begin
     */
    public int addPersonPayee() {
        wait.until(ExpectedConditions.elementToBeClickable(newPayeeTab));
        newPayeeTab.click();
        wait.until(ExpectedConditions.elementToBeClickable(enterDetailsBtn));
        enterDetailsBtn.click();
        Reporter.log("Add new person payee button selected");
        return getAllpayeesCount();
    }

    /**
     * This is blank implementation for PRD
     * 
     * @return '0'
     */
    public int addCompanyPayee() {

        return 0;

    }

    /**
     * This method click on 'Person' tab to initiate on My Payees page to
     * initiate Add Person Payee flow
     */
    public void clickNewPersonPayeeTab(final WebElement element) {
        element.click();
        wait.until(ExpectedConditions.elementToBeClickable(newPayeeTab));
    }


    /**
     * This method selects the HSBC Payee from Payee Type dropdown list
     * 
     */
    public String selectHSBCDomesticPayee() {
        return selectPayeeType(payeeTypeDropdownIcon, payeeTypeList, domHSBCPayeeItem);

    }

    /**
     * This method selects the NON HSBC Payee from Payee Type dropdown list
     * 
     */
    public String selectOtherLocalBankPayee() {
        return selectPayeeType(payeeTypeDropdownIcon, payeeTypeList, otherLocalankPayeeItem);
    }

    /**
     * This method randomly selects company name from Company List
     * 
     * @return: selected Company Name
     */
    public String selectCompanyPayee() {
        String payeeName = null;
        wait.until(ExpectedConditions.visibilityOf(companyPayeeListDropdownIcon));
        companyPayeeListDropdownIcon.click();
        wait.until(ExpectedConditions.visibilityOf(companyPayeeList));
        List<WebElement> companyList = companyPayeeList.findElements(companyListLocator);
        int randomValue = RandomUtil.generateIntNumber(0, companyList.size());
        WebElement companySelected = companyList.get(randomValue);
        jsx.executeScript(AddBeneficiaryModel.SCROLL_TO_VIEW, companySelected);
        payeeName = companySelected.getText();
        companySelected.click();
        Reporter.log("Company Selected selected is " + companySelected.getText());
        return payeeName;
    }

    /**
     * This is generic method to select Payee type
     * 
     * @param dropDownIcon
     *            : Drop down Arrow Icon
     * @param list
     *            : Drop down Arrow Icon
     * @param dropDownItem
     *            : Drop down Arrow Icon
     * @param obj
     *            : Payee Type selected
     * @return
     */
    // ?? Need to check
    public String selectPayeeType(final WebElement dropDownIcon, final WebElement list, final WebElement dropDownItem) {
        dropDownIcon.click();
        wait.until(ExpectedConditions.visibilityOf(list));
        String payeeType = dropDownItem.getText();
        dropDownItem.click();
        Reporter.log("Payee type " + payeeType + " is selected");
        return payeeType;
    }

    /**
     * set International payee Type
     * 
     * @return internationalPayeeType
     */
    public String setInternationalPayeeType() {
        return AddBeneficiaryModel.INT_PAYEE_TYPE;
    }

    /**
     * set payee Type sa Company pyeee
     * 
     * @return Company Payee type
     */
    public String setCompanyPayeeType() {
        return AddBeneficiaryModel.PAYEE_TYPE_COMPANY;
    }

    /**
     * This method populates the HSBC Bank Payee details like account number
     * 
     * @param accNum
     *            : HSBC bank account number to be set in Account number field
     */
    public BankDetails enterHSBCBankDetails(final String accNum) {
        BankDetails objBankDetails = new BankDetails();
        enterDomesticAccountNumber(accNum);
        objBankDetails.setAccountNumber(accNum);
        return objBankDetails;
    }

    /**
     * This method populates Other Local bank Payee details like account number
     * Randomly generates valid account number for NON HSBC bank payee. And
     * populates in Account number field
     * 
     * @return : Account number
     */
    public BankDetails enterNonHSBCBankDetails(final String searchText) {
        BankDetails objBankDetails = new BankDetails();
        objBankDetails.setBankName(selectOtherLocalBank(searchText, localBankNameList));
        String accountNum = RandomUtil.generateIntNumber(10);
        objBankDetails.setAccountNumber(accountNum);
        enterDomesticAccountNumber(accountNum);
        objBankDetails.setAccountNumber(accountNum);
        Reporter.log("Account number entered is :" + accountNum);
        return objBankDetails;
    }

    /**
     * This method populates International bank Payee details like account
     * number & currency Randomly generates valid account number for
     * International bank payee. And selects currency from dropdown list
     * 
     * @param isOtherRequired
     *            -If true, Bank city and bank name should be 'Others'
     * @return: Account number
     */
    public BankDetails enterInternationalPayeeBankDetails(final boolean isOtherRequired) {
        BankDetails objBankDetails = new BankDetails();
        objBankDetails.setBankCntry(selectCountry(isOtherRequired));
        if (objBankDetails.getBankCntry().contains(AddBeneficiaryModel.COUNTRY_OTHER)) {
            objBankDetails.setBankCode(enterBankClearingCode());
            objBankDetails.setBankName(enterBankNameOthers());
            objBankDetails.setBankAddressFields(enterBankAdressDetails());
        } else {
            objBankDetails.setBankCity(selectCity(isOtherRequired));
            if (objBankDetails.getBankCity().contains(AddBeneficiaryModel.CITY_OTHER)) {
                objBankDetails.setBankCode(enterBankClearingCode());
                objBankDetails.setBankName(enterBankNameOthers());
                objBankDetails.setBankAddressFields(enterBankAdressDetails());
            } else {
                objBankDetails.setBankName(selectInternationalBank(isOtherRequired));
                if (objBankDetails.getBankName().contains(AddBeneficiaryModel.BANK_OTHER)) {
                    objBankDetails.setBankCode(enterBankClearingCode());
                    objBankDetails.setBankName(enterBankNameOthers());
                    objBankDetails.setBankAddressFields(enterBankAdressDetails());
                } else {
                    objBankDetails.setBankCode(null);
                }
            }
        }
        String accountNum = RandomUtil.generateIntNumber(10);
        enterInternationalAccountNumber(accountNum);
        objBankDetails.setAccountNumber(accountNum);
        Reporter.log("Account number entered is :" + accountNum);
        objBankDetails.setAccountCCY(selectCurrency(false));
        return objBankDetails;
    }

    /**
     * This method populates Bank Name field
     * 
     * @return Bank name
     */
    public String enterBankNameOthers() {
        bankName.isDisplayed();
        bankName.clear();
        bankName.sendKeys(RandomUtil.generateAlphabatic(10));
        return bankName.getText();
    }

    /**
     * This method populated Company payee details like country, company
     * reference number
     * 
     * @return objBankDetails
     */
    public BankDetails enterCompanyPayeeDetails() {
        BankDetails objBankDetails = new BankDetails();
        objBankDetails.setBankCntry(BANK_COUNTRY);
        objBankDetails.setAccountNumber(RandomUtil.generateIntNumber(10));
        companyReferenceField.isDisplayed();
        companyReferenceField.clear();
        companyReferenceField.sendKeys(objBankDetails.getAccountNumber());
        companyReferenceField.sendKeys(Keys.RETURN);
        Reporter.log("Company reference number is entered" + objBankDetails.getAccountNumber());
        return objBankDetails;
    }

    /**
     * This method randomly select the country from Country Drop down list
     * 
     * @param element
     *            : Country List
     */
    public String selectCountry(final boolean isSelectOtherCountry) {
        String bankCountry = null;
        countryListDropdownIcon.click();
        wait.until(ExpectedConditions.visibilityOf(countryList));
        List<WebElement> listings = driver.findElements(countryLocator);
        do {
            if (!isSelectOtherCountry) {
                int randomValue = RandomUtil.generateIntNumber(0, listings.size());
                WebElement countrySelected = listings.get(randomValue);
                jsx.executeScript(AddBeneficiaryModel.SCROLL_TO_VIEW, countrySelected);
                if (!countrySelected.getText().contains(AddBeneficiaryModel.COUNTRY_OTHER)
                    && !countrySelected.getText().contains(AddBeneficiaryModel.BANK_COUNTRY)) {
                    bankCountry = countrySelected.getText();
                    countrySelected.click();
                } else {
                    jsx.executeScript(AddBeneficiaryModel.SCROLL_TO_VIEW, listings.get(0));
                }
            } else {
                WebElement otherCntry = driver.findElement(otherCountryLocator);
                jsx.executeScript(AddBeneficiaryModel.SCROLL_TO_VIEW, otherCntry);
                otherCntry.click();
                Reporter.log("country selected is " + otherCntry.getText() + "");
                bankCountry = AddBeneficiaryModel.COUNTRY_OTHER;
            }
        } while (StringUtils.isEmpty(bankCountry));
        return bankCountry;
    }

    /**
     * This method randomly select the city from Country Drop down list
     * 
     * @param element
     *            : Bank City List
     * @param IsSelectOtherCity
     *            :If true, Bank city should be 'Others'
     */
    public String selectCity(final boolean isSelectOtherCity) {
        String city = null;
        intBankCityListDropdownIcon.click();
        wait.until(ExpectedConditions.visibilityOf(internationalBankCityList));
        List<WebElement> listings = internationalBankCityList.findElements(cityLocator);
        do {
            if (!isSelectOtherCity) {
                int randomValue = RandomUtil.generateIntNumber(0, listings.size());
                WebElement citySelected = listings.get(randomValue);
                jsx.executeScript(AddBeneficiaryModel.SCROLL_TO_VIEW, citySelected);
                if (!citySelected.getText().contains(AddBeneficiaryModel.CITY_OTHER)) {
                    city = citySelected.getText();
                    citySelected.click();
                } else {
                    jsx.executeScript(AddBeneficiaryModel.SCROLL_TO_VIEW, listings.get(0));
                }
            } else {
                WebElement otherCity = internationalBankCityList.findElement(otherCityLocator);
                jsx.executeScript(AddBeneficiaryModel.SCROLL_TO_VIEW, otherCity);
                otherCity.click();
                city = otherCity.getText();
            }
        } while (StringUtils.isEmpty(city));
        Reporter.log("City selected is " + city + "");
        return city;
    }

    /**
     * This method randomly select the Local Bank name from Bank Drop down list
     * 
     * @param element
     *            : Bank/Bank Branch List
     */
    public String selectOtherLocalBank(final String text, final WebElement element) {
        // chineese character is not recognized, have to read from properties
        // file
        localBankNameField.sendKeys(text);
        localBankNameListDropdownIcon.click();
        wait.until(ExpectedConditions.visibilityOf(element));
        List<WebElement> listings = element.findElements(otherLocalBankLocator);
        int randomValue = RandomUtil.generateIntNumber(0, listings.size());
        WebElement bankSelected = listings.get(randomValue);// Clicking on the
        ((JavascriptExecutor) driver).executeScript(AddBeneficiaryModel.SCROLL_TO_VIEW, bankSelected);
        bankSelected.click();
        return bankSelected.getText();

    }

    /**
     * This method randomly select the International Bank name from Bank Drop
     * down list
     * 
     * @param element
     *            : Bank/Bank Branch List
     * @param IsSelectOtherBank
     *            : If true, Bank Branch should be 'Others'
     */
    public String selectInternationalBank(final boolean isSelectOtherBank) {
        String internationalBankName;
        intlBankListDropdownIcon.click();
        wait.until(ExpectedConditions.visibilityOf(internationalBankList));
        List<WebElement> listings = driver.findElements(intBankLocator);
        if (!isSelectOtherBank) {
            int randomValue = RandomUtil.generateIntNumber(0, listings.size());
            WebElement bankSelected = listings.get(randomValue);
            jsx.executeScript(AddBeneficiaryModel.SCROLL_TO_VIEW, bankSelected);
            internationalBankName = bankSelected.getText();
            bankSelected.click();
        } else {
            WebElement otherBank = internationalBankList.findElement(otherBankLocator);
            otherBank.click();
            otherBank.sendKeys(RandomUtil.generateAlphabatic(15));
            internationalBankName = otherBank.getText();
        }
        Reporter.log("Bank selected  is  " + internationalBankName);
        return internationalBankName;
    }

    /**
     * this method populated the BCID
     * 
     * @return Bank clearing code
     */
    public String enterBankClearingCode() {
        wait.until(ExpectedConditions.visibilityOf(bankClearingCode));
        bankClearingCode.clear();
        bankClearingCode.sendKeys(AddBeneficiaryModel.BANK_CODE);
        return bankClearingCode.getText();
    }

    /**
     * This method populates the additional Bank address fields like band
     * addressLine1,addressLine2,addressLine3
     * 
     * @return bankAddress
     */
    public String enterBankAdressDetails() {
        String addLine1 = RandomUtil.generateAlphaNumericText(10);
        String addLine2 = RandomUtil.generateAlphaNumericText(10);
        String addLine3 = RandomUtil.generateAlphaNumericText(10);
        bankAdd1Field.clear();
        bankAdd1Field.click();
        bankAdd1Field.sendKeys(addLine1);
        bankAdd1Field.sendKeys(Keys.RETURN);
        bankAdd2Field.clear();
        bankAdd1Field.click();
        bankAdd2Field.sendKeys(addLine2);
        bankAdd2Field.sendKeys(Keys.RETURN);
        bankAdd3Field.clear();
        bankAdd1Field.click();
        bankAdd3Field.sendKeys(addLine3);
        bankAdd3Field.sendKeys(Keys.RETURN);
        return addLine1 + "::" + addLine2 + "::" + addLine3;

    }

    /**
     * This method randomly select the Account currency
     * 
     * @param element
     *            : Currency List
     */
    public String selectCurrency(final boolean isLocalCCY) {
        wait.until(ExpectedConditions.visibilityOf(currencyListDropDownIcon));
        currencyListDropDownIcon.click();
        wait.until(ExpectedConditions.visibilityOf(currencyList));
        List<WebElement> listings = driver.findElements(currencyLocator);
        int randomValue = RandomUtil.generateIntNumber(0, listings.size());
        WebElement ccySelected = listings.get(randomValue);
        jsx.executeScript(AddBeneficiaryModel.SCROLL_TO_VIEW, ccySelected);
        ccySelected.click();
        Reporter.log("Currency selected is " + ccySelected.getText());
        return ccySelected.getText();
    }

    /**
     * This method enters the domestic HSBC or NON HSBC Bank (Other Local bank)
     * account number
     * 
     * @param account
     *            : Account number to be populated
     */
    public void enterDomesticAccountNumber(final String account) {
        domAccountNumberField.click();
        domAccountNumberField.clear();
        domAccountNumberField.sendKeys(account);
        domAccountNumberField.sendKeys(Keys.RETURN);
        Reporter.log("Account Number Entered for new payee :" + account);

    }

    /**
     * This method enters the International Bank account number
     * 
     * @param account
     *            : Account number to be populated
     */
    public void enterInternationalAccountNumber(final String account) {
        internationalAccountNumberField.clear();
        internationalAccountNumberField.sendKeys(account);
        Reporter.log("Account Number Entered for new payee :" + account);

    }

    /**
     * Blank implementations as payee name for HSBC payee is removed from PRD
     * This method randomly generates the valid Payee name And populates the
     * Payee Personal details
     * 
     * @return
     */
    public String enterHSBCPayeeName() {
        return null;
    }

    /**
     * Blank implementations as payee name for HSBC payee is removed from PRD
     * This method randomly generates the valid Payee name And populates the
     * Payee Personal details
     * 
     * @return
     */
    public String enterPayeeName() {
        getAddPayeeDetailsBtn().click();
        String newPayeeName = RandomUtil.generateAlphaNumericText(10);
        enterPayeeName(newPayeeName);
        Reporter.log("Payee name entered is " + newPayeeName);
        return newPayeeName;
    }

    /**
     * This method enters the payee name in Payee name field
     * 
     * @param payeeName
     */
    public void enterPayeeName(final String payeeName) {
        payeeNameField.clear();
        payeeNameField.click();
        payeeNameField.sendKeys(payeeName);
        payeeNameField.sendKeys(Keys.RETURN);
        Reporter.log("Payee Name Entered for New payee :" + payeeName);
    }

    /**
     * 
     * <p>
     * <b> TThis method generates the Transaction signing code required to add
     * New payee </b>
     * </p>
     * 
     * @param profileProperties
     * @param accountNum
     *            : Payee account number
     * @param lastDigitsLength
     * @throws IOException
     */
    public void enterTDS(final Map<String, String> profileProperties, final String accountNum, final int lastDigitsLength)
        throws IOException {
        String username = profileProperties.get("userName");
        String otpKey = profileProperties.get("otpKey");
        String refAccountNumber = accountNum.substring(accountNum.length() - lastDigitsLength, accountNum.length());
        String tdsCode = tokenGenerator.getTransactionTDS(username, otpKey, refAccountNumber);
        tdsCodeField.sendKeys(tdsCode);
        Reporter.log("TDS code  Entered for new payee :" + tdsCodeField);

    }

    /**
     * This method verify 'Do not Cancel' button functionality present on
     * Confirm Cancel Pop Up
     */
    public void continueAddpayeeFlow() {
        clickCancelbutton(cancelNewPayeeButton);
        // pass 'Dont Cancel' button
        selectBtnOnCancelPopUp(dontCancelBtn);
        Reporter.log("'Dont Cancel' button is clicked on Cancel pop Up");
    }

    /**
     * This method verify ' Continue Cancel' button functionality present on
     * Confirm Cancel flow Pop Up
     */
    public void cancelAddpayeeFlow() {
        clickCancelbutton(cancelNewPayeeButton);
        // pass 'Confirm cancel' button
        selectBtnOnCancelPopUp(confirmCancelButton);
        Reporter.log(" 'Confrim' button is clicked on  Cancel Pop up clicked.");
    }

    /**
     * This method clicks on 'Cancel Button' on Add Payees page
     * 
     * @param element
     *            : Cancel Button
     */
    public void clickCancelbutton(final WebElement element) {
        wait.until(ExpectedConditions.elementToBeClickable(element));
        element.click();
        Reporter.log("Cancel Button on Add payee page is clicked clicked.");
    }

    /**
     * This element click on 'Continue Cancel'/'Do Not Cancel' button on cancel
     * pop up
     * 
     * @param element
     *            : Button to be clicked
     */
    public void selectBtnOnCancelPopUp(final WebElement element) {
        wait.until(ExpectedConditions.elementToBeClickable(element));
        element.click();
        wait.until(ExpectedConditions.visibilityOf(linkMyBanking));
        Reporter.log("On cancellation  user is redirected to dashboard poge");
    }

    /**
     * This method clicks 'Save' button to complete Add Neww payee flow
     */
    public void clickSavebutton() {
        wait.until(ExpectedConditions.elementToBeClickable(saveDetailsBtn));
        saveDetailsBtn.click();
        Reporter.log("Save button clicked.");
    }

    /**
     * This method verify success/fail message displayed on My Payees page on
     * completing the add New payee flow
     * 
     * @param payeeName
     *            : Newly added payee name
     */
    public void verifySucessMessage(final AddBeneficiaryDetails addBeneficiaryDetails) {
        wait.until(ExpectedConditions.visibilityOf(confirmPayeeMsg));
        Assert.assertTrue(confirmPayeeMsg.getText().contains(AddBeneficiaryModel.SUCCESS_MSG)
            && confirmPayeeMsg.getText().contains(addBeneficiaryDetails.getPayeeName()),
            "Payee " + addBeneficiaryDetails.getPayeeName() + " is not sucessfully added");
        Reporter.log("Payee " + addBeneficiaryDetails.getPayeeName() + " is  sucessfully added");
    }

    /**
     * This method validates if Newly added payee is successfully added to All
     * payees list And All payees count is incremented by '1'
     * 
     * @param name
     *            : Name of newly added payee
     * @param accNum
     *            : Account number of newly added payee
     * @param payeeCnt
     *            : Count before new payee is added
     */
    public void searchNewlyAddedPayee(final String name, final String accNum, final int payeeCnt) {
        wait.until(ExpectedConditions.visibilityOf(myPayeesPageTitle));
        List<WebElement> payeeListRows = driver.findElements(By.xpath("//*[contains(text(),'" + name + "')]"));
        if (!payeeListRows.isEmpty()) {
            Reporter.log("Newly added payee name is present in All payees list");
            Assert.assertTrue(getAllpayeesCount() == payeeCnt + 1, "All Payees count is NOT updated");
            Reporter.log("All Payees count is incremented");
        } else {
            Assert.fail("Newly added Payee not found in list.");
        }
    }

    public String enterPayeeAddressDetails() {
        return null;
    }

    public void clickConfirmOnReviewPage() {

    }

    /**
     * This method returns the count for All payees currently present on My
     * payees page
     * 
     * @return: All payees current count
     */
    public int getAllpayeesCount() {
        String payeeCountText = payeesCount.getText();
        return Integer.parseInt(payeeCountText.substring(payeeCountText.indexOf('(') + 1, payeeCountText.lastIndexOf(')')));
    }

    /**
     * This is blank implementation as confirm dialog is not displayed for PRD
     */
    public void closeConfirmDialog() {

    }

    /**
     * This is blank implementation as Review page is not displayed for PRD
     */
    public void verifyPayeeReviewPage(final AddBeneficiaryDetails objAddDetails) {

    }

    /**
     * POM methods for story- 40- Add Beneficiary------------Ends
     */

    /**
     * POM methods for story- 41- Manage Beneficiary------------Starts
     */
    /**
     * This method verify if Payees on My payees page are displayed in
     * alphabetic order
     */
    public void isPayeeListOrdered() {
        wait.until(ExpectedConditions.visibilityOf(allPayeesTable));
        Assert.assertTrue(sortPayeeList(), "Payee names are NOT displayed in Alphabetic Order");
        Reporter.log("Payee names are  displayed correctly in Alphabetic Order");
    }

    /**
     * This method randomly select payee from All payees List
     * 
     * @param element
     *            : Payee List
     * @return payeeName
     */
    public WebElement selectPayee() {
        List<WebElement> allPayeeRows = allPayeesTable.findElements(By.tagName("tr"));
        int randomValue = RandomUtil.generateIntNumber(0, allPayeeRows.size());
        WebElement payeeSelected = allPayeeRows.get(randomValue);
        Actions builder = new Actions(driver);
        builder.moveToElement(payeeSelected).build().perform();
        Reporter.log("Payee selected  is " + payeeSelected.getText());
        return payeeSelected;
    }

    public void verifyPayeeDetails(final WebElement payeeRow) {
        wait.until(ExpectedConditions.visibilityOf(payeePageTitle));
        String payeeType = payeeRow.findElement(locatorPayeeType).getAttribute("alt");
        List<WebElement> country = payeeRow.findElements(payeeCountry);
        if (payeeType.equalsIgnoreCase(AddBeneficiaryModel.COMPANY_PAYEE) && !country.isEmpty()) {
            Reporter.log("Selected Payee is Company payee");
            verifyCompanyPayeeDetails(payeeRow);
        } else if (payeeType.equalsIgnoreCase(AddBeneficiaryModel.PERSON_PAYEE) && !country.isEmpty()) {
            Reporter.log("Selected Payee is  domestic HSBC bank payee");
            verifyHSBCPersoPayeeDetails(payeeRow);
        } else {
            verifyPersonPayeeDetails(payeeRow);
            Reporter.log("Selected Payee is  NON HSBC Bank  payee");
        }
    }

    /**
     * This method verify Company Payee details displayed when View button is
     * clicked
     * 
     * @param payeeName
     */
    public void verifyCompanyPayeeDetails(final WebElement element) {
        String displayName = element.findElement(payeeName).getText();
        String displayAccNumber = element.findElement(accNumber).getText();
        WebElement button = element.findElement(viewButton);
        button.isEnabled();
        button.click();
        wait.until(ExpectedConditions.visibilityOf(companyPayeeDetailsView));
        String name = verifyPayeeNameField(companyPayeeDetailsView, LABEL_PAYEE_NAME);
        Assert.assertTrue(displayName.equals(name), "Company  payee name is NOT  matched in Details pane");
        Reporter.log("Company payee name " + name + " is  displayed and matched");
        Assert.assertTrue(displayAccNumber.equals(accNumber), "Company payee account number is NOT matched in Details pane");
        Reporter.log("Company payee account number  " + accNumber + " is  displayed");
        Assert.assertTrue(companyPayeeDetailsView.findElement(closeButton).isEnabled(), "Close button is NOT enabled");
        companyPayeeDetailsView.findElement(closeButton).click();
    }

    public void verifyHSBCPersoPayeeDetails(final WebElement element) {
        String displayName = element.findElement(payeeName).getText();
        WebElement viewButtonElement = element.findElement(viewButton);
        viewButtonElement.isEnabled();
        viewButtonElement.click();
        wait.until(ExpectedConditions.visibilityOf(personPayeeDetailsView));
        String name = verifyPayeeNameField(personPayeeDetailsView, LABEL_PAYEE_NAME);
        Assert.assertTrue(displayName.equals(name), "Person payee name is NOT  matched in Details pane");
        verifyField(personPayeeDetailsView, accountNumberField, accountNumbervalue);
        verifyField(personPayeeDetailsView, accountCCYField, accountCCYValue);
        personPayeeDetailsView.findElement(closeButton).click();
    }

    /**
     * This method verify HSBC bank Payee details displayed when View button is
     * clicked
     * 
     * @param payeeName
     */
    public void verifyPersonPayeeDetails(final WebElement element) {
        String displayName = element.findElement(payeeName).getText();
        WebElement button = element.findElement(viewButton);
        button.isEnabled();
        button.click();
        wait.until(ExpectedConditions.visibilityOf(personPayeeDetailsView));
        String name = verifyPayeeNameField(personPayeeDetailsView, LABEL_PAYEE_NAME);
        Assert.assertTrue(displayName.equals(name), "Person payee name is NOT  matched in Details pane");
        verifyField(personPayeeDetailsView, addressFieldLabel, addressFieldValue);
        verifyField(personPayeeDetailsView, bankCodeField, bankCodeValue);
        verifyField(personPayeeDetailsView, accountNumberField, accountNumbervalue);
        verifyField(personPayeeDetailsView, accountCCYField, accountCCYValue);
        verifyField(personPayeeDetailsView, bankNameField, bankNameValue);
        verifyField(personPayeeDetailsView, bankAddField, bankAddvalue);
        personPayeeDetailsView.findElement(closeButton).click();
    }

    public String verifyPayeeNameField(final WebElement elem, final String label) {
        WebElement payeeDetails = elem.findElement(By.xpath("//following::dt[text()='" + label + "']//following-sibling::dd"));
        Assert.assertTrue(payeeDetails.isDisplayed(), "Payee  details for " + label + " is  not displayed ");
        Reporter.log("Field " + label + " is present and value is :" + payeeDetails.getText());
        return payeeDetails.getText();
    }

    public void verifyField(final WebElement elem, final By label, final By value) {
        Assert.assertTrue(elem.findElement(label).isDisplayed(), "Label not dispalyed ");
        Assert.assertTrue(elem.findElement(value).isDisplayed(), "Value against label   not dispalyed  ");
        Reporter.log("Value for label " + elem.findElement(label).getText() + "is " + elem.findElement(value).getText());
    }

    /**
     * This method cancels the Delete Payee flow by clicking on 'Cancel' button
     * on confirm pop Up
     * 
     * @param payeeName
     */
    public void cancelDeletePayee(final WebElement payeeRow) {
        String displayName = payeeRow.findElement(payeeName).getText();
        WebElement deleteBtn = payeeRow.findElement(deleteButton);
        deleteBtn.isEnabled();
        deleteBtn.click();
        wait.until(ExpectedConditions.visibilityOf(delPayeeDialog));
        if (displayName.equalsIgnoreCase(getPayeeNameOnDialog().getText())) {
            Reporter.log("Payee Name is present on delete popup");
        } else {
            Reporter.log("Payee Name is not present on delete popup");
        }
        delPayeeDialog.findElement(cancelBtnOnDialog).click();
        wait.until(ExpectedConditions.not(ExpectedConditions.visibilityOf(delPayeeDialog)));
        Reporter.log("Delete Payee flow is Cancelled");
    }


    /**
     * This method cancels the Delete Payee flow by clicking on 'Cancel' button
     * on confirm pop Up
     * 
     * @param payeeName
     */
    public void cancelDeletePayee(final AccountDetails accountDetail) {
        List<WebElement> payeeRows = driver.findElements(locatorAllPayeesRow);
        for (WebElement payeeRow : payeeRows) {
            jsx.executeScript(AddBeneficiaryModel.SCROLL_TO_VIEW, payeeRow);
            String personPayeeName = payeeRow.findElement(locatorPayeeName).getText();
            WebElement deleteBtn = payeeRow.findElement(deleteButton);
            if (personPayeeName.equalsIgnoreCase(accountDetail.getAccountName())) {
                wait.until(ExpectedConditions.elementToBeClickable(deleteBtn));
                deleteBtn.click();
                wait.until(ExpectedConditions.visibilityOf(delPayeeDialog));
                if (personPayeeName.equalsIgnoreCase(getPayeeNameOnDialog().getText())) {
                    Reporter.log("Payee Name is present on delete popup");
                } else {
                    Reporter.log("Payee Name is not present on delete popup");
                }
                delPayeeDialog.findElement(cancelBtnOnDialog).click();
                wait.until(ExpectedConditions.visibilityOf(payeeRow));
                Reporter.log("Delete Payee flow is Cancelled");
                break;
            }
        }
    }


    public void cancelCompanyPayeeWithFutureTransaction() {
        wait.until(ExpectedConditions.visibilityOf(deletePayeeWithFuturePaymentDialogs.get(DEFAULT_LIST_STARTING_INDEX)));
        wait.until(ExpectedConditions.elementToBeClickable(cancelButtonDeletePayeeWithFuturePaymentDialog));
        cancelButtonDeletePayeeWithFuturePaymentDialog.click();
        Assert.assertTrue(myPayeesPageTitle.isDisplayed(), "My Payees page is not displayed.");
    }

    public void viewPaymentsCompanyPayeeWithFutureTransaction() {
        wait.until(ExpectedConditions.visibilityOf(deletePayeeWithFuturePaymentDialogs.get(DEFAULT_LIST_STARTING_INDEX)));
        wait.until(ExpectedConditions.elementToBeClickable(viewPaymentButtonDeletePayeeWithFuturePaymentDialog));
        viewPaymentButtonDeletePayeeWithFuturePaymentDialog.click();
    }

    /**
     * This method cancels the Delete Payee flow by clicking on 'Ok To Delete'
     * button on confirm pop Up
     * 
     * @param payeeName
     */
    public void deletePayee(final WebElement element) {
        String displayName = element.findElement(payeeName).getText();
        int beforeCnt = getAllpayeesCount();
        WebElement button = element.findElement(deleteButton);
        button.isEnabled();
        button.click();
        wait.until(ExpectedConditions.visibilityOf(delPayeeDialog));
        if (displayName.equalsIgnoreCase(getPayeeNameOnDialog().getText())) {
            Reporter.log("Payee Name is  present on delete popup");
        } else {
            Reporter.log("Payee Name is not present on delete popup");
        }
        delPayeeDialog.findElement(deletBtnOnDialog).isEnabled();
        delPayeeDialog.findElement(deletBtnOnDialog).click();
        wait.until(ExpectedConditions.visibilityOf(sucessMsg));
        String payeeDeleted = deletedPayeeName.getText().substring(1, deletedPayeeName.getText().length() - 1);
        Assert.assertTrue(displayName.equalsIgnoreCase(payeeDeleted),
            "Payee name dispalyed in sucess message is not the correct payee");
        Reporter.log("Payee Name " + deletedPayeeName.getText() + "is  present in sucess message");
        Assert.assertTrue(getAllpayeesCount() == beforeCnt - 1, "All Payees count is NOT updated");
        Reporter.log("All Payees count is decremented:" + getAllpayeesCount());
    }


    public void deletePayee(final AccountDetails accountDetail) {
        List<WebElement> payeeRows = driver.findElements(locatorAllPayeesRow);
        for (WebElement payeeRow : payeeRows) {
            jsx.executeScript(AddBeneficiaryModel.SCROLL_TO_VIEW, payeeRow);
            String personPayeeName = payeeRow.findElement(locatorPayeeName).getText();
            WebElement deleteBtn = payeeRow.findElement(deleteButton);
            if (personPayeeName.equalsIgnoreCase(accountDetail.getAccountName())) {
                wait.until(ExpectedConditions.elementToBeClickable(deleteBtn));
                deleteBtn.click();
                wait.until(ExpectedConditions.visibilityOf(delPayeeDialog));
                if (personPayeeName.equalsIgnoreCase(getPayeeNameOnDialog().getText())) {
                    Reporter.log("Payee Name is  present on delete popup");
                } else {
                    Reporter.log("Payee Name is not present on delete popup");
                }
                delPayeeDialog.findElement(deletBtnOnDialog).isEnabled();
                delPayeeDialog.findElement(deletBtnOnDialog).click();
                break;
            }
        }
    }

    public void deletionSuccess(AddBeneficiaryDetails beneDetails, AccountDetails accountDetail) {
        wait.until(ExpectedConditions.visibilityOf(sucessMsg));
        String payeeDeleted = deletedPayeeName.getText().substring(1, deletedPayeeName.getText().length() - 1);
        Assert.assertTrue(accountDetail.getAccountName().equalsIgnoreCase(payeeDeleted),
            "Payee name dispalyed in sucess message is not the correct payee");
        Reporter.log("Payee Name " + deletedPayeeName.getText() + "is  present in sucess message");
        Assert.assertTrue(getAllpayeesCount() == beneDetails.getPayeeCount() - 1, "All Payees count is NOT updated");
        Reporter.log("All Payees count is decremented:" + getAllpayeesCount());
    }

    /**
     * 
     * @param payeeName
     * @return : Flag if payee name passed is displayed on My payees page
     */
    public boolean isPayeeeDisplayed(final String payeeName) {
        return driver.findElements(
            By.xpath(".//div[@class='gridxBody gridxBodyRowHoverEffect'  and @data-dojo-attach-point='bodyNode']//*[text()='"
                + payeeName + "']")).size() >= 1;
    }

    /**
     * This method clicks on Pay button for payee passed Verify if user is
     * navigated to MM page with payee already selected in 'Transfer To' field
     * 
     * @param payeeName
     */
    public AccountDetails payToSelectedPayee(final WebElement element) {
        AccountDetails payeeDetails = new AccountDetails();
        payeeDetails.setAccountName(element.findElement(payeeName).getText());
        payeeDetails.setAccountNumber(element.findElement(accNumber).getText());
        WebElement payBtnElement = element.findElement(payButton);
        payBtnElement.isEnabled();
        payBtnElement.click();
        return payeeDetails;
    }

    public AccountDetails payToSelectedPayee(final AccountDetails accountDetail) {
        List<WebElement> payeeRows = driver.findElements(locatorAllPayeesRow);
        for (WebElement payeeRow : payeeRows) {
            jsx.executeScript(AddBeneficiaryModel.SCROLL_TO_VIEW, payeeRow);
            String personPayeeName = payeeRow.findElement(locatorPayeeName).getText();
            WebElement payBtnElement = payeeRow.findElement(payButton);
            if (personPayeeName.equalsIgnoreCase(accountDetail.getAccountName())) {
                payBtnElement.isEnabled();
                payBtnElement.click();
                break;
            }
        }
        return accountDetail;
    }

    /**
     * This method validates the message displayed when User has no payee added
     * on My payees page
     */
    public void verifyIfNoPayeePresent() {
        wait.until(ExpectedConditions.visibilityOf(payeePageTitle));
        if (alertMessageWhenNoPayee.isDisplayed()) {
            Assert.assertTrue(alertMessageWhenNoPayee.isDisplayed(), "Alert message " + alertMessageWhenNoPayee.getText()
                + " for no payees  is NOT displayed correctly in myPayees Tab");
            Reporter.log("Alert message for " + alertMessageWhenNoPayee.getText()
                + "  no payees  is NOT displayed correctly in myPayees Tab");
        }
        if (!personTabsPayees.isEmpty() && personTabsPayees.get(DEFAULT_LIST_STARTING_INDEX).isDisplayed()) {
            personTabsPayees.get(DEFAULT_LIST_STARTING_INDEX).click();
            Assert.assertTrue(alertMessageWhenNoPayee.isDisplayed(), "Alert message  " + alertMessageWhenNoPayee.getText()
                + " for no Person payees  is NOT displayed correctly in myPayees Tab");
            Reporter.log("Alert message " + alertMessageWhenNoPayee.getText()
                + "  no Person payees  is NOT displayed correctly in myPayees Tab");
        }
        if (!companyTabsPayees.isEmpty() && companyTabsPayees.get(DEFAULT_LIST_STARTING_INDEX).isDisplayed()) {
            companyTabsPayees.get(DEFAULT_LIST_STARTING_INDEX).click();
            Assert.assertTrue(alertMessageWhenNoPayee.isDisplayed(), "Alert message " + alertMessageWhenNoPayee.getText()
                + "   for no Company payees  is NOT displayed correctly in myPayees Tab");
            Reporter.log("Alert message for" + alertMessageWhenNoPayee.getText()
                + "   no Comapny  payees  is NOT displayed correctly in myPayees Tab");
        }

    }

    /**
     * This method compares the Original payee list with sorted Payee list on
     * basis of Payee names
     * 
     * @return: flag- 'true' if Default Payee list is in sorted order
     */
    public boolean sortPayeeList() {
        boolean isSorted = true;
        List<String> sortedList = new ArrayList<>();
        for (WebElement payeeRow : allPayeesNamesList) {
            sortedList.add(payeeRow.getText());
        }
        Collections.sort(sortedList);
        for (int i = 0; i < allPayeesNamesList.size(); i++) {
            if (!allPayeesNamesList.get(i).getText().equals(sortedList.get(i))) {
                isSorted = false;
                break;
            }
        }
        return isSorted;
    }

    private boolean isValidAccount(final boolean domesticAccount, final String entity, final String accountlocation) {
        return domesticAccount && accountlocation.equalsIgnoreCase(entity) || !domesticAccount
            && !accountlocation.equalsIgnoreCase(entity);
    }

    private boolean isValidCurrency(final boolean domesticCurrency, final String accountCurrency, final String entityCurrency) {
        return (domesticCurrency && accountCurrency.equalsIgnoreCase(entityCurrency))
            || (!domesticCurrency && !accountCurrency.equalsIgnoreCase(entityCurrency));
    }

    protected boolean isValidPayee(final boolean domesticAccount, final boolean domesticCurrency, final String entity,
        final String entityCurrency, final String payeeCountry, final String payeeCurrency) {
        return isValidAccount(domesticAccount, entity, payeeCountry)
            && isValidCurrency(domesticCurrency, payeeCurrency, entityCurrency);
    }


    protected List<AccountDetails> validPersonPayeeDetails(final String entityCurrency, final boolean domesticHSBCPayee,
        final boolean domesticAccount, final boolean domesticCurrency) {
        List<AccountDetails> storeAccountValue = new ArrayList<>();
        String entity = getEntityBankCountry();
        List<WebElement> payeeList = driver.findElements(locatorAllPayeesRow);
        for (WebElement payee : payeeList) {
            jsx.executeScript(AddBeneficiaryModel.SCROLL_TO_VIEW, payee);
            if (payee.findElement(locatorPayeeType).getAttribute("alt").equalsIgnoreCase(AddBeneficiaryModel.PERSON_PAYEE)) {
                String personPayeeName = payee.findElement(locatorPayeeName).getText();
                WebElement btnView = payee.findElement(locatorViewPayee);
                wait.until(ExpectedConditions.elementToBeClickable(btnView));
                btnView.click();
                wait.until(ExpectedConditions.visibilityOf(payee.findElement(locatorManagePerson)));
                WebElement elemManagePerson = payee.findElement(locatorManagePerson);
                String personPayeeBankCountry = domesticHSBCPayee ? payee.findElement(locatorPayeeCountry).getText() : (String) jsx
                    .executeScript(AddBeneficiaryModel.GET_HIDDEN_TEXT, elemManagePerson.findElement(locatorPayeeBankCountry));
                String personPayeeNumber = elemManagePerson.findElement(locatorPayeeAccountNumber).getText();
                String personPayeeCurrency = elemManagePerson.findElement(locatorPayeeCurrency).getText();
                if (isValidPayee(domesticAccount, domesticCurrency, entity, entityCurrency, personPayeeBankCountry,
                    personPayeeCurrency) && !personPayeeBankCountry.trim().isEmpty()) {
                    AccountDetails accountDetails = addPayeeAccountInformation(personPayeeName, personPayeeNumber,
                        personPayeeBankCountry, personPayeeCurrency);
                    storeAccountValue.add(accountDetails);
                }
            }
        }
        return storeAccountValue;
    }

    protected AccountDetails addPayeeAccountInformation(final String personPayeeName, final String personPayeeNumber,
        final String personPayeeBankCountry, final String personPayeeCurrency) {
        AccountDetails accountInformations = new AccountDetails();
        accountInformations.setAccountName(personPayeeName);
        accountInformations.setAccountNumber(personPayeeNumber);
        accountInformations.setAccountCountry(personPayeeBankCountry);
        accountInformations.setCurrency(personPayeeCurrency);
        return accountInformations;
    }

    protected AccountDetails selectPersonPayeeFromPersonPayeeList(final String entityCurrency, final boolean domesticHSBCPayee,
        final boolean domesticAccount, final boolean domesticCurrency) {
        List<AccountDetails> payeeList = validPersonPayeeDetails(entityCurrency, domesticHSBCPayee, domesticAccount,
            domesticCurrency);
        int index = RandomUtil.generateIntNumber(AddBeneficiaryModel.DEFAULT_LIST_STARTING_INDEX, payeeList.size());
        Assert.assertTrue(index >= AddBeneficiaryModel.DEFAULT_LIST_STARTING_INDEX, "No Payees found.");
        return payeeList.get(index);
    }

    public AccountDetails selectPersonIEPayeeFromPersonIEPayeeList(final String entityCurrency, final boolean domesticHSBCPayee,
        final boolean domesticAccount, final boolean domesticCurrency) {
        return null;
    }


    protected List<AccountDetails> validCompanyPayeeDetails() {
        List<AccountDetails> storeAccountValue = new ArrayList<>();
        storeAccountValue.clear();
        List<WebElement> payeeList = driver.findElements(locatorAllPayeesRow);
        if (!payeeList.isEmpty()) {
            for (WebElement payee : payeeList) {
                jsx.executeScript(AddBeneficiaryModel.SCROLL_TO_VIEW, payee);
                if (payee.findElement(locatorPayeeType).getAttribute("alt").equalsIgnoreCase(AddBeneficiaryModel.COMPANY_PAYEE)) {
                    String companyPayeeName = payee.findElement(locatorCompanyPayeeName).getText();
                    String companyPayeeNumber = payee.findElement(locatorCompanyPayeeNumber).getText();
                    AccountDetails accountInformations = new AccountDetails();
                    accountInformations.setAccountName(companyPayeeName);
                    accountInformations.setAccountNumber(companyPayeeNumber);
                    storeAccountValue.add(accountInformations);
                }
            }
        }
        return storeAccountValue;
    }

    public AccountDetails selectCompanyPayeeFromCompanyPayeeList() {
        List<AccountDetails> payeeList = validCompanyPayeeDetails();
        int index = RandomUtil.generateIntNumber(AddBeneficiaryModel.DEFAULT_LIST_STARTING_INDEX, payeeList.size());
        Assert.assertTrue(index >= AddBeneficiaryModel.DEFAULT_LIST_STARTING_INDEX, "No Payees found.");
        return payeeList.get(index);
    }

    public AccountDetails domesticHSBCPersonLCYPayees(final String entityCurrency) {
        wait.until(ExpectedConditions.visibilityOf(payeePageTitle));
        return selectPersonPayeeFromPersonPayeeList(entityCurrency, true, true, true);
    }

    public AccountDetails domesticHSBCPersonIELCYPayees(final String entityCurrency) {
        AccountDetails acc = new AccountDetails();
        return acc;
    }


    public AccountDetails domesticHSBCPersonFCYPayees(final String entityCurrency) {
        wait.until(ExpectedConditions.visibilityOf(payeePageTitle));
        return selectPersonPayeeFromPersonPayeeList(entityCurrency, true, true, false);
    }

    public AccountDetails domesticCompanyPayees() {
        wait.until(ExpectedConditions.visibilityOf(payeePageTitle));
        return selectCompanyPayeeFromCompanyPayeeList();
    }

    public AccountDetails internationalHSBCPersonLCYPayees(final String entityCurrency) {
        wait.until(ExpectedConditions.visibilityOf(payeePageTitle));
        return selectPersonPayeeFromPersonPayeeList(entityCurrency, false, false, true);
    }

    public AccountDetails internationalHSBCPersonFCYPayees(final String entityCurrency) {
        wait.until(ExpectedConditions.visibilityOf(payeePageTitle));
        return selectPersonPayeeFromPersonPayeeList(entityCurrency, false, false, false);
    }

    public AccountDetails nonHSBCPersonLCYPayees(final String entityCurrency) {
        wait.until(ExpectedConditions.visibilityOf(payeePageTitle));
        return selectPersonPayeeFromPersonPayeeList(entityCurrency, false, true, true);
    }

    public AccountDetails nonHSBCPersonFCYPayees(final String entityCurrency) {
        wait.until(ExpectedConditions.visibilityOf(payeePageTitle));
        return selectPersonPayeeFromPersonPayeeList(entityCurrency, false, true, false);
    }


    protected List<AccountDetails> validPersonPayeeDetailsIETransfer(final String entityCurrency, final boolean domesticHSBCPayee,
        final boolean domesticAccount, final boolean domesticCurrency) {

        return null;
    }

    protected AccountDetails addPayeeAccountInformation_new(final String personPayeeName) {
        AccountDetails acc = new AccountDetails();
        return acc;
    }


    /**
     * POM methods for story 41- Manage beneficiary -----------ENDS
     * 
     **/

}
