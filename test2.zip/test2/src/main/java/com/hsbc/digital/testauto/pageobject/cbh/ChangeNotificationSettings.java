/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.cbh;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.pageobject.ChangeNotificationSettingsModel;

/**
 * <p><b>
 * TODO : Insert description of the class's responsibility/role.
 * </b></p>
 */
public class ChangeNotificationSettings extends ChangeNotificationSettingsModel {


    @FindBy(xpath = "//button[@class='btnSecondary']")
    private WebElement subscribeButton;

    @FindBy(xpath = "//div[not(contains(@class,'nodisplay'))]/button[text()='Unsubscribe']")
    private List<WebElement> unSubscribeButtonList;

    @FindBy(xpath = "//div[@id='dapAccountsPopupDropDown_menu']/table/tbody/tr")
    private List<WebElement> accountDropDownList;

    @FindBy(xpath = "//input[@value='Minimum Balance']")
    private WebElement minimumBalanceCheckBox;

    @FindBy(xpath = "//input[@value='Debit Amount']")
    private WebElement debitAmountCheckBox;

    @FindBy(xpath = "//input[@value='Credit Amount']")
    private WebElement creditAmountCheckBox;

    @FindBy(xpath = "//div//p[@class='externalLabel' and contains(text(),'Maximum Balance')]/parent::div/following-sibling::div//input[contains(@id,'CurrencyTextBox')]")
    private WebElement maxBalanceTextField;

    @FindBy(xpath = "//div//p[@class='externalLabel' and contains(text(),'Minimum Balance')]/parent::div/following-sibling::div//input[contains(@id,'CurrencyTextBox')]")
    private WebElement minBalanceTextField;

    @FindBy(xpath = "//div//p[@class='externalLabel' and contains(text(),'Debit Amount')]/parent::div/following-sibling::div//input[contains(@id,'CurrencyTextBox')]")
    private WebElement debitAmountTextField;

    @FindBy(xpath = "//div[contains(@id,'ContentPane')]//button[text()='Cancel']")
    private WebElement cancleButton;

    @FindBy(xpath = "//div[@data-dojo-attach-point='containerNode']//a[text()='Yes - cancel']")
    private WebElement yesCancleButton;

    @FindBy(xpath = " //span[text()='Move money' and @title='Move money']")
    private WebElement moveMoneyButton;

    @FindBy(xpath = "//div[contains(@id,'TemplatedMixin')]//a[contains(text(),'Edit personal')]")
    private WebElement editPersonelDetailsLink;

    @FindBy(xpath = "//h2[contains(text(),'Edit personal')]")
    private WebElement editPersonelDetailsHeading;

    @FindBy(xpath = "//input[contains(@id,'TermsAndConditions')]")
    private WebElement termsAndConditionCheckBox;

    @FindBy(xpath = "//span[contains(@class,'TermsAndConditions')]")
    private WebElement termsAndConditionLink;

    @FindBy(xpath = "//button[text()='Close']")
    private WebElement closeTermsAndConditionButton;

    @FindBy(xpath = " //div[contains(@class,'DialogPaneContent')]//button[text()='Save']")
    private WebElement saveButtonopoUp;

    @FindBy(xpath = "// button[@data-dojo-attach-point='submitBtn']")
    private WebElement saveButton;

    @FindBy(xpath = "//div[contains(@class,'confirmation')]//p")
    private WebElement confirmationMessage;

    public ChangeNotificationSettings(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    public void selectAccount() {
        accountDropDownIcon.click();
        if (!accountDropDownList.isEmpty()) {
            int selectedElementNumber = RandomUtil.generateIntNumber(1, accountDropDownList.size());
            for (int count = 0; count < accountDropDownList.size(); count++) {
                WebElement tempAccDropDown = accountDropDownList.get(count);
                if (count == selectedElementNumber) {
                    Reporter.log("Account Selected:" + tempAccDropDown.getText());
                    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", tempAccDropDown);
                    tempAccDropDown.click();
                    break;
                }
            }
        } else {
            Assert.fail("No Accounts Avialable to Select");
        }
    }

    public void subscribeAlerts() {
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        if (!unSubscribeButtonList.isEmpty()) {
            for (WebElement btn : unSubscribeButtonList) {
                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", btn);
                btn.click();
            }
        }
        subscribeButton.click();
        selectAccount();
        Assert.assertTrue(minimumBalanceCheckBox.isDisplayed(), "Minimum Balance Check Box is not Displayed");
        if (!(minimumBalanceCheckBox.getAttribute("checked") == "checked")) {
            minimumBalanceCheckBox.click();
            Reporter.log("Minumum Balance Check Box is Clicked");
        }
        if (!(debitAmountCheckBox.getAttribute("checked") == "checked")) {
            debitAmountCheckBox.click();
            Reporter.log("debit amount Check Box is Clicked");
        }
        saveButtonopoUp.click();
        Reporter.log("Save button on pop up is clicked");
        captureNotificationDetails();
        selectTermsAndCondition();
        saveButton.click();
        Reporter.log("Save button on is clicked");
        verifyConfirmationMessage();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    }

    public void verifyCancelFlowForSubscribeAlerts() {
        Assert.assertTrue(cancleButton.isDisplayed(), "Cancel button is not displayed");
        cancleButton.click();
        Reporter.log("Cancel button clicked");
        Assert.assertTrue(yesCancleButton.isDisplayed(), "Cancellation pop up is not displayed");
        yesCancleButton.click();
        Reporter.log("Yes - Cancel button clicked");
        Assert.assertTrue(moveMoneyButton.isDisplayed(), "User not nagigated to Dashboard page after cancellling the flow");
        Reporter.log("Navigated to Dashboard flow after cancelling the flow");
    }

    public void verifyEditPersonelDetailsPage() {
        editPersonelDetailsLink.click();
        Assert.assertTrue(editPersonelDetailsHeading.isDisplayed(), "Edit Personal Details page is not displayed");
        Reporter.log("Navigated to Edit Personal Details from Notification Setting Page");

    }

    public void selectTermsAndCondition() {
        Assert.assertTrue(termsAndConditionCheckBox.isDisplayed(), "Terms and Condition check box is not displayed");
        termsAndConditionCheckBox.click();
        Reporter.log("Terms and Condition check box is clicked");
    }

    public void captureNotificationDetails() {
        Assert.assertTrue(maxBalanceTextField.isDisplayed(), "Maximum Balance field is not displayed");
        maxBalanceTextField.sendKeys(String.valueOf(RandomUtil.generateIntNumber(10000, 100000)));
        Reporter.log("Value is entered in Maximum Amount");
        Assert.assertTrue(minBalanceTextField.isDisplayed(), "Minimum Balance field is not displayed");
        minBalanceTextField.sendKeys(String.valueOf(RandomUtil.generateIntNumber(1, 10)));
        Reporter.log("Value is entered in Maximum Amount");
        Assert.assertTrue(debitAmountTextField.isDisplayed(), "Debit Amount field is not displayed");
        debitAmountTextField.sendKeys(String.valueOf(RandomUtil.generateIntNumber(12, 1000)));
        Reporter.log("Value is entered in Maximum Amount");
    }

    public void verifyConfirmationMessage() {
        Assert.assertTrue(confirmationMessage.isDisplayed(), "confirmation message is not displayed");
        Reporter.log("Confirmation message is displayed as " + confirmationMessage.getText());
    }

    public void verifyTermsAndConditionPopUp() {
        Assert.assertTrue(termsAndConditionLink.isDisplayed(), "Terms and Condition link is not displayed");
        termsAndConditionLink.click();
        Reporter.log("Terms and Condition link is clicked");
        Assert.assertTrue(closeTermsAndConditionButton.isDisplayed(), "Terms and Condition pop up is not displayed");
        closeTermsAndConditionButton.click();
        Reporter.log("Clicked on Close button Terms and Condition po up");
        Assert.assertTrue(termsAndConditionLink.isDisplayed(), "Terms and Condition pop up is not closed");
        Reporter.log("Terms and Condition pop up is closed");
    }

}
