/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.listeners;

import java.lang.reflect.Method;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.TestListenerAdapter;

import com.hsbc.digital.testauto.library.ScreenShot;

/**
 * <br>
 * Custom Listener for Test Cases to Log Additional Results and Screen shots
 * for Reporting purpose.</b>
 * 
 * @version 1.0.0
 * @author Rishabhkumar Singh
 * 
 */
public class TestCaseListener extends TestListenerAdapter {

    /**
     * Method name constant which will return driver object instance for
     * current script. <br>
     * Need to be present in All scripts.
     */
    private static final String DRIVER_METHOD_NAME = "getDriver";

    /**
     * Logger Utility for loggin as per Apache Logger in Separate Log file for
     * project. <br>
     * Need to be present in all classes.
     */
    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(TestCaseListener.class);

    @Override
    public void onTestStart(final ITestResult tr) {
        TestCaseListener.logger.info("Test method name:" + tr.getName());
        TestCaseListener.logger.info("Test Started....");
    }

    @Override
    public void onTestSuccess(final ITestResult tr) {
        TestCaseListener.logger.info("Test '" + tr.getName() + "' PASSED");
        TestCaseListener.logger.info(tr.getTestClass());
        doProcessScreenShot(tr);
    }

    @Override
    public void onTestFailure(final ITestResult tr) {

        TestCaseListener.logger.info("Test '" + tr.getName() + "' FAILED");
        doProcessScreenShot(tr);
    }

    @Override
    public void onTestSkipped(final ITestResult tr) {
        TestCaseListener.logger.info("Test '" + tr.getName() + "' SKIPPED");
    }

    /**
     * Method to process Screenshot capture activity.
     * 
     * @param testResult
     */
    private void doProcessScreenShot(final ITestResult testResult) {
        Object testScriptObj = testResult.getInstance();
        try {
            for (Method method : testScriptObj.getClass().getMethods()) {
                if (method.getName().equals(TestCaseListener.DRIVER_METHOD_NAME)) {
                    WebDriver driver = (WebDriver) method.invoke(testResult.getInstance());
                    ScreenShot.takeScreenShot(driver);
                    break;
                }
            }
        } catch (Exception e) {
            TestCaseListener.logger.error("Exception thrown at TestCaseListener class:onTestSuccess() :", e);
        }
    }

}