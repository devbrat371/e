/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.mx;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.hsbc.digital.testauto.pageobject.LoginModel;


/**
 * <p>
 * <b> Login Specific changes to Mexico Entity. </b>
 * 
 * @author Shrikant Joshi
 * @version 1.0.0
 *          </p>
 */
public class LoginPage extends LoginModel {

    @FindBy(xpath = "//*[contains(@name,'pass') and @type='password']")
    private WebElement passwordField;

    @FindBy(xpath = "//div[contains(@id, 'viewNo') and contains(@class, 'showStep')]//input[contains(@class, 'submit_input')]")
    private WebElement submitButton;

    @FindBy(xpath = "//input[@class='submit_input' and @value='Activate now']")
    private List<WebElement> activateNowBtn;

    @FindBy(xpath = "//span[@class='buttonInner' and text()='Activate later ']")
    private List<WebElement> activateLaterBtn;

    public LoginPage(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    @Override
    public void loginToUserNamePage(final String userName, final String password) {
        waitAndCloseLoginPopUp();
        super.loginToUserNamePage(userName, password);
    }

    /*
     * Commenting code because there might be changes in Canada cam30 login
     * page. (non-Javadoc)
     * 
     * @see
     * com.hsbc.digital.testauto.pageobject.LoginModel#loginWithoutOtp(java
     * .lang.String, java.lang.String, java.lang.String)
     */
    @Override
    public void loginWithoutOtp(final String userName, final String memorableAnswer, final String password) {
        super.loginToUserNamePage(userName, password);
        this.wait.until(ExpectedConditions.visibilityOf(this.passwordField));
        this.passwordField.sendKeys(password);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.hsbc.digital.testauto.pageobject.LoginModel#waitAndClickSubmit()
     */
    @Override
    public void waitAndClickSubmit() {
        this.wait.until(ExpectedConditions.visibilityOf(this.submitButton));
        this.submitButton.click();
        switchLanguage("English");
    }

    @Override
    public void waitForDashboardPage() {
        // TODO: remove after SFT_TEST_021 fix for MX
        if (!activateNowBtn.isEmpty() && activateNowBtn.get(0).isDisplayed()) {
            activateNowBtn.get(0).click();
            wait.until(ExpectedConditions.elementToBeClickable(activateLaterBtn.get(0)));
            activateLaterBtn.get(0).click();
        }
        wait.until(ExpectedConditions.elementToBeClickable(super.myBankingMenu));
    }
}
