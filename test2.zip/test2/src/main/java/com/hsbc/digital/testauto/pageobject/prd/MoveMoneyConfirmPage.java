package com.hsbc.digital.testauto.pageobject.prd;


import java.text.ParseException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import com.hsbc.digital.testauto.library.DateUtil;
import com.hsbc.digital.testauto.models.AccountDetails;
import com.hsbc.digital.testauto.models.Transaction;
import com.hsbc.digital.testauto.models.TransactionFrequency;
import com.hsbc.digital.testauto.pageobject.MoveMoneyCapturePageModel;
import com.hsbc.digital.testauto.pageobject.MoveMoneyConfirmPageModel;
import com.hsbc.digital.testauto.ui.library.UICommonUtil;

public class MoveMoneyConfirmPage extends MoveMoneyConfirmPageModel {
    protected static final String LABEL_FROM = "From";
    protected static final String LABEL_TO = "To";
    private static final String LABEL_PAYMENT_DATE = "Transfer date";
    private static final String TRANSFER_DATE_FORMAT = "EEEEE, dd MMMMM yyyy";
    private static final String LABEL_NUMBER_OF_PAYMENT = "Number of transfers";
    private static final String LABEL_AMOUNT = "Amonut";
    private static final int UNMASKED_PART_TO_ACCOUNT_LENGTH = 4;
    protected By pageFieldName = By.xpath("//div[contains(@class, 'itemLabel') or contains(@class,'divRedVerticalBar')]");

    public MoveMoneyConfirmPage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);

    }


    @Override
    protected void isReasonForTransaction(String reasonForTransaction) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_REASON_FOR_TRANSACTION, reasonForTransaction,
            UICommonUtil.confirmPage, pageFieldName, UICommonUtil.pageFieldValue), "Given Reason For Transaction Value not found");
        Reporter.log("Reason For Transaction Value displayed is :" + reasonForTransaction);
    }

    @Override
    protected void isPaymentDateAsLaterDateDisplayed(Transaction transaction) {
        String paymentDate;
        try {
            paymentDate = DateUtil.getDateToString(TRANSFER_DATE_FORMAT, transaction.getLaterDate());
            Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_PAYMENT_DATE, paymentDate, UICommonUtil.confirmPage,
                pageFieldName, UICommonUtil.pageFieldValue), "Given Payment Date not found");
            Reporter.log("Payment Date displayed is :" + paymentDate);
        } catch (ParseException e) {
            Assert.fail("Parsing to Payment Date Fail " + e.getMessage());
            MoveMoneyCapturePageModel.logger.error(e);
        }
    }

    @Override
    protected void isFromAccountNameDisplayed(AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_FROM, accountDetail.getAccountName(), UICommonUtil.confirmPage,
            pageFieldName, UICommonUtil.pageFieldValue), "Given From Account Name not found.");
        Reporter.log("From Account Name displayed is :" + accountDetail.getAccountName());
    }

    @Override
    protected void isFromAccountNumberDisplayed(AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_FROM, accountDetail.getAccountNumber(),
            UICommonUtil.confirmPage, pageFieldName, UICommonUtil.pageFieldValue), "Given From Account Number not found.");
        Reporter.log("From Account Number displayed is :" + accountDetail.getAccountNumber());
    }

    @Override
    protected void isToAccountNameDisplayed(AccountDetails accountDetail) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_TO, accountDetail.getAccountName(), UICommonUtil.confirmPage,
            pageFieldName, UICommonUtil.pageFieldValue), "Given To Account Name not found.");
        Reporter.log("To Account Name displayed is :" + accountDetail.getAccountName());
    }

    @Override
    protected void isToAccountNumberDisplayed(AccountDetails accountDetail) {
        String refAccNumber = accountDetail.getAccountNumber().substring(
            Math.max(accountDetail.getAccountNumber().length() - UNMASKED_PART_TO_ACCOUNT_LENGTH, 0));
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_TO, refAccNumber, UICommonUtil.verifyPage, pageFieldName,
            UICommonUtil.pageFieldValue), "Given To Account Number not found.");
        Reporter.log("To Account Number displayed is :" + accountDetail.getAccountNumber());
    }

    @Override
    protected void isPaymentDateDisplayed(String paymentDate) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_PAYMENT_DATE, "Now", UICommonUtil.confirmPage, pageFieldName,
            UICommonUtil.pageFieldValue), "Given Payment Date not found.");
        Reporter.log("Payment Date displayed is :" + paymentDate);
    }

    @Override
    protected void isFrequencyDisplayed(String frequencyValue) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_FREQUENCY, frequencyValue, UICommonUtil.confirmPage,
            pageFieldName, UICommonUtil.pageFieldValue), "Given Frequency Value not found.");
        Reporter.log("Frequency Value displayed is :" + frequencyValue);
    }

    @Override
    protected void isNumberOfPaymentDisplayed(String valueNOP) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_NUMBER_OF_PAYMENT, valueNOP, UICommonUtil.confirmPage,
            pageFieldName, UICommonUtil.pageFieldValue), "Given Number Of Payment not found.");
        Reporter.log("Number Of Payment displayed is :" + valueNOP);
    }


    @Override
    protected void isTransactionEndDateDisplayed(TransactionFrequency transactionFrequency) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_TRANSACTION_END_DATE, transactionFrequency.getValue(),
            UICommonUtil.confirmPage, pageFieldName, UICommonUtil.pageFieldValue),
            "Given Transaction End Date dropdown value not found.");
        Reporter.log("Transaction End Date dropdown value displayed is :" + transactionFrequency.getValue());
    }

    @Override
    protected void isAmountDisplayed(String amount) {
        Assert.assertTrue(uiCommonUtil.textByParentAndSibling(LABEL_AMOUNT, amount, UICommonUtil.confirmPage,
            UICommonUtil.pageFieldName, UICommonUtil.pageFieldValue), "Given Transfer Amount not found.");
        Reporter.log("Amount displayed is :" + amount);
    }

    /**
     * Method to verify FCY to LCY Transaction details on confirm page for Now
     * flow
     */
    @Override
    public void verifyFCY2LCYNowTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        Reporter.log("FCY2LCYNow Transaction is Not Applicable for PRD");
    }


    @Override
    public void verifyLCY2FCYLaterTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        Reporter.log("LCY2FCYLater Transaction is Not Applicable for PRD");
    }

    @Override
    public void verifyFCY2LCYLaterTransactionDetailsOnConfirmPage(Transaction transactionDetail) {

        Reporter.log("FCY to LCY Later Flow is not applicable for PRD");
    }

    /**
     * Method to verify LCY2FCYRecurring Transaction details on confirm page
     * for Recurring flow
     */
    @Override
    public void verifyLCY2FCYRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {

        Reporter.log("LCY to FCY Recurring Flow is not applicable for PRD");
    }

    /**
     * Method to verify FCY2LCYRecurring Transaction details on confirm page
     * for Recurring flow
     */
    @Override
    public void verifyFCY2LCYRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        Reporter.log("FCY to LCY Recurring Flow is not applicable for PRD");
    }

    /**
     * Method to verify FCY2FCYRecurring Transaction details on confirm page
     * for Recurring flow
     */
    @Override
    public void verifyFCY2FCYRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        Reporter.log("FCY to FCY Recurring Flow is not applicable for PRD");
    }

    @Override
    public void verifyLCY2LCYNowTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateNowFlow(transactionDetail);
        isAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYNow Transaction Details verified on Confirm Page.");
    }

    @Override
    public void verifyLCY2LCYLaterTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateLaterFlow(transactionDetail);
        isAmountDisplayed(transactionDetail.getAmount());
        Reporter.log("LCY2LCYLater Transaction Details verified on Confirm Page.");
    }

    @Override
    public void verifyLCY2LCYRecurringTransactionDetailsOnConfirmPage(Transaction transactionDetail) {
        validateRecurringFlow(transactionDetail);
        isFrequencyDisplayed(transactionDetail.getFrequencyValue());
        isAmountDisplayed(transactionDetail.getAmount());
        isNumberOfPaymentDisplayed(transactionDetail.getNumberOfPayment());
        Reporter.log("LCY2LCYRecurring Transaction Details verified on Confirm Page.");
    }
}
