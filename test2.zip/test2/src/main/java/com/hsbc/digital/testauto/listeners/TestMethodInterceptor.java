/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.listeners;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.testng.IMethodInstance;
import org.testng.IMethodInterceptor;
import org.testng.ITestContext;
import org.w3c.dom.Document;

import com.hsbc.digital.testauto.library.XMLUtil;

/**
 * <p>
 * <b> This listener will filter test method based on entity and only entity
 * specific methods will be invoked. </b>
 * 
 * @version 1.0.0
 * @author Shrikant Joshi
 *         </p>
 */
public class TestMethodInterceptor implements IMethodInterceptor {

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(TestMethodInterceptor.class);

    public List<IMethodInstance> intercept(final List<IMethodInstance> methods, final ITestContext testContext) {
        String entity = testContext.getSuite().getParameter("entity");
        List<IMethodInstance> filteredMethods = new ArrayList<>();
        try {
            Document document = XMLUtil.getProfileMappingXML();
            for (IMethodInstance methodInstance : methods) {
                String profile = XMLUtil.getProfileName(methodInstance.getMethod().getConstructorOrMethod().getMethod(), entity,
                    document);
                if (StringUtils.isNotEmpty(profile)) {
                    filteredMethods.add(methodInstance);
                }
            }

        } catch (Exception e) {
            logger.error("Exception thrown at method interceptor:", e);
        }
        return filteredMethods;
    }

}
