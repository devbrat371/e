/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

/**
 * <p>
 * <b> This model class will hold locators and functionality for View Fee Terms
 * and conditions To navigate to this page we need to click Tariif of Charges
 * link under MyBanking tab </b>
 * </p>
 * 
 * @author Vaibhav Sharma
 * @version 1.0.0
 */
public abstract class ViewPrintFeeTnCModel {

    // xpath to find Products & Services heading
    @FindBy(xpath = "//ul[@data-dojo-attach-point='menuNode']/li[2]")
    public WebElement productservicingLink;

    // xpath of link to navigate Edit Tariff Of Charges page
    @FindBy(xpath = "//a[@data-uid='tariffOfCharges']")
    public WebElement tariffOfChargesLink;

    // xpath of button to to close tab
    @FindBy(xpath = "//button[@title='Close']")
    public WebElement closeButton;

    // xpath of button to to download file
    @FindBy(xpath = "//button[@title='Download as PDF']")
    public WebElement downloadAsPDFButton;


    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(ViewPrintFeeTnCModel.class);


    public ViewPrintFeeTnCModel(final WebDriver driver) {
        PageFactory.initElements(driver, this);

    }


    /*
     * Parameter : driver Purpose : To navigate Tariff and Charges page
     */
    public void navigateTnCPage(final WebDriver driver) {

        // Needs to be implement when common functions are ready

    }

    /*
     * Purpose : To download the TnC file
     */
    public void downloadTnCFile() throws AWTException {

        Assert.assertTrue(this.downloadAsPDFButton.isDisplayed(), "Download button is not displayed");
        Reporter.log("Download button is displayed");
        this.downloadAsPDFButton.click();
        Reporter.log("Download button is clicked");

        Robot robot = new Robot();
        robot.delay(5000);
        robot.keyPress(KeyEvent.VK_CONTROL);
        robot.keyPress(KeyEvent.VK_V);
        robot.keyRelease(KeyEvent.VK_V);
        robot.keyRelease(KeyEvent.VK_CONTROL);
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);

        Reporter.log("Choose Ok button to download file");


    }

    /*
     * Purpose : To verify downloaded file
     */

    public void verifyDownloadFile() {

        // Needs to check if thi scan be automate

    }


    /*
     * Purpose : To close download tab
     */
    public void closeDownloadTab() {

        Assert.assertTrue(this.closeButton.isDisplayed(), "Button to close download tab is not displayed");
        Reporter.log("Close button is displayed on download tab");
        this.closeButton.click();
        Reporter.log("Close button is clicked on download tab");

    }

    /*
     * Purpose : To navigate update notification page
     */

    public void navigateUpdateNotificationPage() {

    }

    /*
     * Purpose : To navigate update notification page
     */

    public void changeNotificationSetting() {

    }

    /*
     * Purpose : To Cancel the downloaded flow
     */

    public void cancelFlow() {

    }


}
