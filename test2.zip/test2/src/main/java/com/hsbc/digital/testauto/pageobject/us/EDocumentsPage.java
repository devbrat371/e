/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.pageobject.us;

import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.pageobject.EDocumentsModel;


/**
 * <p>
 * <b>This class will have locators and specific behaviours for Canada for
 * Secure Messaging story. </b>
 * </p>
 */
public class EDocumentsPage extends EDocumentsModel {

    @FindBy(xpath = ".//*[contains(@class,'dijitArrowNode')]//parent::div//span[contains(text(),'View')]")
    private List<WebElement> viewDetails;

    @FindBy(xpath = ".//*[@data-dojo-attach-point='downloadbutton']")
    private List<WebElement> downloadButton;

    @FindBy(xpath = ".//*[@data-dojo-attach-point='listDataNode']//following-sibling::div[contains(@aria-labelledby,'colDocumentType')]")
    private List<WebElement> documentTypeAndName;

    private WebDriverWait wait;

    private WebDriver driver;

    public EDocumentsPage(final WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
        this.driver = driver;
        wait = new WebDriverWait(driver, 30);
    }

    /*
     * Method to verify whether the downloadbutton is enabled or not
     */
    @Override
    public void viewDownloadPreview() {
        super.viewDownloadPreview();
        int tobeSelectedIndex = RandomUtil.generateIntNumber(0, this.viewDetails.size());
        ((JavascriptExecutor) this.driver).executeScript("arguments[0].scrollIntoView(true);",
            this.viewDetails.get(tobeSelectedIndex));
        this.viewDetails.get(tobeSelectedIndex).click();
        if (this.downloadButton.get(tobeSelectedIndex).isEnabled()) {
            this.downloadButton.get(tobeSelectedIndex).click();
            EDocumentsModel.logger.info("Element Selected at index:" + tobeSelectedIndex);
        }

    }
}
