/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.scripts.landingpage;

import java.lang.reflect.Method;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.hsbc.digital.testauto.library.BrowserLib;
import com.hsbc.digital.testauto.library.DateUtil;
import com.hsbc.digital.testauto.library.FileUtil;
import com.hsbc.digital.testauto.library.ReflectionUtil;
import com.hsbc.digital.testauto.library.XMLUtil;
import com.hsbc.digital.testauto.pageobject.LandingPageModel;
import com.hsbc.digital.testauto.pageobject.LoginModel;

/**
 * <p>
 * <b> This class will hold test methods for story 3 Download Transaction
 * History </b>
 * </p>
 * 
 * @version 1.0.0
 * @author SatyaPrakash Vyas
 * 
 */
public class DownloadTransactionHistory {

    WebDriver driver;
    BrowserLib browserLib;
    Map<String, String> envProperties;
    LoginModel loginModel;
    LandingPageModel landingPageModel;

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(DownloadTransactionHistory.class);

    @Parameters({"browser", "entity"})
    @BeforeMethod(alwaysRun = true)
    public void beforeMethod(final String browser, final String entity, final Method method) {
        try {
            browserLib = new BrowserLib(browser);
            driver = browserLib.getDriver();
            envProperties = FileUtil.getConfigProperties(entity);
            String profile = XMLUtil.getProfileName(method, entity);
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            loginModel = (LoginModel) ReflectionUtil.getEntityPOM(entity, "LoginPage", driver);
            landingPageModel = (LandingPageModel) ReflectionUtil.getEntityPOM(entity, "LandingPage", driver);
            loginModel.login(profile, envProperties);
        } catch (Exception e) {
            DownloadTransactionHistory.logger.error("Exception thrown at Login Contructor:", e);
        }
    }

    /**
     * This method will not enter any search criteria but downloads the
     * transaction history
     */
    @Test(testName = "Download Transaction History without any criteria", groups = {"functionaltest"})
    public void downloadHistoryWithoutSerach() {
        try {
            landingPageModel.verifyTransactionHistorySection(LandingPageModel.VIEW_TRANSACTION_TEXT);
            landingPageModel.downloadTransactionHistory(false);
            landingPageModel.downloadTransactionHistory(true);
        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage());
            DownloadTransactionHistory.logger.error(e);
        }
    }

    // Search and download the transaction after entering the date range
    @Test(testName = "Download Transaction History with Date Range", groups = {"functionaltest"})
    public void downloadHistoryWithDateRange() {
        try {
            landingPageModel.verifyTransactionHistorySection(LandingPageModel.VIEW_TRANSACTION_TEXT);
            String fromDate = landingPageModel.getFromDate();
            String toDate = landingPageModel.getToDate();
            landingPageModel.clickSearchButton();
            landingPageModel.enterFromDate(fromDate);
            landingPageModel.enterToDate(toDate);
            landingPageModel.clickViewResultButton();
            landingPageModel.downloadTransactionHistory(true);
        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage());
            DownloadTransactionHistory.logger.error(e);
        }
    }

    // Search and download the transaction after entering the amount range
    @Test(testName = "Download Transaction History with Amount Range", groups = {"functionaltest",})
    public void downloadHistoryWithAmountRange() {
        try {
            landingPageModel.verifyTransactionHistorySection(LandingPageModel.VIEW_TRANSACTION_TEXT);
            landingPageModel.clickSearchButton();
            landingPageModel.enterFromAmount();
            landingPageModel.enterToAmount();
            landingPageModel.clickViewResultButton();
            landingPageModel.downloadTransactionHistory(true);
        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage());
            DownloadTransactionHistory.logger.error(e);
        }
    }

    // verify the error message after entering the future date
    @Test(testName = "Verify the error message for Future Date", groups = {"functionaltest"})
    public void verifyErrorMessageForFutureDate() {
        try {
            landingPageModel.verifyTransactionHistorySection(LandingPageModel.VIEW_TRANSACTION_TEXT);
            landingPageModel.clickSearchButton();
            Date date = DateUtil.getSystemDate();
            String futureDate = landingPageModel.getFutureDate(date, 3);
            landingPageModel.enterFromDate(futureDate);
            landingPageModel.verifyErrorMessageForInvalidDate();
        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage());
            DownloadTransactionHistory.logger.error(e);
        }
    }

    // verify the error message after entering the invalid date
    @Test(testName = "Verify the error message for Invalid Date", groups = {"functionaltest",})
    public void verifyErrorMessageForInvalidDate() {
        try {
            landingPageModel.verifyTransactionHistorySection(LandingPageModel.VIEW_TRANSACTION_TEXT);
            landingPageModel.clickSearchButton();
            landingPageModel.enterInvalidFromDate();
            landingPageModel.enterInvalidToDate();
            landingPageModel.clickViewResultButton();
            landingPageModel.verifyErrorMessageForInvalidDate();
        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage());
            DownloadTransactionHistory.logger.error(e);
        }
    }

    @Test(testName = "Verify the error message for account having no transaction", groups = {"functionaltest"})
    public void verifyErrorMessageNoTransaction() {
        try {
            landingPageModel.verifyTransactionHistorySection(LandingPageModel.ERROR_MESSAGE);
            landingPageModel.verifyErrorMessageForInvalidDetails();
        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage());
            DownloadTransactionHistory.logger.error(e);
        }
    }

    // Verify View More button functionality
    @Test(testName = "Functinality of ViewMore", groups = {"functionaltest"})
    public void verifyViewMoreFunctionality() {
        try {
            landingPageModel.verifyTransactionHistorySection(LandingPageModel.VIEW_MORE_BUTTON_TEXT);
            landingPageModel.verifyViewMoreButtonFunctionality();
        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage());
            DownloadTransactionHistory.logger.error(e);
        }
    }

    @AfterMethod(alwaysRun = true)
    public void afterTest() {
        browserLib.closeAllBrowsers();
    }

    /**
     * 
     * <p>
     * <b> This method is used to take screen shot so every test script should
     * have it as it is used by Framework internally. </b>
     * </p>
     * 
     * @return driver
     */
    public WebDriver getDriver() {
        return this.driver;
    }
}
