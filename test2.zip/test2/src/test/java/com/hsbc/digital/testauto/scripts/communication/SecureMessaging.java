/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.scripts.communication;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.hsbc.digital.testauto.library.BrowserLib;
import com.hsbc.digital.testauto.library.FileUtil;
import com.hsbc.digital.testauto.library.ReflectionUtil;
import com.hsbc.digital.testauto.library.XMLUtil;
import com.hsbc.digital.testauto.models.SecureMessagingEnums;
import com.hsbc.digital.testauto.pageobject.FlyerMenuNavigationModel;
import com.hsbc.digital.testauto.pageobject.LoginModel;
import com.hsbc.digital.testauto.pageobject.SecureMessage;
import com.hsbc.digital.testauto.pageobject.SecureMessageModel;

/**
 * <p>
 * <b> This Test Script has scripts for Story 15 Secure Messaging where user
 * will send/Receive/Read messages for communication with Bank. </b>
 * 
 * @author Shrikant Joshi
 * @version 1.0.0
 *          </p>
 */
public class SecureMessaging {

    WebDriver driver;
    BrowserLib browserLib;
    Map<String, String> envProperties;
    LoginModel loginModel;
    SecureMessageModel secureMessageModel;
    FlyerMenuNavigationModel navigationMenu;
    SecureMessage sm = new SecureMessage();

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(SecureMessaging.class);

    @Parameters({"browser", "entity"})
    @BeforeMethod(alwaysRun = true)
    public void beforeMethod(final String browser, final String entity, final Method testMethod) {
        try {
            this.browserLib = new BrowserLib(browser);
            this.driver = this.browserLib.getDriver();
            this.envProperties = FileUtil.getConfigProperties(entity);
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            String profile = XMLUtil.getProfileName(testMethod, entity);
            loginModel = (LoginModel) ReflectionUtil.getEntityPOM(entity, "LoginPage", driver);
            secureMessageModel = (SecureMessageModel) ReflectionUtil.getEntityPOM(entity, "SecureMessagePage", driver);
            navigationMenu = (FlyerMenuNavigationModel) ReflectionUtil.getEntityPOM(entity, "FlyerMenuNavigation", driver);
            loginModel.login(profile, this.envProperties);
            loginModel.switchLanguage("English");
        } catch (Exception e) {
            SecureMessaging.logger.error("Exception thrown:", e);
        }
    }

    @Test(testName = "Send Secure Message End to End", groups = {"functionaltest"})
    public void doMessaging() {
        try {
            secureMessageModel.navigateToMessageCenter();
            String messageTitle = secureMessageModel.readMessage();
            secureMessageModel.replyToMessage(messageTitle);
            secureMessageModel.backToMessages();
            secureMessageModel.printMessage();
            secureMessageModel.deleteCurrentMessage(false);
            secureMessageModel.deleteCurrentMessage(true);
            secureMessageModel.isMessageExist(messageTitle);
            secureMessageModel.sendMessage();
            secureMessageModel.backToMessages();
        } catch (Exception e) {
            SecureMessaging.logger.error("Exception at SecureMessaging Script:doMessaging()", e);
            Assert.fail("Exception at doMessaging:", e);
        }
    }

    @Test(groups = {"functionaltest"})
    public void cancelReplyMessage() {
        try {
            secureMessageModel.navigateToMessageCenter();
            String messageTitle = secureMessageModel.readMessage();
            secureMessageModel.typeReplyMessage();
            secureMessageModel.cancelReplyMessage(false);
            secureMessageModel.verifyMessage(messageTitle, false);
            secureMessageModel.cancelReplyMessage(true);
            secureMessageModel.verifyMessage(messageTitle, true);
        } catch (Exception e) {
            SecureMessaging.logger.error("Exception at SecureMessaging Script:cancelReplyMessage()", e);
            Assert.fail("Exception at cancelReplyMessage:", e);
        }
    }


    @Test(groups = {"functionaltest"}, enabled = true)
    public void cancelSendMessage() {
        try {
            secureMessageModel.navigateToMessageCenter();
            secureMessageModel.typeNewMessage();
            secureMessageModel.cancelSendMessage(false);
            secureMessageModel.checkSendMessageCancel(false);
            secureMessageModel.cancelSendMessage(true);
            secureMessageModel.checkSendMessageCancel(true);
        } catch (Exception e) {
            SecureMessaging.logger.error("Exception at SecureMessaging Script:cancelSendMessage()", e);
            Assert.fail("Exception at cancelSendMessage:", e);
        }
    }

    @Test(testName = "Send Secure Message via header link End to End", groups = {"functionaltest"})
    public void sendMessageFromLink() {
        try {
            secureMessageModel.checkMessageNotification();
            secureMessageModel.navigateToMessageCenterSendMessage();
            secureMessageModel.sendMessageFromLink();
        } catch (Exception e) {
            SecureMessaging.logger.error("Exception at SecureMessaging Script :sendMessageFromLink()", e);
            Assert.fail("Exception at doMessaging:", e);
        }
    }

    @Test(groups = {"functionaltest"})
    public void cancelSubmitBillingDispute() {
        try {
            secureMessageModel.navigateToReportProblem(sm, secureMessageModel.billPayProblemButton);
            secureMessageModel.enterBillingDisputeDetailsTxnSummary(sm, SecureMessagingEnums.problemReason.LATE_PAYMENT.getValue(),
                "cancelSubmitBillingDispute", null);
            secureMessageModel.cancelBillingDispute(false);
            secureMessageModel.verifyProblem(secureMessageModel.submitBillingDisputeTitle, false);
            secureMessageModel.submitBillingDisputeTitle.click();
            secureMessageModel.cancelBillingDispute(true);
            secureMessageModel.verifyProblem(secureMessageModel.submitBillingDisputeTitle, true);
            SecureMessaging.logger.info("cancelSubmitBillingDispute execution completed");
        } catch (Exception e) {
            SecureMessaging.logger.error("Exception at SecureMessaging cancelSubmitBillingDispute()", e);
            Assert.fail("Exception at cancelSubmitBillingDispute:", e);
        }
    }

    @Test(groups = {"functionaltest"})
    public void cancelReportTxnProblem() {
        try {
            secureMessageModel.navigateToReportProblem(sm, secureMessageModel.otherProblemButton);
            secureMessageModel.enterReportProblemDetailsTxnSummary(sm, SecureMessagingEnums.typeOfTxnArray.ALL_TXNS.getValue(),
                SecureMessagingEnums.problemWithTxnArray.TRANSFER_NT_RECD.getValue(), null);
            secureMessageModel.cancelProblem(false);
            secureMessageModel.verifyProblem(secureMessageModel.reportAProblemTitle, false);
            secureMessageModel.reportAProblemTitle.click();
            secureMessageModel.cancelProblem(true);
            secureMessageModel.verifyProblem(secureMessageModel.reportAProblemTitle, true);
            SecureMessaging.logger.info("cancelBillingDisputeReview execution completed");
        } catch (Exception e) {
            SecureMessaging.logger.error("Exception at SecureMessaging cancelReportTxnProblem()", e);
            Assert.fail("Exception at cancelReportTxnProblem:", e);
        }
    }

    @Test(groups = {"functionaltest"})
    public void submitBillingDispute() {
        try {
            secureMessageModel.navigateToReportProblem(sm, secureMessageModel.billPayProblemButton);
            secureMessageModel.enterBillingDisputeDetailsTxnSummary(sm, SecureMessagingEnums.problemReason.LATE_PAYMENT.getValue(),
                "submitBillingDispute", null);
            secureMessageModel.clickContinueButton(secureMessageModel.reviewBillingDisputeTitle);
            secureMessageModel.validateSubmitBillingDispute(sm, secureMessageModel.reviewBillingDisputeTitle);
            secureMessageModel.clickEditButton();
            secureMessageModel.enterBillingDisputeDetailsTxnSummary(sm,
                SecureMessagingEnums.problemReason.OTHER_PAY_PROB.getValue(), "submitBillingDispute", "Aditional Comments");
            secureMessageModel.clickContinueButton(secureMessageModel.reviewBillingDisputeTitle);
            secureMessageModel.validateSubmitBillingDispute(sm, secureMessageModel.reviewBillingDisputeTitle);
            secureMessageModel.isAdditionalCommentsDisplayed(sm);
            secureMessageModel.clickSendButton(secureMessageModel.confirmBillingDisputeTitle);
            if (secureMessageModel.successMessageBillingDispute.isDisplayed()) {
                secureMessageModel.validateSubmitBillingDispute(sm, secureMessageModel.confirmBillingDisputeTitle);
                secureMessageModel.isAdditionalCommentsDisplayed(sm);
                secureMessageModel.clickMyAccounts();
                SecureMessaging.logger.info("submitBillingDispute execution completed");
            } else
                SecureMessaging.logger.error("Success message not displayed !");
        } catch (Exception e) {
            SecureMessaging.logger.error("Exception at SecureMessaging submitBillingDispute()" + e);
            Assert.fail("Exception at submitBillingDispute:", e);
        }
    }

    @Test(groups = {"functionaltest"})
    public void reportTransactionProblem() {
        try {
            secureMessageModel.navigateToReportProblem(sm, secureMessageModel.otherProblemButton);
            secureMessageModel.enterReportProblemDetailsTxnSummary(sm, SecureMessagingEnums.typeOfTxnArray.ALL_TXNS.getValue(),
                SecureMessagingEnums.problemWithTxnArray.TRANSFER_NT_RECD.getValue(), null);
            secureMessageModel.clickContinueButton(secureMessageModel.reviewTxnProbReportTitle);
            secureMessageModel.validateReportTxnProblem(sm, secureMessageModel.reviewTxnProbReportTitle);
            secureMessageModel.clickEditButton();
            secureMessageModel.enterReportProblemDetailsTxnSummary(sm, SecureMessagingEnums.typeOfTxnArray.DEBIT_TXN.getValue(),
                SecureMessagingEnums.problemWithTxnArray.OTHER.getValue(), "Aditional Comments");
            secureMessageModel.clickContinueButton(secureMessageModel.reviewTxnProbReportTitle);
            secureMessageModel.validateReportTxnProblem(sm, secureMessageModel.reviewTxnProbReportTitle);
            secureMessageModel.isAdditionalCommentsDisplayed(sm);
            secureMessageModel.clickSendButton(secureMessageModel.confirmReportTxnPrbmTitle);
            if (secureMessageModel.successMessageTxnProblm.isDisplayed()) {
                secureMessageModel.validateReportTxnProblem(sm, secureMessageModel.confirmReportTxnPrbmTitle);
                secureMessageModel.isAdditionalCommentsDisplayed(sm);
                secureMessageModel.clickMyAccounts();
                SecureMessaging.logger.info("reportTransactionProblem execution completed");
            } else
                SecureMessaging.logger.error("Success message not displayed !");
        } catch (Exception e) {
            SecureMessaging.logger.error("Exception at SecureMessaging reportTransactionProblem()", e);
            Assert.fail("Exception at reportTransactionProblem:", e);
        }
    }


    @Test(groups = {"functionaltest"})
    public void cancelBillingDisputeReview() {
        try {
            secureMessageModel.navigateToReportProblem(sm, secureMessageModel.billPayProblemButton);
            secureMessageModel.enterBillingDisputeDetailsTxnSummary(sm, SecureMessagingEnums.problemReason.LATE_PAYMENT.getValue(),
                "submitBillingDispute", null);
            secureMessageModel.clickContinueButton(secureMessageModel.reviewBillingDisputeTitle);
            secureMessageModel.validateSubmitBillingDispute(sm, secureMessageModel.reviewBillingDisputeTitle);
            secureMessageModel.cancelBillingDispute(false);
            secureMessageModel.verifyProblem(secureMessageModel.reviewBillingDisputeTitle, false);
            secureMessageModel.reviewBillingDisputeTitle.click();
            secureMessageModel.cancelBillingDispute(true);
            secureMessageModel.verifyProblem(secureMessageModel.reviewBillingDisputeTitle, true);
            SecureMessaging.logger.info("cancelBillingDisputeReview execution completed");
        } catch (Exception e) {
            SecureMessaging.logger.error("Exception at SecureMessaging cancelBillingDisputeReview()" + e);
            Assert.fail("Exception at cancelBillingDisputeReview:", e);
        }
    }

    @Test(groups = {"functionaltest"})
    public void cancelTxnProblemReview() {
        try {
            secureMessageModel.navigateToReportProblem(sm, secureMessageModel.otherProblemButton);
            secureMessageModel.enterReportProblemDetailsTxnSummary(sm, SecureMessagingEnums.typeOfTxnArray.ALL_TXNS.getValue(),
                SecureMessagingEnums.problemWithTxnArray.TRANSFER_NT_RECD.getValue(), null);
            secureMessageModel.clickContinueButton(secureMessageModel.reviewTxnProbReportTitle);
            secureMessageModel.validateReportTxnProblem(sm, secureMessageModel.reviewTxnProbReportTitle);
            secureMessageModel.cancelProblem(false);
            secureMessageModel.verifyProblem(secureMessageModel.reviewTxnProbReportTitle, false);
            secureMessageModel.reviewTxnProbReportTitle.click();
            secureMessageModel.cancelProblem(true);
            secureMessageModel.verifyProblem(secureMessageModel.reviewTxnProbReportTitle, true);
            SecureMessaging.logger.info("cancelTxnProblemReview execution completed");
        } catch (Exception e) {
            SecureMessaging.logger.error("Exception at SecureMessaging cancelTxnProblemReview()", e);
            Assert.fail("Exception at cancelTxnProblemReview:", e);
        }
    }

    @Test(groups = {"functionaltest"})
    public void cancelBillingDisputeSmartSearch() {
        try {
            secureMessageModel.navigateToRprtPrblmSmartSearch(sm, secureMessageModel.billPayProblemButton);
            secureMessageModel.enterBillingDisputeDetailsSmartSearch(envProperties, sm,
                SecureMessagingEnums.problemReason.LATE_PAYMENT.getValue(), SecureMessagingEnums.paymentFreq.BI_MONTHLY.getValue(),
                SecureMessageModel.DEFAULT_PAYMENT_AMOUNT, "cancelBillingDisputeSmartSearch", null);
            secureMessageModel.cancelBillingDispute(false);
            secureMessageModel.verifyProblem(secureMessageModel.submitBillingDisputeTitle, false);
            secureMessageModel.submitBillingDisputeTitle.click();
            secureMessageModel.cancelBillingDispute(true);
            secureMessageModel.verifyProblem(secureMessageModel.submitBillingDisputeTitle, true);
            SecureMessaging.logger.info("cancelBillingDisputeSmartSearch execution completed");
        } catch (Exception e) {
            SecureMessaging.logger.error("Exception at SecureMessaging cancelBillingDisputeSmartSearch()" + e);
            Assert.fail("Exception at cancelBillingDisputeSmartSearch:" + e);
        }
    }

    @AfterMethod(alwaysRun = true)
    public void afterMethod() {
        this.browserLib.closeAllBrowsers();
    }

    /**
     * 
     * <p>
     * <b> This method is used to take screen shot so every test script should
     * have it as it is used by Framework internally. </b>
     * </p>
     * 
     * @return driver
     */

    public WebDriver getDriver() {
        return this.driver;
    }


}
