package com.hsbc.digital.testauto.scripts.movemoney;

/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.hsbc.digital.testauto.library.BrowserLib;
import com.hsbc.digital.testauto.library.FileUtil;
import com.hsbc.digital.testauto.library.ReflectionUtil;
import com.hsbc.digital.testauto.library.XMLUtil;
import com.hsbc.digital.testauto.models.Transaction;
import com.hsbc.digital.testauto.pageobject.LoginModel;
import com.hsbc.digital.testauto.pageobject.QuickMoveMoneyCaptureModel;
import com.hsbc.digital.testauto.pageobject.QuickMoveMoneyConfirmModel;

/**
 * <p>
 * <b> This class is holding Test Case and functionality for quick move money.
 * </b>
 * </p>
 * 
 * @author Pramesh G
 * @version 1.0.0
 */
public class QuickMoveMoneyTransfer {

    WebDriver driver;
    BrowserLib browserLib;
    Map<String, String> envProperties;
    LoginModel loginModel;
    QuickMoveMoneyCaptureModel qmmCapturePage;
    QuickMoveMoneyConfirmModel qmmConfirmPage;


    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(QuickMoveMoneyTransfer.class);

    @Parameters({"browser", "entity"})
    @BeforeMethod(alwaysRun = true)
    public void beforeMethod(final String browser, final String entity, Method method) throws Exception {
        try {
            browserLib = new BrowserLib(browser);
            driver = browserLib.getDriver();
            envProperties = FileUtil.getConfigProperties(entity);
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            loginModel = (LoginModel) ReflectionUtil.getEntityPOM(entity, "LoginPage", driver);
            qmmCapturePage = (QuickMoveMoneyCaptureModel) ReflectionUtil.getEntityPOM(entity, "QuickMoveMoney", driver);
            qmmConfirmPage = (QuickMoveMoneyConfirmModel) ReflectionUtil.getEntityPOM(entity, "QuickMoveMoneyConfirm", driver);
            String profile = XMLUtil.getProfileName(method, entity);
            loginModel.login(profile, envProperties);
            loginModel.switchLanguage("English");
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException e) {
            QuickMoveMoneyTransfer.logger.error("Exception thrown at Login Contructor:", e);
        } catch (Exception e) {
            QuickMoveMoneyTransfer.logger.error("Exception thrown at Login Contructor:", e);
        }
    }


    /**
     * Scenario to check quick transfer function.
     */
    @Test(groups = {"functionaltest"}, enabled = true, priority = 1)
    @Parameters("browser")
    public void quickTransfer() {
        try {
            Transaction transaction = new Transaction();
            qmmCapturePage.scrollToWidget();
            transaction.setFromAccount(qmmCapturePage.selectFromAccount());
            transaction.setToAccount(qmmCapturePage.selectToAccount());
            transaction.setAmount(qmmCapturePage.enterAmount(transaction));
            qmmCapturePage.clickTransferButton();
            qmmConfirmPage.validateConfirmationPage(transaction);
            qmmConfirmPage.clickNewTransaction();
            qmmCapturePage.checkBalance(transaction);
        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage());
            QuickMoveMoneyTransfer.logger.error(e);
        }
    }

    /**
     * Scenario to check Quick Move Money widget reset function.
     */
    @Test(groups = {"functionaltest"}, enabled = true, priority = 2)
    @Parameters("browser")
    public void cancelQuickTransfer() {
        try {
            Transaction transaction = new Transaction();
            qmmCapturePage.scrollToWidget();
            transaction.setFromAccount(qmmCapturePage.selectFromAccount());
            transaction.setToAccount(qmmCapturePage.selectToAccount());
            transaction.setAmount(qmmCapturePage.enterAmount(transaction));
            qmmCapturePage.resetWidget();

        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage());
            QuickMoveMoneyTransfer.logger.error(e);
        }
    }


    /**
     * Scenario to Check the Transfer Limit function.
     */
    @Test(groups = {"functionaltest"}, enabled = true, priority = 3)
    @Parameters("browser")
    public void testTransferLimit() {
        try {
            qmmCapturePage.scrollToWidget();
            qmmCapturePage.selectFromAccount();
            qmmCapturePage.selectToAccount();
            qmmCapturePage.enterLargeAmount();
            qmmCapturePage.clickTransferButton();
            qmmConfirmPage.verifyTransferLimitMessage();

        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage());
            QuickMoveMoneyTransfer.logger.error(e);
        }
    }


    @AfterMethod(alwaysRun = true)
    public void afterMethod() {
        // Log off needs to be impl
        browserLib.closeAllBrowsers();
    }

    /**
     * <p>
     * <b> This method is used to take screen shot so every test script should
     * have it as it is used by Framework internally. </b>
     * </p>
     * 
     * @return driver
     */
    public WebDriver getDriver() {
        return driver;
    }
}
