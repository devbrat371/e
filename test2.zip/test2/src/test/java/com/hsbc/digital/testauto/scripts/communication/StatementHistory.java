/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.scripts.communication;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.hsbc.digital.testauto.library.BrowserLib;
import com.hsbc.digital.testauto.library.FileUtil;
import com.hsbc.digital.testauto.library.ReflectionUtil;
import com.hsbc.digital.testauto.library.XMLUtil;
import com.hsbc.digital.testauto.pageobject.DownloadStatementHistoryModel;
import com.hsbc.digital.testauto.pageobject.FlyerMenuNavigationModel;
import com.hsbc.digital.testauto.pageobject.LoginModel;

/**
 * <p>
 * <b> This class will hold testing scripts for story 17 - Download Statement
 * History </b>
 * </p>
 * 
 * @version 1.0.0
 * @author Midde Rajesh Kumar
 * 
 */
public class StatementHistory {
    WebDriver driver;
    BrowserLib browserLib;
    Map<String, String> envProperties;
    LoginModel loginModel;
    DownloadStatementHistoryModel downloadStatementHistoryModel;
    FlyerMenuNavigationModel flyerMenuNavigation;

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(StatementHistory.class);

    @Parameters({"browser", "entity"})
    @BeforeMethod(alwaysRun = true)
    public void beforeMethod(final String browser, final String entity, final Method method) {
        try {
            browserLib = new BrowserLib(browser);
            driver = browserLib.getDriver();
            envProperties = FileUtil.getConfigProperties(entity);
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            loginModel = (LoginModel) ReflectionUtil.getEntityPOM(entity, "LoginPage", driver);
            downloadStatementHistoryModel = (DownloadStatementHistoryModel) ReflectionUtil.getEntityPOM(entity,
                "DownloadStatementHistory", driver);
            flyerMenuNavigation = (FlyerMenuNavigationModel) ReflectionUtil.getEntityPOM(entity, "FlyerMenuNavigation", driver);
            String profile = XMLUtil.getProfileName(method, entity);
            loginModel.login(profile, envProperties);
            loginModel.switchLanguage("English");
        } catch (Exception e) {
            StatementHistory.logger.error("Exception thrown at Login Constructor:", e);
        }
    }

    /**
     * 
     * This method is for download the account statement history
     * 
     */
    @Test(groups = {"functionaltest"})
    public void downloadStatmentHistory() {
        try {
            flyerMenuNavigation.navigateToStatementsAndAdvices();
            downloadStatementHistoryModel.selectAccountFromDropDownList();
            downloadStatementHistoryModel.selectYearFromDropdown();
            downloadStatementHistoryModel.verifyNoTransactionHistoryMessage();
            downloadStatementHistoryModel.clickAndVerifyDownloadTransaction();
        } catch (Exception e) {
            StatementHistory.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * 
     * This method is for Verify the Search year list
     * 
     */
    @Test(groups = {"functionaltest"})
    public void verifyDate() {
        try {
            flyerMenuNavigation.navigateToStatementsAndAdvices();
            downloadStatementHistoryModel.selectAccountFromDropDownList();
            downloadStatementHistoryModel.selectYearFromDropdown();
            downloadStatementHistoryModel.verifyNoTransactionHistoryMessage();
            downloadStatementHistoryModel.verifyDateDropDownList();
        } catch (Exception e) {
            StatementHistory.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * 
     * This method is for verifying the order of date display
     * 
     */
    @Test(groups = {"functionaltest"})
    public void verifyDisplayOrder() {
        try {
            flyerMenuNavigation.navigateToStatementsAndAdvices();
            downloadStatementHistoryModel.selectAccountFromDropDownList();
            downloadStatementHistoryModel.selectYearFromDropdown();
            downloadStatementHistoryModel.verifyNoTransactionHistoryMessage();
            downloadStatementHistoryModel.verifyOrderofDisplay();
        } catch (Exception e) {
            StatementHistory.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * 
     * This method is for verify the user is notified by sms or email
     * 
     */
    @Test(groups = {"functionaltest"})
    public void verifyUserIsNotified() {
        try {
            flyerMenuNavigation.navigateToStatementsAndAdvices();
            downloadStatementHistoryModel.selectAccountFromDropDownList();
            downloadStatementHistoryModel.selectYearFromDropdown();
            // below steps are not implemented in application
            downloadStatementHistoryModel.notificationChannelPreference();
        } catch (Exception e) {
            StatementHistory.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * 
     * This method is for to terminate the alerts
     * 
     */
    @Test(groups = {"functionaltest"})
    public void terminateAlerts() {
        try {
            flyerMenuNavigation.navigateToStatementsAndAdvices();
            downloadStatementHistoryModel.selectAccountFromDropDownList();
            downloadStatementHistoryModel.selectYearFromDropdown();
            // below steps are not implemented in application
            downloadStatementHistoryModel.selectFutrueDateToTerminateAlerts();
        } catch (Exception e) {
            StatementHistory.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @AfterMethod(alwaysRun = true)
    public void afterMethod() {
        this.browserLib.closeAllBrowsers();
    }

    /**
     * 
     * <p>
     * <b> This method is used to take screen shot so every test script should
     * have it as it is used by Framework internally. </b>
     * </p>
     * 
     * @return driver
     */
    public WebDriver getDriver() {
        return this.driver;
    }
}
