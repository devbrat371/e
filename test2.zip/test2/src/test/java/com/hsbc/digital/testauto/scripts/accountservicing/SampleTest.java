/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.scripts.accountservicing;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.hsbc.digital.testauto.library.BrowserLib;
import com.hsbc.digital.testauto.library.FileUtil;

/**
 * <p>
 * <b> This class will hold testing scripts for story 91 - Change Internet
 * Banking Limits </b>
 * </p>
 * 
 * @version 1.0.0
 * @author SatyaPrakash S Vyas
 * 
 */
public class SampleTest {

    WebDriver driver;
    BrowserLib browserLib;
    Map<String, String> envProperties;

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(SampleTest.class);

    @Parameters({"browser", "entity"})
    @BeforeMethod(alwaysRun = true)
    public void beforeMethod(final String browser, final String entity, final Method method) {
        try {
            browserLib = new BrowserLib(browser);
            driver = browserLib.getDriver();
            envProperties = FileUtil.getConfigProperties(entity);
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

        } catch (Exception e) {
            SampleTest.logger.error("Exception thrown at Login Contructor:", e);
        }
    }

    @Test(groups = {"functionaltest"}, testName = "End-to-end")
    @AfterMethod(alwaysRun = true)
    public void afterMethod() {
        this.browserLib.closeAllBrowsers();
    }

    /**
     * 
     * <p>
     * <b> This method is used to take screen shot so every test script should
     * have it as it is used by Framework internally. </b>
     * </p>
     * 
     * @return driver
     */
    public WebDriver getDriver() {
        return driver;
    }
}
