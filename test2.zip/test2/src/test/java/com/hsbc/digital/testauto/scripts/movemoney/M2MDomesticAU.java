package com.hsbc.digital.testauto.scripts.movemoney;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.hsbc.digital.testauto.library.BrowserLib;
import com.hsbc.digital.testauto.library.FileUtil;
import com.hsbc.digital.testauto.library.ReflectionUtil;
import com.hsbc.digital.testauto.library.XMLUtil;
import com.hsbc.digital.testauto.models.Transaction;
import com.hsbc.digital.testauto.models.TransactionFlow;
import com.hsbc.digital.testauto.pageobject.FlyerMenuNavigationModel;
import com.hsbc.digital.testauto.pageobject.LandingPageModel;
import com.hsbc.digital.testauto.pageobject.LoginModel;
import com.hsbc.digital.testauto.pageobject.MoveMoneyCapturePageModel;
import com.hsbc.digital.testauto.pageobject.MoveMoneyConfirmPageModel;
import com.hsbc.digital.testauto.pageobject.MoveMoneyVerifyPageModel;

public class M2MDomesticAU {
    WebDriver driver;
    BrowserLib browserLib;
    Map<String, String> envProperties;
    LoginModel loginModel;
    FlyerMenuNavigationModel navigate;
    MoveMoneyCapturePageModel mmCapturePageModel;
    MoveMoneyVerifyPageModel mmVerifyPageModel;
    MoveMoneyConfirmPageModel mmConfirmPageModel;
    LandingPageModel landingPageModel;

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(M2MDomesticAU.class);

    @Parameters({"browser", "entity"})
    @BeforeMethod(alwaysRun = true)
    public void beforeMethod(final String browser, final String entity, Method testMethod) throws Exception {
        this.browserLib = new BrowserLib(browser);
        this.driver = this.browserLib.getDriver();
        this.envProperties = FileUtil.getConfigProperties(entity);
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        try {
            loginModel = (LoginModel) ReflectionUtil.getEntityPOM(entity, "LoginPage", driver);
            navigate = (FlyerMenuNavigationModel) ReflectionUtil.getEntityPOM(entity, "FlyerMenuNavigation", driver);
            mmCapturePageModel = (MoveMoneyCapturePageModel) ReflectionUtil.getEntityPOM(entity, "MoveMoneyCapturePage", driver);
            mmVerifyPageModel = (MoveMoneyVerifyPageModel) ReflectionUtil.getEntityPOM(entity, "MoveMoneyVerifyPage", driver);
            mmConfirmPageModel = (MoveMoneyConfirmPageModel) ReflectionUtil.getEntityPOM(entity, "MoveMoneyConfirmPage", driver);
            landingPageModel = (LandingPageModel) ReflectionUtil.getEntityPOM(entity, "LandingPage", driver);
            String profile = XMLUtil.getProfileName(testMethod, entity);
            loginModel.login(profile, this.envProperties);
            loginModel.switchLanguage("English");
        } catch (ClassNotFoundException e) {
            M2MDomesticAU.logger.error("Exception thrown at Login Contructor:", e);
        } catch (InstantiationException e) {
            M2MDomesticAU.logger.error("Exception thrown at Login Contructor:", e);
        } catch (IllegalAccessException e) {
            M2MDomesticAU.logger.error("Exception thrown at Login Contructor:", e);
        }
    }


    /******************* Now Flow ***********/
    @Test(groups = {"functionaltest", "regressiontest", "smoketest"})
    @Parameters("browser")
    public void m2mLCYToLCYNow() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2M_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.selectDomesticToLCYAccount(envProperties.get("currencyCode")));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickCancelButton();
            mmCapturePageModel.clickContinuePopupContinueButton();
            mmCapturePageModel.verifyDetailsAfterContinueCancelOnCapturePage(transaction);
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyLCY2LCYNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyLCY2LCYNowTransactionDetailsOnConfirmPage(transaction);
            mmConfirmPageModel.referenceNumber(transaction);
            mmConfirmPageModel.clickBacktoMyAccountsButton();
            landingPageModel.selectAccountOnDashboardByNameAndNumber(transaction.getFromAccount());
            landingPageModel.isImmediateTransactionPosted(transaction);
        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage());
            M2MDomesticAU.logger.error(e);
        }
    }

    @Test(groups = {"functionaltest", "regressiontest", "smoketest"})
    @Parameters("browser")
    public void m2mLCYToLCYNowCancelAtCapturePage() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2M_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            mmCapturePageModel.selectDomesticToLCYAccount(envProperties.get("currencyCode"));
            mmCapturePageModel.enterTransferAmount(transaction);
            mmCapturePageModel.enterYourReferenceText(transaction);
            mmCapturePageModel.clickCancelButton();
            mmCapturePageModel.clickCancelPopUpCancelButton();
            mmCapturePageModel.checkDashBoardContent();

        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage());
            M2MDomesticAU.logger.error(e);
        }
    }

    /**
     * 
     * For PRD this Flow is Not Applicable
     */
    @Test(groups = {"functionaltest", "regressiontest", "smoketest"})
    @Parameters("browser")
    public void m2mLCYToFCYNow() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2M_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.selectDomesticToFCYAccount(envProperties.get("currencyCode")));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyLCY2FCYNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyLCY2FCYNowTransactionDetailsOnConfirmPage(transaction);

        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage());
            M2MDomesticAU.logger.error(e);
        }
    }

    /**
     * 
     * For PRD this Flow is Not Applicable
     */
    @Test(groups = {"functionaltest", "regressiontest", "smoketest"})
    @Parameters("browser")
    public void m2mFCYToLCYNow() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2M_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.selectDomesticToLCYAccount(envProperties.get("currencyCode")));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            transaction.setReasonForTransaction(mmCapturePageModel.selectReasonForTransaction(transaction));
            mmCapturePageModel.clickTermsAndConditionsCheckBox();
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyFCY2LCYNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyFCY2LCYNowTransactionDetailsOnConfirmPage(transaction);

        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage());
            M2MDomesticAU.logger.error(e);
        }
    }

    @Test(groups = {"functionaltest", "regressiontest", "smoketest"})
    @Parameters("browser")
    public void m2mFCYToFCYNow() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2M_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.selectDomesticToFCYAccount(envProperties.get("currencyCode")));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyFCY2FCYNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyFCY2FCYNowTransactionDetailsOnConfirmPage(transaction);

        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage());
            M2MDomesticAU.logger.error(e);
        }
    }

    @Test(groups = {"functionaltest", "regressiontest", "smoketest"})
    @Parameters("browser")
    public void m2mFCYToLCYNowEditDetailOnVerifyPage() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2M_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.selectDomesticToLCYAccount(envProperties.get("currencyCode")));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            transaction.setReasonForTransaction(mmCapturePageModel.selectReasonForTransaction(transaction));
            mmCapturePageModel.clickTermsAndConditionsCheckBox();
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyFCY2LCYNowTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickEditDetailsButton();
            mmCapturePageModel.verifyCaptureDetailsAfterEditOnVerifyPageforM2M(transaction);
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.selectDomesticToLCYAccount(envProperties.get("currencyCode")));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            transaction.setReasonForTransaction(mmCapturePageModel.selectReasonForTransaction(transaction));
            mmCapturePageModel.clickTermsAndConditionsCheckBox();
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyFCY2LCYNowTransactionDetailsOnVerifyPage(transaction);

        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage());
            M2MDomesticAU.logger.error(e);
        }
    }

    /******************* Later Flow ***********/
    @Test(groups = {"functionaltest", "regressiontest", "smoketest"})
    @Parameters("browser")
    public void m2mLCYToLCYLater() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2M_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.selectDomesticToLCYAccount(envProperties.get("currencyCode")));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickLaterTab();
            transaction.setLaterDate(mmCapturePageModel.enterLaterDate(envProperties));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyLCY2LCYLaterTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyLCY2LCYLaterTransactionDetailsOnConfirmPage(transaction);

        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
            M2MDomesticAU.logger.error(e);
        }
    }

    /**
     * This Flow is Not Applicable for PRD
     */
    @Test(groups = {"functionaltest", "regressiontest", "smoketest"})
    @Parameters("browser")
    public void m2mLCYToFCYLater() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2M_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.selectDomesticToLCYAccount(envProperties.get("currencyCode")));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickLaterTab();
            transaction.setLaterDate(mmCapturePageModel.enterLaterDate(envProperties));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyLCY2FCYLaterTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyLCY2FCYLaterTransactionDetailsOnConfirmPage(transaction);

        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage());
            M2MDomesticAU.logger.error(e);
        }
    }

    /**
     * This Flow is Not Applicable for PRD
     */
    @Test(groups = {"functionaltest", "regressiontest", "smoketest"})
    @Parameters("browser")
    public void m2mFCYToLCYLater() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2M_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.selectDomesticToLCYAccount(envProperties.get("currencyCode")));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickLaterTab();
            transaction.setLaterDate(mmCapturePageModel.enterLaterDate(envProperties));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyFCY2LCYLaterTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyFCY2LCYLaterTransactionDetailsOnConfirmPage(transaction);

        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage());
            M2MDomesticAU.logger.error(e);
        }
    }

    @Test(groups = {"functionaltest", "regressiontest", "smoketest"})
    @Parameters("browser")
    public void m2mFCYToFCYLater() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2M_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromFCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.selectDomesticToFCYAccount(envProperties.get("currencyCode")));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickLaterTab();
            transaction.setLaterDate(mmCapturePageModel.enterLaterDate(envProperties));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyFCY2FCYLaterTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyFCY2FCYLaterTransactionDetailsOnConfirmPage(transaction);

        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage());
            M2MDomesticAU.logger.error(e);
        }
    }

    @Test(groups = {"functionaltest", "regressiontest", "smoketest"})
    @Parameters("browser")
    public void m2mLCYToLCYLaterCancelAtReviewPage() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2M_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.selectDomesticToLCYAccount(envProperties.get("currencyCode")));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickLaterTab();
            transaction.setLaterDate(mmCapturePageModel.enterLaterDate(envProperties));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyLCY2FCYLaterTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickCancelButton();
            mmVerifyPageModel.clickCancelPopUpCancelButton();
            mmCapturePageModel.verifyDetailsAfterCancelOnVerifyPage(transaction);

        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage());
            M2MDomesticAU.logger.error(e);
        }
    }

    /******************* Recurring Flow ***********/
    @Test(groups = {"functionaltest", "regressiontest", "smoketest"})
    @Parameters("browser")
    public void m2mLCYToLCYRecurringNumberOfPayment() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2M_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.selectDomesticToLCYAccount(envProperties.get("currencyCode")));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickRecurringTab();
            transaction.setFrequencyValue(mmCapturePageModel.selectFrequency());
            transaction.setFirstDateOfTransaction(mmCapturePageModel.enterDateOfFirstTransfer(envProperties));
            transaction.setNumberOfPayment(mmCapturePageModel.enterNumberOfPayment(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyM2MLCY2LCYRecurringTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2MLCY2LCYRecurringTransactionDetailsOnConfirmPage(transaction);

        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
            M2MDomesticAU.logger.error(e);
        }
    }


    @Test(groups = {"functionaltest", "regressiontest", "smoketest"})
    @Parameters("browser")
    public void m2mLCYToFCYRecurringNumberOfPayment() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2M_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.selectDomesticToFCYAccount(envProperties.get("currencyCode")));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickRecurringTab();
            transaction.setFrequencyValue(mmCapturePageModel.selectFrequency());
            transaction.setFirstDateOfTransaction(mmCapturePageModel.enterDateOfFirstTransfer(envProperties));
            transaction.setNumberOfPayment(mmCapturePageModel.enterNumberOfPayment(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyM2MLCY2FCYRecurringTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2MLCY2FCYRecurringTransactionDetailsOnConfirmPage(transaction);

        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
            M2MDomesticAU.logger.error(e);
        }
    }

    @Test(groups = {"functionaltest", "regressiontest", "smoketest"})
    @Parameters("browser")
    public void m2mFCYToLCYRecurringNumberOfPayment() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2M_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.selectDomesticToLCYAccount(envProperties.get("currencyCode")));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickRecurringTab();
            transaction.setFrequencyValue(mmCapturePageModel.selectFrequency());
            transaction.setFirstDateOfTransaction(mmCapturePageModel.enterDateOfFirstTransfer(envProperties));
            transaction.setNumberOfPayment(mmCapturePageModel.enterNumberOfPayment(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyM2MFCY2LCYRecurringTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2MFCY2LCYRecurringTransactionDetailsOnConfirmPage(transaction);

        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage());
            M2MDomesticAU.logger.error(e);
        }
    }

    @Test(groups = {"functionaltest", "regressiontest", "smoketest"})
    @Parameters("browser")
    public void m2mFCYToFCYRecurringNumberOfPayment() {
        try {
            Transaction transaction = new Transaction();
            transaction.setTransactionFlow(TransactionFlow.M2M_TRANSFER);
            navigate.navigateToNewTransactionPage();
            transaction.setFromAccount(mmCapturePageModel.selectDomesticFromLCYAccount(envProperties.get("currencyCode")));
            transaction.setToAccount(mmCapturePageModel.selectDomesticToLCYAccount(envProperties.get("currencyCode")));
            transaction.setAmount(mmCapturePageModel.enterTransferAmount(transaction));
            transaction.setYourReference(mmCapturePageModel.enterYourReferenceText(transaction));
            mmCapturePageModel.clickRecurringTab();
            transaction.setFrequencyValue(mmCapturePageModel.selectFrequency());
            transaction.setFirstDateOfTransaction(mmCapturePageModel.enterDateOfFirstTransfer(envProperties));
            transaction.setNumberOfPayment(mmCapturePageModel.enterNumberOfPayment(transaction));
            mmCapturePageModel.clickContinueButton();
            mmVerifyPageModel.verifyM2MFCY2FCYRecurringTransactionDetailsOnVerifyPage(transaction);
            mmVerifyPageModel.clickConfirmButton();
            mmConfirmPageModel.verifyM2MFCY2FCYRecurringTransactionDetailsOnConfirmPage(transaction);

        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage());
            M2MDomesticAU.logger.error(e);
        }
    }

    @AfterMethod(alwaysRun = true)
    public void afterMethod() {
        // Log off needs to be impl
        browserLib.closeAllBrowsers();
    }

}
