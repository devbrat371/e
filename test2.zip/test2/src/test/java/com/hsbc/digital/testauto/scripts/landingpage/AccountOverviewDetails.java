/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.scripts.landingpage;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.hsbc.digital.testauto.library.BrowserLib;
import com.hsbc.digital.testauto.library.FileUtil;
import com.hsbc.digital.testauto.library.ReflectionUtil;
import com.hsbc.digital.testauto.library.XMLUtil;
import com.hsbc.digital.testauto.pageobject.LandingPageModel;
import com.hsbc.digital.testauto.pageobject.LoginModel;

/**
 * <p>
 * <b> This class will hold testing scripts for story 35 Account Overview </b>
 * </p>
 * 
 * @version 1.0.0
 * @author Deepti Patil
 * 
 */
public class AccountOverviewDetails {

    WebDriver driver;
    BrowserLib browserLib;
    Map<String, String> envProperties;
    LoginModel loginModel;
    LandingPageModel landingPageModel;

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(AccountOverviewDetails.class);

    @Parameters({"browser", "entity"})
    @BeforeMethod(alwaysRun = true)
    public void beforeMethod(final String browser, final String entity, final Method testMethod) {
        try {
            this.browserLib = new BrowserLib(browser);
            this.driver = this.browserLib.getDriver();
            this.envProperties = FileUtil.getConfigProperties(entity);
            String profile = XMLUtil.getProfileName(testMethod, entity);
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            loginModel = (LoginModel) ReflectionUtil.getEntityPOM(entity, "LoginPage", driver);
            landingPageModel = (LandingPageModel) ReflectionUtil.getEntityPOM(entity, "LandingPage", driver);
            landingPageModel.readProductTypeMapping(entity);
            loginModel.login(profile, this.envProperties);
            loginModel.switchLanguage("English");
        } catch (Exception e) {
            AccountOverviewDetails.logger.error("Exception thrown at Login Contructor:", e);
        }
    }

    @Test(testName = "Verify Account Details Section and print functionality", groups = {"functionaltest"})
    public void accountDetails() {
        try {
            landingPageModel.verifyAccountOverviewSection();
        } catch (Exception e) {
            AccountOverviewDetails.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @AfterMethod(alwaysRun = true)
    public void afterTest() {
        this.browserLib.closeAllBrowsers();
    }

    /**
     * 
     * <p>
     * <b> This method is used to take screen shot so every test script should
     * have it as it is used by Framework internally. </b>
     * </p>
     * 
     * @return driver
     */
    public WebDriver getDriver() {
        return this.driver;
    }
}
