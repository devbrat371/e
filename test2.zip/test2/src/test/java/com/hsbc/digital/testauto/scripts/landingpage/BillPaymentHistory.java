/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * 
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.scripts.landingpage;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.hsbc.digital.testauto.library.BrowserLib;
import com.hsbc.digital.testauto.library.FileUtil;
import com.hsbc.digital.testauto.library.RandomUtil;
import com.hsbc.digital.testauto.library.ReflectionUtil;
import com.hsbc.digital.testauto.library.XMLUtil;
import com.hsbc.digital.testauto.models.BillPaymentDetails;
import com.hsbc.digital.testauto.pageobject.BillPaymentHistoryModel;
import com.hsbc.digital.testauto.pageobject.FlyerMenuNavigationModel;
import com.hsbc.digital.testauto.pageobject.LoginModel;
import com.hsbc.digital.testauto.pageobject.MoveMoneyCapturePageModel;


/**
 * <p>
 * <b> This class will hold testing scripts for story 1 - View Bill Payment
 * History </b>
 * </p>
 * 
 * @version 1.0.0
 * @author Midde Rajesh Kumar
 * 
 */
public class BillPaymentHistory {

    WebDriver driver;
    BrowserLib browserLib;
    Map<String, String> envProperties;
    LoginModel loginModel;
    BillPaymentHistoryModel billPaymentHistoryModel;
    FlyerMenuNavigationModel flyerMenuNavigation;
    MoveMoneyCapturePageModel moveMoneyCapturePageModel;

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(BillPaymentHistory.class);

    @Parameters({"browser", "entity"})
    @BeforeMethod(alwaysRun = true)
    public void beforeMethod(final String browser, final String entity, final Method method) {
        try {
            browserLib = new BrowserLib(browser);
            driver = browserLib.getDriver();
            envProperties = FileUtil.getConfigProperties(entity);
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            loginModel = (LoginModel) ReflectionUtil.getEntityPOM(entity, "LoginPage", driver);
            billPaymentHistoryModel = (BillPaymentHistoryModel) ReflectionUtil.getEntityPOM(entity, "BillPaymentHistory", driver);
            flyerMenuNavigation = (FlyerMenuNavigationModel) ReflectionUtil.getEntityPOM(entity, "FlyerMenuNavigation", driver);
            moveMoneyCapturePageModel = (MoveMoneyCapturePageModel) ReflectionUtil.getEntityPOM(entity, "MoveMoneyCapturePage",
                driver);
            String profile = XMLUtil.getProfileName(method, entity);
            loginModel.login(profile, envProperties);
            loginModel.switchLanguage("English");
        } catch (Exception e) {
            BillPaymentHistory.logger.error("Exception thrown at Login Contructor:", e);
        }
    }

    /**
     * 
     * This method is to view, verify Bill Payment Transactions by date
     * 
     */
    @Test(groups = {"functionaltest"})
    public void viewBillPaymentTransactionsByDate() {
        try {
            flyerMenuNavigation.navigateToBillPaymentHistory();
            billPaymentHistoryModel.selectAccount();
            billPaymentHistoryModel.clickSearchButton();
            String fromDate = billPaymentHistoryModel.getFromDate();
            billPaymentHistoryModel.enterFromDate(fromDate);
            String toDate = billPaymentHistoryModel.getToDate();
            billPaymentHistoryModel.enterToDate(toDate);
            billPaymentHistoryModel.clickViewResultButton();
            billPaymentHistoryModel.verifyBillPaymentHistoryByDate(fromDate, toDate);
        } catch (Exception e) {
            BillPaymentHistory.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * 
     * This method is to view, verify Bill Payment Transactions by Description
     * Name
     * 
     */
    @Test(groups = {"functionaltest"})
    public void viewBillPaymentTransactionsByName() {
        try {
            flyerMenuNavigation.navigateToBillPaymentHistory();
            billPaymentHistoryModel.selectAccount();
            billPaymentHistoryModel.clickSearchButton();
            String descriptionName = billPaymentHistoryModel.getDescriptionName();
            billPaymentHistoryModel.searchByBenificiaryName(descriptionName);
            billPaymentHistoryModel.clickViewResultButton();
            billPaymentHistoryModel.compareResultByName(descriptionName);
        } catch (Exception e) {
            BillPaymentHistory.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }


    /**
     * 
     * This method is to view, verify and sort Bill Payment Transactions by
     * Amount
     * 
     */
    @Test(groups = {"functionaltest"})
    public void viewBillPaymentTransactionsByAmount() {
        try {
            flyerMenuNavigation.navigateToBillPaymentHistory();
            billPaymentHistoryModel.selectAccount();
            billPaymentHistoryModel.clickSearchButton();
            Double fromAmount = billPaymentHistoryModel.getFromAmount();
            billPaymentHistoryModel.enterFromAmount(fromAmount);
            Double toAmount = billPaymentHistoryModel.getToAmount();
            billPaymentHistoryModel.enterToAmount(toAmount);
            billPaymentHistoryModel.clickViewResultButton();
            billPaymentHistoryModel.checkBillPaymentHistoryAvailability();
            billPaymentHistoryModel.compareResultByAmount(fromAmount, toAmount);
        } catch (Exception e) {
            BillPaymentHistory.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * 
     * This method is to verify sort Bill Payment Transactions by date
     * 
     */
    @Test(groups = {"functionaltest"})
    public void verifySortingByDate() {
        try {
            flyerMenuNavigation.navigateToBillPaymentHistory();
            billPaymentHistoryModel.selectAccount();
            billPaymentHistoryModel.sortByDate();
        } catch (Exception e) {
            BillPaymentHistory.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * 
     * This method is to verify sort Bill Payment Transactions by Description
     * Name
     * 
     */
    @Test(groups = {"functionaltest"})
    public void verifySortingByName() {
        try {
            flyerMenuNavigation.navigateToBillPaymentHistory();
            billPaymentHistoryModel.selectAccount();
            billPaymentHistoryModel.sortDescription();
        } catch (Exception e) {
            BillPaymentHistory.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * 
     * This method is to verify sort Bill Payment Transactions by Amount
     * 
     */
    @Test(groups = {"functionaltest"})
    public void verifySortingByAmount() {
        try {
            flyerMenuNavigation.navigateToBillPaymentHistory();
            billPaymentHistoryModel.selectAccount();
            billPaymentHistoryModel.sortByAmount();
        } catch (Exception e) {
            BillPaymentHistory.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * 
     * This method is for Verifying the clear filters functionality
     * 
     */
    @Test(groups = {"functionaltest"})
    public void verifyClearResultButtonFunctionality() {
        try {
            flyerMenuNavigation.navigateToBillPaymentHistory();
            billPaymentHistoryModel.selectAccount();
            billPaymentHistoryModel.clickSearchButton();
            billPaymentHistoryModel.searchByBenificiaryName(RandomUtil.generateAlphabatic(5));
            billPaymentHistoryModel.verifyClearResultsButton();
            billPaymentHistoryModel.checkBillPaymentHistoryAvailability();
            billPaymentHistoryModel.defaultOrderCheck();
        } catch (Exception e) {
            BillPaymentHistory.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * 
     * This method is for verifying the Print button functionality
     * 
     */
    @Test(groups = {"functionaltest"})
    public void verifyPrintButtonFunctionality() {
        try {
            flyerMenuNavigation.navigateToBillPaymentHistory();
            billPaymentHistoryModel.selectAccount();
            billPaymentHistoryModel.clickPrintButton();
            billPaymentHistoryModel.verifyPrintPopupDialogDisplayed();
        } catch (Exception e) {
            BillPaymentHistory.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * 
     * This method is for verifying the Help button functionality
     * 
     */
    @Test(groups = {"functionaltest"})
    public void verifyHelpButtonFunctionality() {
        try {
            flyerMenuNavigation.navigateToBillPaymentHistory();
            billPaymentHistoryModel.selectAccount();
            billPaymentHistoryModel.verifyHelpIcon();
        } catch (Exception e) {
            BillPaymentHistory.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * 
     * This method is for verifying error message functionality
     * 
     */
    @Test(groups = {"functionaltest"})
    public void verifyErrorMessageFunctionality() {
        try {
            flyerMenuNavigation.navigateToBillPaymentHistory();
            billPaymentHistoryModel.selectAccount();
            billPaymentHistoryModel.clickSearchButton();
            billPaymentHistoryModel.searchByBenificiaryName(RandomUtil.generateAlphabatic(5));
            billPaymentHistoryModel.clickViewResultButton();
            billPaymentHistoryModel.verifyErrorMessage();
        } catch (Exception e) {
            BillPaymentHistory.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    /**
     * 
     * This method is to view, verify Bill Payment Transactions by Description
     * Name selecting SelectAllAccounts option
     * 
     */
    @Test(groups = {"functionaltest"})
    public void viewBillPaymentBySelectAllAccountsOption() {
        try {
            flyerMenuNavigation.navigateToBillPaymentHistory();
            billPaymentHistoryModel.selectSelectAllAccounts();
            billPaymentHistoryModel.clickSearchButton();
            String descriptionName = billPaymentHistoryModel.getDescriptionName();
            billPaymentHistoryModel.searchByBenificiaryName(descriptionName);
            billPaymentHistoryModel.clickViewResultButton();
            billPaymentHistoryModel.compareResultByName(descriptionName);
        } catch (Exception e) {
            BillPaymentHistory.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(testName = "verify visibility of ViewMore button", groups = {"functionaltest"})
    public void verifyVisibilityOfViewMore() {
        try {
            flyerMenuNavigation.navigateToBillPaymentHistory();
            billPaymentHistoryModel.selectAccount();
            billPaymentHistoryModel.verifyVisibilityOfViewMoreButton();
        } catch (Exception e) {
            BillPaymentHistory.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage());
        }
    }

    @Test(testName = "Verify functionality of 'Search Again' button", groups = {"functionaltest"})
    public void verifySearchAgainButtonFunctionality() {
        try {
            flyerMenuNavigation.navigateToBillPaymentHistory();
            billPaymentHistoryModel.selectAccount();
            billPaymentHistoryModel.clickSearchButton();
            String fromDate = billPaymentHistoryModel.getFromDate();
            billPaymentHistoryModel.enterFromDate(fromDate);
            String toDate = billPaymentHistoryModel.getToDate();
            billPaymentHistoryModel.enterToDate(toDate);
            String descriptionName = billPaymentHistoryModel.getDescriptionName();
            billPaymentHistoryModel.searchByBenificiaryName(descriptionName);
            billPaymentHistoryModel.clickViewResultButton();
            billPaymentHistoryModel.validateDisclaimerText();
            billPaymentHistoryModel.verifySearchAgainButton(descriptionName);
        } catch (Exception e) {
            BillPaymentHistory.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(testName = "Verify functionality of Clear Search button", groups = {"functionaltest"})
    public void verifyClearSearchButtonFunctionality() {
        try {
            BillPaymentDetails billPaymentDetails = new BillPaymentDetails();
            flyerMenuNavigation.navigateToBillPaymentHistory();
            billPaymentHistoryModel.selectAccount();
            billPaymentHistoryModel.clickSearchButton();
            billPaymentDetails.setTransactionsList(billPaymentHistoryModel.transactionsList());
            String descriptionName = billPaymentHistoryModel.getDescriptionName();
            billPaymentHistoryModel.searchByBenificiaryName(descriptionName);
            billPaymentHistoryModel.clickViewResultButton();
            billPaymentHistoryModel.verifyClearSearchButton(billPaymentDetails.getTransactionsList());
            billPaymentHistoryModel.defaultOrderCheck();
        } catch (Exception e) {
            BillPaymentHistory.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(testName = "Validate Transactions Default order", groups = {"functionaltest"})
    public void validateTransactionsDefaultOrder() {
        try {
            flyerMenuNavigation.navigateToBillPaymentHistory();
            billPaymentHistoryModel.selectAccount();
            billPaymentHistoryModel.defaultOrderCheck();
        } catch (Exception e) {
            BillPaymentHistory.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(testName = "Verify Move Money Button Functionality", groups = {"functionaltest"})
    public void verifyMoveMoneyButtonFunctionality() {
        try {
            flyerMenuNavigation.navigateToBillPaymentHistory();
            billPaymentHistoryModel.selectAccount();
            billPaymentHistoryModel.clickMoveMoneyButton();
            moveMoneyCapturePageModel.verifyPageTitle();
        } catch (Exception e) {
            BillPaymentHistory.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @AfterMethod(alwaysRun = true)
    public void afterMethod() {
        browserLib.closeAllBrowsers();
    }

    /**
     * 
     * <p>
     * <b> This method is used to take screen shot so every test script should
     * have it as it is used by Framework internally. </b>
     * </p>
     * 
     * @return driver
     */
    public WebDriver getDriver() {
        return driver;
    }
}
