package com.hsbc.digital.testauto.scripts.movemoney;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.hsbc.digital.testauto.library.BrowserLib;
import com.hsbc.digital.testauto.library.FileUtil;
import com.hsbc.digital.testauto.library.ReflectionUtil;
import com.hsbc.digital.testauto.library.XMLUtil;
import com.hsbc.digital.testauto.models.AddBeneficiaryDetails;
import com.hsbc.digital.testauto.pageobject.AddBeneficiaryModel;
import com.hsbc.digital.testauto.pageobject.FlyerMenuNavigationModel;
import com.hsbc.digital.testauto.pageobject.LoginModel;

/**
 * <p>
 * <b> This class is holding Test Case and functionality for Adding standalone
 * beneficiary . Story 40</b>
 * </p>
 * 
 * @author Shweta Jain
 * @version 1.0.0
 */

public class AddBeneficiary {
    WebDriver driver;
    BrowserLib browserLib;
    Map<String, String> envProperties;
    LoginModel loginModel;
    FlyerMenuNavigationModel navigate;
    AddBeneficiaryModel addBeneficiaryModel;
    Map<String, String> profileProperties;
    private static final String ACCOUNT_DIGIT_LENGTH = "accountNoLengthTDS";
    private static final String HSBC_ACCOUNT_NUMBER = "HSBCAccNo";

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(AddBeneficiary.class);

    @Parameters({"browser", "entity"})
    @BeforeMethod(alwaysRun = true)
    public void beforeMethod(final String browser, final String entity, final Method testMethod) {
        try {
            this.browserLib = new BrowserLib(browser);
            this.driver = this.browserLib.getDriver();
            this.envProperties = FileUtil.getConfigProperties(entity);
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            loginModel = (LoginModel) ReflectionUtil.getEntityPOM(entity, "LoginPage", driver);
            navigate = (FlyerMenuNavigationModel) ReflectionUtil.getEntityPOM(entity, "FlyerMenuNavigation", driver);
            addBeneficiaryModel = (AddBeneficiaryModel) ReflectionUtil.getEntityPOM(entity, "AddBeneficiary", driver);
            String profile = XMLUtil.getProfileName(testMethod, entity);
            loginModel.login(profile, this.envProperties);
            loginModel.switchLanguage("English");
            profileProperties = FileUtil.getTestDataProperties(envProperties.get("countryCode"), profile);

        } catch (Exception e) {
            AddBeneficiary.logger.error("Exception thrown at Login Contructor:", e);
        }
    }

    /**
     * Test Case for adding HSBC Bank domestic Payee-End to End flow
     * 
     */
    @Test(groups = {"functionaltest"}, testName = "Add_HSBC_Domestic_Payee_E2E")
    public void addDomesticHSBCBankPayee() {
        AddBeneficiaryDetails beneficiaryDetails = new AddBeneficiaryDetails();
        try {
            int lastDigitsLength = Integer.parseInt(envProperties.get(AddBeneficiary.ACCOUNT_DIGIT_LENGTH));
            String accountNum = profileProperties.get(AddBeneficiary.HSBC_ACCOUNT_NUMBER);
            navigate.navigateToMypayeesPage();
            beneficiaryDetails.setPayeeCount(addBeneficiaryModel.addPersonPayee());
            beneficiaryDetails.setAccountType(addBeneficiaryModel.selectHSBCDomesticPayee());
            beneficiaryDetails.setBankDetails(addBeneficiaryModel.enterHSBCBankDetails(accountNum));
            beneficiaryDetails.setPayeeName(addBeneficiaryModel.enterHSBCPayeeName());
            addBeneficiaryModel.enterTDS(profileProperties, accountNum, lastDigitsLength);
            addBeneficiaryModel.continueAddpayeeFlow();
            addBeneficiaryModel.clickSavebutton();
            addBeneficiaryModel.verifyPayeeReviewPage(beneficiaryDetails);
            addBeneficiaryModel.clickConfirmOnReviewPage();
            addBeneficiaryModel.verifySucessMessage(beneficiaryDetails);
            addBeneficiaryModel.closeConfirmDialog();
            addBeneficiaryModel.searchNewlyAddedPayee(beneficiaryDetails.getPayeeName(), accountNum,
                beneficiaryDetails.getPayeeCount());

        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
            AddBeneficiary.logger.error(e);
        }
    }

    /* *//**
     * Test Case for adding Other Local Bank Payee-End to End flow
     * 
     */

    @Test(groups = {"functionaltest"}, testName = "Add_Other_Local_Bank_Payee_E2E")
    public void addOtherLocalbankPayee() {
        try {
            int lastDigitsLength = Integer.parseInt(envProperties.get(AddBeneficiary.ACCOUNT_DIGIT_LENGTH));
            AddBeneficiaryDetails beneficiaryDetails = new AddBeneficiaryDetails();
            String bankNameSearch = profileProperties.get("BankSearchText");
            navigate.navigateToMypayeesPage();
            beneficiaryDetails.setPayeeCount(addBeneficiaryModel.addPersonPayee());
            beneficiaryDetails.setAccountType(addBeneficiaryModel.selectOtherLocalBankPayee());
            beneficiaryDetails.setBankDetails(addBeneficiaryModel.enterNonHSBCBankDetails(bankNameSearch));
            beneficiaryDetails.setPayeeName(addBeneficiaryModel.enterPayeeName());
            beneficiaryDetails.setPayeeAddressFields(addBeneficiaryModel.enterPayeeAddressDetails());
            addBeneficiaryModel.enterTDS(profileProperties, beneficiaryDetails.getBankDetails().getAccountNumber(),
                lastDigitsLength);
            addBeneficiaryModel.clickSavebutton();
            addBeneficiaryModel.verifyPayeeReviewPage(beneficiaryDetails);
            addBeneficiaryModel.clickConfirmOnReviewPage();
            addBeneficiaryModel.verifySucessMessage(beneficiaryDetails);
            addBeneficiaryModel.closeConfirmDialog();
            addBeneficiaryModel.searchNewlyAddedPayee(beneficiaryDetails.getPayeeName(), beneficiaryDetails.getBankDetails()
                .getAccountNumber(), beneficiaryDetails.getPayeeCount());
        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
            AddBeneficiary.logger.error("Exception:", e);
        }
    }

    /**
     * Test Case for adding International bank Payee -End to End flow
     * 
     */

    @Test(groups = {"functionaltest"}, testName = "Add_International_Payee_E2E")
    public void addInternationalPayee() {
        try {
            int lastDigitsLength = Integer.parseInt(envProperties.get(AddBeneficiary.ACCOUNT_DIGIT_LENGTH));
            AddBeneficiaryDetails objAddBeneDetails = new AddBeneficiaryDetails();
            navigate.navigateToMypayeesPage();
            objAddBeneDetails.setPayeeCount(addBeneficiaryModel.addPersonPayee());
            objAddBeneDetails.setAccountType(addBeneficiaryModel.setInternationalPayeeType());
            objAddBeneDetails.setBankDetails(addBeneficiaryModel.enterInternationalPayeeBankDetails(false));
            objAddBeneDetails.setPayeeName(addBeneficiaryModel.enterPayeeName());
            objAddBeneDetails.setPayeeAddressFields(addBeneficiaryModel.enterPayeeAddressDetails());
            addBeneficiaryModel
                .enterTDS(profileProperties, objAddBeneDetails.getBankDetails().getAccountNumber(), lastDigitsLength);
            addBeneficiaryModel.clickSavebutton();
            addBeneficiaryModel.verifyPayeeReviewPage(objAddBeneDetails);
            addBeneficiaryModel.clickConfirmOnReviewPage();
            addBeneficiaryModel.verifySucessMessage(objAddBeneDetails);
            addBeneficiaryModel.closeConfirmDialog();
            addBeneficiaryModel.searchNewlyAddedPayee(objAddBeneDetails.getPayeeName(), objAddBeneDetails.getBankDetails()
                .getAccountNumber(), objAddBeneDetails.getPayeeCount());

        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
            AddBeneficiary.logger.error("Exception:", e);
        }
    }

    /**
     * Test Case for adding International Bank Payee with City & Branch
     * selected as 'Other' End to End flow
     * 
     */

    @Test(groups = {"functionaltest"}, testName = "Add_Others_City&Bank_International_Payee_E2E")
    public void addOtherCityInternationalPayee() {
        try {
            AddBeneficiaryDetails addBeneficiaryDetails = new AddBeneficiaryDetails();
            int lastDigitsLength = Integer.parseInt(envProperties.get(AddBeneficiary.ACCOUNT_DIGIT_LENGTH));
            navigate.navigateToMypayeesPage();
            addBeneficiaryDetails.setPayeeCount(addBeneficiaryModel.addPersonPayee());
            addBeneficiaryDetails.setAccountType(addBeneficiaryModel.setInternationalPayeeType());
            addBeneficiaryDetails.setBankDetails(addBeneficiaryModel.enterInternationalPayeeBankDetails(true));
            addBeneficiaryDetails.setPayeeName(addBeneficiaryModel.enterPayeeName());
            addBeneficiaryDetails.setPayeeAddressFields(addBeneficiaryModel.enterPayeeAddressDetails());
            addBeneficiaryModel.enterTDS(profileProperties, addBeneficiaryDetails.getBankDetails().getAccountNumber(),
                lastDigitsLength);
            addBeneficiaryModel.clickSavebutton();
            addBeneficiaryModel.verifyPayeeReviewPage(addBeneficiaryDetails);
            addBeneficiaryModel.clickConfirmOnReviewPage();
            addBeneficiaryModel.verifySucessMessage(addBeneficiaryDetails);
            addBeneficiaryModel.closeConfirmDialog();
            addBeneficiaryModel.searchNewlyAddedPayee(addBeneficiaryDetails.getPayeeName(), addBeneficiaryDetails.getBankDetails()
                .getAccountNumber(), addBeneficiaryDetails.getPayeeCount());

        } catch (Exception e) {
            AddBeneficiary.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);

        }
    }

    /**
     * Test Case for adding Company Payee for Bill payement
     */

    @Test(groups = {"functionaltest"}, testName = "addCompanyPayee")
    public void addCompanyPayee() {
        try {
            AddBeneficiaryDetails objAddBeneDetails = new AddBeneficiaryDetails();
            navigate.navigateToMypayeesPage();
            objAddBeneDetails.setPayeeCount(addBeneficiaryModel.addCompanyPayee());
            objAddBeneDetails.setAccountType(addBeneficiaryModel.setCompanyPayeeType());
            objAddBeneDetails.setPayeeName(addBeneficiaryModel.selectCompanyPayee());
            objAddBeneDetails.setBankDetails(addBeneficiaryModel.enterCompanyPayeeDetails());
            addBeneficiaryModel.clickSavebutton();
            addBeneficiaryModel.verifyPayeeReviewPage(objAddBeneDetails);
            addBeneficiaryModel.clickConfirmOnReviewPage();
            addBeneficiaryModel.verifySucessMessage(objAddBeneDetails);
            addBeneficiaryModel.closeConfirmDialog();
            addBeneficiaryModel.searchNewlyAddedPayee(objAddBeneDetails.getPayeeName(), objAddBeneDetails.getBankDetails()
                .getAccountNumber(), objAddBeneDetails.getPayeeCount());
        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
            AddBeneficiary.logger.error("Exception:", e);
        }
    }

    /**
     * Test Case to check Cancel Button functionality
     * 
     */

    @Test(groups = {"functionaltest"}, testName = "Cancel_AddPayee_Flow")
    @Parameters("browser")
    public void cancelAddpayeeFlow() {
        try {
            AddBeneficiaryDetails objAddBeneDetails = new AddBeneficiaryDetails();
            int lastDigitsLength = Integer.parseInt(envProperties.get(AddBeneficiary.ACCOUNT_DIGIT_LENGTH));
            String bankNameSearch = profileProperties.get("BankSearchText");
            navigate.navigateToMypayeesPage();
            objAddBeneDetails.setPayeeCount(addBeneficiaryModel.addPersonPayee());
            objAddBeneDetails.setAccountType(addBeneficiaryModel.selectOtherLocalBankPayee());
            objAddBeneDetails.setBankDetails(addBeneficiaryModel.enterNonHSBCBankDetails(bankNameSearch));
            objAddBeneDetails.setPayeeName(addBeneficiaryModel.enterPayeeName());
            objAddBeneDetails.setPayeeAddressFields(addBeneficiaryModel.enterPayeeAddressDetails());
            addBeneficiaryModel
                .enterTDS(profileProperties, objAddBeneDetails.getBankDetails().getAccountNumber(), lastDigitsLength);
            addBeneficiaryModel.cancelAddpayeeFlow();

        } catch (Exception e) {
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
            AddBeneficiary.logger.error(e);
        }
    }

    @AfterMethod(alwaysRun = true)
    public void afterMethod() {
        this.browserLib.closeAllBrowsers();
    }

    /**
     * 
     * <p>
     * <b> This method is used to take screen shot so every test script should
     * have it as it is used by Framework internally. </b>
     * </p>
     * 
     * @return driver
     */
    public WebDriver getDriver() {
        return this.driver;
    }
}
