/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.digital.testauto.scripts.landingpage;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.hsbc.digital.testauto.library.BrowserLib;
import com.hsbc.digital.testauto.library.FileUtil;
import com.hsbc.digital.testauto.library.ReflectionUtil;
import com.hsbc.digital.testauto.library.XMLUtil;
import com.hsbc.digital.testauto.pageobject.ExchangeRateEnquiryModel;
import com.hsbc.digital.testauto.pageobject.LoginModel;

/**
 * <p>
 * <b> This class will hold testing scripts for story 100 Exchange rate Enquiry
 * </b>
 * </p>
 * 
 * @version 1.0.0
 * @author Deepti Patil
 * 
 */

public class ExchangeRateEnquiry {
    WebDriver driver;
    BrowserLib browserLib;
    Map<String, String> envProperties;
    LoginModel loginModel;
    ExchangeRateEnquiryModel exchangeRateModel;

    public static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(ExchangeRateEnquiry.class);

    @Parameters({"browser", "entity"})
    @BeforeMethod(alwaysRun = true)
    public void beforeMethod(final String browser, final String entity, final Method method) {
        try {
            this.browserLib = new BrowserLib(browser);
            this.driver = this.browserLib.getDriver();
            this.envProperties = FileUtil.getConfigProperties(entity);
            String profile = XMLUtil.getProfileName(method, entity);
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            loginModel = (LoginModel) ReflectionUtil.getEntityPOM(entity, "LoginPage", driver);
            exchangeRateModel = (ExchangeRateEnquiryModel) ReflectionUtil.getEntityPOM(entity, "ExchangeRateEnquiry", driver);
            loginModel.login(profile, envProperties);
            loginModel.switchLanguage("English");
        } catch (Exception e) {
            ExchangeRateEnquiry.logger.error("Exception thrown at Login Contructor:", e);
        }
    }

    @Test(testName = "Verify Exchange Rate functionality", groups = {"functionaltest"})
    @Parameters("browser")
    public void exchangeRate() {
        try {
            exchangeRateModel.isExchageRateEnquiryToolDisplayed();
            exchangeRateModel.verifyCurrencyOrder();
            exchangeRateModel.verifyCurrencyDefaultValues();
            exchangeRateModel.performExchangeRateTransaction();
            exchangeRateModel.isRateApplied();
            exchangeRateModel.verifyNewTransactionButton();
        } catch (Exception e) {
            ExchangeRateEnquiry.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);

        }
    }

    @Test(testName = "Verify Exchange Rate Reverse functionality", groups = {"functionaltest"})
    @Parameters("browser")
    public void exchangeRateReverse() {
        try {
            exchangeRateModel.performExchangeRateTransaction();
            exchangeRateModel.verifyReverseCurrency();
        } catch (Exception e) {
            ExchangeRateEnquiry.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @Test(testName = "Verify Exchange Rate Reset functionality", groups = {"functionaltest"})
    @Parameters("browser")
    public void exchangeRateReset() {
        try {
            exchangeRateModel.performExchangeRateTransaction();
            exchangeRateModel.verifyResetCurrency();
        } catch (Exception e) {
            ExchangeRateEnquiry.logger.error("Exception:", e);
            Assert.fail("Exception thrown Test case failed :" + e.getMessage(), e);
        }
    }

    @AfterMethod(alwaysRun = true)
    public void afterTest() {
        this.browserLib.closeAllBrowsers();
    }

    public WebDriver getDriver() {
        return this.driver;
    }
}
